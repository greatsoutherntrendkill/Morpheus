"""FastAPI read-only backend for the generated AllAnalytics payload.

Static mode still works with site/index.html + data.js.
API mode gives a migration path away from one large JS payload:
    uvicorn api:app --reload --port 8000
Then open http://127.0.0.1:8000/
"""
from __future__ import annotations

import json
import os
import time
import pandas as pd
from pathlib import Path

import resilient_http_v430 as RH430
RH430.install_global_patch()
from threading import Lock
from concurrent.futures import ThreadPoolExecutor, as_completed

from fastapi import FastAPI, HTTPException, Body
from fastapi.responses import FileResponse, JSONResponse
import quality_contract_v4401011 as QUALITY
from fastapi.staticfiles import StaticFiles

import news as NEWS
import models
import config as C
import db
import model_registry as MR
import premium_data_v37 as PD37
import alternative_data_v40 as AD40
import news_map_v40 as NMAP40
import market_data_v41 as MD41
import market_data_v43 as MD43
import short_forecast_v45 as SF45
import macro_policy_service_v19 as MP19
import macro_event_model_v440109 as MACRO109
import macro_calendar_v440109 as MACROCAL109
import research_forecast_v46 as RF46
import research_monthly_v4403 as RM4403
import policy_meeting_evidence_v4404 as PME4404
import scenario_engine_v46 as SE46
import scenario_ai_core_v47 as SC47
import corporate_finance_v471 as CF471
import equity_universe_v48 as EU48
import valuation_dynamic_v48 as VD48
import sec_edgar_deals_v49 as SEC49
import sec_deal_analysis_v410 as SDA410
import russian_ma_v411 as RUMA411
import russian_ipo_v412 as RUIPO412
import moex_fast_v419 as MOEX419
import market_universe_v416 as MU416
import equity_forecast_v416 as EQF416
import feature_event_v434 as FE434
import dynamic_ensemble_v435 as META435
import prospective_feedback_v436 as FB436
import prospective_selection_v438 as SEL437
import event_response_v439 as EV439
import prospective_selection_v439 as SEL439
import distributional_forecast_v440 as DIST440
import distribution_feedback_v440 as DFB440
import evidence_store_v4401 as EVIDENCE4401
import evidence_readiness_v4401 as READY4401
import routing_policy_v4408 as ROUTE4408
import sealed_shadow_v44010 as SHADOW44010

try:
    import yfinance as yf
except Exception:
    yf = None

SITE = Path(__file__).parent / "site"
DATA = SITE / "data.json"

# legacy regression marker: version="4.26"
# legacy refresh-contract markers: ttl=max(30,int(os.getenv("QUOTE_REFRESH_SECONDS","30"))) ; ttl = max(30, int(os.getenv("NEWS_REFRESH_SECONDS", "30")))
app = FastAPI(title="AllAnalytics API", version="4.40.9")
# compatibility regression marker retained for historical tests: version="4.35"
_lock = Lock()
_cache = {"mtime": None, "data": None}
_news_lock = Lock()
_news_cache = {"ts": 0.0, "rows": None, "refreshing": False}
_news_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="aa-news")
_research_lock = Lock()
_research_cache = {"ts": 0.0, "result": None, "input_ts": 0.0, "input_refreshing": False, "input_status": None}
_research_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="aa-research")
_quotes_lock = Lock()
_quotes_cache = {"ts": 0.0, "rows": None}
_terminal_quote_lock = Lock()
_terminal_quote_cache = {}
TERMINAL_QUOTE_LASTGOOD = Path(__file__).parent / "runtime_cache" / "terminal_quotes_last_good_v430.json"
_chart_lock = Lock()
_chart_cache = {}
_short_forecast_lock = Lock()
_short_forecast_cache = {}
NEWS_LASTGOOD = Path(__file__).parent / "runtime_cache" / "news_last_good_v429.json"
NEWS_LASTGOOD.parent.mkdir(parents=True, exist_ok=True)
TERMINAL_QUOTE_LASTGOOD.parent.mkdir(parents=True, exist_ok=True)

import forecast_journal_v4401015 as JOURNAL15
from threading import Event, Thread
_journal_stop = Event()
_journal_last_error = None

# v4.36 prospective feedback is deliberately isolated from request latency.
_feedback_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="aa-feedback")
_feedback_lock = Lock()
_feedback_refreshing = False

def _feedback_history_loader_v436(symbol: str):
    s=str(symbol or "").upper()
    try:
        if MU416.is_ru_equity(s) or s in C.MOEX_INDICES:
            d,_diag=EQF416._resolve_ru_forecast_history(s,force=False)
            if d is not None and len(d):
                return d
    except Exception:
        pass
    rr=MD41.fetch_history(s,long_history=True)
    return rr.frame

def _run_feedback_settlement_v436(limit: int=18):
    global _feedback_refreshing
    try:
        global _journal_last_error
        result=JOURNAL15.journal().settle(_feedback_history_loader_v436,limit=limit)
        _journal_last_error=None
        return result
    except Exception as exc:
        _journal_last_error=type(exc).__name__
        return {"error":_journal_last_error}
    finally:
        with _feedback_lock:
            _feedback_refreshing=False

def _schedule_feedback_settlement_v436():
    global _feedback_refreshing
    with _feedback_lock:
        if _feedback_refreshing:
            return False
        _feedback_refreshing=True
    try:
        _feedback_executor.submit(_run_feedback_settlement_v436,18)
    except Exception:
        with _feedback_lock:_feedback_refreshing=False
        raise
    return True

def _record_feedback_v436(row: dict, origin: str):
    global _journal_last_error
    try:
        result=JOURNAL15.journal().record(row,origin=origin)
    except Exception as exc:
        result={"recorded":False,"inserted":0,"existing":0,"skipped":0,"error":type(exc).__name__,"message":"Прогноз не сохранён в журнале"}
    for f in (row.get("forecasts") or {}).values():
        if isinstance(f,dict):f["journal_receipt"]={"recorded":result.get("recorded",False),"issues":result.get("issues",[]),"error":result.get("error")}
    try:
        _schedule_feedback_settlement_v436()
    except Exception as exc:
        _journal_last_error=type(exc).__name__
    return result

def _load_terminal_quote_disk() -> dict:
    try:
        if TERMINAL_QUOTE_LASTGOOD.exists():
            j=json.loads(TERMINAL_QUOTE_LASTGOOD.read_text(encoding="utf-8"))
            return j if isinstance(j,dict) else {}
    except Exception:
        pass
    return {}

def _save_terminal_quote_disk(symbol: str, row: dict) -> None:
    if row.get("last") is None:
        return
    try:
        data=_load_terminal_quote_disk()
        data[str(symbol)]={**row,"saved_at":time.time()}
        tmp=TERMINAL_QUOTE_LASTGOOD.with_suffix(".tmp")
        tmp.write_text(json.dumps(data,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
        tmp.replace(TERMINAL_QUOTE_LASTGOOD)
    except Exception:
        pass

EXTRA_MARKET_ASSETS = MU416.EXTRA_MARKET_ASSETS

@app.middleware("http")
async def no_stale_frontend_cache(request, call_next):
    response = await call_next(request)
    path = request.url.path
    if path == "/" or path.endswith((".html", ".js", ".json")) or path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


def payload() -> dict:
    if not DATA.exists():
        raise HTTPException(503, "data.json not generated; run export_site.py")
    mtime = DATA.stat().st_mtime_ns
    with _lock:
        if _cache["mtime"] != mtime:
            _cache["data"] = QUALITY.snapshot(json.loads(DATA.read_text(encoding="utf-8")))
            _cache["mtime"] = mtime
    return _cache["data"]


def _market_asset(symbol: str) -> dict | None:
    """One canonical asset resolver shared by Markets and Technical Lab.

    v4.24.2 added US/MOEX equities to the browser only.  The terminal APIs still
    validated against the static generated payload, so every new equity returned
    404 before its market-data code could run.  Keep one server-side universe.
    """
    s=str(symbol or "").strip()
    for a in payload().get("assets", []):
        if str(a.get("symbol") or "") == s:
            return a
    su=s.upper()
    for a in MU416.EXTRA_MARKET_ASSETS:
        if str(a.get("symbol") or "").upper() == su:
            return {**a, "drivers": [], "history": [], "chart_history": []}
    if su in C.MOEX_INDICES:
        name,cat=C.MOEX_INDICES[su]
        return {"symbol":su,"name":name,"category":cat,"market":"RU","drivers":[],"history":[],"chart_history":[]}
    return None


def _supported_market_symbols() -> set[str]:
    out={str(a.get("symbol")) for a in payload().get("assets",[]) if a.get("symbol")}
    out.update(str(a.get("symbol")) for a in MU416.EXTRA_MARKET_ASSETS if a.get("symbol"))
    out.update(C.MOEX_INDICES.keys())
    return out


def _ru_terminal_daily_history(symbol: str, period: str, force: bool=False):
    """Technical-Lab OHLC through the same VPN-resilient MOEX layer as Markets."""
    s=str(symbol or "").upper()
    is_share=MU416.is_ru_equity(s)
    is_index=s in C.MOEX_INDICES
    if not (is_share or is_index):
        return pd.DataFrame(), "", []
    secid=MU416.moex_secid(s) if is_share else s
    market="shares" if is_share else "index"
    board="TQBR" if is_share else "SNDX"
    cal={"1m":80,"3m":155,"6m":300,"1y":520,"3y":1250,"5y":2050,"max":2500}.get(str(period),300)
    errors=[]
    try:
        if period in {"1m","3m"}:
            d=MOEX419.candles_recent(secid,market=market,board=board,calendar_days=cal,force=force)
            src=f"MOEX ISS · {board} · recent candles"
        else:
            d=MOEX419.candles_fast(secid,market=market,board=board,calendar_days=cal,force=force)
            src=f"MOEX ISS · {board} · resilient candles"
        if d is not None and not d.empty:
            return MD41._norm(d),src,errors
    except Exception as exc:
        errors.append(f"MOEX candles: {type(exc).__name__}: {str(exc)[:120]}")
    # Last-resort official board history. It only guarantees CLOSE, therefore
    # Technical Lab will correctly switch to line mode rather than show no chart.
    try:
        d,diag=MOEX419.history_recent(secid,market=market,board=board,calendar_days=145,force=force)
        errors.extend(list((diag or {}).get("errors") or [])[-4:])
        if d is not None and not d.empty:
            return MD41._norm(d),(diag or {}).get("source") or f"MOEX ISS · {board} · board history",errors
    except Exception as exc:
        errors.append(f"MOEX board history: {type(exc).__name__}: {str(exc)[:120]}")
    return pd.DataFrame(),"",errors


@app.get("/api/health")
def health():
    d = payload()
    return {"ok": True, "generated_at": d.get("generated_at"), "assets": len(d.get("assets", []))}


@app.get("/api/assets")
def assets(category: str | None = None):
    rows = payload().get("assets", [])
    if category:
        rows = [a for a in rows if a.get("category") == category]
    # Summary endpoint intentionally avoids heavy chart history.
    return [{k: a.get(k) for k in ("symbol", "name", "category", "last", "chg1d",
                                    "regime", "scenario", "model_quality", "model_horizons")}
            for a in rows]


@app.get("/api/assets/{symbol:path}")
def asset(symbol: str):
    for a in payload().get("assets", []):
        if a.get("symbol") == symbol:
            return a
    raise HTTPException(404, "asset not found")



def _snapshot_quotes() -> list[dict]:
    rows = []
    seen = set()
    base = payload()
    for a in base.get("assets", []):
        sym = a.get("symbol")
        if not sym:
            continue
        seen.add(sym)
        rows.append({
            "symbol": sym,
            "name": a.get("name"),
            "category": a.get("category"),
            "last": a.get("last"),
            "chg1d": a.get("chg1d"),
            "as_of": base.get("generated_at"),
            "source": "snapshot",
        })
    for a in EXTRA_MARKET_ASSETS:
        sym = a.get("symbol")
        if not sym or sym in seen:
            continue
        rows.append({
            "symbol": sym,
            "name": a.get("name"),
            "category": a.get("category"),
            "last": None,
            "chg1d": None,
            "as_of": base.get("generated_at"),
            "source": "snapshot",
        })
    return rows


def _extract_yf_frame(raw, symbol: str):
    if raw is None or getattr(raw, "empty", True):
        return None
    cols = raw.columns
    try:
        if isinstance(cols, pd.MultiIndex):
            lv0 = list(cols.get_level_values(0))
            lv1 = list(cols.get_level_values(1))
            if symbol in lv0:
                return raw[symbol]
            if symbol in lv1:
                return raw.xs(symbol, axis=1, level=1)
        return raw
    except Exception:
        return None


def _yf_live_quotes(snapshot_rows: list[dict]) -> dict[str, dict]:
    if yf is None:
        return {}
    symbols = [r["symbol"] for r in snapshot_rows if r.get("symbol") in C.YF_PRICES]
    if not symbols:
        return {}
    try:
        raw = yf.download(
            tickers=" ".join(symbols),
            period="5d",
            interval="5m",
            group_by="ticker",
            auto_adjust=True,
            threads=True,
            progress=False,
            prepost=False,
        )
    except Exception:
        return {}

    out = {}
    for sym in symbols:
        frame = _extract_yf_frame(raw, sym)
        if frame is None or getattr(frame, "empty", True):
            continue
        close_col = None
        for candidate in ("Close", "close"):
            if candidate in frame.columns:
                close_col = candidate
                break
        if close_col is None:
            continue
        s = pd.to_numeric(frame[close_col], errors="coerce").dropna()
        if s.empty:
            continue
        # Collapse to the last quote of every calendar trading day.
        try:
            idx = pd.DatetimeIndex(s.index)
            days = pd.Series(s.values, index=idx).groupby(idx.date).last()
        except Exception:
            continue
        last = float(days.iloc[-1])
        if len(days) >= 2 and float(days.iloc[-2]) > 0:
            chg = (last / float(days.iloc[-2]) - 1.0) * 100.0
        else:
            chg = None
        try:
            as_of = pd.Timestamp(s.index[-1]).isoformat()
        except Exception:
            as_of = None
        out[sym] = {
            "symbol": sym,
            "last": round(last, 6),
            "chg1d": None if chg is None else round(chg, 3),
            "as_of": as_of,
            "source": "yahoo-5m",
        }
    # Derived CNY/RUB.
    rub = out.get("RUB=X")
    cny = out.get("CNY=X")
    if rub and cny and cny.get("last"):
        last = rub["last"] / cny["last"]
        # Approximate cross daily move from legs.
        rr = (rub.get("chg1d") or 0) / 100.0
        cr = (cny.get("chg1d") or 0) / 100.0
        chg = ((1 + rr) / (1 + cr) - 1) * 100.0
        out["CNYRUB"] = {
            "symbol": "CNYRUB",
            "last": round(last, 6),
            "chg1d": round(chg, 3),
            "as_of": min(str(rub.get("as_of") or ""), str(cny.get("as_of") or "")) or None,
            "source": "derived-5m",
        }
    return out


@app.get("/api/quotes/live")
def live_quotes(force: int = 0):
    """Отказоустойчивые котировки + короткая история для графиков.

    v4.1 больше не зависит от одного bulk-запроса yfinance. Каждый инструмент
    обновляется независимоим каскадом источников. При полном сетевом сбое
    сохраняется последний пригодный снимок, а не удаляются цены.
    """
    try:
        ttl=max(5,int(os.getenv("QUOTE_REFRESH_SECONDS","12")))
    except ValueError:
        ttl=12
    now=time.time()
    with _quotes_lock:
        if force or _quotes_cache["rows"] is None or now-_quotes_cache["ts"]>=ttl:
            snap=_snapshot_quotes()
            symbols=[r.get("symbol") for r in snap if r.get("symbol")]
            live_rows=MD41.fetch_all(symbols,workers=int(os.getenv("QUOTE_WORKERS","8")))
            live={r.get("symbol"):r for r in live_rows}
            merged=[]
            live_count=0
            fallback_count=0
            failed=[]
            for row in snap:
                sym=row.get("symbol")
                lr=live.get(sym) or {}
                if lr.get("last") is not None and MD41.plausible(sym,lr.get("last")):
                    r={**row,**lr}
                    live_count+=1
                else:
                    r=dict(row)
                    # Старый снимок используется только как последний резерв и
                    # только если цена проходит грубую проверку диапазона.
                    if MD41.plausible(sym,r.get("last")):
                        r["source"]="последний снимок"
                        r["errors"]=lr.get("errors") or []
                        fallback_count+=1
                    else:
                        r["last"]=None
                        r["chg1d"]=None
                        r["source"]=None
                        r["errors"]=lr.get("errors") or ["нет пригодной котировки"]
                        failed.append(sym)
                merged.append(r)
            _quotes_cache["rows"]=merged
            _quotes_cache["ts"]=now
            _quotes_cache["diag"]={
                "live":live_count,"snapshot_fallback":fallback_count,
                "failed":failed,"total":len(symbols),
            }
        return {
            "version":"4.1",
            "refresh_seconds":ttl,
            "server_time":time.strftime("%Y-%m-%dT%H:%M:%S"),
            "summary":_quotes_cache.get("diag") or {},
            "quotes":list(_quotes_cache["rows"] or []),
        }


@app.get("/api/terminal/quote")
def terminal_quote(symbol: str, force: int = 0):
    """Low-latency quote for one visible instrument.

    v4.30 keeps this path independent from the large market batch and persists a
    last-good value.  A temporary provider/VPN failure therefore never turns a
    previously known price into a blank card.
    """
    a=_market_asset(symbol)
    if a is None:
        raise HTTPException(404,"asset not found")
    now=time.time(); ttl=max(3,int(os.getenv("TERMINAL_QUOTE_CACHE_SECONDS","5")))
    with _terminal_quote_lock:
        cached=_terminal_quote_cache.get(symbol)
        if not force and cached and now-float(cached.get("_ts") or 0)<ttl:
            return {k:v for k,v in cached.items() if k!="_ts"}
    s=str(symbol or "").upper(); row=None
    try:
        if MU416.is_ru_equity(s):
            sec=MU416.moex_secid(s)
            x=MOEX419.get_snapshot([sec],market="shares",force=bool(force)).get(sec) or {}
            if x.get("last") is not None:
                row={"version":"4.30","symbol":symbol,"last":x.get("last"),"chg1d":x.get("chg1d"),"as_of":x.get("time"),"source":x.get("source"),"stale":bool(x.get("stale"))}
        elif s in C.MOEX_INDICES:
            x=MOEX419.get_snapshot([s],market="index",force=bool(force)).get(s) or {}
            if x.get("last") is not None:
                row={"version":"4.30","symbol":symbol,"last":x.get("last"),"chg1d":x.get("chg1d"),"as_of":x.get("time"),"source":x.get("source"),"stale":bool(x.get("stale"))}
        if row is None:
            q=MD41.fetch_quote(symbol)
            if q.get("last") is not None:
                row={"version":"4.30",**q,"stale":False}
    except Exception:
        row=None
    if row and row.get("last") is not None:
        row["server_time"]=time.strftime("%Y-%m-%dT%H:%M:%S")
        with _terminal_quote_lock:
            _terminal_quote_cache[symbol]={**row,"_ts":now}
        _save_terminal_quote_disk(symbol,row)
        return row
    # Persistent last-good is preferable to an empty UI.  It is explicitly marked stale.
    disk=_load_terminal_quote_disk().get(str(symbol)) or {}
    if disk.get("last") is not None:
        return {**disk,"version":"4.30","symbol":symbol,"stale":True,"source":f"{disk.get('source') or 'last-good'} · резерв","server_time":time.strftime("%Y-%m-%dT%H:%M:%S")}
    snap=next((x for x in _snapshot_quotes() if x.get("symbol")==symbol),None) or {}
    if snap.get("last") is not None:
        return {"version":"4.30",**snap,"stale":True,"source":"встроенный последний снимок","server_time":time.strftime("%Y-%m-%dT%H:%M:%S")}
    raise HTTPException(503,detail={"message":"quote unavailable","symbol":symbol})


@app.get("/api/moex/live")
def moex_live(force: int = 0):
    """Fast dedicated Russian market endpoint: TQBR shares + SNDX indices.

    It intentionally bypasses the rest of the global quote universe, so the
    Russian cards can become usable even when another provider is slow.
    """
    data=MOEX419.refresh_live(force=bool(force))
    rows=[]
    for a in MU416.EXTRA_MARKET_ASSETS:
        if a.get("market")!="RU":
            continue
        sec=MU416.moex_secid(a.get("symbol"))
        x=(data.get("shares") or {}).get(sec) or {}
        rows.append({
            "symbol":a.get("symbol"),"name":a.get("name"),"category":a.get("category"),
            "last":x.get("last"),"chg1d":x.get("chg1d"),"as_of":x.get("time"),
            "source":x.get("source"),"stale":bool(x.get("stale")),
        })
    for sym,(name,cat) in C.MOEX_INDICES.items():
        x=(data.get("indices") or {}).get(sym) or {}
        rows.append({
            "symbol":sym,"name":name,"category":cat,"last":x.get("last"),
            "chg1d":x.get("chg1d"),"as_of":x.get("time"),"source":x.get("source"),
            "stale":bool(x.get("stale")),
        })
    ok=sum(1 for r in rows if r.get("last") is not None)
    return {"version":"4.20","count":len(rows),"available":ok,"rows":rows,
            "status":MOEX419.status(),"server_time":time.strftime("%Y-%m-%dT%H:%M:%S")}


@app.get("/api/moex/status")
def moex_status():
    return MOEX419.status()


@app.get("/api/quotes/status")
def quote_status():
    """Безопасная диагностика: источники и ошибки без секретов."""
    data=live_quotes(force=0)
    return {
        "version":"4.1",
        "summary":data.get("summary"),
        "sources":{
            r.get("symbol"):{
                "source":r.get("source"),
                "as_of":r.get("as_of"),
                "errors":(r.get("errors") or [])[-4:],
            } for r in data.get("quotes",[])
        }
    }


@app.get("/api/markets/equity-forecast")
def equity_forecast(symbol: str, horizons: str = "1,5,10,20", force: int = 0):
    hs=[]
    for x in str(horizons or "10").split(","):
        try:
            v=int(x.strip())
            if v in (1,3,5,10,20,30,60): hs.append(v)
        except Exception:
            pass
    if not (MU416.is_us_equity(symbol) or MU416.is_ru_equity(symbol) or symbol in C.MOEX_INDICES):
        raise HTTPException(400,"forecast endpoint is reserved for supported market universe")
    try:
        row=EQF416.forecast_fast(symbol,tuple(hs or [10]),force=bool(force))
        feedback=_record_feedback_v436(row,"/api/markets/equity-forecast")
        return {"version":"4.36","prospective_feedback":feedback,**row}
    except Exception as exc:
        raise HTTPException(503,f"equity forecast unavailable: {type(exc).__name__}")


@app.get("/api/markets/forecast")
def market_forecast(symbol: str, horizon: int = 10, force: int = 0):
    """Unified market forecast for the Markets detail panel.

    30m-4h stays on /api/forecast/short. This endpoint covers 1-60 trading days
    for every asset present in the site market universe. Longer horizons request
    long history lazily only after the user chooses them.
    """
    if _market_asset(symbol) is None:
        raise HTTPException(404,"asset not found")
    try:
        h=int(horizon)
    except Exception:
        h=10
    if h not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"horizon must be 1, 3, 5, 10, 20, 30 or 60 trading days")
    try:
        row=EQF416.forecast_fast(symbol,(h,),force=bool(force))
        feedback=_record_feedback_v436(row,"/api/markets/forecast")
        return {"version":"4.36","prospective_feedback":feedback,**row}
    except Exception as exc:
        raise HTTPException(503,f"market forecast unavailable: {type(exc).__name__}")


@app.get("/api/markets/equity-forecast/status")
def equity_forecast_status(symbol: str):
    """Forecast diagnostics without changing live prices or any other site data."""
    s=str(symbol or "").upper()
    if not (MU416.is_us_equity(s) or MU416.is_ru_equity(s) or s in C.MOEX_INDICES):
        raise HTTPException(400,"unsupported symbol")
    row=EQF416.forecast_fast(s,(10,),force=False)
    return {
        "version":"4.34", "symbol":s, "status":row.get("status"),
        "source":row.get("source"), "observations":row.get("observations"),
        "model":row.get("model"), "errors":row.get("errors") or [],
        "diagnostics":row.get("diagnostics") or {},
    }


@app.get("/api/markets/equity-forecasts")
def equity_forecasts(symbols: str, horizon: int = 10, force: int = 0):
    syms=[]
    for raw in str(symbols or "").split(","):
        s=raw.strip().upper()
        if s and (MU416.is_us_equity(s) or MU416.is_ru_equity(s) or s in C.MOEX_INDICES) and s not in syms:
            syms.append(s)
    syms=syms[:32]
    h=int(horizon) if int(horizon) in (1,3,5,10,20,30,60) else 10
    out=[]
    workers=max(1,min(2,len(syms) or 1))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        fut={ex.submit(EQF416.forecast_fast,s,(h,),bool(force)):s for s in syms}
        for f in as_completed(fut):
            s=fut[f]
            try:
                row=dict(f.result()); _record_feedback_v436(row,"/api/markets/equity-forecasts"); row.pop("history",None); out.append(row)
            except Exception as exc: out.append({"symbol":s,"status":"unavailable","errors":[type(exc).__name__]})
    by={r.get("symbol"):r for r in out}
    return {"version":"4.36","horizon":h,"count":len(syms),"rows":[by.get(s,{"symbol":s,"status":"unavailable"}) for s in syms]}


@app.post("/api/markets/equity-forecast/from-history")
def equity_forecast_from_history(body: dict = Body(...)):
    """Model fallback when the browser can reach MOEX but local Python cannot.

    The browser supplies official MOEX candles fetched via JSONP; the model still
    runs locally through the same AllAnalytics models.py pipeline.
    """
    symbol=str(body.get("symbol") or "").upper()
    if not (MU416.is_ru_equity(symbol) or symbol in C.MOEX_INDICES):
        raise HTTPException(400,"only supported Russian market instruments")
    rows=list(body.get("history") or [])[-3000:]
    hs=[]
    for x in body.get("horizons") or [1,5,10,20,30,60]:
        try:
            v=int(x)
            if v in (1,3,5,10,20,30,60) and v not in hs: hs.append(v)
        except Exception:
            pass
    if len(rows)<61:
        raise HTTPException(400,"not enough history: need at least 61 closes")
    d=pd.DataFrame(rows)
    # browser fallback uses t/o/h/l/c; accept date/open/high/low/close too
    ren={"t":"date","o":"open","h":"high","l":"low","c":"close"}
    d=d.rename(columns={k:v for k,v in ren.items() if k in d.columns})
    if "date" not in d.columns or "close" not in d.columns:
        raise HTTPException(400,"history requires date and close")
    d["date"]=pd.to_datetime(d["date"],errors="coerce")
    for c in ("open","high","low","close"):
        if c in d.columns: d[c]=pd.to_numeric(d[c],errors="coerce")
    d=d.dropna(subset=["date","close"]).sort_values("date")
    if len(d)<61: raise HTTPException(400,"not enough valid history: need at least 61 closes")
    d,data_audit=EQF416.DATA13.prepare(d,symbol,"MOEX browser history")
    if len(d)<61: raise HTTPException(400,"Недостаточно завершённых и проверенных свечей")
    close=pd.Series(d["close"].astype(float).values,index=pd.to_datetime(d["date"]))
    shaped={}
    for h in (hs or [10]):
        r=EQF416.META435.forecast_horizon(close,symbol=symbol,horizon=h,fast=True) if len(close)>=390 else None
        shaped[str(h)]=EQF416._shape_meta_result(r,h) if r else EQF416._scenario_shape(close,h)
        shaped[str(h)]=EQF416.DATA13.decorate(QUALITY.forecast(MACRO109.apply(shaped[str(h)],close,symbol,h)),data_audit,symbol,h,"browser-fast")
    tail=[]
    for r in d.tail(190).itertuples():
        cl=float(r.close); op=float(getattr(r,"open",cl) if pd.notna(getattr(r,"open",cl)) else cl); hi=float(getattr(r,"high",cl) if pd.notna(getattr(r,"high",cl)) else cl); lo=float(getattr(r,"low",cl) if pd.notna(getattr(r,"low",cl)) else cl)
        tail.append({"t":str(pd.Timestamp(r.date).date()),"o":op,"h":hi,"l":lo,"c":cl})
    out={"version":"4.36","symbol":symbol,"status":"ok","source":"MOEX ISS browser history → AllAnalytics v4.40 Distributional Forecast",
         "as_of":str(pd.Timestamp(d.iloc[-1]["date"]).date()),"observations":int(len(d)),
         "forecasts":shaped,"stats":EQF416._market_stats(d),"history":tail,
         "errors":[],"model":"AllAnalytics v4.40 Distributional Forecast · guarded direction + calibrated range"}
    out["prospective_feedback"]=_record_feedback_v436(out,"/api/markets/equity-forecast/from-history")
    return out









@app.get("/api/models/features-v434")
def model_features_v434(symbol: str):
    """Current cross-sectional, event and drift feature snapshot for one asset."""
    if _market_asset(symbol) is None:
        raise HTTPException(404,"asset not found")
    try:
        row=EQF416.forecast_fast(symbol,(10,),force=False)
        hist=row.get("history") or []
        close=None
        if hist:
            d=pd.DataFrame(hist)
            if "t" in d.columns and "c" in d.columns:
                close=pd.Series(pd.to_numeric(d["c"],errors="coerce").values,index=pd.to_datetime(d["t"],errors="coerce")).dropna()
        ctx=FE434.build_context(symbol,own_close=close)
        return {"version":"4.34",**ctx}
    except Exception as exc:
        raise HTTPException(503,f"feature context unavailable: {type(exc).__name__}")


@app.get("/api/models/quality-v438")
def model_quality_v438(symbol: str, horizon: int = 10, force: int = 0):
    """v4.38 asset-class specialist diagnostics + prospective guard."""
    try:
        h=int(horizon)
    except Exception:
        h=10
    if h not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:
        raise HTTPException(404,"asset not found")
    row=EQF416.forecast_fast(symbol,(h,),force=bool(force))
    feedback=_record_feedback_v436(row,"/api/models/quality-v438")
    f=(row.get("forecasts") or {}).get(str(h)) or {}
    try:
        selection=SEL437.selection_report(window_days=180,symbol=symbol,horizon=h)
    except Exception as exc:
        selection={"version":SEL437.VERSION,"error":type(exc).__name__,"automatic_champion_promotion":False}
    return {
        "version":"4.38","symbol":symbol,"horizon":h,"status":row.get("status"),
        "model":row.get("model"),"source":row.get("source"),"as_of":row.get("as_of"),
        "forecast":f,"asset_specialist":f.get("asset_specialist") or {},
        "specialist_gate":f.get("specialist_gate") or {},"specialist_weight_status":f.get("specialist_weight_status"),
        "dynamic_weights":f.get("dynamic_weights") or {},"meta_learning":f.get("meta_learning") or {},
        "reliability":f.get("reliability") or {},"threshold_selection":f.get("threshold_selection") or {},
        "prospective_feedback":feedback,"prospective_status":FB436.status(),
        "selection_guard":selection,"context_gate":f.get("prospective_selection_guard") or {},
        "diagnostics":row.get("diagnostics") or {},"errors":row.get("errors") or []
    }


@app.get("/api/models/specialist-v438")
def model_specialist_v438(symbol: str, horizon: int = 10, force: int = 0):
    """Inspect the routed asset-class specialist without hiding its guard status."""
    out=model_quality_v438(symbol,horizon,force)
    return {"version":"4.38","symbol":symbol,"horizon":int(horizon),
            "specialist":out.get("asset_specialist") or {},"gate":out.get("specialist_gate") or {},
            "weight_status":out.get("specialist_weight_status"),"automatic_promotion":False}


@app.get("/api/models/selection-v438")
def model_selection_v438(window_days: int = 180, horizon: int | None = None, symbol: str | None = None):
    if horizon is not None and int(horizon) not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    try:
        return SEL437.selection_report(window_days=max(30,min(int(window_days),3650)),symbol=symbol,horizon=horizon)
    except Exception as exc:
        raise HTTPException(503,f"selection guard unavailable: {type(exc).__name__}")


@app.get("/api/models/specialist-gate-v438")
def specialist_gate_v438(symbol: str, horizon: int = 10, window_days: int = 180):
    if int(horizon) not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:
        raise HTTPException(404,"asset not found")
    row=EQF416.forecast_fast(symbol,(int(horizon),),force=False)
    f=(row.get("forecasts") or {}).get(str(int(horizon))) or {}
    sp=f.get("asset_specialist") or {}
    return SEL437.specialist_gate(symbol,int(horizon),window_days=max(30,min(int(window_days),3650)),max_live_weight=float(sp.get("max_live_weight") or .12))


@app.get("/api/models/promotion-v438/status")
def promotion_status_v438(limit: int = 50):
    return SEL437.review_status(limit=max(1,min(int(limit),200)))


@app.post("/api/models/promotion-v438/review")
def promotion_review_v438(body: dict = Body(...)):
    candidate=str((body or {}).get("candidate") or "").strip()
    decision=str((body or {}).get("decision") or "").strip().lower()
    note=str((body or {}).get("note") or "")
    symbol=str((body or {}).get("symbol") or "").strip().upper() or None
    horizon=(body or {}).get("horizon")
    window_days=int((body or {}).get("window_days") or 180)
    if candidate not in {"dynamic_ensemble_v437","vol_regime","context_blend","asset_specialist"}:
        raise HTTPException(400,"unsupported candidate")
    if decision not in {"approve","reject","hold"}:
        raise HTTPException(400,"decision must be approve, reject or hold")
    if horizon is not None:
        horizon=int(horizon)
        if horizon not in (1,3,5,10,20,30,60):
            raise HTTPException(400,"unsupported horizon")
    try:
        return SEL437.review(candidate,decision,note,window_days=max(30,min(window_days,3650)),symbol=symbol,horizon=horizon)
    except ValueError as exc:
        raise HTTPException(409,str(exc))
    except Exception as exc:
        raise HTTPException(503,f"promotion review unavailable: {type(exc).__name__}")



@app.get("/api/models/quality-v440")
def model_quality_v440(symbol: str, horizon: int = 10, force: int = 0):
    """v4.40 directional diagnostics plus calibrated return distribution."""
    try:h=int(horizon)
    except Exception:h=10
    if h not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:raise HTTPException(404,"asset not found")
    row=EQF416.forecast_fast(symbol,(h,),force=bool(force));feedback=_record_feedback_v436(row,"/api/models/quality-v440")
    f=(row.get("forecasts") or {}).get(str(h)) or {}
    return {"version":"4.40","symbol":symbol,"horizon":h,"status":row.get("status"),"model":row.get("model"),"source":row.get("source"),"as_of":row.get("as_of"),
            "forecast":f,"distribution_forecast":f.get("distribution_forecast") or {},"distribution_version":f.get("distribution_version"),
            "event_response":f.get("event_response") or {},"asset_specialist":f.get("asset_specialist") or {},
            "dynamic_weights":f.get("dynamic_weights") or {},"meta_learning":f.get("meta_learning") or {},"reliability":f.get("reliability") or {},
            "prospective_feedback":feedback,"distribution_feedback_status":DFB440.status(),"diagnostics":row.get("diagnostics") or {},"errors":row.get("errors") or []}


@app.get("/api/models/distribution-v440")
def model_distribution_v440(symbol: str, horizon: int = 10, force: int = 0, full: int = 0):
    try:h=int(horizon)
    except Exception:h=10
    if h not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:raise HTTPException(404,"asset not found")
    if bool(full):
        row=EQF416.forecast(symbol,(h,),force=bool(force));_record_feedback_v436(row,"/api/models/distribution-v440/full")
        f=(row.get("forecasts") or {}).get(str(h)) or {};dist=f.get("distribution_forecast") or {}
    else:
        out=model_quality_v440(symbol,h,force);dist=out.get("distribution_forecast") or {}
    return {"version":"4.40","symbol":symbol,"horizon":h,"distribution":dist,
            "compute_profile":dist.get("compute_profile"),"changes_directional_probability":False,"automatic_promotion":False}


@app.get("/api/models/distribution-score-v440")
def model_distribution_score_v440(window_days: int = 365, horizon: int | None = None, symbol: str | None = None):
    if horizon is not None and int(horizon) not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    try:return DFB440.scorecard(window_days=max(30,min(int(window_days),3650)),symbol=symbol,horizon=horizon)
    except Exception as exc:raise HTTPException(503,f"distribution score unavailable: {type(exc).__name__}")


@app.get("/api/models/distribution-status-v440")
def model_distribution_status_v440():
    return DFB440.status()


@app.get("/api/models/evidence-v4401/status")
def evidence_status_v4401():
    """Persistent prospective-evidence store health; no model weights are changed."""
    return {
        "version":"4.40.1",
        "store":EVIDENCE4401.store_status(),
        "directional":FB436.status(),
        "distribution":DFB440.status(),
        "automatic_model_changes":False,
    }


@app.get("/api/models/evidence-v4401/readiness")
def evidence_readiness_v4401():
    """Data-volume/context gates for the future v4.41 regime/event review."""
    try:
        return READY4401.readiness()
    except Exception as exc:
        raise HTTPException(503,f"evidence readiness unavailable: {type(exc).__name__}")


@app.get("/api/models/quality-v439")
def model_quality_v439(symbol: str, horizon: int = 10, force: int = 0):
    """v4.39 event-response diagnostics plus all v4.38 specialist diagnostics."""
    try:h=int(horizon)
    except Exception:h=10
    if h not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:raise HTTPException(404,"asset not found")
    row=EQF416.forecast_fast(symbol,(h,),force=bool(force));feedback=_record_feedback_v436(row,"/api/models/quality-v439")
    f=(row.get("forecasts") or {}).get(str(h)) or {}
    try:selection=SEL439.selection_report(window_days=365,symbol=symbol,horizon=h)
    except Exception as exc:selection={"version":SEL439.VERSION,"error":type(exc).__name__,"automatic_champion_promotion":False}
    return {"version":"4.39","symbol":symbol,"horizon":h,"status":row.get("status"),"model":row.get("model"),"source":row.get("source"),"as_of":row.get("as_of"),
            "forecast":f,"event_response":f.get("event_response") or {},"event_gate":f.get("event_gate") or {},"event_weight_status":f.get("event_weight_status"),
            "asset_specialist":f.get("asset_specialist") or {},"specialist_gate":f.get("specialist_gate") or {},"specialist_weight_status":f.get("specialist_weight_status"),
            "dynamic_weights":f.get("dynamic_weights") or {},"meta_learning":f.get("meta_learning") or {},"reliability":f.get("reliability") or {},
            "threshold_selection":f.get("threshold_selection") or {},"prospective_feedback":feedback,"prospective_status":FB436.status(),"selection_guard":selection,
            "diagnostics":row.get("diagnostics") or {},"errors":row.get("errors") or []}


@app.get("/api/models/event-response-v439")
def model_event_response_v439(symbol: str, horizon: int = 10, force: int = 0):
    out=model_quality_v439(symbol,horizon,force)
    return {"version":"4.39","symbol":symbol,"horizon":int(horizon),"event_response":out.get("event_response") or {},
            "gate":out.get("event_gate") or {},"weight_status":out.get("event_weight_status"),"automatic_promotion":False}


@app.get("/api/models/event-history-v439")
def model_event_history_v439(symbol: str, horizon: int = 10):
    if int(horizon) not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:raise HTTPException(404,"asset not found")
    row=EQF416.forecast_fast(symbol,(int(horizon),),force=False);hist=row.get("history") or []
    d=pd.DataFrame(hist)
    close=pd.Series(dtype=float)
    if not d.empty and "t" in d.columns and "c" in d.columns:
        close=pd.Series(pd.to_numeric(d["c"],errors="coerce").values,index=pd.to_datetime(d["t"],errors="coerce")).dropna()
    archive=EV439.sync_event_archive(persist=True)
    types=sorted({str(x.get("type")) for x in archive if x.get("type")})
    stats={et:EV439.historical_event_responses(close,symbol,et,int(horizon),as_of=row.get("as_of"),events=archive) for et in types}
    return {"version":"4.39","symbol":symbol,"horizon":int(horizon),"as_of":row.get("as_of"),"archive_events":len(archive),"event_types":types,"responses":stats}


@app.get("/api/models/selection-v439")
def model_selection_v439(window_days: int = 365, horizon: int | None = None, symbol: str | None = None):
    if horizon is not None and int(horizon) not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    try:return SEL439.selection_report(window_days=max(30,min(int(window_days),3650)),symbol=symbol,horizon=horizon)
    except Exception as exc:raise HTTPException(503,f"selection guard unavailable: {type(exc).__name__}")


@app.get("/api/models/event-gate-v439")
def event_gate_v439(symbol: str, horizon: int = 10, window_days: int = 365):
    if int(horizon) not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:raise HTTPException(404,"asset not found")
    row=EQF416.forecast_fast(symbol,(int(horizon),),force=False);f=(row.get("forecasts") or {}).get(str(int(horizon))) or {};ev=f.get("event_response") or {}
    return SEL439.event_gate(symbol,int(horizon),window_days=max(30,min(int(window_days),3650)),max_live_weight=float(ev.get("max_live_weight") or .10))


@app.get("/api/models/promotion-v439/status")
def promotion_status_v439(limit: int = 50):
    return SEL439.review_status(limit=max(1,min(int(limit),200)))


@app.post("/api/models/promotion-v439/review")
def promotion_review_v439(body: dict = Body(...)):
    candidate=str((body or {}).get("candidate") or "").strip();decision=str((body or {}).get("decision") or "").strip().lower();note=str((body or {}).get("note") or "")
    symbol=str((body or {}).get("symbol") or "").strip().upper() or None;horizon=(body or {}).get("horizon");window_days=int((body or {}).get("window_days") or 365)
    if candidate not in {"dynamic_ensemble_v437","vol_regime","context_blend","asset_specialist","event_response"}:raise HTTPException(400,"unsupported candidate")
    if decision not in {"approve","reject","hold"}:raise HTTPException(400,"decision must be approve, reject or hold")
    if horizon is not None:
        horizon=int(horizon)
        if horizon not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    try:return SEL439.review(candidate,decision,note,window_days=max(30,min(window_days,3650)),symbol=symbol,horizon=horizon)
    except ValueError as exc:raise HTTPException(409,str(exc))
    except Exception as exc:raise HTTPException(503,f"promotion review unavailable: {type(exc).__name__}")

@app.get("/api/models/quality-v437")
def model_quality_v437(symbol: str, horizon: int = 10, force: int = 0):
    """v4.37 forecast diagnostics + prospective selection/promotion guard."""
    try:
        h=int(horizon)
    except Exception:
        h=10
    if h not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:
        raise HTTPException(404,"asset not found")
    row=EQF416.forecast_fast(symbol,(h,),force=bool(force))
    feedback=_record_feedback_v436(row,"/api/models/quality-v437")
    f=(row.get("forecasts") or {}).get(str(h)) or {}
    try:
        selection=SEL437.selection_report(window_days=180,symbol=symbol,horizon=h)
    except Exception as exc:
        selection={"version":SEL437.VERSION,"error":type(exc).__name__,"automatic_champion_promotion":False}
    return {
        "version":"4.37","symbol":symbol,"horizon":h,"status":row.get("status"),
        "model":row.get("model"),"source":row.get("source"),"as_of":row.get("as_of"),
        "forecast":f,"dynamic_weights":f.get("dynamic_weights") or {},
        "meta_learning":f.get("meta_learning") or {},"reliability":f.get("reliability") or {},
        "threshold_selection":f.get("threshold_selection") or {},
        "prospective_feedback":feedback,"prospective_status":FB436.status(),
        "selection_guard":selection,"context_gate":f.get("prospective_selection_guard") or {},
        "diagnostics":row.get("diagnostics") or {},"errors":row.get("errors") or []
    }

@app.get("/api/models/quality-v436")
def model_quality_v436(symbol: str, horizon: int = 10, force: int = 0):
    """Compatibility alias; v4.37 adds prospective selection guard."""
    return model_quality_v437(symbol,horizon,force)

@app.get("/api/models/quality-v435")
def model_quality_v435(symbol: str, horizon: int = 10, force: int = 0):
    """Compatibility alias; v4.36 adds prospective monitoring."""
    return model_quality_v436(symbol,horizon,force)

@app.get("/api/models/quality-v434")
def model_quality_v434(symbol: str, horizon: int = 10, force: int = 0):
    return model_quality_v436(symbol,horizon,force)

@app.get("/api/models/quality-v433")
def model_quality_v433_compat(symbol: str, horizon: int = 10, force: int = 0):
    return model_quality_v436(symbol,horizon,force)

@app.get("/api/models/routing-v4408/status")
def routing_status_v4408(symbol: str | None = None, horizon: int | None = None):
    if horizon is not None and int(horizon) not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    return ROUTE4408.status(symbol=(str(symbol).upper() if symbol else None),horizon=horizon)


@app.get("/api/models/shadow-v44010/status")
def shadow_status_v44010():
    return SHADOW44010.audit()


@app.get("/api/models/prospective-v436/status")
def prospective_status_v436():
    """Prospective ledger health. Monitoring only; it never promotes a model."""
    return FB436.status()


@app.get("/api/models/prospective-v436/ledger")
def prospective_ledger_v436(limit: int = 100, symbol: str | None = None, horizon: int | None = None, settled_only: int = 0):
    if horizon is not None and int(horizon) not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    return {"version":"4.36","rows":FB436.LEDGER.rows(limit=limit,symbol=symbol,horizon=horizon,settled_only=bool(settled_only))}


@app.get("/api/models/prospective-v436/leaderboard")
def prospective_leaderboard_v436(window_days: int = 90, horizon: int | None = None, symbol: str | None = None):
    if horizon is not None and int(horizon) not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    return FB436.leaderboard(window_days=window_days,horizon=horizon,symbol=symbol)


@app.get("/api/models/prospective-v436/errors")
def prospective_errors_v436(limit: int = 250, horizon: int | None = None, symbol: str | None = None):
    return FB436.errors(limit=limit,horizon=horizon,symbol=symbol)


@app.post("/api/models/prospective-v436/settle")
def prospective_settle_v436(limit: int = 24):
    """Manual diagnostic settlement pass; normal forecast requests schedule this in background."""
    try:
        return _run_feedback_settlement_v436(max(1,min(int(limit),100)))
    except Exception as exc:
        raise HTTPException(503,f"prospective settlement unavailable: {type(exc).__name__}")


@app.get("/api/models/selection-v437")
def model_selection_v437(window_days: int = 180, horizon: int | None = None, symbol: str | None = None):
    """Paired prospective comparison with bootstrap confidence intervals and stability gates."""
    if horizon is not None and int(horizon) not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    try:
        return SEL437.selection_report(window_days=max(30,min(int(window_days),3650)),symbol=symbol,horizon=horizon)
    except Exception as exc:
        raise HTTPException(503,f"selection guard unavailable: {type(exc).__name__}")


@app.get("/api/models/context-gate-v437")
def context_gate_v437(symbol: str, horizon: int = 10, window_days: int = 180):
    if int(horizon) not in (1,3,5,10,20,30,60):
        raise HTTPException(400,"unsupported horizon")
    if _market_asset(symbol) is None:
        raise HTTPException(404,"asset not found")
    return SEL437.context_gate(symbol,int(horizon),window_days=max(30,min(int(window_days),3650)))


@app.get("/api/models/promotion-v437/status")
def promotion_status_v437(limit: int = 50):
    return SEL437.review_status(limit=max(1,min(int(limit),200)))


@app.post("/api/models/promotion-v437/review")
def promotion_review_v437(body: dict = Body(...)):
    candidate=str((body or {}).get("candidate") or "").strip()
    decision=str((body or {}).get("decision") or "").strip().lower()
    note=str((body or {}).get("note") or "")
    symbol=str((body or {}).get("symbol") or "").strip().upper() or None
    horizon=(body or {}).get("horizon")
    window_days=int((body or {}).get("window_days") or 180)
    if candidate not in {"dynamic_ensemble_v437","vol_regime","context_blend","asset_specialist"}:
        raise HTTPException(400,"unsupported candidate")
    if decision not in {"approve","reject","hold"}:
        raise HTTPException(400,"decision must be approve, reject or hold")
    if horizon is not None:
        horizon=int(horizon)
        if horizon not in (1,3,5,10,20,30,60):
            raise HTTPException(400,"unsupported horizon")
    try:
        return SEL437.review(candidate,decision,note,window_days=max(30,min(window_days,3650)),symbol=symbol,horizon=horizon)
    except ValueError as exc:
        raise HTTPException(409,str(exc))
    except Exception as exc:
        raise HTTPException(503,f"promotion review unavailable: {type(exc).__name__}")


@app.get("/api/research/outlook")
def research_outlook():
    """Legacy 1m / 6m / 1y research trajectory (kept for compatibility)."""
    return MP19.public()


def _research_news_rows_v4403():
    with _news_lock:
        rows=list(_news_cache.get("rows") or [])
    if rows:
        return rows
    if NEWS_LASTGOOD.exists():
        try:
            j=json.loads(NEWS_LASTGOOD.read_text(encoding="utf-8"))
            rows=list(j.get("rows") or [])
            if rows:return rows
        except Exception:
            pass
    return list(payload().get("news") or [])


def _refresh_research_inputs_job_v4403():
    try:
        st=RM4403.refresh_current_inputs()
        with _research_lock:
            _research_cache["input_status"]=st
            _research_cache["input_ts"]=time.time()
            _research_cache["ts"]=0.0
    finally:
        with _research_lock:
            _research_cache["input_refreshing"]=False


@app.get("/api/research/monthly-v4404")
@app.get("/api/research/monthly-v4403")
def research_monthly_v4403(force: int = 0, refresh_inputs: int = 0):
    """Compatibility route: legacy hand-weighted research no longer served."""
    return MP19.public()

@app.get("/api/macro-policy/v19")
def macro_policy_v19():
    return MP19.public()

@app.post("/api/macro-policy/v19/refresh")
def macro_policy_refresh_v19():
    return MP19.start(True)


@app.get("/api/models/policy-meeting-evidence-v4404")
def policy_meeting_evidence_v4404():
    return PME4404.status()


@app.get("/api/corpfin/company")
def corpfin_company(ticker: str = "AAPL", market: str = "US", name: str | None = None, force: int = 0):
    try:
        return {"version":"4.8",**VD48.company_snapshot(ticker,market,name,force=bool(force))}
    except Exception as exc:
        raise HTTPException(503,f"company data unavailable: {type(exc).__name__}")


@app.get("/api/corpfin/universe")
def corpfin_universe(exchange: str = "all", q: str = "", limit: int = 5000, force: int = 0):
    d=EU48.universe(force=bool(force)); rows=d.get("rows",[])
    ex=str(exchange or "all").lower(); term=str(q or "").strip().lower()
    if ex in {"nyse","us"}: rows=[x for x in rows if x.get("market")=="US"]
    elif ex in {"moex","ru"}: rows=[x for x in rows if x.get("market")=="RU"]
    if term: rows=[x for x in rows if term in (str(x.get("ticker",""))+" "+str(x.get("name",""))).lower()]
    return {"version":"4.8","count":len(rows[:max(1,min(limit,10000))]),"sources":d.get("sources",[]),"rows":rows[:max(1,min(limit,10000))]}






@app.get("/api/corpfin/russia-ma/status")
def corpfin_russia_ma_status():
    return RUMA411.status()


@app.get("/api/corpfin/russia-ma")
def corpfin_russia_ma(
    range: str = "latest",
    limit: int = 50,
    offset: int = 0,
    q: str = "",
    sector: str = "",
    year: int | None = None,
):
    try:
        return RUMA411.list_deals(
            range_id=str(range or "latest"),
            limit=max(1,min(int(limit),100)),
            offset=max(0,int(offset)),
            q=str(q or "")[:160],
            sector=str(sector or "")[:120],
            year=year,
        )
    except ValueError as exc:
        raise HTTPException(400,str(exc))
    except Exception as exc:
        raise HTTPException(500,f"Russian M&A database: {type(exc).__name__}")


@app.get("/api/corpfin/russia-ma/{deal_id}")
def corpfin_russia_ma_detail(deal_id: str):
    try:
        return RUMA411.analyze(deal_id)
    except KeyError:
        raise HTTPException(404,"Russian M&A deal not found")
    except Exception as exc:
        raise HTTPException(500,f"Russian M&A analysis: {type(exc).__name__}")


@app.get("/api/corpfin/russia-ipo/status")
def corpfin_russia_ipo_status():
    return RUIPO412.status()


@app.get("/api/corpfin/russia-ipo")
def corpfin_russia_ipo(
    range: str = "latest",
    limit: int = 60,
    offset: int = 0,
    q: str = "",
    sector: str = "",
    year: int | None = None,
    status: str = "completed",
):
    try:
        return RUIPO412.list_ipos(
            range_id=str(range or "latest"),
            limit=max(1,min(int(limit),100)),
            offset=max(0,int(offset)),
            q=str(q or "")[:160],
            sector=str(sector or "")[:160],
            year=year,
            status_filter=str(status or "completed"),
        )
    except ValueError as exc:
        raise HTTPException(400,str(exc))
    except Exception as exc:
        raise HTTPException(500,f"Russian IPO database: {type(exc).__name__}")


@app.get("/api/corpfin/russia-ipo/{ipo_id}")
def corpfin_russia_ipo_detail(ipo_id: str):
    try:
        return RUIPO412.analyze(ipo_id)
    except KeyError:
        raise HTTPException(404,"Russian IPO not found")
    except Exception as exc:
        raise HTTPException(500,f"Russian IPO analysis: {type(exc).__name__}")

@app.get("/api/corpfin/sec-diagnostic")
def corpfin_sec_diagnostic():
    return SEC49.diagnostic()

@app.get("/api/corpfin/deal-provider-status")
def corpfin_deal_provider_status():
    return SEC49.status()


@app.get("/api/corpfin/transactions")
def corpfin_transactions(kind: str = "mna", range: str = "latest", limit: int = 40, offset: int = 0, force: int = 0):
    """SEC-only M&A / IPO feed.

    SEC EDGAR does not require an API key. A declared SEC_USER_AGENT with a
    contact e-mail must be configured in .env before live synchronization.
    """
    try:
        k=str(kind or "mna").lower()
        lim=max(1,min(int(limit),100))
        # v4.17: список M&A должен открываться мгновенно. Тяжёлая аналитика
        # собирается только после клика по конкретной сделке.
        enrich_n=min(lim,2) if k=="mna" else min(lim,12)
        return SEC49.list_events(
            kind=k,
            range_id=str(range or "latest").lower(),
            limit=lim,
            offset=max(0,int(offset)),
            enrich=enrich_n,
            force_sync=bool(force),
        )
    except ValueError as exc:
        raise HTTPException(400,str(exc))
    except Exception as exc:
        raise HTTPException(503,f"SEC EDGAR unavailable: {type(exc).__name__}")


@app.get("/api/corpfin/transactions/{accession}")
def corpfin_transaction_detail(accession: str, force: int = 0):
    try:
        base=SEC49.enrich_accession(accession,force=bool(force))
        return {"version":"4.10",**SDA410.analyze(base,force=bool(force))}
    except KeyError:
        raise HTTPException(404,"SEC filing not indexed")
    except RuntimeError as exc:
        raise HTTPException(503,str(exc))
    except Exception as exc:
        raise HTTPException(503,f"SEC EDGAR detail unavailable: {type(exc).__name__}")


@app.get("/api/trainer/cases")
def trainer_cases():
    cases=CF471.live_training_cases()
    # Эталон остаётся на сервере до проверки ответа в UI-версии. Для текущего
    # автономного режима фронтенд получает его, но визуально он скрыт.
    return {"version":"4.8","cases":cases}


@app.get("/api/scenario/capabilities")
def scenario_capabilities():
    return SC47.CORE.capabilities()


@app.post("/api/scenario/analyze")
def scenario_analyze(body: dict = Body(...)):
    question=str((body or {}).get("question") or "").strip()
    previous=str((body or {}).get("previous_question") or "").strip() or None
    if len(question)<5:
        raise HTTPException(400,"Введите сценарий чуть подробнее")
    if len(question)>3000:
        raise HTTPException(400,"Сценарий слишком длинный")
    try:
        return {"version":"4.7",**SC47.CORE.analyze(payload(),question,previous)}
    except ValueError as exc:
        raise HTTPException(400,str(exc))
    except Exception as exc:
        raise HTTPException(500,f"scenario core: {type(exc).__name__}")


@app.get("/api/forecast/short")
def short_forecast(symbol: str, horizon: str = "1h", force: int = 0):
    """Короткая исследовательская оценка 30м / 1ч / 2ч / 4ч.

    Число 0–1 здесь является консервативным техническим индексом направления,
    а не исторически откалиброванной вероятностью. Дневная модель в этот расчёт
    не маскируется под intraday.
    """
    if _market_asset(symbol) is None:
        raise HTTPException(404,"asset not found")
    horizon=str(horizon or "1h").lower()
    if horizon not in SF45.HORIZONS:
        raise HTTPException(400,"horizon must be 30m, 1h, 2h or 4h")
    ttl=max(30,int(os.getenv("SHORT_FORECAST_REFRESH_SECONDS","90")))
    key=(symbol,horizon)
    now=time.time()
    with _short_forecast_lock:
        cached=_short_forecast_cache.get(key)
        if force or not cached or now-cached["ts"]>=ttl:
            asset=_market_asset(symbol) or {}
            try:
                result=SF45.forecast(symbol,horizon,asset)
            except Exception as exc:
                result={"status":"unavailable","symbol":symbol,"horizon":horizon,
                        "reason":"Краткосрочная оценка временно недоступна.",
                        "errors":[type(exc).__name__]}
            _short_forecast_cache[key]={"ts":now,"result":result}
            cached=_short_forecast_cache[key]
        result=dict(cached["result"])
        # Daily event statistics are not presented as intraday announcement moves.
        result=QUALITY.forecast(MACRO109.apply(result,pd.Series(dtype=float),symbol,horizon))
        return {"version":"4.40.10.17-short-horizons","refresh_seconds":ttl,**result}


@app.get("/api/chart/history")
def chart_history(symbol: str, period: str = "6m", interval: str = "1d", force: int = 0):
    """OHLC-свечи для пользовательских графиков.

    interval:
      1m — 1 минута
      5m — 5 минут
      1h — 1 час
      1d — 1 день

    Внутридневные интервалы никогда не синтезируются из дневных свечей.
    Если live-интрадей недоступен, API сохраняет только ранее полученный
    внутридневной кэш и не подменяет его дневной историей.
    """
    if _market_asset(symbol) is None:
        raise HTTPException(404,"asset not found")

    interval=str(interval or "1d").lower()
    if interval not in {"1m","5m","1h","1d"}:
        raise HTTPException(400,"interval must be 1m, 5m, 1h or 1d")
    period=str(period or ("6m" if interval=="1d" else "5d")).lower()

    daily_periods={"1m":35,"3m":100,"6m":190,"1y":380,"3y":1100,"5y":1900,"max":2200}
    intraday_days={"1d":1.35,"5d":6.0,"1mo":32.0,"3mo":95.0,"6mo":190.0}
    if interval=="1d":
        if period not in daily_periods:
            raise HTTPException(400,"daily period must be 1m, 3m, 6m, 1y, 3y, 5y or max")
    elif period not in intraday_days:
        raise HTTPException(400,"intraday period must be 1d, 5d, 1mo, 3mo or 6mo")

    now=time.time()
    # Daily MOEX windows have different history depth. Include period in the key
    # so opening 1M first cannot poison a later 6M/1Y request with a short cache.
    key=(symbol,interval,period if interval=="1d" else "intraday")
    ttl=max(30,int(os.getenv("CHART_REFRESH_SECONDS","180")))
    with _chart_lock:
        cached=_chart_cache.get(key)
        if force or not cached or now-cached["ts"]>=ttl:
            # Запрашиваем длинную историю только когда пользователь реально выбрал
            # длинный горизонт. Это особенно ускоряет MOEX ISS / RTS / IMOEX.
            need_long = interval=="1d" and period in {"3y","5y","max"}
            if interval=="1d" and (MU416.is_ru_equity(symbol) or str(symbol).upper() in C.MOEX_INDICES):
                d,src,errs=_ru_terminal_daily_history(symbol,period,force=bool(force))
                rr=MD41.MarketResult(symbol,d,src,errs)
                # Preserve the old cascade as a fallback only; it must no longer be
                # the primary terminal route for Russian instruments.
                if rr.frame.empty:
                    fallback=MD41.fetch_history(symbol,long_history=need_long)
                    rr=MD41.MarketResult(symbol,fallback.frame,fallback.source,errs+list(fallback.errors or []))
            else:
                rr=MD41.fetch_history(symbol,long_history=need_long) if interval=="1d" else MD43.fetch_intraday(symbol,interval)
            if not rr.frame.empty:
                _chart_cache[key]={"ts":now,"frame":rr.frame.copy(),"source":rr.source,
                                   "errors":list(rr.errors or []),"interval":interval}
                cached=_chart_cache[key]
            elif interval=="1d" and not cached:
                # Только дневной график может использовать экспортированный дневной snapshot.
                a=_market_asset(symbol)
                hist=(a or {}).get("chart_history") or (a or {}).get("history") or []
                rows=[]
                for x in hist:
                    try:
                        rows.append({"date":x.get("t") or x.get("date"),
                                     "open":x.get("o",x.get("open")),
                                     "high":x.get("h",x.get("high")),
                                     "low":x.get("l",x.get("low")),
                                     "close":x.get("c",x.get("close"))})
                    except Exception:
                        pass
                df=MD41._norm(pd.DataFrame(rows))
                _chart_cache[key]={"ts":now,"frame":df,"source":"последний дневной снимок",
                                   "errors":list(rr.errors or [])+["live-источники недоступны"],
                                   "interval":interval}
                cached=_chart_cache[key]
            elif not cached:
                raise HTTPException(503,detail={
                    "message":"Внутридневные данные сейчас недоступны",
                    "symbol":symbol,"interval":interval,
                    "errors":list(rr.errors or [])[-5:]
                })

        cached=_chart_cache.get(key)
        if not cached:
            raise HTTPException(503,"market history unavailable")
        d=cached["frame"].copy().sort_values("date")
        if interval=="1d":
            d=d.tail(daily_periods[period])
        else:
            last=pd.Timestamp(d["date"].max())
            cut=last-pd.Timedelta(days=float(intraday_days[period]))
            d=d[d["date"]>=cut]
            # Жёсткий предел защищает браузер, но оставляет достаточно свечей
            # для индикаторов и ручного анализа.
            d=d.tail(2400)

        candles=[{
            "t":pd.Timestamp(r.date).isoformat(timespec="minutes") if interval!="1d"
                else str(pd.Timestamp(r.date).date()),
            "o":round(float(r.open),8),"h":round(float(r.high),8),
            "l":round(float(r.low),8),"c":round(float(r.close),8),
        } for r in d.itertuples()]
        return {
            "version":"4.8","symbol":symbol,"period":period,"interval":interval,
            "source":cached["source"],"refresh_seconds":ttl,
            "as_of":candles[-1]["t"] if candles else None,
            "points":len(candles),"candles":candles,
            "errors":cached.get("errors",[])[-5:],
        }


@app.get("/api/pulse")
def pulse():
    d = payload()
    aa = d.get("assets", [])
    trusted = [a for a in aa if (a.get("model_quality") or {}).get("trusted")]
    return {
        "generated_at": d.get("generated_at"),
        "assets": len(aa),
        "trusted_10d": len(trusted),
        "sentiment": d.get("sentiment"),
        "next_event": (d.get("events") or [None])[0],
        "macro_data": (aa[0].get("macro_data") if aa else None),
    }


@app.get("/api/model-audit")
def model_audit():
    """Transparent model-validation summary for the current generated snapshot."""
    d = payload()
    rows = []
    for a in d.get("assets", []):
        m = (a.get("model_horizons") or {}).get("10") or {}
        sc = m.get("scorecard") or {}
        ho = m.get("holdout") or {}
        rows.append({
            "symbol": a.get("symbol"),
            "name": a.get("name"),
            "trusted": (m.get("quality") or {}).get("trusted", False),
            "dev_edge": sc.get("edge"),
            "dev_edge_ci": sc.get("edge_ci"),
            "effective_n": sc.get("n_eff"),
            "holdout": ho,
        })
    return {
        "generated_at": d.get("generated_at"),
        "macro_data": ((d.get("assets") or [{}])[0].get("macro_data")),
        "horizon": 10,
        "assets": rows,
    }


@app.get("/api/events")
def events():
    return payload().get("events", [])


def _filter_news(rows, category: str | None = None, min_impact: int = 0):
    if category:
        rows = [n for n in rows if n.get("category") == category]
    if min_impact:
        rows = [n for n in rows if int(n.get("impact_score") or 0) >= min_impact]
    return rows


@app.get("/api/news")
def news(category: str | None = None, min_impact: int = 0):
    return _filter_news(payload().get("news", []), category, min_impact)


@app.get("/api/news/live")
def live_news(category: str | None = None, min_impact: int = 0, force: int = 0):
    """Fast stale-while-revalidate news endpoint.

    The UI never waits for an external news/image provider. A generated snapshot or
    last-good disk cache is returned immediately, while a single background worker
    refreshes live headlines. Publisher image URLs are preserved in the payload and
    loaded by the browser only after the text/news response has rendered.
    """
    try:
        ttl = max(30, int(os.getenv("NEWS_REFRESH_SECONDS", "30")))
    except ValueError:
        ttl = 30

    def load_local_rows():
        if NEWS_LASTGOOD.exists():
            try:
                cached = json.loads(NEWS_LASTGOOD.read_text(encoding="utf-8"))
                rows = cached.get("rows") or []
                if rows:
                    return rows
            except Exception:
                pass
        return list(payload().get("news", []) or [])

    def refresh_job():
        try:
            aa = [{"symbol": a.get("symbol"), "name": a.get("name")} for a in payload().get("assets", [])]
            # Do not download publisher/Pexels images in the critical news/map path.
            # Preserve provider image URLs instead: the visual feed loads them client-side,
            # so image latency can never block headlines or the map.
            rows = NEWS.build(aa)
            if rows:
                with _news_lock:
                    _news_cache["rows"] = rows
                    _news_cache["ts"] = time.time()
                try:
                    NEWS_LASTGOOD.write_text(json.dumps({"saved_at": time.time(), "rows": rows}, ensure_ascii=False), encoding="utf-8")
                except Exception:
                    pass
        finally:
            with _news_lock:
                _news_cache["refreshing"] = False

    now = time.time()
    with _news_lock:
        if not _news_cache.get("rows"):
            _news_cache["rows"] = load_local_rows()
        expired = force or now - float(_news_cache.get("ts") or 0) >= ttl
        if expired and not _news_cache.get("refreshing"):
            _news_cache["refreshing"] = True
            _news_executor.submit(refresh_job)
        rows = list(_news_cache.get("rows") or [])
    return _filter_news(rows, category, min_impact)


@app.get("/api/model-benchmark")
def model_benchmark():
    """Latest locked champion/challenger comparison snapshot."""
    for fn, ver in (("model_benchmark_v34.json","3.4"),("model_benchmark_v33.json","3.3")):
        p = SITE / fn
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception as exc:
                return {"version":ver,"status":"error","error":str(exc)}
    return {"version":"3.4","status":"not_generated","message":"Run python benchmark_v34.py."}






@app.get("/api/altdata/live")
def altdata_live(force: int = 0):
    """Живые альтернативные данные. Секреты никогда не уходят в браузер."""
    return AD40.build_snapshot(force=bool(force))

@app.get("/api/altdata/refresh/{provider}")
def altdata_refresh_provider(provider: str):
    """Обновить одного поставщика, не заставляя пользователя ждать остальные API."""
    try:
        return AD40.build_snapshot(force=True, provider=provider)
    except ValueError as exc:
        raise HTTPException(404, str(exc))

@app.get("/api/altdata/asset/{symbol:path}")
def altdata_asset(symbol: str, force: int = 0):
    snap=AD40.build_snapshot(force=bool(force))
    return {"version":"4.0", **AD40.asset_altdata(snap,symbol),
            "generated_at":snap.get("generated_at")}

@app.get("/api/altdata/providers")
def altdata_providers():
    snap=AD40.build_snapshot(force=False)
    return {"version":"4.0","providers":AD40.provider_status(),
            "digest":snap.get("digest"),"generated_at":snap.get("generated_at")}

@app.get("/api/unified-forecast/{symbol:path}")
def unified_forecast(symbol: str, horizon: int = 10):
    for a in payload().get("assets", []):
        if a.get("symbol")==symbol:
            h=str(int(horizon))
            return {"version":"4.0","symbol":symbol,"horizon":int(horizon),
                    "forecast":(a.get("unified_forecast_v39") or {}).get(h)}
    raise HTTPException(404,"asset not found")

@app.get("/api/news-map")
def news_map(category: str | None = None, min_impact: int = 0, force: int = 0):
    rows=live_news(category=category,min_impact=min_impact,force=force)
    return {"version":"4.30","rows":NMAP40.enrich(rows),"stale_while_revalidate":True}

@app.get("/api/map/geo")
def map_geo():
    p = SITE / "world_map_geo.json"
    if not p.exists():
        raise HTTPException(404, "map geometry missing")
    return json.loads(p.read_text(encoding="utf-8"))

@app.get("/api/network/status")
def network_status():
    return {"version":"4.30", "transport": RH430.status(), "news_cache_rows": len(_news_cache.get("rows") or []), "news_last_good": NEWS_LASTGOOD.exists(), "terminal_quote_last_good": TERMINAL_QUOTE_LASTGOOD.exists()}

@app.get("/api/data-provider-status")
def data_provider_status():
    """Safe v3.7 provider readiness: booleans and planned features, never secrets."""
    return {"version":"4.0","providers":AD40.provider_status()}

@app.get("/api/regime-model")
def regime_model(symbol: str = "", horizon: int = 10):
    """v3.7 Regime Mixture-of-Experts research output."""
    p = SITE / "regime_v37.json"
    if not p.exists():
        return {"version":"3.7","status":"not_generated",
                "message":"Run python build_regime_v37.py."}
    try:
        data=json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"version":"3.7","status":"error","error":str(exc)}
    if not symbol:
        return data
    h=int(horizon)
    for row in data.get("horizons",[]):
        if int(row.get("horizon",-1))!=h:
            continue
        live=next((x for x in (row.get("live") or []) if x.get("symbol")==symbol),None)
        return {
            "version":"3.7","model_version":data.get("model_version"),
            "symbol":symbol,"horizon":h,"live":live,
            "development":row.get("development"),
            "regime_development":row.get("regime_development"),
            "cluster_date_bootstrap":row.get("cluster_date_bootstrap"),
            "calibration_check":row.get("calibration_check"),
            "prospective_holdout":row.get("prospective_holdout"),
            "decision":data.get("decision"),
        }
    return {"version":"3.7","status":"not_found","symbol":symbol,"horizon":h}

@app.get("/api/cross-asset-model")
def cross_asset_model(symbol: str = "", horizon: int = 10):
    """v3.6 pooled cross-asset research models and prospective holdout status."""
    p = SITE / "cross_asset_v36.json"
    if not p.exists():
        return {"version":"3.6","status":"not_generated",
                "message":"Run python build_cross_asset_v36.py."}
    try:
        data=json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"version":"3.6","status":"error","error":str(exc)}
    if not symbol:
        return data
    h=int(horizon)
    for row in data.get("horizons",[]):
        if int(row.get("horizon",-1))!=h:
            continue
        out={"version":"3.6","symbol":symbol,"horizon":h,
             "prospective_holdout_start":data.get("prospective_holdout_start"),
             "decision":data.get("decision"),"models":{}}
        for name,m in (row.get("models") or {}).items():
            live=next((x for x in (m.get("live") or []) if x.get("symbol")==symbol),None)
            out["models"][name]={
                "version":m.get("version"),"live":live,
                "development":m.get("development"),
                "cluster_date_bootstrap":m.get("cluster_date_bootstrap"),
                "calibration_check":m.get("calibration_check"),
                "prospective_holdout":m.get("prospective_holdout"),
                "top_features_frozen":m.get("top_features_frozen"),
            }
        return out
    return {"version":"3.6","status":"not_found","symbol":symbol,"horizon":h}

@app.get("/api/model-track-record")
def model_track_record(symbol: str = "", horizon: int = 10):
    """Immutable live champion forecast history for one asset/horizon."""
    con = db.connect()
    try:
        if not symbol:
            return {"version":"3.5","status":"error","message":"symbol is required"}
        h = int(horizon)
        if h not in (1,5,10,20):
            return {"version":"3.5","status":"error","message":"horizon must be 1, 5, 10 or 20"}
        return {
            "version":"4.40.6",
            "status":"legacy_only",
            "legacy":True,
            "model_version":MR.MODEL_VERSION,
            "current_model_generation":EQF416.META435.MODEL_GENERATION,
            "message":"Этот endpoint хранит исторический бинарный ledger v3.2 и не является track record текущей three-state модели. Для текущей модели используйте prospective feedback/evidence endpoints.",
            "symbol":symbol,
            "horizon":h,
            "track_record":MR.live_track_record(con,MR.MODEL_VERSION,symbol,h),
        }
    finally:
        con.close()

@app.get("/api/model-decision")
def model_decision():
    p = SITE / "model_decision_v34.json"
    if not p.exists():
        return {"version":"3.4","status":"not_generated"}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"version":"3.4","status":"error","error":str(exc)}


@app.get("/api/model-registry")
def model_registry():
    con=db.connect()
    try:
        MR.register_champion(con)
        return MR.registry_snapshot(con)
    finally:
        con.close()


@app.get("/api/prediction-ledger")
def prediction_ledger(symbol: str | None = None, limit: int = 200):
    con=db.connect()
    try:
        MR.ensure_schema(con)
        limit=max(1,min(int(limit),1000))
        sql="SELECT prediction_id,model_version,feature_version,symbol,horizon,prediction_time,data_cutoff,p_up,holdout_status,realized_at,realized_return,realized_up FROM prediction_ledger"
        args=[]
        if symbol:
            sql += " WHERE symbol=?"; args.append(symbol)
        sql += " ORDER BY created_at DESC LIMIT ?"; args.append(limit)
        cols=["prediction_id","model_version","feature_version","symbol","horizon","prediction_time","data_cutoff","p_up","holdout_status","realized_at","realized_return","realized_up"]
        return [dict(zip(cols,r)) for r in con.execute(sql,args)]
    finally:
        con.close()


@app.on_event("startup")
def refresh_macro_calendar_v440109():
    # No network on the forecast request path. Refresh in background at startup;
    # failures preserve the shipped/last good snapshot and its original timestamp.
    from threading import Thread
    Thread(target=MACROCAL109.refresh,daemon=True,name="macro-calendar-refresh").start()

@app.get("/api/markets/event-study")
def macro_event_study(symbol: str, horizon: int=1):
    if _market_asset(symbol) is None:raise HTTPException(404,"asset not found")
    if horizon not in (1,3,5,10,20,30,60):raise HTTPException(400,"unsupported horizon")
    result=EQF416.forecast_fast(symbol,horizons=(horizon,))
    return (result.get("forecasts",{}).get(str(horizon),{}) or {}).get("macro_events",{})

@app.get('/data.json')
def quality_snapshot_json():
    return JSONResponse(payload(), headers={'Cache-Control':'no-store'})

@app.get('/data.js')
def quality_snapshot_js():
    from fastapi.responses import Response
    return Response('window.FORECASTS = '+json.dumps(payload(),ensure_ascii=False)+';',media_type='application/javascript',headers={'Cache-Control':'no-store'})

@app.get("/")
def index():
    return FileResponse(SITE / "index.html")


@app.on_event("startup")
def start_forecast_journal_worker():
    _journal_stop.clear()
    def run():
        global _journal_last_error
        while not _journal_stop.is_set():
            try:_schedule_feedback_settlement_v436()
            except Exception as exc:_journal_last_error=type(exc).__name__
            _journal_stop.wait(300)
    Thread(target=run,daemon=True,name="forecast-journal-settlement").start()

@app.on_event("shutdown")
def stop_forecast_journal_worker():
    _journal_stop.set()

@app.get("/api/models/forecast-journal")
def forecast_journal_dashboard(symbol: str=None,generation: str=None):
    result=JOURNAL15.journal().dashboard(symbol=symbol,generation=generation)
    result['worker_error']=_journal_last_error
    return JSONResponse(result,headers={'Cache-Control':'no-store'})

@app.get("/api/models/forecast-journal/{issue_id}")
def forecast_journal_detail(issue_id: int):
    result=JOURNAL15.journal().detail(issue_id)
    if result is None:raise HTTPException(404,"Выпуск не найден")
    return JSONResponse(result,headers={'Cache-Control':'no-store'})

@app.get("/api/models/verified-extensions")
def verified_extensions_status():
    import verified_extensions_v4401016 as EXT16
    result=EXT16.policy()
    report=SITE / "extensions_results_v4401016.json"
    if report.exists():
        try:result['experiment']=json.loads(report.read_text(encoding='utf-8'))
        except (OSError,ValueError):result['report_error']='Не удалось прочитать сохранённый эксперимент'
    return JSONResponse(result,headers={'Cache-Control':'no-store'})

app.mount("/", StaticFiles(directory=SITE), name="site")


@app.on_event("startup")
def start_macro_policy_learning():
    MP19.start_scheduler()

@app.on_event("shutdown")
def stop_macro_policy_learning():
    MP19.stop_scheduler()
