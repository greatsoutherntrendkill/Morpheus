"""Regression checks: resource release must not depend on cyclic GC."""
import gc
import os
from contextlib import closing
from unittest.mock import Mock, patch
import pytest
import macro_policy_data_v19 as macro
from forecast_journal_v4401015 import Journal
from prospective_feedback_v436 import Ledger as Feedback
from distribution_feedback_v440 import Ledger as Distribution

@pytest.mark.parametrize('kind', ['journal', 'feedback', 'distribution'])
def test_repeated_reads_release_descriptors(tmp_path, kind):
    if not os.path.isdir('/dev/fd'):
        pytest.skip('POSIX descriptor check')
    obj = {'journal': Journal, 'feedback': Feedback, 'distribution': Distribution}[kind](tmp_path/'ledger.db')
    operation = obj.rows
    operation()
    gc.collect()
    before = len(os.listdir('/dev/fd'))
    enabled = gc.isenabled()
    gc.disable()
    try:
        for _ in range(400):
            operation()
        assert len(os.listdir('/dev/fd')) <= before + 2
    finally:
        if enabled: gc.enable()
        gc.collect()

@pytest.mark.parametrize('failure', [False, True])
def test_fred_owned_session_closed(failure):
    session = Mock()
    session.__enter__ = Mock(return_value=session)
    session.__exit__ = Mock(return_value=False)
    session.get.return_value.status_code = 200
    session.get.return_value.json.return_value = {'observations': [], 'count': 0}
    if failure: session.get.side_effect = macro.requests.ConnectionError('offline')
    with patch.object(macro.requests, 'Session', return_value=session):
        if failure:
            with pytest.raises(RuntimeError): macro.fetch_series('UNRATE', 'test-placeholder')
        else: assert macro.fetch_series('UNRATE', 'test-placeholder') == []
    session.__exit__.assert_called_once()

def test_fred_borrowed_session_not_closed():
    session = Mock()
    session.get.return_value.status_code = 200
    session.get.return_value.json.return_value = {'observations': [], 'count': 0}
    macro.fetch_series('UNRATE', 'test-placeholder', session=session)
    session.close.assert_not_called()

def test_macro_rollback_preserved(tmp_path):
    with closing(macro.connect(tmp_path/'macro.db')) as c:
        with pytest.raises(ValueError):
            macro.ingest(c, 'UNRATE', [dict(date='2020-01-01',realtime_start='2020-02-01',value='1'),dict(date='2020-01-01',realtime_start='2020-02-01',value='2')])
        assert c.execute('select count(*) from observations').fetchone()[0] == 0
