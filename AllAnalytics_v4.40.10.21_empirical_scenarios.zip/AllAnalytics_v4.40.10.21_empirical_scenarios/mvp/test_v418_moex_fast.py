from pathlib import Path
import json
import tempfile

import moex_fast_v418 as M


def _sample_marketdata_share():
    return {
        "marketdata": {
            "columns": ["SECID","LAST","MARKETPRICE","LCURRENTPRICE","WAPRICE","LASTCHANGEPRCNT","LASTTOPREVPRICE","UPDATETIME","SYSTIME","NUMTRADES"],
            "data": [
                ["SBER", 315.25, None, None, 314.9, 1.23, None, "18:01:00", "18:01:02", 12345],
                ["GAZP", None, None, None, None, None, None, None, "18:01:02", 0],
            ]
        }
    }


def _sample_securities_share():
    return {
        "securities": {
            "columns": ["SECID","SHORTNAME","PREVPRICE","PREVLEGALCLOSEPRICE","PREVVALUE"],
            "data": [
                ["SBER","Сбербанк",311.42,None,None],
                ["GAZP","Газпром",128.55,None,None],
            ]
        }
    }


def test_marketdata_and_prevclose_fallback(monkeypatch, tmp_path):
    calls=[]
    def fake(path, params, **kwargs):
        calls.append((path, dict(params)))
        if params.get("iss.only") == "marketdata":
            return _sample_marketdata_share()
        return _sample_securities_share()
    monkeypatch.setattr(M, "_request_json", fake)
    M._STATIC_META.clear()
    rows=M._board_live("shares","TQBR")
    assert rows["SBER"]["last"] == 315.25
    assert rows["SBER"]["chg1d"] == 1.23
    assert rows["GAZP"]["last"] == 128.55
    assert rows["GAZP"]["stale"] is True
    # The live call must be small: only marketdata and explicit columns.
    live=[p for _,p in calls if p.get("iss.only")=="marketdata"][0]
    assert live.get("marketdata.columns")
    assert "SECID" in live["marketdata.columns"] and "LAST" in live["marketdata.columns"]


def test_rows_column_mapping():
    block={"columns":["SECID","LAST"],"data":[["SBER",300.0],["GAZP",130.0]]}
    assert M._rows(block)==[{"SECID":"SBER","LAST":300.0},{"SECID":"GAZP","LAST":130.0}]
