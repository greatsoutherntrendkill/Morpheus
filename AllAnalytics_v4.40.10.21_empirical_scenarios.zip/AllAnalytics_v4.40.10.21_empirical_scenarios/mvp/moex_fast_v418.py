"""AllAnalytics v4.18 — fast/reliable MOEX ISS adapter.

The adapter follows the same endpoints used by apimoex.get_board_securities:
  stock / shares / TQBR  -> shares
  stock / index  / SNDX  -> indices

Design goals:
* one compact request per board, not one request per ticker;
* request only the marketdata columns that are actually displayed;
* PREVPRICE/PREVVALUE fallback outside trading / before the first trade;
* persistent last-good cache so a transient MOEX/DNS/TLS outage does not blank UI;
* short connect/read timeouts + retries so the global quote refresh is not blocked;
* compact candles endpoint + persistent history cache for model forecasts.
"""
from __future__ import annotations

import json
import os
import time
import warnings
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib3.exceptions import InsecureRequestWarning

ROOT = Path(__file__).resolve().parent
CACHE_DIR = ROOT / "runtime_cache" / "moex_v418"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
LIVE_CACHE_FILE = CACHE_DIR / "live.json"
HISTORY_DIR = CACHE_DIR / "history"
HISTORY_DIR.mkdir(parents=True, exist_ok=True)

BASE = "https://iss.moex.com"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 AllAnalytics/4.18"
CONNECT_TIMEOUT = float(os.getenv("MOEX_CONNECT_TIMEOUT", "2.5"))
READ_TIMEOUT = float(os.getenv("MOEX_READ_TIMEOUT", "5.0"))
LIVE_TTL = max(3, int(os.getenv("MOEX_LIVE_CACHE_SECONDS", "10")))
HISTORY_TTL = max(600, int(os.getenv("MOEX_HISTORY_CACHE_SECONDS", str(6 * 3600))))

_LOCK = Lock()
_FETCH_LOCK = Lock()
_MEM_LIVE: dict = {"ts": 0.0, "shares": {}, "indices": {}, "errors": []}
_STATIC_META: dict[tuple[str, str], tuple[float, dict]] = {}


def _session() -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=2, connect=2, read=2, status=2,
        backoff_factor=0.18,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET"]),
        raise_on_status=False,
    )
    s.mount("https://", HTTPAdapter(max_retries=retry, pool_connections=4, pool_maxsize=8))
    s.headers.update({"User-Agent": UA, "Accept": "application/json,text/plain,*/*", "Connection": "keep-alive"})
    return s

_SESSION = _session()


def _request_json(path: str, params: dict, *, allow_insecure: bool = True) -> dict:
    url = BASE + path
    try:
        r = _SESSION.get(url, params=params, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
        r.raise_for_status()
        return r.json() or {}
    except requests.exceptions.SSLError:
        if not allow_insecure:
            raise
        # Public delayed market data only. This fallback exists for local Python
        # installations with a broken CA bundle; normal verified TLS is primary.
        warnings.simplefilter("ignore", InsecureRequestWarning)
        r = _SESSION.get(url, params=params, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), verify=False)
        r.raise_for_status()
        return r.json() or {}


def _rows(block: dict) -> list[dict]:
    cols = (block or {}).get("columns") or []
    data = (block or {}).get("data") or []
    return [{c: row[i] if i < len(row) else None for i, c in enumerate(cols)} for row in data]


def _finite(v):
    try:
        x = float(v)
        return x if x > 0 else None
    except Exception:
        return None


def _read_persistent_live() -> dict:
    try:
        return json.loads(LIVE_CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"shares": {}, "indices": {}, "saved_at": None}


def _save_persistent_live(shares: dict, indices: dict):
    if not shares and not indices:
        return
    old = _read_persistent_live()
    merged_shares = {**(old.get("shares") or {}), **shares}
    merged_indices = {**(old.get("indices") or {}), **indices}
    tmp = LIVE_CACHE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps({
        "saved_at": datetime.now().isoformat(timespec="seconds"),
        "shares": merged_shares,
        "indices": merged_indices,
    }, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    tmp.replace(LIVE_CACHE_FILE)


def _static_board_meta(market: str, board: str) -> dict:
    key = (market, board)
    now = time.time()
    cached = _STATIC_META.get(key)
    if cached and now - cached[0] < 6 * 3600:
        return cached[1]
    path = f"/iss/engines/stock/markets/{market}/boards/{board}/securities.json"
    # Static block is small because we explicitly request only four columns.
    cols = "SECID,SHORTNAME,PREVPRICE,PREVLEGALCLOSEPRICE,PREVVALUE"
    j = _request_json(path, {
        "iss.meta": "off", "iss.only": "securities",
        "securities.columns": cols,
    })
    out = {str(r.get("SECID") or "").upper(): r for r in _rows(j.get("securities") or {}) if r.get("SECID")}
    _STATIC_META[key] = (now, out)
    return out


def _board_live(market: str, board: str) -> dict:
    path = f"/iss/engines/stock/markets/{market}/boards/{board}/securities.json"
    if market == "shares":
        columns = "SECID,LAST,MARKETPRICE,LCURRENTPRICE,WAPRICE,LASTCHANGEPRCNT,LASTTOPREVPRICE,UPDATETIME,SYSTIME,NUMTRADES"
        last_keys = ("LAST", "LCURRENTPRICE", "MARKETPRICE", "WAPRICE")
        change_keys = ("LASTCHANGEPRCNT", "LASTTOPREVPRICE")
    else:
        columns = "SECID,CURRENTVALUE,LAST,MARKETPRICE,LASTCHANGEPRCNT,CHANGE,UPDATETIME,SYSTIME"
        last_keys = ("CURRENTVALUE", "LAST", "MARKETPRICE")
        change_keys = ("LASTCHANGEPRCNT", "CHANGE")

    # This is the crucial v4.18 change: marketdata only + explicit columns.
    # On TQBR this cuts a ~200 KB full payload down to a compact quote snapshot.
    j = _request_json(path, {
        "iss.meta": "off", "iss.only": "marketdata",
        "marketdata.columns": columns,
    })
    market_rows = _rows(j.get("marketdata") or {})
    meta = _static_board_meta(market, board)
    out = {}
    for m in market_rows:
        secid = str(m.get("SECID") or "").upper()
        if not secid:
            continue
        s = meta.get(secid, {})
        last = next((_finite(m.get(k)) for k in last_keys if _finite(m.get(k)) is not None), None)
        prev = next((_finite(s.get(k)) for k in ("PREVPRICE", "PREVLEGALCLOSEPRICE", "PREVVALUE") if _finite(s.get(k)) is not None), None)
        # If there was no trade yet today, show the previous official close instead of "—".
        used_prev = False
        if last is None and prev is not None:
            last = prev
            used_prev = True
        chg = None
        for k in change_keys:
            try:
                if m.get(k) is not None:
                    chg = float(m.get(k))
                    break
            except Exception:
                pass
        if chg is None and last is not None and prev:
            chg = (last / prev - 1.0) * 100.0
        if last is None:
            continue
        out[secid] = {
            "secid": secid,
            "last": round(float(last), 8),
            "chg1d": None if chg is None else round(float(chg), 4),
            "time": m.get("UPDATETIME") or m.get("SYSTIME"),
            "name": s.get("SHORTNAME") or secid,
            "prev": prev,
            "board": board,
            "source": "MOEX ISS · previous close" if used_prev else f"MOEX ISS · {board} marketdata",
            "stale": bool(used_prev),
        }
    # Some instruments may be absent from marketdata outside the active session.
    # Add them from official PREVPRICE so the cards remain usable.
    for secid, s in meta.items():
        if secid in out:
            continue
        prev = next((_finite(s.get(k)) for k in ("PREVPRICE", "PREVLEGALCLOSEPRICE", "PREVVALUE") if _finite(s.get(k)) is not None), None)
        if prev is None:
            continue
        out[secid] = {
            "secid": secid, "last": round(prev, 8), "chg1d": None,
            "time": None, "name": s.get("SHORTNAME") or secid, "prev": prev,
            "board": board, "source": "MOEX ISS · previous close", "stale": True,
        }
    return out


def refresh_live(force: bool = False) -> dict:
    now = time.time()
    with _LOCK:
        if not force and _MEM_LIVE.get("shares") and now - float(_MEM_LIVE.get("ts") or 0) < LIVE_TTL:
            return dict(_MEM_LIVE)
    # Prevent the dedicated /api/moex/live request and the global quote loop from
    # opening two identical ISS requests during first page load.
    with _FETCH_LOCK:
        now = time.time()
        with _LOCK:
            if not force and _MEM_LIVE.get("shares") and now - float(_MEM_LIVE.get("ts") or 0) < LIVE_TTL:
                return dict(_MEM_LIVE)
        errors = []
        shares, indices = {}, {}
        try:
            shares = _board_live("shares", "TQBR")
        except Exception as e:
            errors.append(f"TQBR: {type(e).__name__}: {str(e)[:120]}")
        try:
            indices = _board_live("index", "SNDX")
        except Exception as e:
            errors.append(f"SNDX: {type(e).__name__}: {str(e)[:120]}")

        if shares or indices:
            try:
                _save_persistent_live(shares, indices)
            except Exception as e:
                errors.append(f"cache-write: {type(e).__name__}")
        persisted = _read_persistent_live()
        if not shares:
            shares = persisted.get("shares") or {}
            for row in shares.values():
                row["source"] = "MOEX ISS · last-good cache"
                row["stale"] = True
        if not indices:
            indices = persisted.get("indices") or {}
            for row in indices.values():
                row["source"] = "MOEX ISS · last-good cache"
                row["stale"] = True

        result = {"ts": now, "shares": shares, "indices": indices, "errors": errors,
                  "saved_at": persisted.get("saved_at")}
        with _LOCK:
            _MEM_LIVE.clear(); _MEM_LIVE.update(result)
        return result


def get_snapshot(secids, market: str = "shares", force: bool = False) -> dict:
    wanted = {str(x or "").upper().replace(".ME", "") for x in secids or [] if x}
    data = refresh_live(force=force)
    source = data.get("shares") if market == "shares" else data.get("indices")
    return {s: dict(source[s]) for s in wanted if s in source}


def status() -> dict:
    d = refresh_live(force=False)
    return {
        "version": "4.18", "shares": len(d.get("shares") or {}),
        "indices": len(d.get("indices") or {}), "errors": d.get("errors") or [],
        "cache_file": LIVE_CACHE_FILE.name, "saved_at": d.get("saved_at"),
    }


def _history_cache_path(market: str, board: str, secid: str) -> Path:
    safe = "".join(ch for ch in str(secid).upper() if ch.isalnum() or ch in "-_")
    return HISTORY_DIR / f"{market}_{board}_{safe}.json"


def _load_history_file(path: Path) -> pd.DataFrame:
    try:
        j = json.loads(path.read_text(encoding="utf-8"))
        rows = j.get("rows") or []
        d = pd.DataFrame(rows)
        if d.empty:
            return pd.DataFrame(columns=["date", "open", "high", "low", "close"])
        d["date"] = pd.to_datetime(d["date"], errors="coerce")
        for c in ("open", "high", "low", "close"):
            d[c] = pd.to_numeric(d[c], errors="coerce")
        return d.dropna(subset=["date", "close"]).sort_values("date")
    except Exception:
        return pd.DataFrame(columns=["date", "open", "high", "low", "close"])


def candles(secid: str, market: str = "shares", board: str = "TQBR", years: int = 5, force: bool = False) -> pd.DataFrame:
    """Compact daily candles for the model layer.

    Uses the candles endpoint from the apimoex documentation instead of the much
    heavier history endpoint. Data is persisted on disk; a stale but valid cache
    is preferred over an empty model when MOEX is temporarily unreachable.
    """
    secid = str(secid or "").upper().replace(".ME", "")
    path_cache = _history_cache_path(market, board, secid)
    now = time.time()
    if path_cache.exists() and not force and now - path_cache.stat().st_mtime < HISTORY_TTL:
        d = _load_history_file(path_cache)
        if not d.empty:
            return d

    start_date = (datetime.now() - timedelta(days=max(2, years) * 366)).date().isoformat()
    path = f"/iss/engines/stock/markets/{market}/boards/{board}/securities/{secid}/candles.json"
    rows = []
    offset = 0
    try:
        # ISS candles pagination is handled with start; compact columns keep every page small.
        for _ in range(12):
            j = _request_json(path, {
                "iss.meta": "off", "iss.only": "candles", "from": start_date,
                "interval": 24, "start": offset,
                "candles.columns": "begin,open,high,low,close",
            })
            block = j.get("candles") or {}
            page = _rows(block)
            if not page:
                break
            for r in page:
                c = _finite(r.get("close"))
                if c is None:
                    continue
                o = _finite(r.get("open")) or c
                h = _finite(r.get("high")) or max(o, c)
                lo = _finite(r.get("low")) or min(o, c)
                rows.append({"date": str(r.get("begin"))[:10], "open": o, "high": h, "low": lo, "close": c})
            offset += len(page)
            if len(page) < 500:
                break
        if rows:
            tmp = path_cache.with_suffix(".tmp")
            tmp.write_text(json.dumps({"saved_at": datetime.now().isoformat(timespec="seconds"), "rows": rows}, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            tmp.replace(path_cache)
            return _load_history_file(path_cache)
    except Exception:
        pass
    # Last-good history is valid for model continuity even if older than TTL.
    return _load_history_file(path_cache)
