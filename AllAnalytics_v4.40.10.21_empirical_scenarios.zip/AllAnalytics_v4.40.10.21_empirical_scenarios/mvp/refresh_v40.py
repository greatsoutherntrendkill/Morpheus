"""AllAnalytics v4.0 — one-command market/site refresh.

Keeps expensive research benchmarks frozen; refreshes only live market data,
site snapshot, unified user forecast and alternative-data collectors.
"""
from __future__ import annotations
import subprocess, sys


def run(*args):
    cmd=[sys.executable,*args]
    print('\n>>>',' '.join(cmd))
    subprocess.run(cmd,check=True)


# v4.40.6 integrity: live forecasts come only from model_integrity_v4406 via API.
# unified_forecast_v39.py is retained as a legacy snapshot reader, not a live source.

if __name__=='__main__':
    run('update.py',*sys.argv[1:])
    run('export_site.py')
    run('update_altdata_v40.py')
    print('\nAllAnalytics v4.0: данные и пользовательский интерфейс обновлены.')
