from pathlib import Path
import numpy as np
import pandas as pd

import movement_guidance_v440102 as MG
import target_contract_v4405 as TARGET


def _close(n=700):
    idx=pd.bdate_range('2023-01-02',periods=n)
    rng=np.random.default_rng(440102)
    r=rng.normal(.00035,.012,n)
    return pd.Series(100*np.exp(np.cumsum(r)),index=idx)


def _forecast(quality=True, direction='down'):
    cond=.28 if direction=='down' else .72
    return {
        'conditional_p_up':cond,
        'p_up':cond,
        'abstain':False,
        'distribution_forecast':{
            'status':'ok','quality_ok':quality,'expected_abs_move_pct':4.2,
            'quantiles':{
                'q10_return_pct':-7.2,'q25_return_pct':-4.6,'q50_return_pct':-1.4,
                'q75_return_pct':2.8,'q90_return_pct':6.5,
            },
            'evaluation':{'effective_n':18,'coverage_80':.8,'coverage_50':.5,'pinball_skill_pct':8.0},
        }
    }


def test_material_threshold_uses_shared_target_contract():
    c=_close();h=10
    out=MG.build(c,h,_forecast())
    expected=TARGET.band_pct_for_asof(c,h)
    assert out['material_move_threshold_pct']==round(float(expected),3)
    assert out['material_threshold_recent_iqr_pct'] and len(out['material_threshold_recent_iqr_pct'])==2


def test_directional_range_is_withheld_when_distribution_quality_fails():
    out=MG.build(_close(),10,_forecast(quality=False))
    assert out['distribution_quality_ok'] is False
    assert out['directional_scenario_range'] is None
    assert out['range_status']=='research_only'


def test_validated_downside_range_comes_from_calibrated_tail_not_hardcoded_numbers():
    c=_close();out=MG.build(c,10,_forecast(quality=True,direction='down'))
    sc=out['directional_scenario_range']
    assert sc is not None and sc['direction']=='down'
    # Upper magnitude is the absolute q10 tail; lower edge cannot be below the
    # shared significant-move threshold.
    assert sc['high_pct']==7.2
    assert sc['low_pct']>=out['material_move_threshold_pct']
    assert 'q10-q25' in sc['basis']


def test_ui_explains_ranges_without_promising_point_target():
    html=Path('site/index.html').read_text(encoding='utf-8')
    for text in ['Порог значимого движения','Типичный масштаб','Направленный диапазон','Как читать прогноз','сценарный диапазон, а не обещание результата']:
        assert text in html
    assert 'новости не используются для искусственного сужения диапазона' in html
