"""AllAnalytics v3.9 — альтернативные данные.

Server-side collectors for CoinGlass, Massive Options and EIA. API keys are loaded
from .env and are never returned to the browser. Every provider fails independently:
a bad entitlement or transient outage does not take down the site.

The normalized JSON is intentionally compact and user-facing; raw vendor payloads
are not exposed. Historical arrays are retained only as much as needed for charts
and later point-in-time research.
"""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from pathlib import Path
import json, math, os, statistics, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse

import requests
from dotenv import load_dotenv

ROOT = Path(__file__).parent
SITE = ROOT / "site"
CACHE = SITE / "altdata_v39.json"
TIMEOUT = 25
CACHE_SECONDS = int(os.getenv("ALTDATA_REFRESH_SECONDS", "900"))
_CACHE_LOCK = Lock()

load_dotenv(ROOT / ".env")

CRYPTO = {
    "BTC": "BTC-USD",
    "ETH": "ETH-USD",
    "SOL": "SOL-USD",
    "XRP": "XRP-USD",
}
OPTIONS_UNDERLYINGS = {
    "SPY": {"label":"S&P 500 / SPY", "assets":["^GSPC","ES=F"]},
    "QQQ": {"label":"Nasdaq 100 / QQQ", "assets":["^NDX","NQ=F"]},
    "IWM": {"label":"Russell 2000 / IWM", "assets":["^RUT"]},
    "DIA": {"label":"Dow Jones / DIA", "assets":["^DJI"]},
    "GLD": {"label":"Gold / GLD", "assets":["GC=F"]},
    "SLV": {"label":"Silver / SLV", "assets":["SI=F"]},
    "USO": {"label":"WTI proxy / USO", "assets":["CL=F"]},
}
EIA_SERIES = {
    "wti_spot": ("PET.RWTC.D", "WTI spot", "$/bbl"),
    "henry_hub": ("NG.RNGWHHD.D", "Henry Hub", "$/MMBtu"),
    "crude_stocks": ("PET.WCESTUS1.W", "US commercial crude stocks", "thousand bbl"),
    "gas_storage": ("NG.NW2_EPG0_SWO_R48_BCF.W", "Lower-48 gas storage", "Bcf"),
    "crude_production": ("PET.WCRFPUS2.W", "US crude production", "thousand b/d"),
}


def _now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def provider_status():
    return {
        "coinglass": {"configured": bool(os.getenv("COINGLASS_API_KEY", "").strip()),
                       "label":"CoinGlass", "kind":"криптодеривативы"},
        "massive": {"configured": bool(os.getenv("OPTIONS_API_KEY", "").strip()),
                     "label":"Massive", "kind":"опционы и волатильность"},
        "eia": {"configured": bool(os.getenv("EIA_API_KEY", "").strip()),
                "label":"EIA", "kind":"энергетика"},
        "cftc": {"configured": True, "label":"CFTC", "kind":"позиционирование",
                 "note":"отдельный ключ не требуется; нормализация контрактов добавляется отдельно"},
    }


def _num(v):
    try:
        x=float(v)
        return x if math.isfinite(x) else None
    except Exception:
        return None


def _pct_change(a,b):
    a=_num(a); b=_num(b)
    if a is None or b is None or abs(b)<1e-12: return None
    return (a/b-1.0)*100.0


def _sorted_points(rows, value_key="close"):
    out=[]
    for r in rows or []:
        t=r.get("time") or r.get("timestamp") or r.get("period")
        v=_num(r.get(value_key))
        if v is None: continue
        # vendor timestamps can be seconds or milliseconds.
        if isinstance(t,(int,float)) or str(t).isdigit():
            z=float(t)
            if z>1e12: z/=1000.0
            try: ds=datetime.fromtimestamp(z,timezone.utc).date().isoformat()
            except Exception: ds=str(t)
        else:
            ds=str(t)
        out.append({"date":ds,"value":v})
    out.sort(key=lambda x:x["date"])
    return out


def _requests_json(url, *, params=None, headers=None):
    r=requests.get(url,params=params or {},headers=headers or {},timeout=TIMEOUT)
    # Do not propagate a URL because Massive/EIA API keys may be query params.
    if r.status_code >= 400:
        raise RuntimeError(f"HTTP {r.status_code}")
    return r.json()


def _cg(path, params):
    key=os.getenv("COINGLASS_API_KEY","").strip()
    if not key: raise RuntimeError("API key is not configured")
    body=_requests_json("https://open-api-v4.coinglass.com"+path,
                        params=params,headers={"CG-API-KEY":key,"accept":"application/json"})
    code=str(body.get("code"))
    if code not in ("0","200","200000"):
        msg=str(body.get("msg") or body.get("message") or "запрос отклонён")[:120]
        raise RuntimeError(f"CoinGlass: {msg} (код {code})")
    return body.get("data") or []


def _metric_call(path, params):
    """Один CoinGlass-запрос. Ошибка метрики не обнуляет остальные метрики актива."""
    try:
        return _cg(path, params), None
    except Exception as exc:
        return [], str(exc)[:140]


def _crypto_one(coin):
    oi,err_oi=_metric_call("/api/futures/open-interest/aggregated-history",
                           {"symbol":coin,"interval":"1d","limit":365,"unit":"usd"})
    funding,err_funding=_metric_call("/api/futures/funding-rate/oi-weight-history",
                                     {"symbol":coin,"interval":"1d","limit":365})
    liq,err_liq=_metric_call("/api/futures/liquidation/aggregated-history",
                             {"symbol":coin,"exchange_list":"Binance,OKX,Bybit",
                              "interval":"1d","limit":365})

    oi_pts=_sorted_points(oi,"close")
    fund_pts=_sorted_points(funding,"close")
    liq_pts=[]
    for r in liq or []:
        ts=r.get("time")
        lv=_num(r.get("aggregated_long_liquidation_usd")) or 0.0
        sv=_num(r.get("aggregated_short_liquidation_usd")) or 0.0
        if ts is None: continue
        try:
            z=float(ts)
            if z>1e12:z/=1000.0
            ds=datetime.fromtimestamp(z,timezone.utc).date().isoformat()
        except Exception:
            ds=str(ts)
        liq_pts.append({"date":ds,"long":lv,"short":sv,"total":lv+sv})
    liq_pts.sort(key=lambda x:x["date"])

    latest_oi=oi_pts[-1]["value"] if oi_pts else None
    oi_1d=oi_pts[-2]["value"] if len(oi_pts)>1 else None
    oi_7d=oi_pts[-8]["value"] if len(oi_pts)>7 else (oi_pts[0]["value"] if oi_pts else None)
    latest_f=fund_pts[-1]["value"] if fund_pts else None
    f7=[p["value"] for p in fund_pts[-7:]]
    l7=liq_pts[-7:]
    long7=sum(x["long"] for x in l7); short7=sum(x["short"] for x in l7); total7=long7+short7

    crowd="сбалансировано"
    if latest_f is not None:
        if latest_f>0.01: crowd="перевес длинных позиций"
        elif latest_f<-0.01: crowd="перевес коротких позиций"
    liq_bias="сбалансировано"
    if total7>0:
        share=long7/total7
        liq_bias="чаще ликвидировались длинные" if share>.58 else "чаще ликвидировались короткие" if share<.42 else "сбалансировано"

    errors={k:v for k,v in {"открытый интерес":err_oi,"ставка фондирования":err_funding,"ликвидации":err_liq}.items() if v}
    available={"открытый интерес":bool(oi_pts),"ставка фондирования":bool(fund_pts),"ликвидации":bool(liq_pts)}
    if not any(available.values()):
        raise RuntimeError("; ".join(f"{k}: {v}" for k,v in errors.items()) or "CoinGlass вернул пустые ответы")
    return {
        "coin":coin,"asset_symbol":CRYPTO.get(coin),
        "latest_date":max([x for x in [oi_pts[-1]["date"] if oi_pts else None,
                                        fund_pts[-1]["date"] if fund_pts else None,
                                        liq_pts[-1]["date"] if liq_pts else None] if x], default=None),
        "open_interest_usd":latest_oi,
        "oi_change_1d_pct":_pct_change(latest_oi,oi_1d),
        "oi_change_7d_pct":_pct_change(latest_oi,oi_7d),
        "funding_oi_weighted":latest_f,
        "funding_7d_avg":statistics.fmean(f7) if f7 else None,
        "crowding":crowd,
        "liquidations_24h_usd":liq_pts[-1]["total"] if liq_pts else None,
        "long_liq_24h_usd":liq_pts[-1]["long"] if liq_pts else None,
        "short_liq_24h_usd":liq_pts[-1]["short"] if liq_pts else None,
        "liquidation_bias_7d":liq_bias,
        "availability":available,"metric_errors":errors,
        "series":{"open_interest":oi_pts[-365:],"funding":fund_pts[-365:],"liquidations":liq_pts[-365:]},
    }


def fetch_coinglass():
    out={"provider":"CoinGlass","status":"ok","updated_at":_now(),"assets":{}}
    errors={}
    with ThreadPoolExecutor(max_workers=4) as ex:
        fut={ex.submit(_crypto_one,coin):coin for coin in CRYPTO}
        for f in as_completed(fut):
            coin=fut[f]
            try: out["assets"][coin]=f.result()
            except Exception as exc: errors[coin]=str(exc)[:160]
    if errors: out["errors"]=errors
    if not out["assets"]: out["status"]="error"
    elif errors or any((x.get("metric_errors") for x in out["assets"].values())): out["status"]="partial"
    return out


def _massive_page(url, key, params=None):
    # The key is kept server-side even though Massive supports it as a query parameter.
    q=dict(params or {})
    q["apiKey"]=key
    return _requests_json(url,params=q)


def _massive_chain(underlying, max_pages=3):
    key=os.getenv("OPTIONS_API_KEY","").strip()
    if not key: raise RuntimeError("API key is not configured")
    today=datetime.now(timezone.utc).date()
    end=today+timedelta(days=60)
    url=f"https://api.massive.com/v3/snapshot/options/{underlying}"
    params={"expiration_date.gte":today.isoformat(),"expiration_date.lte":end.isoformat(),
            "limit":250,"sort":"expiration_date","order":"asc"}
    rows=[]
    for _ in range(max_pages):
        body=_massive_page(url,key,params)
        if str(body.get("status","")).upper() not in ("OK","SUCCESS") and not body.get("results"):
            raise RuntimeError("provider rejected request or plan lacks option-chain access")
        rows.extend(body.get("results") or [])
        nxt=body.get("next_url")
        if not nxt: break
        # Massive next_url often omits apiKey. Parse and re-attach safely.
        url=nxt; params={}
    return rows


def _weighted_avg(vals, weights):
    pairs=[(float(v),max(float(w),0.0)) for v,w in zip(vals,weights) if _num(v) is not None and _num(w) is not None]
    sw=sum(w for _,w in pairs)
    return sum(v*w for v,w in pairs)/sw if sw>0 else (statistics.fmean(v for v,_ in pairs) if pairs else None)


def _options_one(underlying):
    rows=_massive_chain(underlying)
    parsed=[]; underlying_px=None
    for r in rows:
        d=r.get("details") or {}; g=r.get("greeks") or {}; ua=r.get("underlying_asset") or {}
        typ=d.get("contract_type"); exp=d.get("expiration_date"); strike=_num(d.get("strike_price"))
        iv=_num(r.get("implied_volatility")); oi=_num(r.get("open_interest")) or 0.0
        delta=_num(g.get("delta")); gamma=_num(g.get("gamma")); vega=_num(g.get("vega"))
        px=_num(ua.get("price")); underlying_px=px or underlying_px
        if typ not in ("call","put") or not exp or strike is None: continue
        parsed.append({"type":typ,"expiration":exp,"strike":strike,"iv":iv,"oi":oi,
                       "delta":delta,"gamma":gamma,"vega":vega})
    if not parsed: raise RuntimeError("option chain returned no usable contracts")
    call_oi=sum(r["oi"] for r in parsed if r["type"]=="call")
    put_oi=sum(r["oi"] for r in parsed if r["type"]=="put")
    ratio=put_oi/call_oi if call_oi>0 else None
    ivs=[r["iv"] for r in parsed if r["iv"] is not None]
    iv_med=statistics.median(ivs) if ivs else None

    # Near-30d 25-delta risk reversal: put IV - call IV. Positive = downside skew richer.
    today=datetime.now(timezone.utc).date()
    exps=sorted({r["expiration"] for r in parsed})
    exp30=min(exps,key=lambda s:abs((datetime.fromisoformat(s).date()-today).days-30)) if exps else None
    bucket=[r for r in parsed if r["expiration"]==exp30]
    call25=min((r for r in bucket if r["type"]=="call" and r["delta"] is not None and r["iv"] is not None),
               key=lambda r:abs(r["delta"]-.25),default=None)
    put25=min((r for r in bucket if r["type"]=="put" and r["delta"] is not None and r["iv"] is not None),
              key=lambda r:abs(r["delta"]+.25),default=None)
    skew=(put25["iv"]-call25["iv"]) if call25 and put25 else None

    # Term structure: OI-weighted IV by expiry.
    term=[]
    for exp in exps[:12]:
        b=[r for r in parsed if r["expiration"]==exp and r["iv"] is not None]
        if not b: continue
        term.append({"expiration":exp,"iv":_weighted_avg([r["iv"] for r in b],[max(r["oi"],1) for r in b]),
                     "open_interest":sum(r["oi"] for r in b)})
    # Top strike concentration by combined OI.
    bystrike={}
    for r in parsed:
        z=bystrike.setdefault(r["strike"],{"call":0.0,"put":0.0})
        z[r["type"]]+=r["oi"]
    top=[]
    for strike,z in bystrike.items():
        top.append({"strike":strike,"call_oi":z["call"],"put_oi":z["put"],"total_oi":z["call"]+z["put"]})
    top=sorted(top,key=lambda x:x["total_oi"],reverse=True)[:15]

    gross_gamma=0.0
    if underlying_px:
        for r in parsed:
            if r["gamma"] is not None:
                gross_gamma += abs(r["gamma"])*r["oi"]*100*(underlying_px**2)/1e6

    sentiment="balanced"
    if ratio is not None:
        sentiment="defensive" if ratio>1.15 else "call-heavy" if ratio<.75 else "balanced"
    return {
        "underlying":underlying,"label":OPTIONS_UNDERLYINGS[underlying]["label"],
        "linked_assets":OPTIONS_UNDERLYINGS[underlying]["assets"],"underlying_price":underlying_px,
        "contracts_sampled":len(parsed),"call_open_interest":call_oi,"put_open_interest":put_oi,
        "put_call_oi_ratio":ratio,"median_iv":iv_med,"nearest_30d_expiration":exp30,
        "skew_25d_put_minus_call":skew,"gross_gamma_intensity_musd":gross_gamma or None,
        "sentiment":sentiment,"term_structure":term,"top_strikes":top,
    }


def fetch_massive():
    out={"provider":"Massive Options","status":"ok","updated_at":_now(),"underlyings":{}}
    errors={}
    with ThreadPoolExecutor(max_workers=3) as ex:
        fut={ex.submit(_options_one,u):u for u in OPTIONS_UNDERLYINGS}
        for f in as_completed(fut):
            u=fut[f]
            try: out["underlyings"][u]=f.result()
            except Exception as e: errors[u]=str(e)[:100]
    if errors: out["errors"]=errors
    if not out["underlyings"]: out["status"]="error"
    return out


def _eia_series(series_id):
    key=os.getenv("EIA_API_KEY","").strip()
    if not key: raise RuntimeError("API key is not configured")
    body=_requests_json(f"https://api.eia.gov/v2/seriesid/{series_id}",
                        params={"api_key":key,"length":400,"sort[0][column]":"period","sort[0][direction]":"desc"})
    response=body.get("response") or {}
    rows=response.get("data") or []
    pts=[]
    for r in rows:
        val=_num(r.get("value")); per=r.get("period")
        if val is None or per is None: continue
        pts.append({"date":str(per),"value":val})
    pts.sort(key=lambda x:x["date"])
    return pts


def fetch_eia():
    out={"provider":"EIA","status":"ok","updated_at":_now(),"series":{}}
    errors={}
    def one(key,sid,label,unit):
        pts=_eia_series(sid)
        if not pts: raise RuntimeError("empty series")
        cur=pts[-1]["value"]; prev=pts[-2]["value"] if len(pts)>1 else None
        old=pts[-53]["value"] if len(pts)>52 else (pts[0]["value"] if pts else None)
        return {"series_id":sid,"label":label,"unit":unit,"latest_date":pts[-1]["date"],
                "latest":cur,"change_prev":None if prev is None else cur-prev,
                "change_prev_pct":_pct_change(cur,prev),"change_1y_pct":_pct_change(cur,old),
                "history":pts[-120:]}
    with ThreadPoolExecutor(max_workers=3) as ex:
        fut={ex.submit(one,key,sid,label,unit):key for key,(sid,label,unit) in EIA_SERIES.items()}
        for f in as_completed(fut):
            key=fut[f]
            try: out["series"][key]=f.result()
            except Exception as e: errors[key]=str(e)[:80]
    if errors: out["errors"]=errors
    if not out["series"]: out["status"]="error"
    return out


def _load_cache():
    try: return json.loads(CACHE.read_text(encoding="utf-8"))
    except Exception: return {}


def _digest(snapshot):
    lines=[]
    crypto=(snapshot.get("crypto") or {}).get("assets") or {}
    if crypto:
        btc=crypto.get("BTC") or next(iter(crypto.values()))
        oi=btc.get("oi_change_7d_pct"); funding=btc.get("funding_oi_weighted")
        if oi is not None:
            lines.append(f"В криптодеривативах открытый интерес за 7 дней {'вырос' if oi>=0 else 'снизился'} на {abs(oi):.1f}%.")
        if funding is not None:
            lines.append("Ставка фондирования положительная — длинные позиции платят коротким." if funding>0 else "Ставка фондирования отрицательная — короткие позиции платят длинным.")
    ops=(snapshot.get("options") or {}).get("underlyings") or {}
    if ops:
        spy=ops.get("SPY") or next(iter(ops.values()))
        ratio=spy.get("put_call_oi_ratio")
        if ratio is not None:
            lines.append("В опционах на американский рынок заметен защитный спрос." if ratio>1.05 else "Опционный рынок не показывает выраженного защитного перекоса." if ratio>=.75 else "В опционах преобладает спрос на коллы.")
    energy=(snapshot.get("energy") or {}).get("series") or {}
    crude=energy.get("crude_stocks")
    if crude and crude.get("change_prev") is not None:
        ch=crude["change_prev"]
        lines.append(f"Коммерческие запасы нефти в США {'увеличились' if ch>0 else 'сократились'} на {abs(ch):,.0f} тыс. баррелей к прошлой публикации.".replace(',', ' '))
    if not lines:
        lines.append("Часть поставщиков пока не вернула данные. Интерфейс сохраняет последнюю успешную сводку и показывает источник проблемы отдельно.")
    return lines[:5]


def build_snapshot(force=False, provider=None):
    old=_load_cache()
    provider=(provider or '').strip().lower() or None
    if not force and provider is None and old.get("generated_unix") and time.time()-float(old["generated_unix"])<CACHE_SECONDS:
        return old
    status=provider_status()
    snap={"version":"3.9","generated_at":_now(),"generated_unix":time.time(),
          "refresh_seconds":CACHE_SECONDS,"providers":status,
          "crypto":old.get("crypto",{}),"options":old.get("options",{}),"energy":old.get("energy",{}),
          "cftc":old.get("cftc") or {"status":"готово к подключению","message":"Для CFTC отдельный ключ не требуется; требуется только нормализация контрактов."}}
    jobs=[("crypto","coinglass",fetch_coinglass),("options","massive",fetch_massive),("energy","eia",fetch_eia)]
    if provider:
        jobs=[j for j in jobs if j[1]==provider or j[0]==provider]
        if not jobs:
            raise ValueError("неизвестный поставщик")
    for section,prov,fn in jobs:
        snap.setdefault("attempts",{})[prov]=_now()
        if not status[prov]["configured"]:
            snap[section]={"provider":status[prov]["label"],"status":"not_configured","updated_at":None,
                           "message":"Ключ не настроен"}
            continue
        try:
            fresh=fn()
            has_data=bool(fresh.get("assets") or fresh.get("underlyings") or fresh.get("series"))
            if fresh.get("status") in ("ok","partial") or has_data:
                fresh["last_success_at"]=_now() if has_data else None
                snap[section]=fresh
            else:
                prev=old.get(section) or {}
                if prev and (prev.get("assets") or prev.get("underlyings") or prev.get("series")):
                    prev=dict(prev); prev["stale"]=True; prev["last_refresh_error"]=fresh.get("errors") or fresh.get("error") or "ошибка поставщика"
                    snap[section]=prev
                else:
                    snap[section]=fresh
        except Exception as exc:
            prev=old.get(section) or {}
            if prev and (prev.get("assets") or prev.get("underlyings") or prev.get("series")):
                prev=dict(prev); prev["stale"]=True; prev["last_refresh_error"]=str(exc)[:180]
                snap[section]=prev
            else:
                snap[section]={"provider":status[prov]["label"],"status":"error","error":str(exc)[:180],"updated_at":None}
    # Provider-specific refreshes may run concurrently from the browser. Merge the
    # latest other sections under a short lock so the last completed request cannot
    # erase data written by another provider a moment earlier.
    with _CACHE_LOCK:
        if provider:
            latest=_load_cache()
            refreshed={section for section,prov,_ in jobs}
            for sec in ("crypto","options","energy","cftc"):
                if sec not in refreshed and latest.get(sec):
                    snap[sec]=latest.get(sec)
            snap["providers"]=status
        snap["generated_at"]=_now(); snap["generated_unix"]=time.time()
        snap["digest"]=_digest(snap)
        SITE.mkdir(parents=True,exist_ok=True)
        CACHE.write_text(json.dumps(snap,ensure_ascii=False,indent=2),encoding="utf-8")
    return snap


def asset_altdata(snapshot, symbol):
    out={"symbol":symbol}
    # crypto mapping
    for coin,ysym in CRYPTO.items():
        if ysym==symbol:
            out["crypto"]=(snapshot.get("crypto") or {}).get("assets",{}).get(coin)
    # options proxy mapping
    for u,meta in OPTIONS_UNDERLYINGS.items():
        if symbol in meta["assets"]:
            out.setdefault("options",[]).append((snapshot.get("options") or {}).get("underlyings",{}).get(u))
    if symbol in ("CL=F","NG=F"):
        out["energy"]=snapshot.get("energy")
    return out


if __name__=="__main__":
    s=build_snapshot(force=True)
    print(json.dumps({"version":s.get("version"),"generated_at":s.get("generated_at"),
                      "crypto_status":(s.get("crypto") or {}).get("status"),
                      "options_status":(s.get("options") or {}).get("status"),
                      "energy_status":(s.get("energy") or {}).get("status")},ensure_ascii=False,indent=2))
