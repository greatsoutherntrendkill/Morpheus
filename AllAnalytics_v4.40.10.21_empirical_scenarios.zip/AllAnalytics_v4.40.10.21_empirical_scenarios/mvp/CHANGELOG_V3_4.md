# AllAnalytics v3.4 — Full-Universe Model Selection

v3.4 completes the first real model-selection cycle after the v3.2 governance
foundation and the v3.3 champion/challenger plumbing.

## Full-universe evidence

The locked benchmark was run over all 33 configured assets and all four horizons
(1/5/10/20 trading days): 132 comparable frozen-holdout tests, 0 execution errors.

Champion:
- `logreg-v3.2.0`

Challengers:
- `lightgbm-v3.3.0`
- `catboost-v3.3.0`

All models use the same point-in-time features, labels, purged walk-forward splits,
frozen final holdout and baseline probabilities. The final holdout is never used
for model tuning.

## New diagnostics

- Full-universe benchmark JSON/CSV.
- Holdout reliability buckets.
- Platt calibration fitted only on development OOS predictions and then evaluated
  on the untouched holdout.
- Frozen-model feature importance.
- Paired block-bootstrap challenger-vs-champion deltas.
- Holm-Bonferroni correction across the benchmark family.
- 1D economic metrics after 2 bps one-way costs.
- Explicit immutable model-governance decision.
- `/api/model-benchmark` now prefers the v3.4 benchmark.
- New `/api/model-decision`.

## Decision

**Keep Logistic Regression (`logreg-v3.2.0`) as production champion.**

LightGBM:
- 132 comparable holdout tests;
- 0 Holm-significant Brier wins;
- 0 Holm-significant losses;
- median paired Brier improvement: +0.004335;
- median paired 1D net-Sharpe delta: +0.1081;
- fails the predeclared statistical promotion gate.

CatBoost:
- 132 comparable holdout tests;
- 0 Holm-significant Brier wins;
- 0 Holm-significant losses;
- median paired Brier improvement: +0.020141;
- median paired 1D net-Sharpe delta: -0.0212;
- fails both the statistical and economic promotion gates.

The nonlinear models remain shadow challengers. Their live predictions stay in
the immutable ledger. This holdout must not be recycled into hyperparameter tuning.

## Run

```bash
python benchmark_v34.py
python decision_v34.py
python test_decision_v34.py
python test_challenger_v33.py
python test_model_governance.py
python smoke_test.py
uvicorn api:app --reload --port 8000
```

Model diagnostics UI: open `http://127.0.0.1:8000/model_lab.html` after starting FastAPI.
