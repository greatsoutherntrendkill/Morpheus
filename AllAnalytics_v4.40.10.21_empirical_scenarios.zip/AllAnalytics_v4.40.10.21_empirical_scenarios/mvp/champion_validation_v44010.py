"""AllAnalytics v4.40.10 — champion solver and chronological regularization selection.

This module is intentionally dependency-light beyond sklearn/numpy. It never sees
future rows: C is selected on a chronological validation tail cut from the legal
training sample and training rows whose label_end overlaps the validation start
are purged.
"""
from __future__ import annotations
import os
import numpy as np
import pandas as pd

VERSION = "champion-validation-v4.40.10"
SOLVER_VERSION = "sklearn-lbfgs-l2-v4.40.10"
C_GRID = (0.03, 0.10, 0.30, 1.0, 3.0)
DEFAULT_C = 0.30


class SelectedLogReg:
    """Small sklearn LogisticRegression adapter with deterministic preprocessing."""
    def __init__(self, C: float = DEFAULT_C, seed: int = 44010, max_iter: int = 900):
        self.C=float(C); self.seed=int(seed); self.max_iter=int(max_iter)
        self.med=None; self.mu=None; self.sd=None; self.model=None

    def _prep_fit(self, X):
        X=np.asarray(X,float)
        med=np.nanmedian(X,axis=0); med=np.where(np.isfinite(med),med,0.0)
        z=np.where(np.isfinite(X),X,med)
        mu=z.mean(0); sd=z.std(0); sd=np.where(sd>1e-9,sd,1.0)
        self.med,self.mu,self.sd=med,mu,sd
        return (z-mu)/sd

    def _prep(self, X):
        X=np.asarray(X,float)
        z=np.where(np.isfinite(X),X,self.med)
        return (z-self.mu)/self.sd

    def fit(self, X, y):
        from sklearn.linear_model import LogisticRegression
        y=np.asarray(y,int)
        z=self._prep_fit(X)
        self.model=LogisticRegression(
            C=self.C, solver="lbfgs", max_iter=self.max_iter,
            random_state=self.seed, class_weight=None,
        )
        self.model.fit(z,y)
        return self

    def proba(self, X):
        return np.asarray(self.model.predict_proba(self._prep(X))[:,1],float)

    @property
    def converged(self):
        try:return bool(np.max(self.model.n_iter_) < self.max_iter)
        except Exception:return None


def _brier(p,y):
    p=np.asarray(p,float); y=np.asarray(y,float)
    return float(np.mean((p-y)**2)) if len(y) else float("nan")


def fit_chronological_selected(X, y, *, dates=None, label_ends=None,
                               c_grid=C_GRID, default_c=DEFAULT_C,
                               min_validation: int=30, min_fit: int=80,
                               seed: int=44010):
    """Fit production logistic model after nested chronological C selection.

    Selection is performed only inside the supplied legal training sample. The
    final model is then refit on the whole supplied legal sample with selected C.
    """
    X=np.asarray(X,float); y=np.asarray(y,int)
    n=len(y)
    diag={"version":VERSION,"solver":SOLVER_VERSION,"selected_c":float(default_c),
          "selection_used":False,"selection_brier":None,"candidates":[],
          "fit_n":int(n),"validation_n":0,"purged_inner_split":False}
    if n < max(min_fit+min_validation, 120) or len(np.unique(y))<2:
        mdl=SelectedLogReg(default_c,seed=seed).fit(X,y)
        diag["converged"]=mdl.converged; diag["reason"]="insufficient_nested_sample"
        return mdl,diag

    if dates is None or label_ends is None:
        mdl=SelectedLogReg(default_c,seed=seed).fit(X,y)
        diag['reason']='missing_temporal_metadata_no_selection'
        diag['converged']=mdl.converged
        return mdl,diag
    ds=pd.to_datetime(np.asarray(dates),errors="coerce") if not np.issubdtype(np.asarray(dates).dtype,np.number) else np.asarray(dates)
    order=np.argsort(ds)
    Xo,yo=X[order],y[order]
    dso=np.asarray(ds)[order]
    les=None
    if label_ends is not None:
        les=pd.to_datetime(np.asarray(label_ends),errors="coerce").to_numpy()[order]

    # Use a recent 22% validation tail, while keeping enough fitting history.
    cut=max(int(len(order)*0.78), min_fit)
    cut=min(cut, len(order)-min_validation)
    if cut < min_fit or len(order)-cut < min_validation:
        mdl=SelectedLogReg(default_c,seed=seed).fit(X,y)
        diag["converged"]=mdl.converged; diag["reason"]="insufficient_validation_tail"
        return mdl,diag

    cut=int(np.searchsorted(dso,dso[cut],side="left"))
    val_idx=np.arange(cut,len(order))
    train_idx=np.arange(0,cut)
    if les is not None and not np.issubdtype(np.asarray(dso).dtype,np.number):
        val_start=pd.Timestamp(dso[cut])
        keep=np.asarray([pd.Timestamp(v)<val_start if not pd.isna(v) else False for v in les[:cut]],bool)
        train_idx=train_idx[keep]
        diag["purged_inner_split"]=True
    if len(train_idx)<min_fit or len(np.unique(yo[train_idx]))<2 or len(np.unique(yo[val_idx]))<2:
        mdl=SelectedLogReg(default_c,seed=seed).fit(X,y)
        diag["converged"]=mdl.converged; diag["reason"]="inner_split_not_identifiable"
        return mdl,diag

    scored=[]
    for j,c in enumerate(c_grid):
        try:
            m=SelectedLogReg(float(c),seed=seed+j).fit(Xo[train_idx],yo[train_idx])
            p=m.proba(Xo[val_idx]); b=_brier(p,yo[val_idx])
            scored.append((b,float(c),m.converged))
            diag["candidates"].append({"c":float(c),"brier":round(float(b),8),"converged":m.converged})
        except Exception as exc:
            diag["candidates"].append({"c":float(c),"error":type(exc).__name__})
    if scored:
        scored.sort(key=lambda z:(z[0],abs(np.log10(z[1])-np.log10(default_c))))
        best_b,best_c,_=scored[0]
        diag.update({"selected_c":best_c,"selection_used":True,"selection_brier":round(best_b,8),
                     "fit_n":int(len(train_idx)),"validation_n":int(len(val_idx)),"reason":"chronological_nested_brier"})
    else:
        best_c=float(default_c); diag["reason"]="all_candidates_failed"
    mdl=SelectedLogReg(best_c,seed=seed+99).fit(X,y)
    diag["converged"]=mdl.converged
    return mdl,diag
