import numpy as np
import pandas as pd

import dynamic_ensemble_v435 as D
import equity_forecast_v416 as E
import model_registry as MR


def series(seed=435,n=760):
    rng=np.random.default_rng(seed)
    idx=pd.bdate_range(end=pd.Timestamp('2026-09-11'),periods=n)
    return pd.Series(100*np.exp(np.cumsum(rng.normal(.0003,.010,n))),index=idx)


def oos_rows(n=220):
    rng=np.random.default_rng(99)
    dates=pd.bdate_range(end='2026-08-31',periods=n)
    y=(rng.random(n)>.48).astype(int)
    pc=np.clip(.5+(y-.5)*.28+rng.normal(0,.16,n),.04,.96)
    pq=np.clip(.5+(y-.5)*.22+rng.normal(0,.18,n),.04,.96)
    regimes=np.where(np.arange(n)%3==0,'trend_up|normal_vol','transition|normal_vol')
    c=[{'date':str(d.date()),'p_up':float(p),'y':int(t)} for d,p,t in zip(dates,pc,y)]
    q=[{'date':str(d.date()),'p_up':float(p),'y':int(t),'state':1 if t else -1,'regime':str(r)} for d,p,t,r in zip(dates,pq,y,regimes)]
    return c,q


def base_v434():
    c,q=oos_rows()
    champion={'live_p_up':.64,'quality':{'trusted':True},'oos_records':c,'scorecard':{'Наблюдений (effective)':80}}
    challenger={'p_up':.61,'quality':{'trusted':True},'regime':'transition|normal_vol','oos_records':q,'scorecard':{'directional_effective_n':75}}
    base_meta={'champion':champion,'challenger':challenger}
    return {
        'p_up':.63,'p_down':.37,'abstain':False,'signal_strength':'умеренный','signal_threshold':.57,
        'regime':'transition|normal_vol','quality':{'trusted':True},'components':[],
        'base_meta':base_meta,'feature_version':'context-event-features-v4.34.0',
        'context_features':{'relative_strength_20d':.03,'breadth_20d':.62,'feature_drift':{'score':.1}},
        'event_context':{'risk_score':.1,'directional_bias':.1},'event_risk':.1,'event_bias':.1,
        'feature_drift':{'score':.1},'scorecard':{'p_neutral':.18},'validation':{}
    }


def context():
    return {'market':{},'event':{},'context_score':.2,'event_bias':.1,'event_risk':.1,'drift_score':.1,'coverage':.9,'context_confidence':.8}


def test_dynamic_meta_learns_from_aligned_oos(monkeypatch):
    monkeypatch.setattr(D.META434,'forecast_horizon',lambda *a,**k:base_v434())
    monkeypatch.setattr(D.FE434,'build_context',lambda *a,**k:context())
    out=D.forecast_horizon(series(),'AAPL',10,True)
    assert out['version']=='dynamic-meta-ensemble-v4.35.0'
    assert out['meta_learning']['aligned_oos_n'] >= 90
    assert abs(sum(out['dynamic_weights'].values())-1) < 1e-6
    assert 0.02 <= out['p_up'] <= .98
    assert 0 <= out['reliability']['probability'] <= 1
    assert .53 <= out['signal_threshold'] <= .74
    assert out['validation']['meta_training_uses_component_oos_only'] is True
    assert out['context_weight_status']=='advisory_until_v4.36_prospective_validation'


def test_threshold_requires_positive_oos_edge():
    p=np.array([.7,.3,.7,.3,.7,.3]*5)
    y=1-(p>=.5).astype(int)
    th,diag=D._empirical_threshold(p,y,.58)
    assert th >= .66
    assert diag['source']=='no_positive_oos_edge'


def test_reliability_shrinks_bad_meta_call(monkeypatch):
    b=base_v434()
    monkeypatch.setattr(D.META434,'forecast_horizon',lambda *a,**k:b)
    monkeypatch.setattr(D.FE434,'build_context',lambda *a,**k:context())
    monkeypatch.setattr(D,'_reliability_model',lambda *a,**k:{'probability':.30,'trained':False,'n':40})
    out=D.forecast_horizon(series(),'AAPL',10,True)
    assert out['abstain'] is True or out['reliability']['probability'] < .56
    assert abs(out['p_up']-.5) <= .35


def test_equity_pipeline_uses_v435(monkeypatch,tmp_path):
    s=series(n=720);c=s.to_numpy(float)
    d=pd.DataFrame({'date':s.index,'open':c,'high':c*1.003,'low':c*.997,'close':c})
    monkeypatch.setattr(E,'FAST_DISK_DIR',tmp_path/'fast');E.FAST_DISK_DIR.mkdir(parents=True,exist_ok=True)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(d.copy(),'history mock',[]))
    fake={
        'version':'dynamic-meta-ensemble-v4.35.0','p_up':.62,'p_down':.38,'abstain':False,'signal_strength':'умеренный',
        'signal_threshold':.57,'regime':'transition|normal_vol','quality':{'trusted':True,'confidence':'средняя'},
        'components':[{'name':'production','p_up':.61,'weight':.6},{'name':'vol_regime','p_up':.63,'weight':.4}],
        'dynamic_weights':{'production':.6,'vol_regime':.4},'reliability':{'probability':.64,'trained':True},
        'meta_learning':{'used':True,'aligned_oos_n':120},'threshold_selection':{'source':'development_oos','final_threshold':.57},
        'scorecard':{'p_neutral':.2},'validation':{},'context_features':{},'event_context':{},'feature_drift':{}
    }
    monkeypatch.setattr(E.META435,'forecast_horizon',lambda *a,**k:fake)
    row=E.forecast_fast('AAPL',(10,),force=True)
    assert row['profile']=='fast-ui-v435'
    f=row['forecasts']['10']
    assert f['model_version']=='dynamic-meta-ensemble-v4.35.0'
    assert f['dynamic_weights']['production']==.6
    assert f['reliability']['probability']==.64


def test_registry_has_v435_contract(tmp_path):
    import sqlite3
    con=sqlite3.connect(tmp_path/'registry.db')
    try:
        MR.register_champion(con);MR.register_v433_models(con);MR.register_v434_models(con);MR.register_v435_models(con)
        rows={r[0] for r in con.execute('select model_version from model_registry')}
        assert MR.V435_DYNAMIC_VERSION in rows
        assert MR.V435_RELIABILITY_VERSION in rows
    finally:
        con.close()


def test_api_and_ui_expose_v435():
    from pathlib import Path
    root=Path(__file__).parent
    api=(root/'api.py').read_text(encoding='utf-8')
    eq=(root/'equity_forecast_v416.py').read_text(encoding='utf-8')
    tech=(root/'site'/'technical_lab_v411.html').read_text(encoding='utf-8')
    assert '/api/models/quality-v435' in api
    assert 'META435.forecast_horizon' in eq
    assert 'dynamic_weights' in tech
    assert 'reliability' in tech
    assert 'threshold_selection' in tech
