# AllAnalytics v4.40.7 — Model Robustness

- Added feature/data freshness guard with confidence shrink and hard abstention for materially stale inputs.
- Replaced user-action-dependent equity peer routing with a synchronized local database universe.
- Added soft regime probabilities and uncertainty-aware confidence shrink instead of brittle hard boundary behavior.
- Added independent Directional ↔ Distribution consistency gate; strong contradiction can produce NO EDGE.
- New generation: `directional-3state-move-robust-v4.40.7`.
- Fixed `export_site.py` CLI completion: after a successful static export it explicitly terminates so optional background workers cannot keep startup hanging.
- v4.40.8 Data-Driven Routing remains the next roadmap stage.
