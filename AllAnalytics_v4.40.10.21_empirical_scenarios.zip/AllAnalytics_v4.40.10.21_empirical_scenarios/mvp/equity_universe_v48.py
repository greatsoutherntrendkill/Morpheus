"""AllAnalytics v4.8 — динамический universe для Valuation Sandbox.

NYSE:
- Massive reference tickers, если доступен OPTIONS_API_KEY/MASSIVE_API_KEY;
- бесплатный Nasdaq Trader symbol directory как fallback.

MOEX:
- MOEX ISS, без ключа.

Списки кэшируются на диске, поэтому повторная загрузка не блокирует UI.
"""
from __future__ import annotations

from pathlib import Path
import json, os, time
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
import requests

ROOT=Path(__file__).parent
CACHE_DIR=ROOT/"runtime_cache"
CACHE_DIR.mkdir(exist_ok=True)
CACHE=CACHE_DIR/"equity_universe_v48.json"
TTL=max(3600,int(os.getenv("EQUITY_UNIVERSE_TTL_SECONDS","86400")))
TIMEOUT=float(os.getenv("EQUITY_UNIVERSE_TIMEOUT_SECONDS","5"))

FALLBACK=[
 {"ticker":"AAPL","name":"Apple Inc.","exchange":"NYSE/US","market":"US","source":"preset"},
 {"ticker":"MSFT","name":"Microsoft Corp.","exchange":"NYSE/US","market":"US","source":"preset"},
 {"ticker":"KO","name":"Coca-Cola Co.","exchange":"NYSE","market":"US","source":"preset"},
 {"ticker":"JPM","name":"JPMorgan Chase & Co.","exchange":"NYSE","market":"US","source":"preset"},
 {"ticker":"SBER","name":"Сбербанк","exchange":"MOEX","market":"RU","source":"preset"},
 {"ticker":"GAZP","name":"Газпром","exchange":"MOEX","market":"RU","source":"preset"},
 {"ticker":"LKOH","name":"ЛУКОЙЛ","exchange":"MOEX","market":"RU","source":"preset"},
 {"ticker":"YDEX","name":"Яндекс","exchange":"MOEX","market":"RU","source":"preset"},
]

def _load_cache():
    try:
        d=json.loads(CACHE.read_text(encoding="utf-8"))
        if time.time()-float(d.get("ts",0))<TTL and d.get("rows"):
            return d
    except Exception:
        pass
    return None

def _save(rows,sources):
    try:CACHE.write_text(json.dumps({"ts":time.time(),"rows":rows,"sources":sources},ensure_ascii=False),encoding="utf-8")
    except Exception:pass

def _massive_key():
    return os.getenv("MASSIVE_API_KEY") or os.getenv("OPTIONS_API_KEY") or ""

def _append_key(url,key):
    p=urlparse(url);q=parse_qs(p.query);q["apiKey"]=[key]
    return urlunparse((p.scheme,p.netloc,p.path,p.params,urlencode(q,doseq=True),p.fragment))

def nyse_massive():
    key=_massive_key()
    if not key:return [],""
    rows=[]
    url="https://api.massive.com/v3/reference/tickers?market=stocks&locale=us&active=true&type=CS&limit=1000&order=asc&sort=ticker"
    for _ in range(8):
        r=requests.get(_append_key(url,key),timeout=TIMEOUT)
        if r.status_code!=200:raise RuntimeError(f"Massive HTTP {r.status_code}")
        j=r.json()
        for x in j.get("results") or []:
            t=str(x.get("ticker") or "").strip()
            if t:
                rows.append({"ticker":t,"name":x.get("name") or t,"exchange":x.get("primary_exchange") or "US","market":"US","source":"Massive","cik":x.get("cik")})
        url=j.get("next_url")
        if not url:break
    return rows,"Massive / US common stocks"

def nyse_nasdaqtrader():
    # Бесплатный официальный symbol directory: Nasdaq + NYSE/NYSE American/Arca.
    out=[]
    try:
        r=requests.get("https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqlisted.txt",timeout=TIMEOUT);r.raise_for_status();lines=r.text.splitlines();head=lines[0].split("|");idx={k:i for i,k in enumerate(head)}
        for line in lines[1:]:
            if not line or line.startswith("File Creation Time"):continue
            c=line.split("|");t=c[idx.get("Symbol",0)].strip();name=c[idx.get("Security Name",1)].strip();etf=c[idx.get("ETF",-1)] if idx.get("ETF",-1)>=0 and idx.get("ETF",-1)<len(c) else "N";test=c[idx.get("Test Issue",-1)] if idx.get("Test Issue",-1)>=0 and idx.get("Test Issue",-1)<len(c) else "N"
            if t and etf!="Y" and test!="Y":out.append({"ticker":t,"name":name or t,"exchange":"NASDAQ","market":"US","source":"Nasdaq Trader"})
    except Exception:pass
    r=requests.get("https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt",timeout=TIMEOUT);r.raise_for_status();lines=r.text.splitlines();head=lines[0].split("|");idx={k:i for i,k in enumerate(head)}
    exch={"N":"NYSE","A":"NYSE American","P":"NYSE Arca","Z":"Cboe BZX","V":"IEX"}
    for line in lines[1:]:
        if not line or line.startswith("File Creation Time"):continue
        c=line.split("|")
        try:
            code=c[idx.get("Exchange",2)];t=c[idx.get("ACT Symbol",0)].strip();name=c[idx.get("Security Name",1)].strip();etf=c[idx.get("ETF",-1)] if idx.get("ETF",-1)>=0 and idx.get("ETF",-1)<len(c) else "N";test=c[idx.get("Test Issue",-1)] if idx.get("Test Issue",-1)>=0 and idx.get("Test Issue",-1)<len(c) else "N"
            if t and etf!="Y" and test!="Y":out.append({"ticker":t,"name":name or t,"exchange":exch.get(code,code or "US"),"market":"US","source":"Nasdaq Trader"})
        except Exception:continue
    return out,"Nasdaq Trader / US listings"

def moex_iss():
    url=("https://iss.moex.com/iss/engines/stock/markets/shares/securities.json"
         "?iss.meta=off&iss.only=securities&securities.columns=SECID,SHORTNAME,ISIN,PRIMARY_BOARDID")
    r=requests.get(url,timeout=TIMEOUT);r.raise_for_status();j=r.json();b=j.get("securities") or {}
    cols=b.get("columns") or [];out=[]
    for row in b.get("data") or []:
        x=dict(zip(cols,row));t=str(x.get("SECID") or "").strip();board=str(x.get("PRIMARY_BOARDID") or "")
        if not t or not board.startswith("TQ"):continue
        out.append({"ticker":t,"name":x.get("SHORTNAME") or t,"exchange":"MOEX","market":"RU","source":"MOEX ISS","isin":x.get("ISIN")})
    return out,"MOEX ISS"

def universe(force=False):
    if not force:
        c=_load_cache()
        if c:return c
    sources=[];rows=[]
    try:
        ny,src=nyse_massive();rows+=ny
        if src:sources.append(src)
    except Exception:ny=[]
    if not ny:
        try:
            ny,src=nyse_nasdaqtrader();rows+=ny
            if src:sources.append(src)
        except Exception:pass
    try:
        ru,src=moex_iss();rows+=ru
        if src:sources.append(src)
    except Exception:pass
    if not rows:rows=list(FALLBACK);sources=["встроенный резервный список"]
    # unique by market+ticker
    seen=set();clean=[]
    for x in rows:
        k=(x.get("market"),x.get("ticker"))
        if k in seen:continue
        seen.add(k);clean.append(x)
    clean.sort(key=lambda x:(x.get("market")!="US",str(x.get("name") or x.get("ticker"))))
    _save(clean,sources)
    return {"ts":time.time(),"rows":clean,"sources":sources}
