# AllAnalytics v3.6 — Cross-Asset Intelligence

v3.6 adds a new model generation without replacing the frozen production champion.

## Why this version

The previous models learned each asset mostly in isolation. With roughly 600 price
rows per instrument and long-horizon overlap, the effective sample for an
individual 10D/20D model is small.

v3.6 pools all 33 public markets into a single chronological panel (~19,800
asset-date rows before target filtering).

## New research models

- `pooled-logreg-v3.6.1`
- `pooled-lightgbm-v3.6.1`

Production champion remains:
- `logreg-v3.2.0`

The pooled models are shadow challengers only.

## New feature layer

The pooled panel combines:

- local asset returns, momentum, volatility and MA-distance features;
- asset-class and region awareness;
- per-asset intercept identity;
- global equity / crypto / commodity / FX state;
- market breadth and cross-sectional dispersion;
- DXY state;
- global equity volatility;
- revision-aware point-in-time macro features;
- explicit interactions such as DXY × crypto, DXY × commodities,
  volatility × US equities / crypto, real yields × risk assets, and
  Russia rates × Russian indices.

### Cross-market timing rule

Same-calendar-day cross-market closes are **not** used directly because US and
Asian markets close at different times. Cross-market market-price features are
lagged one day before entering the panel.

## Validation

The development benchmark uses one global clock:

1. predict every available asset on date T;
2. training may contain only rows with `label_end < T`;
3. retraining uses the same global chronological split for every asset;
4. H-day overlap is handled conservatively;
5. bootstrap resampling is by global date blocks, with all assets on a date moving
   together, so cross-sectional correlation is not mistaken for independent evidence.

Calibration uses only development OOS predictions.

## Probability shrinkage

Three probabilities are retained:

- `raw_p_up` — direct model output;
- `calibrated_p_up` — Platt calibration learned only from development OOS;
- `evidence_shrunk_p_up` — main research probability.

The last probability is shrunk toward 50% according to both asset-level effective
sample size and OOS quality. Weak Brier skill / poor ECE receives stronger
shrinkage. Raw output is never deleted.

## New prospective holdout

The v3.4 benchmark already examined all packaged history through 2026-09-04.
Therefore it would be dishonest to call any subset of that same history a "new"
final holdout.

v3.6 instead freezes a **prospective holdout beginning 2026-09-08**, after the
packaged data cutoff.

At package time:
- realized prospective holdout observations: **0**
- holdout used for tuning: **No**

Future `build_cross_asset_v36.py` runs reconstruct the same frozen pre-holdout
model and evaluate newly realized post-2026-09-08 rows without refitting on them.

## Current development evidence

The pooled models are not promoted from development results.

Notably, Pooled LightGBM has positive point Brier skill on some horizons,
including 10D/20D, while time-cluster confidence intervals remain too uncertain
for a production promotion decision. Calibration materially reduces extreme raw
probabilities.

This is exactly why the new prospective holdout exists.

## Files / endpoints

- `cross_asset_models.py`
- `build_cross_asset_v36.py`
- `refresh_v36.py`
- `site/cross_asset_v36.json`
- `cross_asset_v36.csv`
- `site/cross_asset_lab_v36.html`
- `GET /api/cross-asset-model`
