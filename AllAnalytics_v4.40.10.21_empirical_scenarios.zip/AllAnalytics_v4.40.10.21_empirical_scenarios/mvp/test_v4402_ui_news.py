from pathlib import Path

HTML = (Path(__file__).parent / "site" / "index.html").read_text(encoding="utf-8")


def test_overview_dropdown_is_above_forecast_body_and_keyboard_accessible():
    assert ".forecast-card>.panel-head{position:relative;z-index:24" in HTML
    assert ".forecast-card .ov-select.is-open{z-index:90}" in HTML
    assert "e.key==='ArrowDown'||e.key==='ArrowUp'" in HTML
    assert "closeOverviewFancySelectV4402" in HTML


def test_news_visual_uses_api_image_and_green_treatment():
    assert "function newsImageUrlV4402" in HTML
    assert "r.image||r.image_url||r.urlToImage" in HTML
    assert "filter:grayscale(1)" in HTML
    assert "mix-blend-mode:color" in HTML
    assert "news-visual-badge" in HTML


def test_news_reader_has_speed_and_mobile_guards():
    assert "setTimeout(()=>ctl.abort(),5500)" in HTML
    assert "navigator.connection?.saveData" in HTML
    assert "requestIdleCallback" in HTML
    assert "bindNewsMobilityV4402" in HTML
    assert "pointerdown" in HTML and "pointerup" in HTML


def test_news_urls_are_protocol_guarded():
    assert "u.protocol==='http:'||u.protocol==='https:'" in HTML
    assert 'rel="noopener noreferrer"' in HTML


def test_news_map_enrichment_preserves_provider_visual_fields():
    import news_map_v40 as nmap
    row = {"title": "ФРС сохранила ставку", "summary": "Рынок ждёт сигналов", "image": "https://cdn.example.com/a.jpg", "url": "https://example.com/story", "impact_score": 70}
    out = nmap.enrich([row])[0]
    assert out["image"] == row["image"]
    assert out["url"] == row["url"]
