"""AllAnalytics v4.40.8 — data-driven routing policy.

This module removes performance-routing constants from the live ensemble wherever
there is enough historical evidence to learn them safely.

Two independent evidence sources are used:
1) component OOS predictions -> chronological Brier-optimal champion/regime blend;
2) settled prospective forecasts -> a publication/trust router that learns when a
   live signal is worth publishing under the current disagreement, move probability,
   drift and event context.

The policy never promotes challengers. Human/prospective promotion guards remain
separate. When evidence is insufficient or a learned router fails its untouched
validation slice, this module returns an explicit neutral fallback rather than
pretending that a learned route exists.
"""
from __future__ import annotations
import evaluation_clock_v4401014 as EC14

import math
import temporal_validation_v4401012 as TV

import numpy as np
import pandas as pd

import prospective_feedback_v436 as FB436
import sealed_shadow_v44010 as SHADOW44010
import target_contract_v4405 as TARGET4405

VERSION = "data-driven-routing-policy-v4.40.10"
ROUTING_EVIDENCE_FAMILY = "three-state-factorized"
MIN_OOS_BLEND_N = 36
MIN_PROSPECTIVE_N = 60


def _finite(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _clip01(x, lo=.001, hi=.999):
    v=_finite(x)
    return None if v is None else float(np.clip(v,lo,hi))


def _brier(p,y):
    p=np.asarray(p,float);y=np.asarray(y,float)
    ok=np.isfinite(p)&np.isfinite(y)
    return None if not ok.any() else float(np.mean((p[ok]-y[ok])**2))


def _optimal_linear_weight(pa,pb,y):
    """Closed-form Brier-optimal weight for p=w*pa+(1-w)*pb."""
    pa=np.asarray(pa,float);pb=np.asarray(pb,float);y=np.asarray(y,float)
    ok=np.isfinite(pa)&np.isfinite(pb)&np.isfinite(y);pa,pb,y=pa[ok],pb[ok],y[ok]
    if len(y)<2:return .5
    d=pa-pb; den=float(np.dot(d,d))
    if den<=1e-12:return .5
    return float(np.clip(np.dot(d,y-pb)/den,0.0,1.0))


def fit_oos_blend(frame: pd.DataFrame, a_col: str, b_col: str, y_col: str, *, min_n: int=MIN_OOS_BLEND_N) -> dict:
    """Chronological fit -> validation routing weight.

    The first 70% is used only to estimate the Brier-optimal linear weight.  The
    recent 30% is untouched during fitting and must beat equal weighting before the
    learned route is allowed live.  Otherwise the fallback is exactly 50/50 — no
    asset-class prior or hand-tuned preference.
    """
    if frame is None or frame.empty:
        return {"version":VERSION,"learned":False,"weight_a":.5,"weight_b":.5,"n":0,"reason":"no_oos_evidence"}
    d=TV.legal(frame).replace([np.inf,-np.inf],np.nan).dropna(subset=[a_col,b_col,y_col]).copy()
    n=len(d)
    if n<max(12,int(min_n)):
        return {"version":VERSION,"learned":False,"weight_a":.5,"weight_b":.5,"n":n,"reason":"insufficient_oos_evidence"}
    cut=max(20,min(n-12,int(n*.70)))
    chunks=TV.split(d,(.70,),(20,10))
    if chunks is None:return {"version":VERSION,"learned":False,"weight_a":.5,"weight_b":.5,"n":n,"reason":"insufficient_purged_oos"}
    train,val=chunks
    if len(val)<10:
        return {"version":VERSION,"learned":False,"weight_a":.5,"weight_b":.5,"n":n,"reason":"insufficient_validation_tail"}
    w=_optimal_linear_weight(train[a_col],train[b_col],train[y_col])
    p_candidate=w*val[a_col].to_numpy(float)+(1-w)*val[b_col].to_numpy(float)
    p_equal=.5*val[a_col].to_numpy(float)+.5*val[b_col].to_numpy(float)
    y=val[y_col].to_numpy(float)
    bc=_brier(p_candidate,y); be=_brier(p_equal,y)
    validated=bool(bc is not None and be is not None and bc<=be+1e-12)
    live_w=w if validated else .5
    return {
        "version":VERSION,"learned":validated,"weight_a":round(float(live_w),6),"weight_b":round(float(1-live_w),6),
        "temporal_split":train.attrs.get("temporal_split"),"fitted_weight_a":round(float(w),6),"n":n,"fit_n":len(train),"validation_n":len(val),
        "validation_brier":None if bc is None else round(bc,7),"equal_weight_brier":None if be is None else round(be,7),
        "brier_improvement":None if bc is None or be is None else round(be-bc,7),
        "reason":"validated_recent_oos" if validated else "learned_weight_failed_recent_oos",
    }


def aligned_move_frame(champion: dict, challenger: dict) -> pd.DataFrame:
    """Align OOS P(material move) from both core components, including neutral rows."""
    def mp(rows):
        out={}
        for r in rows or []:
            date=str(r.get("date") or "")[:10]
            pm=_finite(r.get("p_move")); state=r.get("state")
            if not date or pm is None or state not in (-1,0,1,-1.0,0.0,1.0,"-1","0","1"):
                continue
            out[date]={"label_end":r.get("label_end"),"feature_available_at":r.get("feature_available_at"),"p_move":pm,"y_move":0.0 if float(state)==0 else 1.0}
        return out
    a=mp((champion or {}).get("oos_records") or []);b=mp((challenger or {}).get("oos_records") or [])
    rows=[]
    for date in sorted(set(a)&set(b)):
        if a[date]["y_move"]!=b[date]["y_move"]:continue
        if any(not z.get(k) for z in (a[date],b[date]) for k in ("label_end","feature_available_at")):continue
        rows.append({"date":pd.Timestamp(date),"label_end":max(pd.Timestamp(a[date]["label_end"]),pd.Timestamp(b[date]["label_end"])),"feature_available_at":max(pd.Timestamp(a[date]["feature_available_at"]),pd.Timestamp(b[date]["feature_available_at"])),"p_champion_move":a[date]["p_move"],"p_challenger_move":b[date]["p_move"],"y_move":a[date]["y_move"]})
    return pd.DataFrame(rows).sort_values("date") if rows else pd.DataFrame()


def _component_disagreement(row: dict) -> float:
    vals=[]
    for c in row.get("components") or []:
        if not isinstance(c,dict):continue
        if str(c.get("name")) not in {"production","vol_regime","core_meta","asset_specialist","event_response"}:continue
        p=_finite(c.get("conditional_p_up"))
        if p is not None:vals.append(p)
    return float(max(vals)-min(vals)) if len(vals)>=2 else 0.0


def _drift(row: dict) -> float:
    ctx=row.get("context") or {}
    fd=ctx.get("feature_drift") or {}
    for k in ("score","drift_score"):
        v=_finite(fd.get(k))
        if v is not None:return float(np.clip(v,0,1))
    return 0.0


def _prospective_feature_row(row: dict) -> list[float] | None:
    pcond=_finite(row.get("conditional_p_up")); pmove=_finite(row.get("p_move"))
    if pcond is None or pmove is None:return None
    ctx=row.get("context") or {}
    event=float(np.clip(_finite(ctx.get("event_risk")) or 0.0,0,1))
    disagree=float(np.clip(_component_disagreement(row),0,1))
    drift=float(np.clip(_drift(row),0,1))
    ctx_dis=1.0 if bool(ctx.get("context_disagreement")) else 0.0
    reliability=float(np.clip(_finite(row.get("reliability")) or .5,0,1))
    return [abs(pcond-.5)*2,pmove,disagree,drift,event,ctx_dis,reliability]


def _live_feature_row(*,conditional_p_up,p_move,disagreement,drift,event_risk,context_disagreement,reliability) -> list[float]:
    p=float(np.clip(float(conditional_p_up),0,1));pm=float(np.clip(float(p_move),0,1))
    return [abs(p-.5)*2,pm,float(np.clip(disagreement,0,1)),float(np.clip(drift,0,1)),
            float(np.clip(event_risk,0,1)),1.0 if context_disagreement else 0.0,float(np.clip(reliability,0,1))]


def _publication_target(row: dict) -> int | None:
    outcome=str(row.get("outcome") or "")
    p=_finite(row.get("conditional_p_up"))
    if outcome not in {"up","down","neutral"} or p is None:return None
    if outcome=="neutral":return 0
    pred="up" if p>=.5 else "down"
    return int(pred==outcome)


def _select_trust_threshold(trust,y):
    """Choose publication threshold by symmetric expected-correctness utility.

    utility = (correct publications - incorrect publications) / total observations.
    No arbitrary penalty coefficient is used.  If no positive-utility threshold
    exists, the returned threshold is 1.0 (publish nothing).
    """
    trust=np.asarray(trust,float);y=np.asarray(y,int)
    if len(trust)<8:return 1.0,{"utility":None,"coverage":0.0,"accuracy":None}
    candidates=np.unique(np.r_[.5,np.round(trust,4)])
    best=None
    for th in candidates:
        mask=trust>=th;n=int(mask.sum())
        if n<max(6,int(len(y)*.15)):continue
        correct=int(y[mask].sum());wrong=n-correct
        utility=(correct-wrong)/len(y);coverage=n/len(y);acc=correct/n
        key=(utility,correct,coverage,-th)
        if best is None or key>best[0]:best=(key,float(th),utility,coverage,acc,n)
    if best is None or best[2]<=0:
        return 1.0,{"utility":None if best is None else round(float(best[2]),6),"coverage":0.0,"accuracy":None,"n":0}
    _,th,u,cov,acc,n=best
    return float(np.clip(th,.5,1.0)),{"utility":round(float(u),6),"coverage":round(float(cov),4),"accuracy":round(float(acc),4),"n":int(n)}


def prospective_publish_router(*, symbol: str, horizon: int, live: dict, ledger=None, window_days: int=720) -> dict:
    """Learn whether the current signal is worth publishing from settled evidence.

    Compatible past generations may contribute only when they share the exact same
    target contract and contain factorized move/direction probabilities.  This is a
    routing model, not a champion-promotion mechanism.
    """
    # Routing is intentionally recomputed from settled evidence only when called;
    # model fitting is cheap at <=500 rows and avoids stale policy state across new settlements.
    led=ledger or FB436.LEDGER
    try:
        rows=led.rows(limit=500,symbol=str(symbol).upper(),horizon=int(horizon),settled_only=True,target_version=TARGET4405.TARGET_VERSION)
        rows=SHADOW44010.training_rows(rows)
    except Exception as exc:
        return {"version":VERSION,"active":False,"validated":False,"n":0,"reason":f"ledger_unavailable:{type(exc).__name__}"}
    cutoff=EC14.now().tz_localize(None).normalize()-pd.Timedelta(days=max(30,min(int(window_days),3650)))
    data=[];generations=set()
    for r in reversed(rows):
        try:dt=pd.Timestamp(str(r.get("data_as_of") or "")[:10])
        except Exception:continue
        if pd.isna(dt) or dt<cutoff:continue
        x=_prospective_feature_row(r);y=_publication_target(r)
        if x is None or y is None:continue
        # A settlement date is not the forecast origin. Preserve both clocks.
        end=pd.to_datetime(r.get('target_as_of'),errors='coerce',utc=True)
        created=pd.to_datetime(r.get('created_at'),errors='coerce',utc=True)
        if pd.isna(end) or pd.isna(created):continue
        end=end.tz_localize(None); created=created.tz_localize(None)
        # Late/reconstructed forecasts cannot act as pre-event observations.
        if created.normalize()>dt or end<=dt:continue
        data.append({'date':dt,'feature_available_at':dt,'label_end':end,'x':x,'y':y})
        generations.add(str(r.get("model_generation") or "unknown"))
    d=TV.legal(pd.DataFrame(data),as_of=EC14.now()) if data else pd.DataFrame()
    n=len(d)
    chunks=TV.split(d,(.55,.78),(32,12,10)) if n>=MIN_PROSPECTIVE_N else None
    if chunks is None:
        return {"version":VERSION,"active":False,"validated":False,"n":n,"reason":"collecting_purged_prospective_evidence","generations":sorted(generations)}
    fit,threshold,audit=chunks
    ordered=pd.concat(chunks)
    X=np.asarray(ordered.x.tolist(),float);y=ordered.y.to_numpy(int)
    a=len(fit);b=a+len(threshold);n=len(ordered)
    if len(np.unique(y[:a]))<2:
        return {"version":VERSION,"active":False,"validated":False,"n":n,"reason":"single_class_training"}
    try:
        from sklearn.linear_model import LogisticRegression
        mdl=LogisticRegression(C=.6,max_iter=350,solver="lbfgs",class_weight="balanced",random_state=4408)
        mdl.fit(X[:a],y[:a])
        p_thr=mdl.predict_proba(X[a:b])[:,1];thr,thr_diag=_select_trust_threshold(p_thr,y[a:b])
        p_eval=mdl.predict_proba(X[b:])[:,1]
        # Baseline is the forecast's own factorized probability of a correct
        # publication: P(move) * conditional directional confidence.
        base_eval=np.clip(X[b:,1]*(.5+.5*X[b:,0]),1e-4,1-1e-4)
        bm=_brier(p_eval,y[b:]);bb=_brier(base_eval,y[b:])
        mask=p_eval>=thr
        eval_y=y[b:]
        published_n=int(mask.sum())
        min_publish_n=max(4,int(math.ceil(len(eval_y)*.12)))
        # Use the same population-normalized utility as threshold selection.  This
        # prevents a router from passing the untouched audit by being right on only
        # a tiny handful of cherry-picked publications.
        utility=float((2*eval_y[mask].sum()-published_n)/len(eval_y)) if published_n else 0.0
        validated=bool(bm is not None and bb is not None and bm<=bb+1e-12 and utility>0 and published_n>=min_publish_n)
        if not validated:
            return {"version":VERSION,"active":False,"validated":False,"n":n,"fit_n":a,"threshold_n":b-a,"evaluation_n":n-b,
                    "router_brier":None if bm is None else round(bm,7),"baseline_brier":None if bb is None else round(bb,7),
                    "threshold":round(thr,4),"threshold_selection":thr_diag,"evaluation_utility":round(utility,6),
                    "evaluation_published_n":published_n,"minimum_evaluation_published_n":min_publish_n,
                    "reason":"prospective_router_failed_untouched_audit","generations":sorted(generations)}
        # Production fit uses all settled evidence only after the untouched audit
        # has approved the modelling recipe.  The threshold stays frozen from the
        # dedicated threshold slice.
        prod=LogisticRegression(C=.6,max_iter=350,solver="lbfgs",class_weight="balanced",random_state=4408)
        prod=mdl  # Preserve the estimator that owns the threshold and audit.
        live_x=np.asarray([_live_feature_row(**live)],float)
        trust=float(prod.predict_proba(live_x)[:,1][0])
        return {"version":VERSION,"active":True,"validated":True,"n":n,"fit_n":a,"threshold_n":b-a,"evaluation_n":n-b,
                "temporal_split":fit.attrs.get("temporal_split"),"trust_probability":round(trust,6),"publish_threshold":round(float(thr),6),"publish":bool(trust>=thr),
                "router_brier":round(float(bm),7),"baseline_brier":round(float(bb),7),"evaluation_utility":round(utility,6),
                "evaluation_published_n":published_n,"minimum_evaluation_published_n":min_publish_n,
                "threshold_selection":thr_diag,"feature_names":["direction_conviction","p_move","component_disagreement","drift","event_risk","context_disagreement","base_reliability"],
                "coefficients":[round(float(v),6) for v in prod.coef_[0]],"intercept":round(float(prod.intercept_[0]),6),
                "generations":sorted(generations),"reason":"prospective_router_validated"}
    except Exception as exc:
        return {"version":VERSION,"active":False,"validated":False,"n":n,"reason":f"router_fit_failed:{type(exc).__name__}","generations":sorted(generations)}


def status(symbol: str|None=None,horizon: int|None=None,ledger=None) -> dict:
    led=ledger or FB436.LEDGER
    try:
        rows=led.rows(limit=500,symbol=symbol,horizon=horizon,settled_only=True,target_version=TARGET4405.TARGET_VERSION)
        rows=SHADOW44010.training_rows(rows)
    except Exception as exc:
        return {"version":VERSION,"error":type(exc).__name__,"settled":0}
    usable=0;gens={}
    for r in rows:
        if _prospective_feature_row(r) is not None and _publication_target(r) is not None:
            usable+=1;g=str(r.get("model_generation") or "unknown");gens[g]=gens.get(g,0)+1
    return {"version":VERSION,"target_version":TARGET4405.TARGET_VERSION,"settled":len(rows),"usable_for_routing":usable,
            "minimum_for_prospective_router":MIN_PROSPECTIVE_N,"generations":gens,
            "policy":"OOS learns core blend; prospective history may gate publication only after chronological untouched validation"}
