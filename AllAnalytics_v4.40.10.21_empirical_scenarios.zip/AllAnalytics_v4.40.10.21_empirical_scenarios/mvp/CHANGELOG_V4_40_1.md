# AllAnalytics v4.40.1 — Persistent Evidence Store + Readiness Monitor

## Что изменено
- prospective SQLite ledgers вынесены из `runtime_cache` в стабильный user-level evidence store;
- default: `~/AllAnalytics_Data/evidence/`;
- добавлены env overrides и автоматический bounded discovery предыдущих release folders;
- миграция старых ledgers идемпотентна и сохраняет settlement↔forecast linkage;
- distribution ledger schema v2 сохраняет asset class / regime / event context point-in-time;
- добавлен Readiness Monitor с независимыми forecast dates и segment maturity gates;
- API: `/api/models/evidence-v4401/status`, `/api/models/evidence-v4401/readiness`;
- Technical Lab показывает состояние Evidence Store и progress к следующему review;
- forecasting probabilities, thresholds, abstention and distribution math не менялись.

## Governance
Readiness — только диагностический gate. Он не меняет веса, не переобучает модель и не выполняет automatic promotion.
