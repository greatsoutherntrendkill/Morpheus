# AllAnalytics v3.5 — Forecast Visibility & Live Evidence

v3.5 changes how model output is presented without weakening the statistical
quality gate.

## Main product change

Previously an untrusted model probability was rendered as "нейтрально". That
mixed up two different statements:
1. what the model currently predicts;
2. whether AllAnalytics has enough evidence to publish that prediction as a
   validated signal.

v3.5 separates them.

Every asset/horizon now exposes:
- raw model direction (`Рост ↑` / `Снижение ↓`);
- raw `P(up)` from day one;
- a separate publication status:
  - `Подтверждённый сигнал`, or
  - `Нет подтверждённого сигнала`;
- evidence progress (`effective N / 30`);
- individual gate checks for Edge CI, Brier-skill CI and ECE;
- immutable live track record:
  forecasts, resolved forecasts, directional accuracy and Brier score.

## Important

The quality gate itself was **not relaxed**. A 70% raw model probability does
not become a validated signal merely because it is far from 50%.

The production champion remains:
- `logreg-v3.2.0`

LightGBM and CatBoost remain shadow challengers from v3.4.

## Live track record

`export_site.py` now calls `settle_predictions()` before building the new
snapshot. As new prices arrive, forecasts whose horizon has matured are resolved
once in the immutable ledger.

New endpoint:

`GET /api/model-track-record?symbol=^GSPC&horizon=10`

## Interface

The homepage and asset cards now show the model's actual directional opinion
immediately. The detailed asset view shows:
- current raw probability;
- research/validated status;
- evidence progress bar;
- live resolved outcomes;
- validation diagnostics by 1/5/10/20D.

This makes "no validated signal" mean exactly that; it no longer looks like a
market-neutral forecast.
