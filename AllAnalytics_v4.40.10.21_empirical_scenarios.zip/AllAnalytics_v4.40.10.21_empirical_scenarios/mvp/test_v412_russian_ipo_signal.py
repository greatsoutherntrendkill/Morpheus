from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import russian_ipo_v412 as ipo


def test_ipo_universe_and_methodology():
    st=ipo.status()
    assert st['version']=='4.12'
    assert st['completed_count'] >= 170
    assert st['planned_count'] >= 10
    assert st['min_year']==1996
    assert st['max_year']>=2026
    assert st['methodology']['spo_excluded'] is True
    assert st['methodology']['dpo_included'] is True
    assert 'не применимо' in st['methodology']['goodwill'].lower()


def test_recent_2026_names_present_and_spo_filtered():
    rows=ipo.list_ipos(range_id='1y',limit=100)['rows']
    names={x['company'] for x in rows}
    assert 'Инкаб Холдинг' in names
    assert 'B2B-РТС' in names
    assert not any('SPO' in (x.get('event_type') or '') for x in rows)


def test_ozon_has_source_backed_finance_fields():
    d=ipo.analyze('ozon-2020')
    assert d['valuation']['ev_sales']==3.2
    assert d['valuation']['market_cap_rub_bn']==412.7
    assert d['market_reaction']['first_day_pct']==7
    assert d['goodwill']['applicable'] is False
    assert d['goodwill']['value'] is None


def test_dpo_is_retained():
    rows=ipo.list_ipos(range_id='2014',limit=100)['rows']
    assert any(x['event_type']=='DPO' for x in rows)


def test_api_and_frontend_wiring():
    api=(ROOT/'api.py').read_text(encoding='utf-8')
    html=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
    assert '/api/corpfin/russia-ipo/status' in api
    assert '/api/corpfin/russia-ipo/{ipo_id}' in api
    assert "'/api/corpfin/russia-ipo'" in html
    assert "dealsState.country='us'" not in html
    assert "classList.toggle('disabled',dealsState.tab==='ipo')" not in html
    assert 'function renderRussianIpoDetail' in html


def test_signal_glass_reference_palette_applied():
    html=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
    assert '--bg:#0d110f' in html
    assert '--panel:#141a16' in html
    assert '--panel2:#1d271f' in html
    assert '--accent:#c0fb50' in html
    assert ('grid-template-columns:218px minmax(0,1fr)' in html or 'grid-template-columns:210px minmax(0,1fr)' in html)
