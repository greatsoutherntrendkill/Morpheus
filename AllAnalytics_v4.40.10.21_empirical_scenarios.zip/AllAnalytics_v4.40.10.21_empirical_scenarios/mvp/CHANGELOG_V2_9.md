# AllAnalytics v2.9 — dependence-aware validation

## What changed
- Added a non-overlapping evaluation layer for every 1/5/10/20D horizon.
- Added phase-robust non-overlap point estimates: each of the H possible non-overlap streams is evaluated separately and the median metric is reported, avoiding an arbitrary start-date phase.
- Added `n_raw`, `n_nonoverlap`, and conservative `n_effective`.
- `n_effective` is capped by the number of non-overlapping H-day outcomes and further reduced by positive serial correlation in the probabilistic loss differential.
- Added 500-resample moving-block bootstrap 95% confidence intervals for:
  - model accuracy;
  - accuracy edge versus baseline;
  - Brier skill;
  - calibration error.
- Bootstrap blocks are at least as long as the forecast horizon, preserving overlap dependence.
- Quality gate now uses effective evidence + non-overlap metrics + lower 95% confidence bounds.
- A positive point estimate is no longer sufficient for a trusted directional signal.
- UI now exposes raw/non-overlap/effective sample sizes and confidence intervals.

## New quality-gate rule
A model is trusted only when all of the following hold:
- effective OOS N >= 30;
- non-overlap accuracy edge > 0;
- non-overlap Brier skill > 0;
- lower 95% bootstrap edge bound > 0;
- lower 95% bootstrap Brier-skill bound > 0;
- non-overlap calibration error <= 0.15.

High confidence is stricter: effective N >= 80, lower CI bounds >= 1 and ECE <= 0.08.

## Why this matters
An H-day target generated every day creates H strongly overlapping outcomes. v2.8 correctly purged future labels from training, but its OOS row count still looked more independent than it really was. v2.9 separates dense diagnostic predictions from the amount of independent statistical evidence.
