"""Register AllAnalytics v4.34 model artifacts in the immutable model registry."""
import db
import model_registry as MR

if __name__ == "__main__":
    con=db.connect()
    try:
        MR.register_champion(con)
        MR.register_v433_models(con)
        MR.register_v434_models(con)
        rows=con.execute(
            "SELECT model_version,role,status FROM model_registry WHERE model_version IN (?,?) ORDER BY model_version",
            (MR.V434_CONTEXT_VERSION,MR.V434_META_VERSION),
        ).fetchall()
        print(rows)
    finally:
        con.close()
