
"""AllAnalytics v4.7.1 — Corporate Finance Workbench.

Небольшой серверный слой для:
- Valuation Sandbox (DCF / DDM);
- M&A / IPO Tracker;
- профессионального тренажёра.

Базовые финансовые допущения — редактируемые модельные пресеты.
Live-цена по возможности обновляется через yfinance; если источник недоступен,
интерфейс честно использует последний встроенный snapshot.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from typing import Any
import math


COMPANIES={
    "AAPL":{
        "ticker":"AAPL","name":"Apple","sector":"Технологии","currency":"USD",
        "model":"DCF","price_snapshot":230.0,
        "revenue":395.0,"ebit_margin":31.5,"tax_rate":16.0,
        "da_pct":3.2,"capex_pct":2.5,"nwc_pct":-4.0,
        "dso":31.0,"dio":12.0,"dpo":95.0,"cogs_pct":53.5,
        "base_growth":6.0,"wacc":8.2,"terminal_growth":2.8,
        "net_debt":-45.0,"shares":15.1,
        "dividend":1.00,"dividend_growth":5.0,"cost_equity":8.5,
        "baseline_policy_rate":3.75,"baseline_inflation":2.5,
        "note":"Базовые допущения модели; все поля можно менять."
    },
    "MSFT":{
        "ticker":"MSFT","name":"Microsoft","sector":"Технологии","currency":"USD",
        "model":"DCF","price_snapshot":510.0,
        "revenue":282.0,"ebit_margin":45.0,"tax_rate":18.0,
        "da_pct":8.0,"capex_pct":13.0,"nwc_pct":-3.0,
        "dso":73.0,"dio":8.0,"dpo":85.0,"cogs_pct":31.0,
        "base_growth":11.0,"wacc":8.0,"terminal_growth":3.0,
        "net_debt":-35.0,"shares":7.43,
        "dividend":3.32,"dividend_growth":9.0,"cost_equity":8.3,
        "baseline_policy_rate":3.75,"baseline_inflation":2.5,
        "note":"Базовые допущения модели; все поля можно менять."
    },
    "KO":{
        "ticker":"KO","name":"Coca-Cola","sector":"Потребительский сектор","currency":"USD",
        "model":"DCF","price_snapshot":70.0,
        "revenue":47.0,"ebit_margin":30.0,"tax_rate":20.0,
        "da_pct":4.2,"capex_pct":4.5,"nwc_pct":-2.0,
        "dso":38.0,"dio":69.0,"dpo":90.0,"cogs_pct":39.0,
        "base_growth":5.0,"wacc":7.2,"terminal_growth":2.5,
        "net_debt":31.0,"shares":4.31,
        "dividend":2.04,"dividend_growth":4.5,"cost_equity":7.4,
        "baseline_policy_rate":3.75,"baseline_inflation":2.5,
        "note":"Базовые допущения модели; все поля можно менять."
    },
    "JPM":{
        "ticker":"JPM","name":"JPMorgan Chase","sector":"Банки","currency":"USD",
        "model":"DDM","price_snapshot":300.0,
        "revenue":175.0,"ebit_margin":38.0,"tax_rate":20.0,
        "da_pct":2.0,"capex_pct":2.5,"nwc_pct":0.0,
        "dso":0.0,"dio":0.0,"dpo":0.0,"cogs_pct":0.0,
        "base_growth":5.0,"wacc":9.0,"terminal_growth":3.0,
        "net_debt":0.0,"shares":2.78,
        "dividend":6.00,"dividend_growth":5.5,"cost_equity":9.2,
        "baseline_policy_rate":3.75,"baseline_inflation":2.5,
        "note":"Для банка основной учебный режим — DDM."
    },
}

MNA=[
    {
        "id":"msft-atvi","type":"M&A","buyer":"Microsoft","target":"Activision Blizzard",
        "date":"2023-10-13","headline_value":68.7,"currency":"USD млрд",
        "consideration":"денежные средства","target_revenue":7.5,"target_ebitda":3.0,
        "net_debt":-3.0,"identifiable_net_assets":24.0,"goodwill":43.8,
        "exit_ebitda_growth":6.0,"financing":{"cash":100,"debt":0,"stock":0},
        "summary":"Крупное стратегическое приобретение игрового контента и экосистемы.",
        "source_note":"Стоимость сделки публичная; EBITDA в хабе нормализована для учебного разбора."
    },
    {
        "id":"avgo-vmw","type":"M&A","buyer":"Broadcom","target":"VMware",
        "date":"2023-11-22","headline_value":69.0,"currency":"USD млрд",
        "consideration":"акции + денежные средства","target_revenue":13.4,"target_ebitda":4.7,
        "net_debt":4.0,"identifiable_net_assets":19.0,"goodwill":45.0,
        "exit_ebitda_growth":8.0,"financing":{"cash":38,"debt":32,"stock":30},
        "summary":"Трансформация Broadcom в инфраструктурное программное обеспечение.",
        "source_note":"Публичная стоимость сделки; отдельные показатели нормализованы для анализа."
    },
    {
        "id":"cof-dfs","type":"M&A","buyer":"Capital One","target":"Discover Financial",
        "date":"2024-02-19","headline_value":35.3,"currency":"USD млрд",
        "consideration":"акции","target_revenue":15.0,"target_ebitda":6.0,
        "net_debt":0.0,"identifiable_net_assets":24.0,"goodwill":11.3,
        "exit_ebitda_growth":5.0,"financing":{"cash":0,"debt":0,"stock":100},
        "summary":"Комбинация карточного бизнеса, депозитной базы и собственной платёжной сети.",
        "source_note":"Стоимость — объявленная; показатели приведены в упрощённом корпоративно-финансовом формате."
    },
]

IPO=[
    {
        "id":"reddit-ipo","type":"IPO","company":"Reddit","ticker":"RDDT","date":"2024-03-21",
        "offer_price":34.0,"shares_offered":22.0,"gross_proceeds":748.0,
        "first_close":50.44,"revenue":804.0,"net_income":-90.8,"currency":"USD",
        "summary":"Публичное размещение социальной платформы; высокая чувствительность к росту рекламы и монетизации данных."
    },
    {
        "id":"arm-ipo","type":"IPO","company":"Arm Holdings","ticker":"ARM","date":"2023-09-14",
        "offer_price":51.0,"shares_offered":95.5,"gross_proceeds":4870.0,
        "first_close":63.59,"revenue":2679.0,"net_income":524.0,"currency":"USD",
        "summary":"IPO производителя архитектуры процессоров с фокусом на лицензирование и royalty-модель."
    },
    {
        "id":"cava-ipo","type":"IPO","company":"CAVA Group","ticker":"CAVA","date":"2023-06-15",
        "offer_price":22.0,"shares_offered":14.4,"gross_proceeds":318.0,
        "first_close":43.78,"revenue":564.1,"net_income":-59.0,"currency":"USD",
        "summary":"IPO быстрорастущей ресторанной сети; ключевой вопрос — темп открытия новых точек и unit economics."
    },
]

TRAINING=[
    {
        "id":"ev-ebitda-aapl","ticker":"AAPL","title":"EV / EBITDA",
        "difficulty":"База","question":"Рассчитайте EV / EBITDA.",
        "raw":{"market_cap":3470.0,"debt":98.0,"cash":157.0,"ebitda":145.0},
        "formula":"EV = капитализация + долг − денежные средства; затем EV / EBITDA.",
        "answer":23.5241,"unit":"x","tolerance":0.35
    },
    {
        "id":"pe-msft","ticker":"MSFT","title":"P / E",
        "difficulty":"База","question":"Рассчитайте мультипликатор P / E.",
        "raw":{"market_cap":3790.0,"net_income":101.8},
        "formula":"P / E = капитализация / чистая прибыль.",
        "answer":37.2299,"unit":"x","tolerance":0.45
    },
    {
        "id":"netdebt-ebitda-ko","ticker":"KO","title":"Net Debt / EBITDA",
        "difficulty":"Средний","question":"Рассчитайте Net Debt / EBITDA.",
        "raw":{"debt":45.5,"cash":14.5,"ebitda":15.2},
        "formula":"Чистый долг = долг − денежные средства; затем / EBITDA.",
        "answer":2.0395,"unit":"x","tolerance":0.08
    },
    {
        "id":"fcf-yield-msft","ticker":"MSFT","title":"FCF Yield",
        "difficulty":"Средний","question":"Рассчитайте доходность свободного денежного потока.",
        "raw":{"operating_cash_flow":136.0,"capex":64.0,"market_cap":3790.0},
        "formula":"FCF = CFO − Capex; FCF Yield = FCF / капитализация × 100%.",
        "answer":1.8997,"unit":"%","tolerance":0.12
    },
]

def _finite(x):
    try:
        return math.isfinite(float(x))
    except Exception:
        return False

def company_snapshot(ticker: str) -> dict[str, Any]:
    t=str(ticker or "").upper()
    if t not in COMPANIES:
        raise KeyError(t)
    out=deepcopy(COMPANIES[t])
    out["price_source"]="встроенный snapshot"
    out["as_of"]="модельный preset"
    try:
        import yfinance as yf
        q=yf.Ticker(t)
        fi=getattr(q,"fast_info",None)
        price=None
        if fi:
            for k in ("last_price","lastPrice"):
                try:
                    v=fi[k] if hasattr(fi,"__getitem__") else getattr(fi,k,None)
                    if _finite(v):
                        price=float(v); break
                except Exception:
                    pass
        if price is None:
            hist=q.history(period="5d",interval="1d",auto_adjust=True)
            if hist is not None and not hist.empty:
                price=float(hist["Close"].dropna().iloc[-1])
        if _finite(price):
            out["price"]=round(float(price),4)
            out["price_source"]="yfinance"
            out["as_of"]=datetime.now(timezone.utc).isoformat(timespec="seconds")
        else:
            out["price"]=out["price_snapshot"]
    except Exception:
        out["price"]=out["price_snapshot"]
    return out

def transactions() -> dict[str, Any]:
    return {"version":"4.8","mna":deepcopy(MNA),"ipo":deepcopy(IPO)}

def training_cases() -> list[dict[str, Any]]:
    return deepcopy(TRAINING)


def live_training_cases() -> list[dict[str, Any]]:
    """Обновляет price-dependent упражнения по текущей цене, если она доступна."""
    cases=training_cases()
    snapshots={}
    for c in cases:
        t=c.get("ticker")
        if t and t not in snapshots:
            try:
                snapshots[t]=company_snapshot(t)
            except Exception:
                snapshots[t]=None
        s=snapshots.get(t)
        if not s:
            continue
        price=float(s.get("price") or s.get("price_snapshot") or 0)
        shares=float(s.get("shares") or 0)  # млрд акций
        if price>0 and shares>0 and "market_cap" in c.get("raw",{}):
            c["raw"]["market_cap"]=round(price*shares,2)  # USD млрд
            c["market_data_source"]=s.get("price_source")
            c["market_as_of"]=s.get("as_of")
            if c["title"]=="EV / EBITDA":
                r=c["raw"]
                c["answer"]=(r["market_cap"]+r["debt"]-r["cash"])/r["ebitda"]
            elif c["title"]=="P / E":
                r=c["raw"]
                c["answer"]=r["market_cap"]/r["net_income"]
            elif c["title"]=="FCF Yield":
                r=c["raw"]
                c["answer"]=(r["operating_cash_flow"]-r["capex"])/r["market_cap"]*100
    return cases
