
"""AllAnalytics v4.7 — единый контракт сценария.

Этот слой — "розетка" для будущего AI-провайдера в v4.8.
Сейчас внешний API НЕ вызывается: контракт заполняет локальный parser.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any


@dataclass
class ScenarioCondition:
    event_type: str = "other"
    subject: str = ""
    region: str = ""
    timing: str = "ближайшее время"
    duration: str = ""
    severity: str = "средняя"
    assets: list[str] = field(default_factory=list)
    channels: list[str] = field(default_factory=list)
    qualifiers: list[str] = field(default_factory=list)


@dataclass
class ScenarioIntent:
    question: str
    language: str = "ru"
    conditions: list[ScenarioCondition] = field(default_factory=list)
    requested_asset: str | None = None
    requested_horizon: str = "первые часы — 5 торговых дней"
    confidence: str = "средняя"
    parser: str = "local-v4.7"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def normalize_intent(data: dict[str, Any]) -> dict[str, Any]:
    """Нормализует результат любого будущего LLM к стабильному контракту."""
    question = str(data.get("question") or "").strip()
    raw_conditions = data.get("conditions") or []
    conditions = []
    for c in raw_conditions[:8]:
        if not isinstance(c, dict):
            continue
        conditions.append(asdict(ScenarioCondition(
            event_type=str(c.get("event_type") or "other"),
            subject=str(c.get("subject") or ""),
            region=str(c.get("region") or ""),
            timing=str(c.get("timing") or "ближайшее время"),
            duration=str(c.get("duration") or ""),
            severity=str(c.get("severity") or "средняя"),
            assets=[str(x) for x in (c.get("assets") or [])[:12]],
            channels=[str(x) for x in (c.get("channels") or [])[:12]],
            qualifiers=[str(x) for x in (c.get("qualifiers") or [])[:12]],
        )))
    if not conditions:
        conditions = [asdict(ScenarioCondition(subject=question))]
    return {
        "question": question,
        "language": str(data.get("language") or "ru"),
        "conditions": conditions,
        "requested_asset": data.get("requested_asset"),
        "requested_horizon": str(data.get("requested_horizon") or "первые часы — 5 торговых дней"),
        "confidence": str(data.get("confidence") or "средняя"),
        "parser": str(data.get("parser") or "unknown"),
    }
