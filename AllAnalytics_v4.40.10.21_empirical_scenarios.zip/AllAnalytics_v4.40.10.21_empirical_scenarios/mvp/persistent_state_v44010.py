"""Persistent non-model state for AllAnalytics v4.40.10.

Keeps cumulative event history and human governance decisions outside a release
folder, so upgrading code cannot silently reset evidence/review history.
"""
from __future__ import annotations
import os
import shutil
from pathlib import Path

VERSION="persistent-state-v4.40.10"


def data_root() -> Path:
    raw=os.getenv("ALLANALYTICS_DATA_DIR")
    return Path(raw).expanduser() if raw else Path.home()/"AllAnalytics_Data"


def events_root() -> Path:
    p=data_root()/"events"; p.mkdir(parents=True,exist_ok=True); return p


def governance_root() -> Path:
    p=data_root()/"governance"; p.mkdir(parents=True,exist_ok=True); return p


def event_db_path() -> Path:
    return Path(os.getenv("ALLANALYTICS_EVENT_DB") or (events_root()/"event_archive.sqlite3")).expanduser()


def governance_db_path() -> Path:
    return Path(os.getenv("ALLANALYTICS_PROMOTION_DB") or (governance_root()/"model_promotion.sqlite3")).expanduser()


def migrate_sqlite_once(src: Path, dst: Path) -> bool:
    """Copy legacy SQLite only when persistent destination does not exist."""
    try:
        src=Path(src); dst=Path(dst)
        if dst.exists() or not src.exists() or src.stat().st_size<=0:return False
        dst.parent.mkdir(parents=True,exist_ok=True)
        tmp=dst.with_suffix(dst.suffix+".tmp")
        shutil.copy2(src,tmp); tmp.replace(dst)
        return True
    except Exception:
        return False
