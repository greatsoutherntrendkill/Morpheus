from pathlib import Path

import pandas as pd

import prospective_feedback_v436 as F
import forecast_contract_v4406 as FC
import target_contract_v4405 as TC


def history(end='2026-01-30', n=80, start=100.0, step=.6):
    idx=pd.bdate_range(end=end,periods=n)
    close=[start+i*step for i in range(n)]
    return pd.DataFrame({'date':idx,'open':close,'high':[x*1.002 for x in close],'low':[x*.998 for x in close],'close':close})


def forecast_row(as_of='2026-01-15', p=.68, abstain=False, horizon=5):
    h=history(end=as_of,n=70)
    tail=[{'t':str(r.date.date()),'o':float(r.open),'h':float(r.high),'l':float(r.low),'c':float(r.close)} for r in h.itertuples()]
    f={
        'p_up':p,'p_down':1-p,'abstain':abstain,'signal_strength':'умеренный' if not abstain else 'нет преимущества',
        'signal_threshold':.58,'regime':'trend_up|normal_vol','model_version':'dynamic-meta-ensemble-v4.35.0',
        'model_generation':FC.MODEL_GENERATION,'target_version':TC.TARGET_VERSION,'probability_semantics':FC.PROBABILITY_SEMANTICS_VERSION,
        'p_move':.70,'p_neutral':.30,'conditional_p_up':min(.99,max(.01,.5+(p-.5)/.70)),
        'class_probabilities':{'up':.70*min(.99,max(.01,.5+(p-.5)/.70)),'neutral':.30,'down':.70*(1-min(.99,max(.01,.5+(p-.5)/.70)))},
        'confidence_score':.64,'reliability':{'probability':.64},
        'components':[
            {'name':'production','p_up':.64,'conditional_p_up':.70,'p_move':.70,'p_neutral':.30,'weight':.58},
            {'name':'vol_regime','p_up':.72,'conditional_p_up':.80,'p_move':.70,'p_neutral':.30,'weight':.42},
            {'name':'context_advisory','p_up':.70,'conditional_p_up':.76,'p_move':.70,'p_neutral':.30,'weight':.04,'validated':False},
        ],
        'dynamic_weights':{'production':.58,'vol_regime':.42},
        'context_disagreement':False,'event_risk':.1,'feature_drift':{'score':.12},
        'quality':{'trusted':not abstain},'scorecard':{'meta_oos_n':42},'validation':{'automatic_promotion':False},
    }
    return {'symbol':'AAPL','status':'ok','source':'test history','as_of':as_of,'history':tail,
            'forecasts':{str(horizon):f},'model':'AllAnalytics v4.35 Dynamic Ensemble'}


def test_ledger_is_idempotent_and_immutable(tmp_path):
    led=F.Ledger(tmp_path/'ledger.sqlite3')
    row=forecast_row()
    first=led.record_row(row,'test')
    second=led.record_row(row,'test-repeat')
    assert first['inserted']==1
    assert second['inserted']==0 and second['existing']==1
    rows=led.rows()
    assert len(rows)==1
    assert rows[0]['p_up']==.68
    assert rows[0]['model_version']==FC.MODEL_GENERATION
    assert rows[0]['abstain'] is False


def test_settlement_uses_future_trading_bars(tmp_path):
    led=F.Ledger(tmp_path/'ledger.sqlite3')
    led.record_row(forecast_row(as_of='2026-01-15',horizon=5),'test')
    pre=history(end='2026-01-15',n=70)
    last=float(pre.iloc[-1]['close'])
    future=pd.DataFrame({'date':pd.bdate_range('2026-01-16',periods=30),'close':[last*(1+.01*(i+1)) for i in range(30)]})
    full=pd.concat([pre[['date','close']],future],ignore_index=True)
    result=led.settle_due(lambda symbol:full,limit=10)
    assert result['settled']==1
    row=led.rows(settled_only=True)[0]
    base=pd.Timestamp('2026-01-15')
    expected=full[full['date']>base].iloc[4]
    assert row['target_as_of']==str(expected['date'].date())
    assert abs(row['target_price']-float(expected['close']))<1e-9
    assert row['outcome']=='up'
    assert row['published_hit']==1


def test_abstention_is_scored_separately(tmp_path):
    led=F.Ledger(tmp_path/'ledger.sqlite3')
    led.record_row(forecast_row(as_of='2026-01-15',p=.53,abstain=True,horizon=3),'test')
    # Flat future: eventual move should remain inside the volatility-adjusted neutral band.
    pre=history(end='2026-01-15',n=70)
    last=float(pre.iloc[-1]['close'])
    future=pd.DataFrame({'date':pd.bdate_range('2026-01-16',periods=8),'close':[last]*8})
    full=pd.concat([pre[['date','close']],future],ignore_index=True)
    out=led.settle_due(lambda symbol:full,limit=10)
    assert out['settled']==1
    row=led.rows(settled_only=True)[0]
    assert row['outcome']=='neutral'
    assert row['published_hit'] is None
    assert row['error_code']=='correct_abstention'


def test_leaderboard_compares_same_prospective_observations(tmp_path):
    led=F.Ledger(tmp_path/'ledger.sqlite3')
    dates=['2025-10-01','2025-10-10','2025-10-20','2025-11-03','2025-11-12','2025-11-21']
    for i,d in enumerate(dates):
        row=forecast_row(as_of=d,p=.68 if i%2==0 else .32,abstain=False,horizon=1)
        led.record_row(row,'test')
    # Build a long zig-zag series with sufficient future observations after every forecast date.
    idx=pd.bdate_range('2025-09-01','2026-02-01')
    vals=[]
    x=100.0
    for d in idx:
        # Alternating broad swings ensure significant outcomes exist.
        x*=1.015 if len(vals)%2==0 else .985
        vals.append(x)
    full=pd.DataFrame({'date':idx,'close':vals})
    led.settle_due(lambda symbol:full,limit=100)
    board=led.leaderboard(window_days=1000,horizon=1,symbol='AAPL')
    names={m['name'] for m in board['models']}
    assert 'dynamic_ensemble_v435' in names
    assert 'production' in names
    assert 'vol_regime' in names
    assert board['review_readiness']['automatic_promotion'] is False


def test_error_attribution_flags_model_disagreement(tmp_path):
    led=F.Ledger(tmp_path/'ledger.sqlite3')
    row=forecast_row(as_of='2026-01-15',p=.75,abstain=False,horizon=1)
    f=row['forecasts']['1']
    f['components'][0]['p_up']=.82
    f['components'][1]['p_up']=.30
    led.record_row(row,'test')
    pre=history(end='2026-01-15',n=70,start=100,step=.3)
    last=float(pre.iloc[-1]['close'])
    future=pd.DataFrame({'date':pd.bdate_range('2026-01-16',periods=5),'close':[last*.96,last*.95,last*.94,last*.93,last*.92]})
    full=pd.concat([pre[['date','close']],future],ignore_index=True)
    led.settle_due(lambda symbol:full,limit=10)
    settled=led.rows(settled_only=True)[0]
    assert settled['error_code']=='component_disagreement'
    assert 'сильное расхождение моделей' in settled['attribution']['tags']


def test_api_and_ui_expose_v436_contract():
    root=Path(__file__).parent
    api=(root/'api.py').read_text(encoding='utf-8')
    tech=(root/'site'/'technical_lab_v411.html').read_text(encoding='utf-8')
    assert '/api/models/prospective-v436/leaderboard' in api
    assert '/api/models/prospective-v436/settle' in api
    assert '_record_feedback_v436' in api
    assert 'Проспективная проверка v4.36' in tech
    assert 'loadProspectiveStatsV436' in tech

def test_long_horizon_pending_rows_do_not_block_ready_short_rows(tmp_path):
    led=F.Ledger(tmp_path/'ledger.sqlite3')
    led.record_row(forecast_row(as_of='2026-08-25',p=.6,abstain=False,horizon=60),'long')
    led.record_row(forecast_row(as_of='2026-09-01',p=.6,abstain=False,horizon=1),'short')
    pending=led._pending(limit=1)
    assert len(pending)==1
    assert pending[0]['horizon']==1
