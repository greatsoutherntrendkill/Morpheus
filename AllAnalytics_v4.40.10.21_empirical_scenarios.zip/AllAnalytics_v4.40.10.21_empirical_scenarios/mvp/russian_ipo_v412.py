"""AllAnalytics v4.12 — Russian IPO/DPO market intelligence.

Primary transaction universe: PREQVECA IPO/SPO database (Russian issuers and
Russian-market placements, 1996–2026 snapshot captured for v4.12).
Analytical overlays: Bank of Russia annual IPO reviews (2024, 2025) and
ALOR BROKER Russian IPO studies (2014–2024 and the 2014–2025 update).

Goodwill is not an IPO metric: it arises in business combinations, so IPO cards
show it as not applicable rather than inventing a number.
"""
from __future__ import annotations
from typing import Any
import re

VERSION="4.12"
PREQVECA_URL="https://preqveca.ru/placements/"

_RAW = r"""
Инкаб Холдинг|Технологии, телекоммуникации и медиа|ММВБ|27|2026-06-24|IPO
B2B-РТС|Технологии, телекоммуникации и медиа|ММВБ|32|2026-04-17|IPO
Базис|Технологии, телекоммуникации и медиа|ММВБ|39|2025-12-10|IPO
ДОМ.РФ|Финансовые услуги|ММВБ|309|2025-11-20|IPO
Glorax|Недвижимость и девелопмент|ММВБ|26|2025-10-31|IPO
JetLend|Финансовые услуги|Санкт-Петербургская биржа|6|2025-03-26|IPO
Ламбумиз|Лесная промышленность и ЦБК, Пищевая|ММВБ|8|2024-10-30|IPO
Озон Фармацевтика|Фармацевтика и аптеки|ММВБ|36|2024-10-16|IPO
Arenadata|Технологии, телекоммуникации и медиа|ММВБ|29|2024-10-01|IPO
АПРИ|Недвижимость и девелопмент|ММВБ|10|2024-07-30|IPO
Промомед|Медицинские услуги|ММВБ|68|2024-07-12|IPO
Всеинструменты.ру|Торговля и потребительский сектор|ММВБ|136|2024-07-05|IPO
IVA Technologies|Технологии, телекоммуникации и медиа|ММВБ|37|2024-06-04|IPO
Группа компаний Элемент|Машиностроение, Технологии, телекоммуникации и медиа|Санкт-Петербургская биржа|166|2024-05-30|IPO
Светофор Групп (IPO СПб)|Образовательные услуги, Технологии, телекоммуникации и медиа|Санкт-Петербургская Валютная Биржа|2|2024-05-24|IPO
МТС Банк|Финансовые услуги|ММВБ|125|2024-04-26|IPO
Займер|Финансовые услуги|ММВБ|37|2024-04-12|IPO
Европлан|Транспорт и логистика, Финансовые услуги|ММВБ|142|2024-03-29|IPO
Калужский ликеро-водочный завод Кристалл|Пищевая|ММВБ|13|2024-02-22|IPO
Диасофт|Технологии, телекоммуникации и медиа|ММВБ|46|2024-02-13|IPO
Делимобиль|Технологии, телекоммуникации и медиа, Транспорт и логистика|ММВБ|46|2024-02-06|IPO
Мосгорломбард (МГЛК)|Финансовые услуги|ММВБ|3|2023-12-28|IPO
Совкомбанк|Финансовые услуги|ММВБ|128|2023-12-15|IPO
Южуралзолото (ЮГК)|Металлургия и горное дело|ММВБ|80|2023-11-22|IPO
Евротранс|Нефть и газ|ММВБ|153|2023-11-21|IPO
Henderson|Текстиль и производство одежды, Торговля и потребительский сектор|ММВБ|41|2023-11-02|IPO
Группа Астра (Astra Linux)|Технологии, телекоммуникации и медиа|ММВБ|36|2023-10-13|IPO
Софтлайн (DPO)|Технологии, телекоммуникации и медиа|ММВБ||2023-09-28|DPO
СмартТехГрупп / CarMoney (DPO)|Финансовые услуги|ММВБ|11|2023-07-03|DPO
Genetico|Биотехнологии и медико-биологические исследования, Медицинские услуги|ММВБ|2|2023-04-25|IPO
Whoosh|Технологии, телекоммуникации и медиа, Транспорт и логистика|ММВБ|33|2022-12-14|IPO
Positive Technologies (DPO)|Технологии, телекоммуникации и медиа|ММВБ||2021-12-17|DPO
СПБ Биржа|Финансовые услуги|Санкт-Петербургская биржа|175|2021-11-19|IPO
ЦИАН|Недвижимость и девелопмент, Технологии, телекоммуникации и медиа|NYSE|291|2021-11-09|IPO
Softline|Технологии, телекоммуникации и медиа|London Stock Exchange|400|2021-10-27|IPO
Ренессанс страхование|Страхование|ММВБ|250|2021-10-20|IPO
Европейский медицинский центр (EMC)|Медицинские услуги|ММВБ|500|2021-07-15|IPO
Segezha Group|Лесная промышленность и ЦБК|ММВБ|411|2021-04-28|IPO
Semrush|Технологии, телекоммуникации и медиа|NYSE|140|2021-03-25|IPO
Fix Price|Торговля и потребительский сектор|London Stock Exchange, ММБ|1740|2021-03-09|IPO
Светофор Групп (IPO МСК)|Образовательные услуги, Технологии, телекоммуникации и медиа|ММВБ||2021-01-17|IPO
OZON|Технологии, телекоммуникации и медиа, Торговля и потребительский сектор|NASDAQ|1140|2020-11-24|IPO
Группа Самолет|Недвижимость и девелопмент|ММВБ|37|2020-10-28|IPO
Совкомфлот|Транспорт и логистика|ММВБ|550|2020-10-07|IPO
Дон Агро|Пищевая, Сельское хозяйство и АПК|Сингапурская биржа|4|2020-02-12|IPO
Гемабанк (ММЦБ)|Биотехнологии и медико-биологические исследования|ММВБ|2|2019-07-26|IPO
HeadHunter|Технологии, телекоммуникации и медиа|NASDAQ|220|2019-05-08|IPO
Норильский Никель|Металлургия и горное дело|ММВБ|550|2019-03-13|IPO
Глобалтрак менеджмент|Транспорт и логистика|ММВБ|65|2017-11-03|IPO
En+ Group|Металлургия и горное дело, Энергетика|London Stock Exchange|1500|2017-11-03|IPO
Обувь России|Торговля и потребительский сектор|ММВБ|103|2017-10-19|IPO
Детский мир|Торговля и потребительский сектор|ММВБ|300|2017-02-08|IPO
Русснефть|Нефть и газ|ММВБ|500|2016-11-24|IPO
ФГ Будущее|Финансовые услуги|ММВБ|185|2016-10-28|IPO
Объединённая вагонная компания (ОВК)|Транспорт и логистика|ММВБ|173|2015-04-29|IPO
Сеть гипермаркетов Лента|Торговля и потребительский сектор|London Stock Exchange|952|2014-02-28|IPO
ОАО ТПГ АЭССЕЛЬ|Другие отрасли|ММВБ|6|2013-11-12|IPO
АЛРОСА|Добыча золота, алмазов и драгоценных камней|ММВБ|1304|2013-10-24|IPO
ТКС Банк|Финансовые услуги|London Stock Exchange|1087|2013-10-22|IPO
ОАО Живой офис|Торговля и потребительский сектор|ММВБ|16|2013-07-08|IPO
Luxoft|Технологии, телекоммуникации и медиа|NYSE|70|2013-06-26|IPO
QIWI Plc|Финансовые услуги|NASDAQ|213|2013-05-03|IPO
Московская Биржа|Финансовые услуги|ММВБ|498|2013-02-15|IPO
Мультисистема|Коммунальный сектор|ММВБ|3|2012-12-27|IPO
Мегафон|Технологии, телекоммуникации и медиа|London Stock Exchange, ММВБ|1860|2012-11-27|IPO
MD Medical Group|Медицинские услуги|London Stock Exchange|311|2012-10-15|IPO
EPAM SYSTEMS|Технологии, телекоммуникации и медиа|NYSE|72|2012-02-08|IPO
Nordgold (IPO I)|Металлургия и горное дело|London Stock Exchange|292|2012-01-19|IPO
RusPetro Plc|Нефть и газ|London Stock Exchange|250|2012-01-19|IPO
Polymetal International plc|Металлургия и горное дело|London Stock Exchange|785|2011-10-27|IPO
Ютинет.Ру|Технологии, телекоммуникации и медиа|ММВБ|14|2011-07-19|IPO
ФосАгро|Химия и нефтехимия|London Stock Exchange|538|2011-07-13|IPO
Global Ports Investments Plc|Транспорт и логистика|London Stock Exchange|588|2011-06-23|IPO
Яндекс|Технологии, телекоммуникации и медиа|NASDAQ|1435|2011-05-23|IPO
Сыктывкар Тиссью Групп|Лесная промышленность и ЦБК|ММВБ||2011-05-26|IPO
Армада|Технологии, телекоммуникации и медиа|ММВБ, РТС|31|2011-04-13|IPO
НОМОС-БАНК|Финансовые услуги|London Stock Exchange, ММВБ|718|2011-04-18|IPO
ЛенспецСМУ|Недвижимость и девелопмент|London Stock Exchange|575|2011-04-14|IPO
Евросеть|Торговля и потребительский сектор|London Stock Exchange|1080|2011-04-14|IPO
Витал Девелопмент Корпорэйшн|Торговля и потребительский сектор, Фармацевтика и аптеки|ММВБ, РТС|14|2011-04-18|IPO
Группа Русагро|Сельское хозяйство и АПК|London Stock Exchange|330|2011-04-08|IPO
WorldWide Papa's|Торговля и потребительский сектор|Frankfurt Stock Exchange|20|2011-02-15|IPO
Mail.ru|Технологии, телекоммуникации и медиа|London Stock Exchange|912|2010-11-05|IPO
Мостотрест|Недвижимость и девелопмент|ММВБ, РТС|388|2010-11-02|IPO
Фармсинтез|Фармацевтика и аптеки|ММВБ|17|2010-11-24|IPO
О'кей|Торговля и потребительский сектор|London Stock Exchange|419|2010-11-01|IPO
Трансконтейнер|Транспорт и логистика|London Stock Exchange, ММВБ, РТС|400|2010-11-15|IPO
IRC (Petropavlovsk)|Металлургия и горное дело|Гонконгская фондовая биржа|240|2010-10-15|IPO
Русские навигационные технологии|Технологии, телекоммуникации и медиа|ММВБ|10|2010-07-07|IPO
ДИОД|Биотехнологии и медико-биологические исследования|ММВБ|10|2010-06-23|IPO
АВАНГАРД Агрохолдинг|Сельское хозяйство и АПК|London Stock Exchange|188|2010-05-06|IPO
Кузбасская топливная компания|Металлургия и горное дело|ММВБ, РТС|164|2010-04-30|IPO
ПРОТЕК|Фармацевтика и аптеки|ММВБ, РТС|400|2010-04-26|IPO
Русское море|Пищевая|ММВБ, РТС|90|2010-04-16|IPO
РУСАЛ|Металлургия и горное дело|Гонконгская фондовая биржа|2240|2010-01-27|IPO
Институт Стволовых Клеток Человека|Биотехнологии и медико-биологические исследования|ММВБ|5|2009-12-04|IPO
ФСК ЕЭС|Энергетика|РТС|1441|2009-10-02|IPO
Alliance Oil|Нефть и газ|London Stock Exchange|390|2009-07-12|IPO
РусГидро|Энергетика|London Stock Exchange||2009-07-06|IPO
Мечел|Металлургия и горное дело|Deutsche Börse, РТС|42|2009-04-02|IPO
Кузбассэнерго|Энергетика|ММВБ|308|2008-10-01|IPO
Банк Москвы|Финансовые услуги|ММВБ, РТС|377|2008-09-01|IPO
Акрон|Химия и нефтехимия|London Stock Exchange, ММВБ|3|2008-08-12|IPO
Globaltrans|Транспорт и логистика|London Stock Exchange|449|2008-05-08|IPO
ТГК-6|Энергетика|РТС|616|2008-04-16|IPO
Волжская ТГК (ТГК-7)|Энергетика|ММВБ, РТС|463|2008-03-14|IPO
Группа ЛСР|Недвижимость и девелопмент|London Stock Exchange, ММВБ|772|2007-11-16|IPO
Синергия|Пищевая|ММВБ, РТС|190|2007-11-15|IPO
Новороссийский морской торговый порт|Транспорт и логистика|London Stock Exchange, ММВБ, РТС|955|2007-11-08|IPO
Банк Санкт-Петербург|Финансовые услуги|ММВБ, РТС|274|2007-11-01|IPO
М.Видео|Торговля и потребительский сектор|ММВБ, РТС|365|2007-11-01|IPO
Уралкалий|Химия и нефтехимия|London Stock Exchange, РТС|1069|2007-10-19|IPO
ОГК-2|Энергетика|London Stock Exchange, ММВБ, РТС|996|2007-10-10|IPO
ДВМП|Транспорт и логистика|РТС|206|2007-08-03|IPO
Армада|Технологии, телекоммуникации и медиа|ММВБ, РТС|30|2007-07-25|IPO
Группа Компаний ПИК|Недвижимость и девелопмент|London Stock Exchange, ММВБ, РТС|1929|2007-06-06|IPO
ТГК-5|Энергетика|РТС|452|2007-05-28|IPO
РТМ|Недвижимость и девелопмент|РТС|92|2007-05-23|IPO
Дикси Групп|Торговля и потребительский сектор|ММВБ, РТС|360|2007-05-21|IPO
ВТБ|Финансовые услуги|London Stock Exchange, ММВБ|8019|2007-05-18|IPO
Фармстандарт|Фармацевтика и аптеки|London Stock Exchange, ММВБ, РТС|952|2007-05-11|IPO
Банк Возрождение|Финансовые услуги|ММВБ, РТС|177|2007-05-11|IPO
AFI Development|Недвижимость и девелопмент|London Stock Exchange|1400|2007-05-03|IPO
ММК|Металлургия и горное дело|London Stock Exchange, ММВБ|1121|2007-04-30|IPO
НУТРИНВЕСТХОЛДИНГ|Пищевая|ММВБ, РТС|200|2007-04-27|IPO
Волга Газ|Нефть и газ|LSE's AIM|125|2007-04-25|IPO
Сбербанк России|Финансовые услуги|ММВБ, РТС|8800|2007-03-24|IPO
ОГК-3|Энергетика|РТС|3100|2007-03-09|IPO
Полиметалл|Металлургия и горное дело|London Stock Exchange, ММВБ, РТС|605|2007-02-27|IPO
Ситроникс|Технологии, телекоммуникации и медиа|London Stock Exchange|402|2007-02-12|IPO
Интегра|Нефтяное оборудование и услуги|London Stock Exchange|768|2007-01-27|IPO
Центр международной торговли|Недвижимость и девелопмент|РТС|105|2006-12-07|IPO
Северсталь|Металлургия и горное дело|London Stock Exchange|1063|2006-11-14|IPO
ТМК|Металлургия и горное дело|London Stock Exchange, РТС|1069|2006-11-10|IPO
Распадская|Металлургия и горное дело|ММВБ, РТС|317|2006-11-10|IPO
Челябинский цинковый завод|Металлургия и горное дело|London Stock Exchange, РТС|324|2006-11-10|IPO
Система-Галс|Недвижимость и девелопмент|London Stock Exchange|432|2006-11-08|IPO
ОГК-5|Энергетика|ММВБ, РТС|459|2006-10-31|IPO
Телесет Нетворкс|Технологии, телекоммуникации и медиа|LSE's AIM|34|2006-10-12|IPO
Петронефть|Нефть и газ|LSE's AIM|16|2006-09-27|IPO
Роснефть|Нефть и газ|London Stock Exchange, ММВБ, РТС|10656|2006-07-19|IPO
СТС Медиа|Технологии, телекоммуникации и медиа|NASDAQ OMX First North|346|2006-06-01|IPO
Белон|Металлургия и горное дело|РТС|57|2006-06-05|IPO
Группа Черкизово|Торговля и потребительский сектор|London Stock Exchange, МФБ, РТС|251|2006-05-15|IPO
Верофарм|Фармацевтика и аптеки|РТС|140|2006-04-25|IPO
Магнит|Торговля и потребительский сектор|ММВБ, РТС|368|2006-04-24|IPO
Группа Разгуляй|Пищевая|ММВБ, РТС|144|2006-03-06|IPO
Комстар-ОТС|Технологии, телекоммуникации и медиа|London Stock Exchange|1062|2006-02-13|IPO
Trader Media East|Технологии, телекоммуникации и медиа|London Stock Exchange|565|2006-02-13|IPO
Юралс Энерджи|Нефть и газ|LSE's AIM|132|2005-08-09|IPO
Рейвен Россия|Недвижимость и девелопмент|LSE's AIM|268|2005-07-29|IPO
Новатэк|Нефть и газ|London Stock Exchange, ММВБ|966|2005-07-27|IPO
Евраз Групп|Металлургия и горное дело|London Stock Exchange|422|2005-06-07|IPO
X5 Retail Group|Торговля и потребительский сектор|London Stock Exchange|639|2005-05-11|IPO
СОЛЛЕРС|Автомобилестроение|ММВБ, РТС|135|2005-04-24|IPO
ПАВА|Пищевая|ММВБ, РТС|8|2005-03-21|IPO
Лебедянский|Пищевая|ММВБ, РТС|151|2005-03-11|IPO
АФК Система|Многопрофильная компания|London Stock Exchange|1557|2005-02-14|IPO
Открытые инвестиции|Недвижимость и девелопмент|РТС|69|2004-11-16|IPO
Седьмой Континент|Торговля и потребительский сектор|РТС|81|2004-11-12|IPO
Калина|Химия и нефтехимия|ММВБ, РТС|53|2004-04-28|IPO
Иркут|Машиностроение|ММВБ, РТС|127|2004-03-26|IPO
Транс Сибирь|Добыча золота, алмазов и драгоценных камней|LSE's AIM|27|2003-11-25|IPO
ОМЗ|Машиностроение|London Stock Exchange||2003-10-30|IPO
Аптечная сеть 36,6|Фармацевтика и аптеки|ММВБ|14|2003-01-31|IPO
Группа компаний Петропавловск|Добыча золота, алмазов и драгоценных камней|London Stock Exchange|11|2002-04-29|IPO
РБК ИС|Технологии, телекоммуникации и медиа|ММВБ, РТС|13|2002-04-18|IPO
ВБД ПП|Пищевая|NYSE|207|2002-02-08|IPO
МТС|Технологии, телекоммуникации и медиа|NYSE|353|2000-06-30|IPO
Лукойл|Нефть и газ|London Stock Exchange||1997-05-07|IPO
Татнефть|Нефть и газ|London Stock Exchange|169|1996-12-13|IPO
Вымпелком|Технологии, телекоммуникации и медиа|NYSE|111|1996-11-13|IPO
Газпром|Нефть и газ|London Stock Exchange|429|1996-10-28|IPO
Eurasia Mining|Металлургия и горное дело, Нефть и газ|LSE's AIM||1996-10-02|IPO
Everfor Diamonds|Добыча золота, алмазов и драгоценных камней|LSE's AIM||1996-04-06|IPO
КИФА|Технологии, телекоммуникации и медиа, Торговля и потребительский сектор|ММВБ|||PLANNED
FabricaONE.AI|Технологии, телекоммуникации и медиа|ММВБ|||PLANNED
Домодедово|Транспорт и логистика||1000|||PLANNED
Первая грузовая компания|Транспорт и логистика|||||PLANNED
Ильюшин финанс|Машиностроение|||||PLANNED
Металлоинвест|Металлургия и горное дело|London Stock Exchange, Гонконгская фондовая биржа|4000|||PLANNED
ГК Дамате||||||PLANNED
ivi|Технологии, телекоммуникации и медиа|NASDAQ||||PLANNED
Nordgold (IPO II)|Добыча золота, алмазов и драгоценных камней|London Stock Exchange||||PLANNED
Высочайший (GV Gold)|Металлургия и горное дело|London Stock Exchange, ММВБ|500|||PLANNED
Цифра|Металлургия и горное дело, Технологии, телекоммуникации и медиа|ММВБ||||PLANNED
Mercury Retail Group (MRG)|FMCG, Торговля и потребительский сектор|ММВБ|1300|||PLANNED
Алмазы Арктики (АЛМАР)|Металлургия и горное дело|Санкт-Петербургская биржа|9|||PLANNED
"""

_ALOR = {
 "OZON": {"offer_price_rub":2272,"mcap_rub_bn":412.7,"ev_rub_bn":333.9,"ev_sales":3.2,"ev_ebitda":None,"net_debt_ebitda":5.3,"pe":None,"pb":5.2,"roe_pct":-28.1,"ebitda_margin_pct":-14.3,"net_margin_pct":-21.3,"first_day_pct":7,"day20_pct":12,"total_return_incl_div_pct":87},
 "Segezha Group": {"offer_price_rub":8,"mcap_rub_bn":125.5,"ev_rub_bn":154.4,"ev_sales":1.9,"ev_ebitda":7.5,"net_debt_ebitda":1.4,"pe":15.1,"pb":2.7,"roe_pct":18.1,"ebitda_margin_pct":25.6,"net_margin_pct":10.4,"first_day_pct":-0.4,"day20_pct":-0.4,"total_return_incl_div_pct":-67},
 "Positive Technologies (DPO)": {"offer_price_rub":770,"mcap_rub_bn":50.8,"ev_rub_bn":52.0,"ev_sales":7.4,"ev_ebitda":19.3,"net_debt_ebitda":0.4,"pe":26.6,"pb":14.5,"roe_pct":54.6,"ebitda_margin_pct":38.1,"net_margin_pct":27.1,"first_day_pct":29,"day20_pct":2,"total_return_incl_div_pct":279},
 "Совкомфлот": {"offer_price_rub":105,"mcap_rub_bn":249.4,"ev_rub_bn":426.4,"ev_sales":3.5,"ev_ebitda":6.4,"net_debt_ebitda":2.6,"pe":12.6,"pb":0.8,"roe_pct":6.7,"ebitda_margin_pct":54.7,"net_margin_pct":16.2,"first_day_pct":-4,"day20_pct":-7,"total_return_incl_div_pct":28},
 "Whoosh": {"offer_price_rub":185,"mcap_rub_bn":20.6,"ev_rub_bn":23.5,"ev_sales":3.4,"ev_ebitda":9.3,"net_debt_ebitda":1.1,"pe":24.8,"pb":4.2,"roe_pct":17.1,"ebitda_margin_pct":36.2},
 "Genetico": {"first_day_pct":40,"day20_pct":59,"quarter_pct":87},
 "Группа Астра (Astra Linux)": {"first_day_pct":40},
 "Диасофт": {"first_day_pct":40},
 "Калужский ликеро-водочный завод Кристалл": {"first_day_pct":-15},
 "Сеть гипермаркетов Лента": {"first_day_pct":-15},
 "Светофор Групп (IPO МСК)": {"first_day_pct":50},
}

_CBR = {
 2024: {"title":"Публичные размещения и предложения акций: итоги 2024 года","public_offerings":19,"first_time_issuers":15,"volume_rub_bn":102.1,"avg_return_day1_pct":2.5,"avg_return_30d_pct":2.4,"avg_return_6m_pct":-25.8,"new_issuer_free_float_range":"8–13,5%","listed_avg_free_float_pct":28,"retail_share_pct":40,"institutional_share_pct":48,"nonfinancial_share_pct":13,"note":"2024 год стал рекордным по количеству публичных размещений за 10 лет; объем привлечения при этом был ниже 2023 года."},
 2025: {"title":"Публичные размещения и предложения акций: итоги 2025 года","public_offerings":9,"ipo_count":4,"spo_count":5,"volume_rub_bn":125.2,"max_ipo_rub_bn":31.7,"median_ipo_rub_bn":2.5,"min_ipo_rub_bn":0.4764,"avg_new_issuer_free_float_pct":11,"listed_avg_free_float_pct":26,"institutional_share_pct":52,"retail_volume_rub_bn":45.1,"note":"Объем публичных размещений вырос, но активность была сконцентрирована в небольшом числе эмитентов; Банк России отдельно отмечал риск завышенной стартовой оценки части IPO."}
}
ALOR_CONTEXT={
 "2024":{"period":"2014–2024","companies":44,"placements":45,"volume_rub_bn":760.3,"avg_total_return_incl_div_pct":8.0,"positive_first_day_pct":51,"negative_first_day_pct":33,"flat_first_day_pct":16,"avg_deal_2023_24_rub_bn":5.8,"avg_deal_2014_22_rub_bn":26.6},
 "2026_update":{"period":"2014–2025","companies":51,"placements":52,"volume_rub_bn":804.4,"avg_total_return_incl_div_pct":0.1,"positive_first_day_pct":48,"negative_first_day_pct":33,"flat_first_day_pct":19,"avg_deal_2023_25_rub_bn":5.9,"avg_deal_2014_22_rub_bn":26.6}
}

def _slug(s:str)->str:
 s=s.lower().replace('ё','е')
 return re.sub(r'[^a-zа-я0-9]+','-',s,flags=re.I).strip('-')[:80] or 'ipo'

def _parse():
 rows=[]; seen={}
 for line in _RAW.strip().splitlines():
  parts=line.split('|')
  if len(parts)<6: continue
  name,sector,exchange,usd,date_s,kind=(parts+['']*6)[:6]
  status='planned' if kind=='PLANNED' or not date_s else 'completed'
  event_type='IPO' if kind in ('IPO','PLANNED') else kind
  year=int(date_s[:4]) if date_s and date_s[:4].isdigit() else None
  base=_slug(name); seen[base]=seen.get(base,0)+1
  rid=base+(f'-{year}' if year else '-planned')+(f'-{seen[base]}' if seen[base]>1 else '')
  row={"id":rid,"company":name,"sector":sector or "Другие отрасли","exchange":exchange or None,"placement_usd_m":float(usd) if usd else None,"date":date_s or None,"year":year,"event_type":event_type,"status":status,"source":"PREQVECA","source_url":PREQVECA_URL}
  row["listing_scope"]="Россия" if exchange and any(x in exchange for x in ('ММВБ','РТС','Санкт-Петербург','ММБ','МФБ')) else "Международная биржа"
  if name in _ALOR: row["alor"]=_ALOR[name]
  if year in _CBR: row["cbr_context"]=_CBR[year]
  rows.append(row)
 return rows

ROWS=_parse()

def status()->dict[str,Any]:
 completed=[r for r in ROWS if r['status']=='completed']; years=[r['year'] for r in completed if r['year']]
 per_year={}
 for r in completed: per_year[r['year']]=per_year.get(r['year'],0)+1
 return {"version":VERSION,"provider":"PREQVECA + Банк России + АЛОР БРОКЕР","count":len(ROWS),"completed_count":len(completed),"planned_count":len(ROWS)-len(completed),"min_year":min(years),"max_year":max(years),"sectors":sorted({r['sector'] for r in completed}),"years":[{"year":k,"count":v} for k,v in sorted(per_year.items())],"cbr":_CBR,"alor":ALOR_CONTEXT,"sources":[{"name":"PREQVECA IPO/SPO","url":PREQVECA_URL,"role":"универсум размещений"},{"name":"Банк России","url":"https://www.cbr.ru/analytics/issuers_corporate/IPO_review/","role":"рынок, инвесторы, free-float, доходность"},{"name":"АЛОР БРОКЕР","url":"https://storage.alorbroker.ru/upload/news/АЛОР БРОКЕР - Исследование Рынка IPO в России.pdf","role":"мультипликаторы и рыночная динамика"}],"methodology":{"spo_excluded":True,"dpo_included":True,"goodwill":"Не применимо к IPO: goodwill возникает при приобретении бизнеса, а не при размещении акций.","multiples":"Показываются только когда опубликованы в источнике; отсутствующие значения не моделируются как факт."}}

def _filter(range_id='latest',q='',sector='',year=None,status_filter='completed'):
 rows=list(ROWS)
 if status_filter!='all': rows=[r for r in rows if r['status']==status_filter]
 max_year=max(r['year'] or 0 for r in ROWS)
 if range_id=='latest': rows=[r for r in rows if r['year'] and r['year']>=max_year-2]
 elif range_id=='1y': rows=[r for r in rows if r['year']==max_year]
 elif range_id in ('1996','all'): pass
 elif range_id=='2014': rows=[r for r in rows if r['year'] and r['year']>=2014]
 else: raise ValueError('range must be latest, 1y, 2014, 1996 or all')
 if q:
  n=q.strip().lower().replace('ё','е'); rows=[r for r in rows if n in (' '.join(str(r.get(k) or '') for k in ('company','sector','exchange','event_type'))).lower().replace('ё','е')]
 if sector: rows=[r for r in rows if sector==r['sector']]
 if year: rows=[r for r in rows if r['year']==int(year)]
 return sorted(rows,key=lambda r:(r['date'] or '0000-00-00',r['company']),reverse=True)

def list_ipos(range_id='latest',limit=60,offset=0,q='',sector='',year=None,status_filter='completed')->dict[str,Any]:
 rows=_filter(range_id,q,sector,year,status_filter); total=len(rows); start=max(0,int(offset)); out=rows[start:start+max(1,min(int(limit),100))]
 return {"version":VERSION,"provider":"Russian IPO Intelligence","range":range_id,"count":len(out),"total":total,"offset":start,"rows":out,"max_year":status()['max_year']}

def _find(ipo_id):
 for r in ROWS:
  if r['id']==ipo_id:return dict(r)
 raise KeyError(ipo_id)

def _structure(row):
 a=row.get('alor') or {}; cash_in=a.get('cash_in_pct')
 return {"placement_usd_m":row.get('placement_usd_m'),"capital_pct":a.get('capital_pct'),"cash_in_pct":cash_in,"cash_out_pct":(100-cash_in) if cash_in is not None else None,"free_float_pct":a.get('free_float_pct'),"note":"Для IPO структура финансирования — cash-in (новые акции, деньги эмитенту) и cash-out (продажа существующих акций акционерами), а не debt/cash consideration как в M&A."}

def analyze(ipo_id:str)->dict[str,Any]:
 r=_find(ipo_id); a=r.get('alor') or {}; cbr=r.get('cbr_context'); placement=r.get('placement_usd_m')
 r.update({"version":VERSION,"country":"RU","asset_class":"IPO","summary_ru":f"{r['company']} — {r['event_type']} на {r.get('exchange') or 'бирже без уточнения'}"+(f" с объемом около ${placement:g} млн." if placement is not None else ". Объем в карточке PREQVECA не указан."),"deal_structure":_structure(r),"valuation":{"market_cap_rub_bn":a.get('mcap_rub_bn'),"enterprise_value_rub_bn":a.get('ev_rub_bn'),"ev_sales":a.get('ev_sales'),"ev_ebitda":a.get('ev_ebitda'),"pe":a.get('pe'),"pb":a.get('pb'),"net_debt_ebitda":a.get('net_debt_ebitda'),"roe_pct":a.get('roe_pct'),"ebitda_margin_pct":a.get('ebitda_margin_pct'),"net_margin_pct":a.get('net_margin_pct'),"note":"Мультипликаторы — только опубликованные значения из аналитических материалов АЛОР; пустое поле означает отсутствие стандартизированного источника, а не ноль."},"goodwill":{"applicable":False,"value":None,"note":"Goodwill не возникает в результате IPO. Это показатель учета бизнес-комбинаций (M&A), поэтому для первичного размещения корректное значение — «не применимо»."},"financing":{"mode":"equity placement","primary_secondary":_structure(r),"note":"Экономический эффект IPO — привлечение собственного капитала и/или монетизация доли действующих акционеров."},"market_reaction":{"first_day_pct":a.get('first_day_pct'),"day20_pct":a.get('day20_pct'),"quarter_pct":a.get('quarter_pct'),"total_return_incl_div_pct":a.get('total_return_incl_div_pct'),"source":"АЛОР БРОКЕР" if a else None,"note":"Доходности показываются только там, где они сопоставлены с конкретным размещением в исследовании АЛОР."},"benchmark":{"cbr":cbr,"alor_market":ALOR_CONTEXT['2026_update'] if (r.get('year') or 0)>=2014 else None},"sources":[{"name":"PREQVECA","url":PREQVECA_URL,"field":"компания, дата, биржа, объем USD, сектор"},{"name":"Банк России","url":"https://www.cbr.ru/analytics/issuers_corporate/IPO_review/","field":"агрегаты рынка 2024–2025"},{"name":"АЛОР БРОКЕР","url":"https://storage.alorbroker.ru/upload/news/АЛОР БРОКЕР - Исследование Рынка IPO в России.pdf","field":"мультипликаторы и реакция рынка, когда доступны"}]})
 return r
