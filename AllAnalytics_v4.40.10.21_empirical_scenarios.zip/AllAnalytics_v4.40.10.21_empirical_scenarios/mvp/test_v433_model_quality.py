import numpy as np
import pandas as pd

import model_quality_v433 as Q
import meta_forecast_v433 as META
import equity_forecast_v416 as E


def series(seed=433, n=900, drift=.00025, vol=.011):
    rng=np.random.default_rng(seed)
    idx=pd.bdate_range(end=pd.Timestamp('2026-09-11'),periods=n)
    r=rng.normal(drift,vol,n)
    return pd.Series(100*np.exp(np.cumsum(r)),index=idx)


def frame(s):
    c=s.to_numpy(float)
    return pd.DataFrame({'date':s.index,'open':c,'high':c*1.004,'low':c*.996,'close':c})


def test_neutral_target_exists_and_is_volatility_adjusted():
    s=series()
    t=Q._target_frame(s,10)
    states=set(t['state'].dropna().astype(int).unique())
    assert 0 in states
    assert states.issubset({-1,0,1})
    assert float(t['threshold'].dropna().median())>0


def test_challenger_has_regime_calibration_and_abstention_contract():
    out=Q.walk_forward_regime(series(),horizon=10,min_train=140,retrain_every=40)
    assert out['version'].startswith('vol-regime-challenger')
    assert 0.02 <= out['p_up'] <= 0.98
    assert '|' in out['regime']
    assert out['signal_strength'] in {'выраженный','умеренный','слабый','нет преимущества'}
    assert isinstance(out['abstain'],bool)
    assert out['validation']['calibration_uses_future'] is False
    assert 'neutral_share_oos' in out['scorecard']


def test_meta_probability_is_bounded_and_components_are_visible():
    out=META.forecast_horizon(series(seed=99),horizon=10,fast=True)
    assert 0.05 <= out['p_up'] <= 0.95
    assert out['components']
    assert {x['name'] for x in out['components']} <= {'production','vol_regime'}
    assert out['signal_strength'] in {'выраженный','умеренный','слабый','нет преимущества'}
    assert 'automatic_promotion' in out['validation']


def test_equity_forecast_uses_v433_meta(monkeypatch,tmp_path):
    d=frame(series(n=760))
    monkeypatch.setattr(E,'RU_HISTORY_DIR',tmp_path)
    monkeypatch.setattr(E,'FAST_DISK_DIR',tmp_path/'fast')
    E.FAST_DISK_DIR.mkdir(parents=True,exist_ok=True)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(d.copy(),'history mock',[]))
    monkeypatch.setattr(E,'_append_live_ru',lambda x,s:x)
    row=E.forecast_fast('SBER.ME',(10,),force=True)
    assert row['status']=='ok'
    f=row['forecasts']['10']
    assert f['p_up'] is not None
    assert f.get('model_version')=='champion-validation-v4.40.10'
    assert 'signal_strength' in f
    assert row['profile'] in {'fast-ui-v433','fast-ui-v434','fast-ui-v435'}


def test_overview_and_terminal_use_v433_market_forecast_endpoint():
    from pathlib import Path
    root=Path(__file__).parent/'site'
    index=(root/'index.html').read_text(encoding='utf-8')
    tech=(root/'technical_lab_v411.html').read_text(encoding='utf-8')
    assert 'loadOverviewDailyForecastV434' in index or 'loadOverviewDailyForecastV433' in index
    assert '/api/markets/forecast?symbol=' in index
    assert '/api/markets/forecast?symbol=' in tech
    assert 'signal_strength' in tech
    assert 'p_neutral' in tech


def test_meta_disagreement_shrinks_probability_toward_half(monkeypatch):
    champion={
        'live_p_up':0.82,
        'quality':{'trusted':True},
        'scorecard':{'Наблюдений (effective)':80,'Преимущество non-overlap, п.п.':4.0,'Brier skill non-overlap, %':3.0,'Calibration error non-overlap':0.06},
        'validation':{}
    }
    challenger={
        'p_up':0.18,'quality':{'trusted':True},'regime':'transition|high_vol',
        'signal_threshold':0.60,'scorecard':{'directional_effective_n':70,'directional_edge_pp':3.0,'directional_brier_skill':2.0,'directional_ece':0.07,'p_neutral':0.30},
        'validation':{}
    }
    monkeypatch.setattr(META.models,'walk_forward_direction',lambda *a,**k:champion)
    monkeypatch.setattr(META.MQ,'walk_forward_regime',lambda *a,**k:challenger)
    out=META.forecast_horizon(series(n=500),horizon=10,fast=True)
    weighted=(0.82*.62+0.18*.55)/(.62+.55)
    assert out['disagreement'] is True
    assert abs(out['p_up']-.5) < abs(weighted-.5)
    assert out['quality']['trusted'] is False


def test_api_and_cache_namespace_are_v433():
    from pathlib import Path
    root=Path(__file__).parent
    api=(root/'api.py').read_text(encoding='utf-8')
    eq=(root/'equity_forecast_v416.py').read_text(encoding='utf-8')
    assert 'version="4.35"' in api or 'version="4.34"' in api or 'version="4.33"' in api
    assert '/api/models/quality-v433' in api
    assert 'equity_forecast_v435_dynamic_fast' in eq or 'equity_forecast_v434_context_fast' in eq or 'equity_forecast_v433_meta_fast' in eq
