# AllAnalytics v4.20 — VPN-resilient MOEX + stable forecasts

- MOEX transport ladder extended with DNS-over-HTTPS direct-IP connection to bypass broken VPN DNS routes.
- Last-resort public relay can fetch only public MOEX JSON; no credentials or user data are sent through it.
- Russian quote last-good disk/browser caches retained across VPN/country switches.
- Equity forecast history uses MOEX candles first through the same resilient ladder; Yahoo is a labelled historical-only backup and is rejected when stale >120 days.
- Forecasts persist to disk for fast reloads and are no longer recalculated every 30 seconds.
- Frontend forecast state machine is stable: queued → calculating → ready / temporarily unavailable. Failed calculations wait 10 minutes before retrying, eliminating the blinking loop.
- Automatic Russian forecasts are processed in small batches with only two model workers.
