import numpy as np
import pandas as pd
import equity_forecast_v416 as E


def synthetic(n=90):
    rng=np.random.default_rng(22)
    dates=pd.bdate_range(end=pd.Timestamp.today().normalize(),periods=n)
    close=200*np.exp(np.cumsum(rng.normal(.0004,.011,n)))
    return pd.DataFrame({"date":dates,"open":close,"high":close*1.004,"low":close*.996,"close":close})


def test_ru_card_forecast_works_from_compact_recent_history(monkeypatch):
    d=synthetic(90)
    monkeypatch.setattr(E,"_yahoo_forecast_history",lambda *a,**k:(pd.DataFrame(),"",["mock yahoo disabled"]))
    monkeypatch.setattr(E.MOEX419,"history_recent",lambda *a,**k:(d.copy(),{"source":"mock history","errors":[],"observations":len(d)}))
    monkeypatch.setattr(E,"_append_live_ru",lambda frame,symbol:frame)
    row=E.forecast_fast("SBER.ME",(10,),force=True)
    assert row["status"]=="ok"
    assert row["forecasts"]["10"]["p_up"] is not None
    assert "scenario fallback" in row["model"]
    assert row["stats"]["momentum_20d_pct"] is not None


def test_ru_card_forecast_supports_all_ui_horizons(monkeypatch):
    d=synthetic(95)
    monkeypatch.setattr(E,"_yahoo_forecast_history",lambda *a,**k:(pd.DataFrame(),"",["mock yahoo disabled"]))
    monkeypatch.setattr(E.MOEX419,"history_recent",lambda *a,**k:(d.copy(),{"source":"mock history","errors":[],"observations":len(d)}))
    monkeypatch.setattr(E,"_append_live_ru",lambda frame,symbol:frame)
    row=E.forecast_fast("GAZP.ME",(1,5,10,20),force=True)
    assert row["status"]=="ok"
    assert set(row["forecasts"])=={"1","5","10","20"}
    assert all(row["forecasts"][h]["p_up"] is not None for h in row["forecasts"])
