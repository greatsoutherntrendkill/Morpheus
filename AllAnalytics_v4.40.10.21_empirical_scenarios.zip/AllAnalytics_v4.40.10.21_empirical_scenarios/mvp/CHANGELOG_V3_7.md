# AllAnalytics v3.7 — Regime Mixture-of-Experts + OOD Guard

v3.7 adds a new research model generation on top of v3.6's pooled cross-asset panel.

## Architecture

`regime-moe-v3.7.0` combines three locked experts:

- global market expert;
- coarse asset-class expert;
- current risk-regime expert.

Weights are fixed before the prospective holdout:
- global: 45%
- asset class: 35%
- risk regime: 20%

The output then passes:
1. development-only Platt calibration;
2. asset-level evidence shrinkage;
3. OOD / regime-familiarity shrinkage;
4. expert-disagreement shrinkage.

Final research probability:

`0.5 + evidence_alpha × ood_alpha × agreement_alpha × (calibrated_p - 0.5)`

Raw model components remain visible for audit.

## Point-in-time regime engine

Risk-on / risk-off / mixed and high/normal/low-vol states are derived from lagged
cross-market data. Historical thresholds are expanding and shifted by one date,
so the definition of "high", "low", or "risk-on" never uses future distribution
information.

Policy and inflation regime features are based on revision-aware macro state.

## OOD guard

The model learns a training-only distribution of continuous features.
Each new observation gets `regime_familiarity` from 0–100.

Low familiarity automatically reduces conviction. Expert disagreement between
global, class and regime experts also reduces conviction.

This is specifically designed to stop the system from printing extreme
probabilities during market states that are unlike the training history.

## Development result

The raw MoE is **not a winner** on the existing development history. Its raw
Brier skill is negative across the packaged development benchmark.

However, a strict time-split Platt calibration check materially improves the late
development period. For example, calibrated late-development Brier skill is
positive on 1D/5D/10D/20D in the included run.

This does not justify promotion. It justifies keeping the architecture as a
shadow research challenger while the new prospective holdout accumulates.

## Prospective holdout

Start: **2026-09-08**

Packaged market data ends: **2026-09-04**

Realized prospective rows at package time: **0**

The production champion therefore remains `logreg-v3.2.0`.

## New free regime factors

The FRED/ALFRED configuration now also requests, on the next real data update:

- 2Y, 5Y, 10Y and 30Y Treasury yields;
- 3m–10Y curve;
- High Yield OAS;
- BBB corporate OAS;
- Chicago Fed NFCI.

The macro feature layer derives yield-curve and credit-stress features from them
while preserving revision-aware point-in-time timing.

## Optional external data slots

v3.7 ships optional clients/configuration for:

- CoinGlass V4: crypto funding, open interest, liquidations;
- Massive options chain: IV, Greeks and open interest;
- EIA API v2: energy inventories / production;
- CFTC public reporting: positioning;
- FRED/ALFRED: macro / credit / yield curves.

No premium key is required for the model to run.

## Files / endpoints

- `regime_models_v37.py`
- `build_regime_v37.py`
- `premium_data_v37.py`
- `site/regime_v37.json`
- `regime_v37.csv`
- `site/regime_lab_v37.html`
- `/api/regime-model`
- `/api/data-provider-status`
