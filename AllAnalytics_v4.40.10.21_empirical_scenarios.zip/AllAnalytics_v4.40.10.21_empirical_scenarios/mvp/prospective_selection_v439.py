"""AllAnalytics v4.39 — prospective guard for the event-response challenger."""
from __future__ import annotations
import time
import prospective_selection_v438 as BASE438
import prospective_selection_v437 as BASE437

VERSION="event-response-selection-guard-v4.40.8"
VALIDATION_VERSION="paired-prospective-event-response-data-routing-v4.40.8"
_CACHE={}


def event_report(*,window_days=365,symbol=None,horizon=None,ledger=None):
    report=BASE437.candidate_report("event_response","core_meta",window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger,current_v437_only=False)
    return {**report,"version":VERSION,"validation_version":VALIDATION_VERSION,"candidate":"event_response","baseline":"core_meta",
            "automatic_promotion":False,"policy_note":"event expert remains challenger-only until paired prospective evidence and explicit human approval"}


def event_gate(symbol:str,horizon:int,*,window_days:int=365,max_live_weight:float=.10,ledger=None,cache_seconds:int=300):
    key=(str(symbol).upper(),int(horizon),int(window_days),round(float(max_live_weight),4));now=time.time();cached=_CACHE.get(key)
    if ledger is None and cached and now-cached[0]<max(15,int(cache_seconds)):return cached[1]
    report=event_report(window_days=key[2],symbol=key[0],horizon=key[1],ledger=ledger)
    review=BASE437.REVIEW.latest("event_response",symbol=key[0],horizon=key[1]);approved=BASE437._review_approves_current_generation(review)
    active=bool(approved and report.get("eligible_for_human_review"))
    route=BASE437.learned_blend_weight("event_response","core_meta",cap=min(max(0.0,float(max_live_weight)),.16),window_days=window_days,symbol=key[0],horizon=key[1],ledger=ledger)
    weight=float(route.get("weight") or 0.0) if active else 0.0;active=bool(active and weight>0)
    result={"version":VERSION,"validation_version":VALIDATION_VERSION,"symbol":key[0],"horizon":key[1],"eligible":bool(report.get("eligible_for_human_review")),
            "human_approved":approved,"active":active,"weight":round(weight,4),"max_live_weight":round(float(max_live_weight),4),"data_driven_weight":route,"report_hash":report.get("report_hash"),
            "reason":"prospective event edge confirmed + human approval" if active else ("awaiting explicit human approval" if report.get("eligible_for_human_review") else report.get("reason")),
            "review":review,"report":report,"automatic_promotion":False}
    if ledger is None:_CACHE[key]=(now,result)
    return result


def selection_report(*,window_days=180,symbol=None,horizon=None,ledger=None):
    base=BASE438.selection_report(window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger)
    ev=event_report(window_days=max(180,int(window_days)),symbol=symbol,horizon=horizon,ledger=ledger);ev["review"]=BASE437.REVIEW.latest("event_response",symbol=symbol,horizon=horizon)
    return {**base,"version":VERSION,"validation_version":VALIDATION_VERSION,"candidates":list(base.get("candidates") or [])+[ev],
            "event_policy":"event-response expert is directional only after an observed surprise and remains challenger-only until guard + human approval",
            "automatic_champion_promotion":False,"review_required":True}


def review(candidate:str,decision:str,note:str="",*,window_days=180,symbol=None,horizon=None,ledger=None):
    if candidate!="event_response":return BASE438.review(candidate,decision,note,window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger)
    report=event_report(window_days=max(180,int(window_days)),symbol=symbol,horizon=horizon,ledger=ledger)
    out=BASE437.REVIEW.add("event_response","core_meta",decision,note,report,symbol=symbol,horizon=horizon,window_days=window_days)
    return {"version":VERSION,"review":out,"report":report,"automatic_promotion":False}


def review_status(limit=50):
    base=BASE438.review_status(limit=limit);return {**base,"version":VERSION}
