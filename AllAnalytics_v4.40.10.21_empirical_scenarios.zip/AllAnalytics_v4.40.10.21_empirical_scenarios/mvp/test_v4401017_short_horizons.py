import numpy as np
import pandas as pd
import pytest
import short_horizon_contract_v4401017 as C
import short_forecast_v45 as S
from types import SimpleNamespace

def frame(n=200):
 c=100+np.sin(np.arange(n)/8)*.5+np.arange(n)*.01
 return pd.DataFrame({'date':pd.date_range('2026-01-01',periods=n,freq='5min'),'open':c,'high':c+2,'low':c-2,'close':c})
@pytest.mark.parametrize('h',C.MINUTES)
def test_windows_and_ambiguity(h):
 r=C.path_diagnostics(frame(),h,5,.1)
 assert r['status']=='descriptive' and not r['calibrated']
 assert r['first_touch_counts']['both_same_bar']==r['observations']
 assert sum(r['first_touch_counts'].values())==r['observations']
 assert r['nonoverlap']<=r['observations']
 assert r['median_touch_minutes']['up']==5
 assert r['max_excursion_median_pct']>r['terminal_median_pct']>r['min_excursion_median_pct']
 costs=[x['windows_with_abs_move_above_cost'] for x in r['cost_sensitivity']]
 assert costs==sorted(costs,reverse=True)
def test_gap_windows_excluded():
 d=frame(120);d.loc[60:,'date']+=pd.Timedelta(days=2)
 r=C.path_diagnostics(d,'1h',5,.1)
 assert r['observations']==96
 assert len(C.contiguous_tail(d,5))==60
def test_missing_threshold_not_zero():
 for t in (None,0,float('nan')):assert C.path_diagnostics(frame(),'1h',5,t)['status']=='unavailable'
@pytest.mark.parametrize('h',C.MINUTES)
def test_live_short_score_and_macro_independence(monkeypatch,h):
 monkeypatch.setattr(S.MD43,'fetch_intraday',lambda *a:SimpleNamespace(frame=frame(),source='test',errors=[]))
 a=S.forecast('BTC-USD',h,{'drivers':[{'label':'ставка ФРС','contribution':100}]})
 b=S.forecast('BTC-USD',h,{'drivers':[{'label':'ставка ФРС','contribution':-100}]})
 assert a['p_up']==b['p_up'] and a['macro_bias']==0
 assert a['confidence_score'] is None and not a['calibrated_probability']
 assert a['target_semantics']=='historical_level_not_calibrated_hit_target'
 assert a['path_diagnostics']['observations']>0
def test_latest_gap_blocks_short_momentum(monkeypatch):
 d=frame();d.loc[195:,'date']+=pd.Timedelta(days=1)
 monkeypatch.setattr(S.MD43,'fetch_intraday',lambda *a:SimpleNamespace(frame=d,source='test',errors=[]))
 assert S.forecast('BTC-USD','1h',{})['status']=='unavailable'
def test_us_session_can_warm_up_from_previous_sessions(monkeypatch):
 d=frame(156);d.loc[78:,'date']+=pd.Timedelta(days=1)
 monkeypatch.setattr(S.MD43,'fetch_intraday',lambda *a:SimpleNamespace(frame=d,source='test',errors=[]))
 assert S.forecast('^GSPC','4h',{})['status']=='ok'
def test_same_threshold_terminal_is_not_first_hit():
 d=frame();d['close']=100;d['open']=100
 r=C.path_diagnostics(d,'1h',5,.1)
 assert r['terminal_median_pct']==0 and r['first_touch_counts']['both_same_bar']>0
 assert all(x['windows_with_abs_move_above_cost']==0 for x in r['cost_sensitivity'])

def test_touch_order_and_starting_bar_excluded():
 d=frame(100);d[['open','close']]=100.;d['high']=100.01;d['low']=99.99
 d.loc[0,'high']=150 # already known bar must not count as a future touch
 r=C.path_diagnostics(d,'30m',5,.1)
 assert r['first_touch_counts']['neither']==94
 d.loc[20,'high']=101;d.loc[22,'low']=99
 r=C.path_diagnostics(d,'30m',5,.1)
 assert r['first_touch_counts']['up']>0 and r['first_touch_counts']['down']>0
 assert r['first_touch_counts']['both_same_bar']==0

def test_unfinished_future_bars_do_not_change_score(monkeypatch):
 d=frame();future=d.tail(20).copy();future.date=pd.date_range('2099-01-01',periods=20,freq='5min');future[['open','close','high','low']]*=20
 monkeypatch.setattr(S.MD43,'fetch_intraday',lambda *a:SimpleNamespace(frame=d,source='test',errors=[]))
 a=S.forecast('BTC-USD','1h',{})
 monkeypatch.setattr(S.MD43,'fetch_intraday',lambda *a:SimpleNamespace(frame=pd.concat([d,future]),source='test',errors=[]))
 b=S.forecast('BTC-USD','1h',{})
 assert a['p_up']==b['p_up'] and a['path_diagnostics']==b['path_diagnostics']

def test_hour_fallback_uses_four_hour_window(monkeypatch):
 d=frame();d.date=pd.date_range('2026-01-01',periods=len(d),freq='1h')
 monkeypatch.setattr(S.MD43,'fetch_intraday',lambda sym,interval:SimpleNamespace(frame=pd.DataFrame() if interval=='5m' else d,source='test',errors=[]))
 r=S.forecast('BTC-USD','4h',{})
 assert r['status']=='ok' and r['interval_minutes']==60
 assert r['path_diagnostics']['observations']==196
