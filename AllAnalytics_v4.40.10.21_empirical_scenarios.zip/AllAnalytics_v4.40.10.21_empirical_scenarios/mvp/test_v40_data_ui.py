from __future__ import annotations
import json, math, sys, types
from pathlib import Path

try:
    import yfinance  # noqa: F401
except Exception:
    sys.modules['yfinance']=types.SimpleNamespace(Ticker=None)

import alternative_data_v40 as AD
import news_map_v40 as NM

ROOT=Path(__file__).parent


def test_crypto_fallback():
    old_primary,old_fb=AD._crypto_one,AD._crypto_fallback
    AD._crypto_one=lambda coin: (_ for _ in ()).throw(RuntimeError('Upgrade plan (код 401)'))
    AD._crypto_fallback=lambda coin:{
        'coin':coin,'asset_symbol':AD.CRYPTO[coin], 'open_interest_usd':123.0,
        'oi_change_1d_pct':1.0,'oi_change_7d_pct':2.0,'funding_oi_weighted':0.01,
        'funding_7d_avg':0.01,'crowding':'сбалансировано','liquidations_24h_usd':None,
        'long_liq_24h_usd':None,'short_liq_24h_usd':None,'liquidation_bias_7d':'недоступно',
        'availability':{'открытый интерес':True,'ставка фондирования':True,'ликвидации':False},
        'metric_errors':{},'series':{'open_interest':[],'funding':[],'liquidations':[]},
        'source':'резерв','fallback_used':True,'latest_date':'2026-09-04'}
    try:
        x=AD.fetch_coinglass()
        assert x['status']=='partial'
        assert len(x['assets'])==4
        assert all(v['fallback_used'] for v in x['assets'].values())
        assert all('Upgrade plan' in v.get('primary_error','') for v in x['assets'].values())
    finally:
        AD._crypto_one,AD._crypto_fallback=old_primary,old_fb



def test_crypto_partial_fill():
    old_primary,old_fb=AD._crypto_one,AD._crypto_fallback
    AD._crypto_one=lambda coin:{'coin':coin,'asset_symbol':AD.CRYPTO[coin],'latest_date':'2026-09-03',
        'open_interest_usd':100.0,'oi_change_1d_pct':1.0,'oi_change_7d_pct':2.0,
        'funding_oi_weighted':None,'funding_7d_avg':None,'crowding':'сбалансировано',
        'liquidations_24h_usd':10.0,'long_liq_24h_usd':6.0,'short_liq_24h_usd':4.0,'liquidation_bias_7d':'long',
        'availability':{'открытый интерес':True,'ставка фондирования':False,'ликвидации':True},
        'metric_errors':{'ставка фондирования':'plan'},
        'series':{'open_interest':[],'funding':[],'liquidations':[]}}
    AD._crypto_fallback=lambda coin:{'latest_date':'2026-09-04','open_interest_usd':120.0,
        'oi_change_1d_pct':3.0,'oi_change_7d_pct':4.0,'funding_oi_weighted':0.012,'funding_7d_avg':0.01,
        'crowding':'перевес длинных позиций','series':{'open_interest':[],'funding':[{'date':'2026-09-04','value':.012}],'liquidations':[]}}
    try:
        x=AD.fetch_coinglass()
        b=x['assets']['BTC']
        assert b['open_interest_usd']==100.0  # primary survives
        assert b['funding_oi_weighted']==0.012  # missing metric filled
        assert b['liquidations_24h_usd']==10.0
        assert b['fallback_used'] is True and 'Bybit/Binance' in b['source']
    finally:
        AD._crypto_one,AD._crypto_fallback=old_primary,old_fb

def test_options_fallback():
    old_primary,old_fb=AD._options_one,AD._yahoo_options_one
    AD._options_one=lambda u: (_ for _ in ()).throw(RuntimeError('plan blocked'))
    AD._yahoo_options_one=lambda u:{'underlying':u,'label':u,'linked_assets':[],
        'put_call_oi_ratio':1.0,'median_iv':.2,'contracts_sampled':100,
        'source':'резерв','fallback_used':True,'term_structure':[],'top_strikes':[]}
    try:
        x=AD.fetch_massive()
        assert x['status']=='partial'
        assert len(x['underlyings'])==len(AD.OPTIONS_UNDERLYINGS)
        assert all(v['fallback_used'] for v in x['underlyings'].values())
    finally:
        AD._options_one,AD._yahoo_options_one=old_primary,old_fb


def test_cftc_parser():
    old=AD._cftc_rows
    dis=[{'report_date_as_yyyy_mm_dd':'2026-09-01T00:00:00.000','market_and_exchange_names':'GOLD - COMMODITY EXCHANGE INC.',
          'm_money_positions_long_all':'150000','m_money_positions_short_all':'50000','open_interest_all':'400000'}]
    tff=[{'report_date_as_yyyy_mm_dd':'2026-09-01T00:00:00.000','market_and_exchange_names':'NASDAQ-100 STOCK INDEX',
          'lev_money_positions_long_all':'20000','lev_money_positions_short_all':'35000','open_interest_all':'200000'}]
    AD._cftc_rows=lambda ds: dis if ds=='72hh-3qpy' else tff
    try:
        x=AD.fetch_cftc()
        assert 'GC=F' in x['contracts']
        assert x['contracts']['GC=F']['net']==100000
        assert '^NDX' in x['contracts']
        assert x['contracts']['^NDX']['net']==-15000
    finally:
        AD._cftc_rows=old


def main():
    html=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
    data=json.loads((ROOT/'site'/'data.json').read_text(encoding='utf-8'))
    assert len(data.get('assets') or [])==33

    # Old AllA logo/wordmark restored.
    assert 'M6 22 L9.5 9 L13 22' in html
    assert 'All<span class="g">A</span>nalytics' in html

    # Original English market names from source data, no aggressive RU override.
    names={a['symbol']:a['name'] for a in data['assets']}
    assert names['^NDX']=='Nasdaq 100'
    assert names['^DJI']=='Dow Jones 30'
    assert names['^RUT']=='Russell 2000'
    assert 'Насдак 100' not in html and 'Доу Джонс 30' not in html and 'Расселл 2000' not in html
    assert 'const ruName=a=>a&&a.name?a.name' in html

    # New forecast presentation.
    for needle in ('id="forecast-mini-chart"','id="confidence-scale"','id="confidence-value"','forecast-asset-name'):
        assert needle in html
    assert 'confidence-ring' not in html.split('<body',1)[1]
    assert 'data.js?v=4.11' in html

    # Every news item gets its own nearby map coordinate.
    rows=[{'title':f'США рынок новость {i}','summary':'ФРС и американский рынок','impact_score':50+i,'published':'2026-09-07'} for i in range(8)]
    out=NM.enrich(rows)
    assert len(out)==8 and all(r['map_region']=='США' for r in out)
    coords={(r['map_lon'],r['map_lat']) for r in out}
    assert len(coords)==8
    # They remain a coherent US cluster rather than being scattered globally.
    assert max(abs(r['map_lon']+98.5) for r in out)<12
    assert max(abs(r['map_lat']-38.5) for r in out)<5

    test_crypto_fallback(); test_crypto_partial_fill(); test_options_fallback(); test_cftc_parser()

    # Bootstrap must force first refresh, and secrets never enter static/browser files.
    alt=json.loads((ROOT/'site'/'altdata_v40.json').read_text(encoding='utf-8'))
    assert alt['version']=='4.0' and not alt.get('generated_unix')
    env=(ROOT/'.env').read_text(encoding='utf-8')
    secrets=[]
    for line in env.splitlines():
        if '=' in line and not line.lstrip().startswith('#'):
            k,v=line.split('=',1)
            if ('API_KEY' in k or k=='COINGLASS_API_KEY') and v.strip(): secrets.append(v.strip().strip('*'))
    public=html+(ROOT/'site'/'data.js').read_text(encoding='utf-8')+(ROOT/'site'/'altdata_v40.json').read_text(encoding='utf-8')
    assert all((not v) or v not in public for v in secrets)

    print('OK: v4.0 AllA logo + English asset names + forecast mini-chart/confidence scale + news jitter + alt-data fallbacks')


if __name__=='__main__':
    main()
