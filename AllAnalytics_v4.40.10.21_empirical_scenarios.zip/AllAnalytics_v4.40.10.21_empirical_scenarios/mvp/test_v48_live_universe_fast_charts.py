from __future__ import annotations
from pathlib import Path
import json
ROOT=Path(__file__).parent

def main():
    import equity_universe_v48 as U
    import valuation_dynamic_v48 as V
    import deal_provider_v48 as D

    assert D.status()["requested_history_start"]=="2000-01-01"
    assert "LSEG" in D.status()["recommended"]["mna"]

    # Fallback universe always keeps UI usable even without network.
    assert any(x["market"]=="US" for x in U.FALLBACK)
    assert any(x["market"]=="RU" for x in U.FALLBACK)

    ru=V._generic_ru("SBER","Сбербанк")
    assert ru["currency"]=="RUB"
    assert ru["preset_quality"]=="price-only"

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    for token in [
        "/api/corpfin/universe", "valuation-market", "рынок США", "MOEX",
        "deal-provider-status", "data-deal-range=\"2000\"",
        "Сохранённая история · обновляем в фоне", "eventPool=NEWS.length?NEWS:(F.news||[])",
        "ResizeObserver", "technical_lab_v48.html"
    ]:
        assert token in html, token

    lab=(ROOT/"site"/"technical_lab_v48.html").read_text(encoding="utf-8")
    assert "Сохранённая история · обновляем live в фоне" in lab
    assert "loadData(false)" in lab

    md=(ROOT/"market_data_v41.py").read_text(encoding="utf-8")
    assert "days=2400 if long_history else 720" in md
    assert "MOEX ISS · быстрый кэш" in md

    api=(ROOT/"api.py").read_text(encoding="utf-8")
    assert '@app.get("/api/corpfin/universe")' in api
    assert '@app.get("/api/corpfin/deal-provider-status")' in api
    assert 'period in {"3y","5y","max"}' in api

    data=json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))
    assert data["ui_version"]=="4.8"
    print("OK: v4.8 live US/MOEX universe + deal provider slot + fast MOEX/overview charts")

if __name__=="__main__":main()
