"""AllAnalytics v4.36 — prospective forecast feedback loop.

This module is intentionally separated from model fitting.  It records what the
live system actually knew at forecast time and settles that prediction only after
future market data exists.  The resulting ledger is append-only from the model's
point of view and is used for monitoring / challenger review, never for automatic
champion promotion.

Core guarantees
---------------
* point-in-time forecast snapshots are immutable;
* repeated requests for an unchanged forecast are idempotent;
* settlement uses closes strictly after ``data_as_of``;
* abstentions are preserved and evaluated separately from published signals;
* component forecasts are retained so the ensemble can be compared with each
  expert on the same prospective observations;
* no prospective result is fed back into the active v4.35 weights in v4.36.
"""
from __future__ import annotations
from contextlib import closing

import hashlib
import json
import math
import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import pandas as pd

import evidence_store_v4401 as EVIDENCE4401
import target_contract_v4405 as TARGET4405
import forecast_contract_v4406 as CONTRACT4406

VERSION = "prospective-feedback-v4.40.5"
SCHEMA_VERSION = 3
LEGACY_DB_NAME = "prospective_feedback_v436.sqlite3"
DEFAULT_DB = EVIDENCE4401.ledger_path("directional_feedback.sqlite3")


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _finite(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _safe_json(value) -> str:
    return json.dumps(value if value is not None else {}, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _json_load(value, fallback=None):
    try:
        return json.loads(value) if value else ({} if fallback is None else fallback)
    except Exception:
        return {} if fallback is None else fallback


def _as_date(v) -> pd.Timestamp | None:
    try:
        x = pd.Timestamp(str(v)[:10])
        return x.normalize() if pd.notna(x) else None
    except Exception:
        return None


def _norm_history(frame) -> pd.DataFrame:
    if frame is None:
        return pd.DataFrame(columns=["date", "close"])
    if isinstance(frame, pd.DataFrame):
        d = frame.copy()
    else:
        d = pd.DataFrame(frame)
    if d.empty:
        return pd.DataFrame(columns=["date", "close"])
    ren = {"t": "date", "c": "close", "Close": "close", "Date": "date"}
    d = d.rename(columns={k: v for k, v in ren.items() if k in d.columns})
    if "date" not in d.columns or "close" not in d.columns:
        return pd.DataFrame(columns=["date", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce").dt.tz_localize(None)
    d["close"] = pd.to_numeric(d["close"], errors="coerce")
    return d.dropna(subset=["date", "close"]).sort_values("date").drop_duplicates("date", keep="last")[["date", "close"]]


def _neutral_band_pct(history, horizon: int, data_as_of=None) -> float:
    """Exact target-contract band at forecast time, in percentage points."""
    d=_norm_history(history)
    if d.empty:
        return float(TARGET4405.MIN_ABS_MOVE*100.0)
    ser=pd.Series(d["close"].to_numpy(float),index=pd.to_datetime(d["date"]))
    band=TARGET4405.band_pct_for_asof(ser,horizon,as_of=data_as_of)
    return float(band if band is not None else TARGET4405.MIN_ABS_MOVE*100.0)


def _forecast_key(symbol: str, horizon: int, data_as_of: str, model_version: str, forecast: dict) -> str:
    classes=TARGET4405.normalize_class_probabilities(
        (forecast or {}).get("class_probabilities"),
        p_neutral=(forecast or {}).get("p_neutral"),
        conditional_p_up=(forecast or {}).get("conditional_p_up"),
    ) or {}
    payload = {
        "symbol": str(symbol).upper(),
        "horizon": int(horizon),
        "data_as_of": str(data_as_of)[:10],
        "model_version": str(model_version or "unknown"),
        "model_generation": str((forecast or {}).get("model_generation") or ""),
        "target_version": str((forecast or {}).get("target_version") or ""),
        "p_up": round(float(forecast.get("p_up")), 5),
        "classes": {k:round(float(v),5) for k,v in classes.items()},
        "abstain": bool(forecast.get("abstain")),
        "threshold": round(float(forecast.get("signal_threshold") or 0), 4),
        "regime": str(forecast.get("regime") or ""),
    }
    return hashlib.sha256(_safe_json(payload).encode("utf-8")).hexdigest()


def path_is_persistent(path: str | Path) -> bool:
    try:
        return Path(path).resolve().parent == EVIDENCE4401.evidence_root().resolve()
    except Exception:
        return False


class Ledger:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path or os.getenv("ALLANALYTICS_FEEDBACK_DB") or DEFAULT_DB).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()
        self.migration_report = self._migrate_legacy() if path is None else {"sources": [], "forecasts_imported": 0, "settlements_imported": 0}

    def _connect(self):
        con = sqlite3.connect(self.path, timeout=6.0)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA busy_timeout=6000")
        con.execute("PRAGMA foreign_keys=ON")
        return con

    def _init_schema(self):
        with closing(self._connect()) as con, con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS forecast_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    forecast_key TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    horizon INTEGER NOT NULL,
                    data_as_of TEXT NOT NULL,
                    model_version TEXT,
                    model_generation TEXT,
                    target_version TEXT,
                    probability_semantics TEXT,
                    p_class_up REAL,
                    p_class_neutral REAL,
                    p_class_down REAL,
                    conditional_p_up REAL,
                    p_move REAL,
                    source TEXT,
                    origin TEXT,
                    entry_price REAL NOT NULL,
                    p_up REAL NOT NULL,
                    p_down REAL NOT NULL,
                    direction TEXT NOT NULL,
                    direction_probability REAL NOT NULL,
                    abstain INTEGER NOT NULL,
                    signal_strength TEXT,
                    signal_threshold REAL,
                    reliability REAL,
                    regime TEXT,
                    neutral_band_pct REAL NOT NULL,
                    components_json TEXT NOT NULL,
                    context_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_feedback_symbol_horizon ON forecast_ledger(symbol,horizon,data_as_of);
                CREATE INDEX IF NOT EXISTS idx_feedback_created ON forecast_ledger(created_at);

                CREATE TABLE IF NOT EXISTS settlement_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    forecast_id INTEGER NOT NULL UNIQUE,
                    settled_at TEXT NOT NULL,
                    target_as_of TEXT NOT NULL,
                    target_price REAL NOT NULL,
                    realized_return_pct REAL NOT NULL,
                    outcome TEXT NOT NULL,
                    soft_target REAL NOT NULL,
                    direction_hit INTEGER,
                    published_hit INTEGER,
                    significant_hit INTEGER,
                    brier REAL NOT NULL,
                    calibration_error REAL NOT NULL,
                    multiclass_brier REAL,
                    multiclass_log_loss REAL,
                    move_brier REAL,
                    direction_brier REAL,
                    direction_log_loss REAL,
                    material_move INTEGER,
                    target_version TEXT,
                    model_generation TEXT,
                    error_code TEXT NOT NULL,
                    attribution_json TEXT NOT NULL,
                    FOREIGN KEY(forecast_id) REFERENCES forecast_ledger(id)
                );
                CREATE INDEX IF NOT EXISTS idx_feedback_settled ON settlement_ledger(settled_at);
                CREATE TABLE IF NOT EXISTS feedback_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )
            # Forward-migrate persistent ledgers created by v4.36-v4.40.4.
            wanted = {
                "forecast_ledger": {
                    "model_generation":"TEXT", "target_version":"TEXT", "probability_semantics":"TEXT",
                    "p_class_up":"REAL", "p_class_neutral":"REAL", "p_class_down":"REAL",
                    "conditional_p_up":"REAL", "p_move":"REAL",
                },
                "settlement_ledger": {
                    "multiclass_brier":"REAL", "multiclass_log_loss":"REAL", "move_brier":"REAL",
                    "direction_brier":"REAL", "direction_log_loss":"REAL", "material_move":"INTEGER",
                    "target_version":"TEXT", "model_generation":"TEXT",
                },
            }
            for table, cols in wanted.items():
                existing={r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}
                for name,ctype in cols.items():
                    if name not in existing:
                        con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ctype}")
            con.execute("CREATE INDEX IF NOT EXISTS idx_feedback_generation ON forecast_ledger(model_generation,target_version)")
            con.execute("INSERT OR REPLACE INTO feedback_meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
            con.execute("INSERT OR REPLACE INTO feedback_meta(key,value) VALUES('evidence_store_version',?)", (EVIDENCE4401.VERSION,))
            con.commit()

    def _migrate_legacy(self) -> dict:
        """Merge immutable v4.36 ledgers from previous unpacked releases.

        Migration is idempotent because forecast_key and forecast_id settlement
        uniqueness are preserved.  Explicit Ledger(path=...) instances used by
        tests never perform discovery/migration.
        """
        report = {"sources": [], "forecasts_imported": 0, "settlements_imported": 0, "errors": []}
        candidates = EVIDENCE4401.legacy_db_candidates(__file__, LEGACY_DB_NAME, self.path)
        forecast_cols = [
            "forecast_key","created_at","symbol","horizon","data_as_of","model_version","source","origin",
            "entry_price","p_up","p_down","direction","direction_probability","abstain","signal_strength",
            "signal_threshold","reliability","regime","neutral_band_pct","components_json","context_json","metadata_json"
        ]
        settlement_cols = [
            "settled_at","target_as_of","target_price","realized_return_pct","outcome","soft_target",
            "direction_hit","published_hit","significant_hit","brier","calibration_error","error_code","attribution_json"
        ]
        for src in candidates:
            try:
                fp_key, fp_value = EVIDENCE4401.source_fingerprint(src)
                meta_key = f"legacy_import:{fp_key}"
                with closing(self._connect()) as probe, probe:
                    seen = probe.execute("SELECT value FROM feedback_meta WHERE key=?", (meta_key,)).fetchone()
                if seen and str(seen[0]) == fp_value:
                    continue
                scon = sqlite3.connect(src, timeout=4.0); scon.row_factory = sqlite3.Row
                tables = {r[0] for r in scon.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if "forecast_ledger" not in tables:
                    scon.close(); continue
                frows = scon.execute("SELECT * FROM forecast_ledger ORDER BY id").fetchall()
                if not frows:
                    scon.close()
                    with closing(self._connect()) as con, con:
                        con.execute("INSERT OR REPLACE INTO feedback_meta(key,value) VALUES(?,?)", (meta_key, fp_value)); con.commit()
                    continue
                srows = scon.execute("SELECT * FROM settlement_ledger ORDER BY id").fetchall() if "settlement_ledger" in tables else []
                source_id_to_key = {int(r["id"]): str(r["forecast_key"]) for r in frows}
                imported_f = imported_s = 0
                with closing(self._connect()) as con, con:
                    qf = ",".join("?" for _ in forecast_cols)
                    for r in frows:
                        vals=[r[c] for c in forecast_cols]
                        cur=con.execute(f"INSERT OR IGNORE INTO forecast_ledger({','.join(forecast_cols)}) VALUES({qf})", vals)
                        imported_f += int(bool(cur.rowcount))
                    qs = ",".join("?" for _ in (["forecast_id"] + settlement_cols))
                    for r in srows:
                        key=source_id_to_key.get(int(r["forecast_id"]))
                        if not key: continue
                        target=con.execute("SELECT id FROM forecast_ledger WHERE forecast_key=?",(key,)).fetchone()
                        if not target: continue
                        vals=[int(target[0])] + [r[c] for c in settlement_cols]
                        cur=con.execute(f"INSERT OR IGNORE INTO settlement_ledger(forecast_id,{','.join(settlement_cols)}) VALUES({qs})", vals)
                        imported_s += int(bool(cur.rowcount))
                    con.execute("INSERT OR REPLACE INTO feedback_meta(key,value) VALUES('evidence_store_version',?)", (EVIDENCE4401.VERSION,))
                    con.execute("INSERT OR REPLACE INTO feedback_meta(key,value) VALUES(?,?)", (meta_key, fp_value))
                    con.commit()
                scon.close()
                report["sources"].append(str(src))
                report["forecasts_imported"] += imported_f
                report["settlements_imported"] += imported_s
            except Exception as exc:
                report["errors"].append({"source": str(src), "error": type(exc).__name__})
        return report

    def record_row(self, row: dict, origin: str = "api") -> dict:
        """Persist all forecast horizons from one ``forecast_fast`` response."""
        symbol = str(row.get("symbol") or "").upper()
        data_as_of = str(row.get("as_of") or "")[:10]
        hist = row.get("history") or []
        d = _norm_history(hist)
        entry = _finite(d.iloc[-1]["close"]) if len(d) else None
        if not symbol or not data_as_of or entry is None:
            return {"inserted": 0, "existing": 0, "skipped": 1, "ids": []}
        model_name = row.get("model") or "AllAnalytics"
        source = row.get("source") or ""
        forecasts = row.get("forecasts") or {}
        inserted = existing = skipped = 0
        ids = []
        with closing(self._connect()) as con, con:
            for raw_h, f in forecasts.items():
                try:
                    h = int(raw_h)
                except Exception:
                    skipped += 1
                    continue
                p = _finite((f or {}).get("p_up"))
                if p is None or not (0 < p < 1):
                    skipped += 1
                    continue
                p = float(np.clip(p, .001, .999))
                class_probs = TARGET4405.normalize_class_probabilities(
                    (f or {}).get("class_probabilities"),
                    p_neutral=(f or {}).get("p_neutral"),
                    conditional_p_up=(f or {}).get("conditional_p_up"),
                )
                p_cond = _finite((f or {}).get("conditional_p_up"))
                p_move = _finite((f or {}).get("p_move"))
                if class_probs is not None:
                    p_move = float(class_probs["up"] + class_probs["down"])
                    if p_cond is None and p_move > 1e-9:
                        p_cond = float(class_probs["up"] / p_move)
                model_generation = str((f or {}).get("model_generation") or "")
                target_version = str((f or {}).get("target_version") or TARGET4405.TARGET_VERSION)
                probability_semantics = str((f or {}).get("probability_semantics") or "")
                reliability = _finite(((f or {}).get("reliability") or {}).get("probability"))
                if reliability is None:
                    reliability = _finite((f or {}).get("confidence_score"))
                components = (f or {}).get("components") or []
                context = {
                    "event_risk": (f or {}).get("event_risk"),
                    "event_bias": (f or {}).get("event_bias"),
                    "context_disagreement": bool((f or {}).get("context_disagreement")),
                    "context_p_up": (f or {}).get("context_p_up"),
                    "conditional_p_up": (f or {}).get("conditional_p_up"),
                    "p_neutral": (f or {}).get("p_neutral"),
                    "class_probabilities": (f or {}).get("class_probabilities") or {},
                    "probability_semantics": probability_semantics,
                    "model_generation": model_generation,
                    "target_version": target_version,
                    "feature_drift": (f or {}).get("feature_drift") or {},
                    "dynamic_weights": (f or {}).get("dynamic_weights") or {},
                    "meta_learning": (f or {}).get("meta_learning") or {},
                    "threshold_selection": (f or {}).get("threshold_selection") or {},
                    "prospective_selection_guard": (f or {}).get("prospective_selection_guard") or {},
                    "guard_version": (f or {}).get("guard_version"),
                    "asset_specialist": (f or {}).get("asset_specialist") or {},
                    "specialist_gate": (f or {}).get("specialist_gate") or {},
                    "specialist_weight_status": (f or {}).get("specialist_weight_status"),
                    "specialist_version": (f or {}).get("specialist_version"),
                    "event_response": (f or {}).get("event_response") or {},
                    "event_gate": (f or {}).get("event_gate") or {},
                    "event_weight_status": (f or {}).get("event_weight_status"),
                    "event_response_version": (f or {}).get("event_response_version"),
                    "data_driven_routing": (f or {}).get("data_driven_routing") or {},
                    "routing_policy": (f or {}).get("routing_policy") or {},
                    "robustness": (f or {}).get("robustness") or {},
                    "freshness_guard": (f or {}).get("freshness_guard") or {},
                    "soft_regime": (f or {}).get("soft_regime") or {},
                    "consistency_gate": (f or {}).get("consistency_gate") or {},
                }
                model_version = ((f or {}).get("model_generation") or (f or {}).get("integrity_version")
                                 or (f or {}).get("model_version") or (f or {}).get("version") or model_name)
                key = _forecast_key(symbol, h, data_as_of, str(model_version), f)
                direction = "up" if p >= .5 else "down"
                dir_prob = max(p, 1-p)
                meta = {
                    "model": model_name,
                    "quality": (f or {}).get("quality") or {},
                    "validation": (f or {}).get("validation") or {},
                    "scorecard": (f or {}).get("scorecard") or {},
                    "feature_version": (f or {}).get("feature_version"),
                    "model_generation": model_generation,
                    "target_version": target_version,
                    "probability_semantics": probability_semantics,
                }
                cp = class_probs or {}
                values = (
                    key, _utc_now(), symbol, h, data_as_of, str(model_version), model_generation, target_version, probability_semantics,
                    _finite(cp.get("up")), _finite(cp.get("neutral")), _finite(cp.get("down")), p_cond, p_move,
                    str(source), str(origin), float(entry), p, 1-p, direction, dir_prob, int(bool((f or {}).get("abstain"))),
                    str((f or {}).get("signal_strength") or ""), _finite((f or {}).get("signal_threshold")), reliability,
                    str((f or {}).get("regime") or ""), _neutral_band_pct(d, h, data_as_of=data_as_of),
                    _safe_json(components), _safe_json(context), _safe_json(meta),
                )
                cur = con.execute(
                    """INSERT OR IGNORE INTO forecast_ledger(
                    forecast_key,created_at,symbol,horizon,data_as_of,model_version,model_generation,target_version,probability_semantics,
                    p_class_up,p_class_neutral,p_class_down,conditional_p_up,p_move,source,origin,entry_price,
                    p_up,p_down,direction,direction_probability,abstain,signal_strength,signal_threshold,reliability,
                    regime,neutral_band_pct,components_json,context_json,metadata_json)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", values
                )
                if cur.rowcount:
                    inserted += 1
                    ids.append(int(cur.lastrowid))
                else:
                    existing += 1
            con.commit()
        return {"inserted": inserted, "existing": existing, "skipped": skipped, "ids": ids}

    def _pending(self, limit: int = 24) -> list[dict]:
        # Do not even try to settle before at least ``horizon`` calendar days have
        # elapsed.  The history check below is the authoritative trading-day gate.
        wanted=max(1,min(int(limit),250))
        # Scan beyond the requested settlement batch. Otherwise a few old 60-day
        # forecasts that are not mature yet could block newer 1-day forecasts that
        # are already ready to settle.
        scan=max(wanted*12,120)
        with closing(self._connect()) as con, con:
            rows = con.execute(
                """SELECT f.* FROM forecast_ledger f
                LEFT JOIN settlement_ledger s ON s.forecast_id=f.id
                WHERE s.forecast_id IS NULL
                ORDER BY f.data_as_of ASC,f.id ASC LIMIT ?""", (min(scan,3000),)
            ).fetchall()
        out = []
        today = pd.Timestamp.utcnow().tz_localize(None).normalize()
        for r in rows:
            x = dict(r); base = _as_date(x.get("data_as_of"))
            if base is None:
                continue
            if (today - base).days >= max(1, int(x.get("horizon") or 1)):
                out.append(x)
                if len(out)>=wanted:
                    break
        return out

    @staticmethod
    def _target_from_history(history, data_as_of: str, horizon: int):
        d = _norm_history(history)
        base = _as_date(data_as_of)
        if base is None or d.empty:
            return None
        future = d[d["date"] > base]
        h = max(1, int(horizon))
        if len(future) < h:
            return None
        row = future.iloc[h-1]
        return {"date": str(pd.Timestamp(row["date"]).date()), "close": float(row["close"])}

    @staticmethod
    def _attribution(f: dict, outcome: str, realized_return_pct: float, hit: bool | None) -> tuple[str, dict]:
        abstain = bool(f.get("abstain"))
        ctx = _json_load(f.get("context_json"), {})
        comps = _json_load(f.get("components_json"), [])
        tags = []
        if outcome == "neutral":
            code = "correct_abstention" if abstain else "noise_false_signal"
        elif abstain:
            code = "missed_move"
        elif hit:
            code = "correct_signal"
        else:
            drift = _finite((ctx.get("feature_drift") or {}).get("score"))
            if drift is None:
                drift = _finite((ctx.get("feature_drift") or {}).get("drift_score"))
            event_risk = _finite(ctx.get("event_risk")) or 0.0
            ps = [_finite(x.get("p_up")) for x in comps if isinstance(x, dict)]
            ps = [x for x in ps if x is not None]
            disagreement = max(ps)-min(ps) if len(ps) >= 2 else 0.0
            if bool(ctx.get("context_disagreement")):
                tags.append("контекст расходился с ансамблем")
            if event_risk >= .55:
                tags.append("высокий событийный риск")
            if drift is not None and drift >= .65:
                tags.append("сдвиг распределения признаков")
            if disagreement >= .15:
                tags.append("сильное расхождение моделей")
            if float(f.get("direction_probability") or .5) >= .70:
                tags.append("высокая уверенность при ошибке")
            if bool(ctx.get("context_disagreement")):
                code = "context_disagreement"
            elif event_risk >= .55:
                code = "event_risk"
            elif drift is not None and drift >= .65:
                code = "feature_drift"
            elif disagreement >= .15:
                code = "component_disagreement"
            elif float(f.get("direction_probability") or .5) >= .70:
                code = "overconfidence"
            else:
                code = "wrong_direction"
        return code, {
            "tags": tags,
            "realized_return_pct": round(float(realized_return_pct), 6),
            "regime_at_forecast": f.get("regime"),
            "event_risk_at_forecast": ctx.get("event_risk"),
            "context_disagreement_at_forecast": bool(ctx.get("context_disagreement")),
        }

    def settle_due(self, history_loader: Callable[[str], object], limit: int = 24) -> dict:
        """Settle predictions for which ``horizon`` future trading closes exist.

        ``history_loader(symbol)`` must return a DataFrame/list containing date and
        close columns.  Failed / incomplete loads remain pending and are retried on
        a later pass.
        """
        pending = self._pending(limit)
        settled = unavailable = errors = 0
        by_symbol: dict[str, object] = {}
        details = []
        for f in pending:
            sym = str(f["symbol"])
            if sym not in by_symbol:
                try:
                    by_symbol[sym] = history_loader(sym)
                except Exception as exc:
                    by_symbol[sym] = exc
            hist = by_symbol[sym]
            if isinstance(hist, Exception):
                errors += 1
                continue
            target = self._target_from_history(hist, f["data_as_of"], int(f["horizon"]))
            if not target:
                unavailable += 1
                continue
            entry = float(f["entry_price"]); target_price = float(target["close"])
            ret = (target_price / entry - 1.0) * 100.0 if entry else 0.0
            band = float(f.get("neutral_band_pct") or TARGET4405.MIN_ABS_MOVE*100.0)
            # Threshold is a log-return fraction, unlike the legacy stored simple return.
            outcome = TARGET4405.classify_return(math.log(target_price/entry), band/100.0)
            soft_target = 1.0 if outcome == "up" else 0.0 if outcome == "down" else .5
            pred_dir = str(f.get("direction"))
            direction_hit = None if outcome == "neutral" else int(pred_dir == outcome)
            published_hit = None if bool(f.get("abstain")) or direction_hit is None else direction_hit
            significant_hit = None if bool(f.get("abstain")) or outcome == "neutral" else int(pred_dir == outcome)
            p = float(f["p_up"])
            brier = (p-soft_target)**2  # legacy soft-direction diagnostic only
            cal_err = abs(p-soft_target)

            cp = TARGET4405.normalize_class_probabilities(
                {"up":f.get("p_class_up"),"neutral":f.get("p_class_neutral"),"down":f.get("p_class_down")},
                p_neutral=(1.0-float(f.get("p_move"))) if _finite(f.get("p_move")) is not None else None,
                conditional_p_up=f.get("conditional_p_up"),
            )
            actual = TARGET4405.one_hot(outcome)
            multiclass_brier = None; multiclass_log_loss = None
            move_brier = None; direction_brier = None; direction_log_loss = None
            if cp is not None:
                multiclass_brier = float(sum((float(cp[k])-float(actual[k]))**2 for k in ("up","neutral","down")))
                multiclass_log_loss = float(-math.log(max(1e-9,float(cp[outcome]))))
                pmove = float(cp["up"]+cp["down"]); ymove = 0.0 if outcome == "neutral" else 1.0
                move_brier = float((pmove-ymove)**2)
                if outcome != "neutral" and pmove > 1e-9:
                    pcond = float(cp["up"]/pmove); yup = 1.0 if outcome == "up" else 0.0
                    direction_brier = float((pcond-yup)**2)
                    direction_log_loss = float(-math.log(max(1e-9,pcond if yup else 1-pcond)))
            code, attr = self._attribution(f, outcome, ret, None if bool(f.get("abstain")) or direction_hit is None else bool(direction_hit))
            attr.update({
                "target_version":f.get("target_version"), "model_generation":f.get("model_generation"),
                "neutral_band_pct":round(band,6), "multiclass_brier":multiclass_brier,
                "move_brier":move_brier, "direction_brier":direction_brier,
            })
            try:
                with closing(self._connect()) as con, con:
                    cur = con.execute(
                        """INSERT OR IGNORE INTO settlement_ledger(
                        forecast_id,settled_at,target_as_of,target_price,realized_return_pct,outcome,soft_target,
                        direction_hit,published_hit,significant_hit,brier,calibration_error,
                        multiclass_brier,multiclass_log_loss,move_brier,direction_brier,direction_log_loss,material_move,
                        target_version,model_generation,error_code,attribution_json)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (int(f["id"]), _utc_now(), target["date"], target_price, ret, outcome, soft_target,
                         direction_hit, published_hit, significant_hit, brier, cal_err,
                         multiclass_brier,multiclass_log_loss,move_brier,direction_brier,direction_log_loss,
                         int(outcome != "neutral"),str(f.get("target_version") or ""),str(f.get("model_generation") or ""),
                         code, _safe_json(attr))
                    )
                    con.commit()
                if cur.rowcount:
                    settled += 1
                    details.append({"forecast_id": int(f["id"]), "symbol": sym, "horizon": int(f["horizon"]), "outcome": outcome, "return_pct": round(ret, 4), "error_code": code})
            except sqlite3.IntegrityError:
                pass
        return {"version": VERSION, "checked": len(pending), "settled": settled, "not_ready": unavailable, "history_errors": errors, "details": details}

    def status(self) -> dict:
        with closing(self._connect()) as con, con:
            total = int(con.execute("SELECT COUNT(*) FROM forecast_ledger").fetchone()[0])
            settled = int(con.execute("SELECT COUNT(*) FROM settlement_ledger").fetchone()[0])
            signals = int(con.execute("SELECT COUNT(*) FROM forecast_ledger WHERE abstain=0").fetchone()[0])
            last = con.execute("SELECT MAX(settled_at) FROM settlement_ledger").fetchone()[0]
            first = con.execute("SELECT MIN(created_at) FROM forecast_ledger").fetchone()[0]
        with closing(self._connect()) as con, con:
            cur_total=int(con.execute("SELECT COUNT(*) FROM forecast_ledger WHERE model_generation=? AND target_version=?",
                                      (CONTRACT4406.MODEL_GENERATION,TARGET4405.TARGET_VERSION)).fetchone()[0])
            cur_settled=int(con.execute("""SELECT COUNT(*) FROM settlement_ledger s JOIN forecast_ledger f ON f.id=s.forecast_id
                WHERE f.model_generation=? AND f.target_version=?""",
                (CONTRACT4406.MODEL_GENERATION,TARGET4405.TARGET_VERSION)).fetchone()[0])
        return {
            "version": VERSION, "schema_version": SCHEMA_VERSION, "forecasts": total, "settled": settled,
            "pending": max(0, total-settled), "published_signals": signals, "first_recorded_at": first,
            "last_settled_at": last, "database": self.path.name, "database_path": str(self.path),
            "persistent_store": path_is_persistent(self.path), "migration": self.migration_report,
            "current_generation":{"model_generation":CONTRACT4406.MODEL_GENERATION,"target_version":TARGET4405.TARGET_VERSION,
                                  "forecasts":cur_total,"settled":cur_settled,"pending":max(0,cur_total-cur_settled)},
            "legacy_evidence_retained":True,"legacy_evidence_used_for_current_promotion":False,
            "automatic_promotion": False, "feeds_active_model": False,
        }

    def rows(self, limit: int = 100, symbol: str | None = None, horizon: int | None = None, settled_only: bool = False,
             model_generation: str | None = None, target_version: str | None = None) -> list[dict]:
        where=[];args=[]
        if symbol:
            where.append("f.symbol=?");args.append(str(symbol).upper())
        if horizon is not None:
            where.append("f.horizon=?");args.append(int(horizon))
        if settled_only:
            where.append("s.forecast_id IS NOT NULL")
        if model_generation:
            where.append("f.model_generation=?"); args.append(str(model_generation))
        if target_version:
            where.append("f.target_version=?"); args.append(str(target_version))
        sql = """SELECT f.*,s.settled_at,s.target_as_of,s.target_price,s.realized_return_pct,s.outcome,s.soft_target,
                 s.direction_hit,s.published_hit,s.significant_hit,s.brier,s.calibration_error,
                 s.multiclass_brier,s.multiclass_log_loss,s.move_brier,s.direction_brier,s.direction_log_loss,
                 s.material_move,s.target_version AS settled_target_version,s.model_generation AS settled_model_generation,
                 s.error_code,s.attribution_json
                 FROM forecast_ledger f LEFT JOIN settlement_ledger s ON s.forecast_id=f.id"""
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY f.id DESC LIMIT ?"; args.append(max(1,min(int(limit),500)))
        with closing(self._connect()) as con, con:
            rows=[dict(x) for x in con.execute(sql,args).fetchall()]
        for x in rows:
            x["abstain"]=bool(x.get("abstain"));x["components"]=_json_load(x.pop("components_json",None),[])
            x["context"]=_json_load(x.pop("context_json",None),{});x["metadata"]=_json_load(x.pop("metadata_json",None),{})
            x["attribution"]=_json_load(x.pop("attribution_json",None),{})
        return rows

    @staticmethod
    def _metric_rows(items: Iterable[dict], name: str, probability_key: str = "p_up",
                     conditional_key: str | None = None, move_key: str | None = None) -> dict:
        rows=list(items); n=len(rows)
        if not n:
            return {"name":name,"n":0,"significant_n":0,"accuracy":None,"brier":None,"calibration_error":None,
                    "direction_brier":None,"move_brier":None,"multiclass_brier":None,"multiclass_log_loss":None}
        legacy=[]; legacy_cal=[]; hits=[]; db=[]; dcal=[]; mb=[]; mcb=[]; mll=[]
        for x in rows:
            p=_finite(x.get(probability_key)); target=_finite(x.get("soft_target"))
            if p is not None and target is not None:
                legacy.append((p-target)**2); legacy_cal.append(abs(p-target))
            outcome=str(x.get("outcome") or "")
            # Direction score is conditional on a material move.
            pc=_finite(x.get(conditional_key)) if conditional_key else _finite(x.get("conditional_p_up"))
            pm=_finite(x.get(move_key)) if move_key else _finite(x.get("p_move"))
            cp=None
            if conditional_key:
                if pm is not None and pc is not None:
                    cp={"up":pm*pc,"neutral":1-pm,"down":pm*(1-pc)}
            else:
                cp=TARGET4405.normalize_class_probabilities(
                    {"up":x.get("p_class_up"),"neutral":x.get("p_class_neutral"),"down":x.get("p_class_down")},
                    p_neutral=(1-pm) if pm is not None else None,conditional_p_up=pc)
            if outcome in {"up","down"} and pc is not None:
                y=1.0 if outcome=="up" else 0.0
                hits.append(int((pc>=.5)==bool(y))); db.append((pc-y)**2); dcal.append(abs(pc-y))
            if outcome in {"up","down","neutral"}:
                if pm is not None:
                    ymove=0.0 if outcome=="neutral" else 1.0; mb.append((pm-ymove)**2)
                if cp is not None:
                    actual=TARGET4405.one_hot(outcome)
                    mcb.append(sum((float(cp[k])-actual[k])**2 for k in ("up","neutral","down")))
                    mll.append(-math.log(max(1e-9,float(cp[outcome]))))
        sig=sum(1 for r in rows if r.get("outcome") in {"up","down"})
        return {
            "name":name,"n":n,"significant_n":sig,
            "accuracy":round(float(np.mean(hits)),4) if hits else None,
            "brier":round(float(np.mean(legacy)),6) if legacy else None,
            "calibration_error":round(float(np.mean(legacy_cal)),6) if legacy_cal else None,
            "direction_brier":round(float(np.mean(db)),6) if db else None,
            "direction_calibration_error":round(float(np.mean(dcal)),6) if dcal else None,
            "move_brier":round(float(np.mean(mb)),6) if mb else None,
            "multiclass_brier":round(float(np.mean(mcb)),6) if mcb else None,
            "multiclass_log_loss":round(float(np.mean(mll)),6) if mll else None,
            "scoring_semantics":"multiclass + move/no-move + conditional direction; legacy soft Brier retained only for compatibility",
        }

    def leaderboard(self, window_days: int = 90, horizon: int | None = None, symbol: str | None = None,
                    model_generation: str | None = CONTRACT4406.MODEL_GENERATION,
                    target_version: str | None = TARGET4405.TARGET_VERSION) -> dict:
        rows=self.rows(limit=500, symbol=symbol, horizon=horizon, settled_only=True,
                       model_generation=model_generation, target_version=target_version)
        cutoff=pd.Timestamp.utcnow().tz_localize(None).normalize()-pd.Timedelta(days=max(7,min(int(window_days),3650)))
        rows=[x for x in rows if (_as_date(x.get("target_as_of")) or pd.Timestamp.min)>=cutoff]
        ensemble_all=[x for x in rows if x.get("soft_target") is not None]
        ensemble_signals=[x for x in ensemble_all if not x.get("abstain")]
        metrics=[self._metric_rows(ensemble_signals,"dynamic_ensemble_v435")]
        # Components are evaluated on exactly the same settled observations.  This
        # keeps the leaderboard comparable and avoids cherry-picking availability.
        names=sorted({str(c.get("name")) for x in ensemble_all for c in (x.get("components") or []) if isinstance(c,dict) and c.get("name") and _finite(c.get("p_up")) is not None})
        for name in names:
            subset=[]
            for x in ensemble_all:
                comp=next((c for c in (x.get("components") or []) if isinstance(c,dict) and str(c.get("name"))==name and _finite(c.get("p_up")) is not None),None)
                if comp:
                    ccond=_finite(comp.get("conditional_p_up")); cmove=_finite(comp.get("p_move")); cneutral=_finite(comp.get("p_neutral"))
                    if cmove is None and cneutral is not None: cmove=1.0-cneutral
                    if ccond is None: ccond=_finite(comp.get("p_up"))
                    subset.append({**x,"component_p_up":float(comp["p_up"]),"component_conditional_p_up":ccond,"component_p_move":cmove})
            metrics.append(self._metric_rows(subset,name,"component_p_up","component_conditional_p_up","component_p_move"))
        metrics=sorted(metrics,key=lambda m:((m.get("accuracy") if m.get("accuracy") is not None else -1),-(m.get("brier") if m.get("brier") is not None else 9)),reverse=True)
        neutral_abstains=[x for x in ensemble_all if x.get("abstain") and x.get("outcome")=="neutral"]
        all_abstains=[x for x in ensemble_all if x.get("abstain")]
        ens=next((m for m in metrics if m["name"]=="dynamic_ensemble_v435"),{"n":0})
        prod=next((m for m in metrics if m["name"]=="production"),None)
        ready=bool(ens.get("significant_n",0)>=30 and ens.get("accuracy") is not None)
        better=None
        if prod and ens.get("accuracy") is not None and prod.get("accuracy") is not None:
            better=round((ens["accuracy"]-prod["accuracy"])*100,3)
        return {
            "version":VERSION,"window_days":int(window_days),"symbol":symbol,"horizon":horizon,
            "model_generation":model_generation,"target_version":target_version,"generation_isolated":bool(model_generation and target_version),
            "settled_forecasts":len(ensemble_all),
            "published_signals":len(ensemble_signals),"coverage":round(len(ensemble_signals)/len(ensemble_all),4) if ensemble_all else None,
            "abstain_precision":round(len(neutral_abstains)/len(all_abstains),4) if all_abstains else None,
            "models":metrics,
            "scoring_semantics":{"primary":"multiclass UP/NEUTRAL/DOWN","move":"P(material move)","direction":"P(up | material move)","legacy_soft_brier":"compatibility_only"},
            "review_readiness":{"eligible_for_human_review":ready,"automatic_promotion":False,"ensemble_vs_production_accuracy_pp":better,
                                "reason":"достаточно prospective наблюдений" if ready else "нужно минимум 30 значимых prospective исходов ансамбля"},
        }

    def error_summary(self, limit: int = 250, symbol: str | None = None, horizon: int | None = None,
                      model_generation: str | None = CONTRACT4406.MODEL_GENERATION,
                      target_version: str | None = TARGET4405.TARGET_VERSION) -> dict:
        rows=self.rows(limit=limit,symbol=symbol,horizon=horizon,settled_only=True,
                       model_generation=model_generation,target_version=target_version)
        counts={}
        examples={}
        for x in rows:
            code=str(x.get("error_code") or "unknown");counts[code]=counts.get(code,0)+1
            if code not in examples:
                examples[code]={"symbol":x.get("symbol"),"horizon":x.get("horizon"),"data_as_of":x.get("data_as_of"),"target_as_of":x.get("target_as_of"),"return_pct":x.get("realized_return_pct")}
        total=sum(counts.values())
        ranked=[{"code":k,"count":v,"share":round(v/total,4) if total else 0,"example":examples.get(k)} for k,v in sorted(counts.items(),key=lambda kv:kv[1],reverse=True)]
        return {"version":VERSION,"model_generation":model_generation,"target_version":target_version,
                "generation_isolated":bool(model_generation and target_version),"total":total,"errors":ranked}


LEDGER = Ledger()


def record_forecast_row(row: dict, origin: str = "api") -> dict:
    return LEDGER.record_row(row, origin=origin)


def settle_due(history_loader: Callable[[str], object], limit: int = 24) -> dict:
    return LEDGER.settle_due(history_loader, limit=limit)


def status() -> dict:
    return LEDGER.status()


def leaderboard(window_days: int = 90, horizon: int | None = None, symbol: str | None = None) -> dict:
    return LEDGER.leaderboard(window_days=window_days,horizon=horizon,symbol=symbol)


def errors(limit: int = 250, horizon: int | None = None, symbol: str | None = None) -> dict:
    return LEDGER.error_summary(limit=limit,horizon=horizon,symbol=symbol)
