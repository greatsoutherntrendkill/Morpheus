"""AllAnalytics v4.40.10 — Champion & Validation Upgrade release wrapper."""
from __future__ import annotations
import evaluation_clock_v4401014 as EC14
import pandas as pd
import data_contract_v4401013 as DATA13
import model_correctness_v4409 as BASE
import forecast_contract_v4406 as CONTRACT
import champion_validation_v44010 as CV44010
import sealed_shadow_v44010 as SHADOW44010
import persistent_state_v44010 as PSTATE44010
import quality_contract_v4401011 as QUALITY
import temporal_validation_v4401012 as TV

VERSION="champion-validation-quality-v4.40.10.16"
MODEL_GENERATION=CONTRACT.MODEL_GENERATION
TARGET4405=BASE.TARGET4405

def forecast_horizon(close,symbol:str,horizon:int=10,fast:bool=True,context:dict|None=None)->dict:
    frame=pd.DataFrame({'date':close.index,'close':close.values})
    frame,audit=DATA13.prepare(frame,symbol,'model input',now=EC14.now())
    if frame.empty:return {}
    close=pd.Series(frame.close.values,index=pd.DatetimeIndex(frame.date))
    out=BASE.forecast_horizon(close,symbol=symbol,horizon=int(horizon),fast=fast,context=context)
    if not out:return {}
    out=dict(out);out["base_model_version"]=out.get("version");out["version"]=VERSION;out["model_version"]=VERSION;out["model_generation"]=MODEL_GENERATION
    out["champion_validation_release"]={
        "version":VERSION,"solver":CV44010.SOLVER_VERSION,"nested_chronological_regularization":True,
        "data_driven_internal_regime_moe_weights":True,"persistent_event_store":str(PSTATE44010.event_db_path()),
        "persistent_governance_store":str(PSTATE44010.governance_db_path()),"sealed_shadow_version":SHADOW44010.VERSION,
        "sealed_shadow_used_for_training":False,
    }
    val=dict(out.get("validation") or {});val.update({
        "champion_validation_release":VERSION,"champion_solver":CV44010.SOLVER_VERSION,
        "nested_chronological_regularization":True,"regime_moe_internal_weights_data_driven":True,
        "sealed_shadow_used_for_training":False,"persistent_event_governance_state":True,
    });out["validation"]=val
    out['temporal_validation']={
        'version':TV.VERSION,'status':'development_only','splits':TV.collect_manifests(out),
        'sealed_start':str(TV.SEALED_START.date()),'final_validation_passed':False,
        'availability_convention':'daily close; external daily factors lagged one observation',
        'note':'Проверка разделения истории исправлена. Независимая оценка точности ещё не завершена.'}
    from verified_extensions_v4401016 import policy
    out['extension_policy']=policy()
    return DATA13.decorate(QUALITY.forecast(out),audit,symbol,horizon,'fast' if fast else 'full')
