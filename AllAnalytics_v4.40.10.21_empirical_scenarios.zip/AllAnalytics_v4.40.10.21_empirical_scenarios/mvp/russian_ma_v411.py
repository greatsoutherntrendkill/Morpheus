
"""AllAnalytics v4.11 — Russian M&A database and analytical layer.

Sources packaged into russian_ma.db:
- uploaded detailed transaction base for 2012–2023;
- uploaded recent transaction base for 2024–2025;
- Kept 2026 Russian M&A market overview for aggregate context.

No missing corporate-finance figure is fabricated. Transaction-level analytics
are derived only from fields present in the uploaded bases plus public MOEX ISS
market prices when a listed company can be identified confidently.
"""
from __future__ import annotations

import datetime as dt
import json
import math
import os
import re
import sqlite3
import time
from pathlib import Path
from typing import Any

import requests

ROOT=Path(__file__).parent
DB_PATH=ROOT/"russian_ma.db"
CACHE_DIR=ROOT/"runtime_cache"/"russian_ma_v411"
CACHE_DIR.mkdir(parents=True,exist_ok=True)
SESSION=requests.Session()
MOEX_TIMEOUT=float(os.getenv("RU_MA_MOEX_TIMEOUT_SECONDS","7"))
CACHE_TTL=max(3600,int(os.getenv("RU_MA_REACTION_TTL_SECONDS","86400")))

TICKER_ALIASES=[
    ("SBER",["сбербанк","сбер (","сбер "]),
    ("GAZP",["газпром"]),
    ("LKOH",["лукойл","lukoil"]),
    ("GMKN",["норильский никель","норникель"]),
    ("ROSN",["роснефть"]),
    ("TATN",["татнефть"]),
    ("CHMF",["северсталь"]),
    ("NLMK",["нлмк","новолипецкий металлургический"]),
    ("MAGN",["магнитогорский металлургический комбинат","ммк"]),
    ("MTSS",["мобильные телесистемы","мтс"]),
    ("RTKM",["ростелеком"]),
    ("VTBR",["банк втб","втб"]),
    ("MOEX",["московская биржа"]),
    ("AFLT",["аэрофлот"]),
    ("ALRS",["алроса"]),
    ("PHOR",["фосагро"]),
    ("MGNT",["магнит"]),
    ("PIKK",["группа пик","пик"]),
    ("SMLT",["самолет"]),
    ("ASTR",["группа астра"]),
    ("LEAS",["европлан"]),
    ("OZON",["ozon","озон"]),
    ("VKCO",["vk ","вконтакте","mail.ru group"]),
    ("YNDX",["яндекс","yandex"]),
]

def _conn():
    con=sqlite3.connect(DB_PATH,timeout=20)
    con.row_factory=sqlite3.Row
    return con

def _meta(key:str,default=None):
    con=_conn()
    try:
        r=con.execute("SELECT value FROM metadata WHERE key=?",(key,)).fetchone()
        return json.loads(r["value"]) if r else default
    finally:con.close()

def status()->dict[str,Any]:
    con=_conn()
    try:
        total=con.execute("SELECT COUNT(*) n FROM deals").fetchone()["n"]
        years=[dict(r) for r in con.execute("SELECT year,COUNT(*) count FROM deals GROUP BY year ORDER BY year")]
        sectors=[r["sector"] for r in con.execute("SELECT DISTINCT sector FROM deals WHERE sector IS NOT NULL ORDER BY sector")]
    finally:con.close()
    return {
      "version":"4.11","provider":"Российская база M&A","count":total,
      "min_year":min(x["year"] for x in years),"max_year":max(x["year"] for x in years),
      "years":years,"sectors":sectors,"market_context":_meta("market_context",{}),
      "sources":_meta("sources",[]),
      "note":"Карточки 2012–2023 содержат детальные поля сделки; 2024–2025 — базовые buyer/target/stake/status из более новой выгрузки.",
    }

def _range_clause(range_id:str)->tuple[str,list]:
    max_year=int(_meta("max_year",2025))
    if range_id=="latest":return "1=1",[]
    if range_id=="1y":return "year=?",[max_year]
    if range_id in {"2012","all"}:return "year>=2012",[]
    raise ValueError("range must be latest, 1y or 2012")

def list_deals(range_id:str="latest",limit:int=50,offset:int=0,q:str="",sector:str="",year:int|None=None)->dict[str,Any]:
    where,args=_range_clause(range_id)
    parts=[where]
    if q:
        parts.append("(buyer LIKE ? OR target LIKE ? OR seller LIKE ? OR characteristic LIKE ?)")
        needle=f"%{q.strip()}%"
        args += [needle,needle,needle,needle]
    if sector:
        parts.append("sector=?");args.append(sector)
    if year:
        parts.append("year=?");args.append(int(year))
    sql_where=" AND ".join(parts)
    con=_conn()
    try:
        total=con.execute(f"SELECT COUNT(*) n FROM deals WHERE {sql_where}",args).fetchone()["n"]
        rows=[dict(r) for r in con.execute(
            f"""SELECT id,date,date_precision,year,month,sector,target,buyer,seller,asset_region,
                       deal_format,stake_pct,stake_text,value_usd_m,implied_equity_value_usd_m,
                       characteristic,status,source_quality,vs_year_median_x,vs_sector_median_x
                FROM deals WHERE {sql_where}
                ORDER BY date DESC,id DESC LIMIT ? OFFSET ?""",
            args+[max(1,min(int(limit),100)),max(0,int(offset))]
        )]
    finally:con.close()
    return {
      "version":"4.11","provider":"Russian M&A uploaded database","range":range_id,
      "count":len(rows),"total":total,"offset":offset,"rows":rows,
      "max_year":_meta("max_year",2025),
    }

def _record(deal_id:str)->dict[str,Any]:
    con=_conn()
    try:
        r=con.execute("SELECT * FROM deals WHERE id=?",(deal_id,)).fetchone()
        if not r:raise KeyError(deal_id)
        return dict(r)
    finally:con.close()

def _money_m(v):
    if v is None:return None
    return float(v)*1_000_000

def _financing(record:dict)->dict[str,Any]:
    text=" ".join(str(record.get(k) or "") for k in ("characteristic","deal_format","status")).lower()
    methods=[]
    if re.search(r"обмен.*акци|акци.*обмен|допэмисс|stock",text):methods.append("акции")
    if re.search(r"кредит|за[её]м|долгов|debt",text):methods.append("долговое финансирование")
    if re.search(r"денежн|cash",text):methods.append("денежные средства")
    return {
      "methods":methods,
      "disclosed":bool(methods),
      "note":"Форма финансирования извлекается только при прямом указании в исходной карточке сделки.",
    }

def _scale(record:dict)->dict[str,Any]:
    sx=record.get("vs_sector_median_x");yx=record.get("vs_year_median_x")
    ref=sx if sx is not None else yx
    if ref is None:
        label="Сравнение недоступно"
    elif ref>=3:
        label="Значительно крупнее типичной сделки"
    elif ref>=1.5:
        label="Крупнее медианной сделки"
    elif ref<=0.5:
        label="Заметно меньше медианной сделки"
    else:
        label="Близко к медианному размеру"
    return {"label":label,"vs_sector_median_x":sx,"vs_year_median_x":yx}

def _find_ticker(name:str|None)->str|None:
    if not name:return None
    low=(" "+name.lower().replace("ё","е")+" ")
    for ticker,aliases in TICKER_ALIASES:
        for a in aliases:
            if a in low:return ticker
    return None

def _market_candidate(record:dict)->tuple[str|None,str|None,str|None]:
    # Prefer target reaction, then buyer reaction.
    t=_find_ticker(record.get("target"))
    if t:return t,"цель сделки",record.get("target")
    b=_find_ticker(record.get("buyer"))
    if b:return b,"покупатель",record.get("buyer")
    return None,None,None

def _reaction_cache(ticker:str,date_s:str)->Path:
    return CACHE_DIR/f"{ticker}_{date_s}.json"

def _moex_history(ticker:str,event:dt.date)->list[tuple[dt.date,float]]:
    p=_reaction_cache(ticker,event.isoformat())
    try:
        d=json.loads(p.read_text(encoding="utf-8"))
        if time.time()-float(d.get("ts",0))<CACHE_TTL:
            return [(dt.date.fromisoformat(x[0]),float(x[1])) for x in d.get("rows",[])]
    except Exception:pass
    start=event-dt.timedelta(days=12);end=event+dt.timedelta(days=18)
    url=f"https://iss.moex.com/iss/history/engines/stock/markets/shares/securities/{ticker}.json"
    params={
      "from":start.isoformat(),"till":end.isoformat(),"iss.meta":"off",
      "history.columns":"TRADEDATE,CLOSE,BOARDID",
    }
    r=SESSION.get(url,params=params,timeout=MOEX_TIMEOUT)
    if r.status_code!=200:return []
    j=r.json().get("history") or {};cols=j.get("columns") or [];data=j.get("data") or []
    by_date={}
    fallback={}
    for row in data:
        x=dict(zip(cols,row))
        try:d=dt.date.fromisoformat(x["TRADEDATE"]);c=float(x["CLOSE"])
        except Exception:continue
        if not math.isfinite(c) or c<=0:continue
        fallback[d]=c
        if x.get("BOARDID")=="TQBR":by_date[d]=c
    rows=sorted((d,by_date.get(d,fallback[d])) for d in fallback)
    try:p.write_text(json.dumps({"ts":time.time(),"rows":[[d.isoformat(),c] for d,c in rows]}),encoding="utf-8")
    except Exception:pass
    return rows

def market_reaction(record:dict)->dict[str,Any]:
    ticker,role,name=_market_candidate(record)
    if not ticker:
        return {"available":False,"reason":"Среди участников не найден однозначно сопоставимый тикер MOEX."}
    try:event=dt.date.fromisoformat(record["date"])
    except Exception:return {"available":False,"reason":"Не удалось определить дату сделки."}
    try:rows=_moex_history(ticker,event)
    except Exception:return {"available":False,"ticker":ticker,"reason":"MOEX ISS временно недоступен."}
    if record.get("date_precision")=="month":
        # The uploaded Russian bases usually store the deal month, not the exact
        # announcement day. Show a monthly market context instead of pretending
        # it is a one-day event study.
        if event.month==12:next_month=dt.date(event.year+1,1,1)
        else:next_month=dt.date(event.year,event.month+1,1)
        prev=[x for x in rows if x[0]<event]
        inside=[x for x in rows if event<=x[0]<next_month]
        if not prev or not inside:
            return {"available":False,"ticker":ticker,"reason":"Недостаточно биржевой истории для месяца сделки."}
        p0=prev[-1][1];pend=inside[-1][1]
        return {
          "available":True,"mode":"month","ticker":ticker,"company":name,"role":role,"source":"MOEX ISS",
          "previous_close":p0,"month_end_close":pend,
          "month_pct":(pend/p0-1)*100 if p0 else None,
          "event_month":event.strftime("%Y-%m"),
          "note":"В исходной базе указаны месяц и год, поэтому это динамика за месяц сделки, а не реакция первого дня."
        }
    prev=[x for x in rows if x[0]<event];post=[x for x in rows if x[0]>=event]
    if not prev or not post:
        return {"available":False,"ticker":ticker,"reason":"Недостаточно биржевой истории вокруг даты события."}
    p0=prev[-1][1];p1=post[0][1];p5=post[min(4,len(post)-1)][1]
    return {
      "available":True,"mode":"event","ticker":ticker,"company":name,"role":role,"source":"MOEX ISS",
      "previous_close":p0,"first_close":p1,"fifth_close":p5,
      "day1_pct":(p1/p0-1)*100 if p0 else None,
      "day5_pct":(p5/p0-1)*100 if p0 else None,
      "event_date":event.isoformat(),"first_trade_date":post[0][0].isoformat(),
    }

def _summary(record:dict)->str:
    buyer=record.get("buyer") or "Покупатель не указан"
    target=record.get("target") or "актив"
    stake=record.get("stake_pct")
    status=record.get("status") or "статус не указан"
    action=(f"приобретает {stake:.2f}% в " if stake is not None else "участвует в сделке по активу ")
    bits=[f"{buyer} {action}{target}."]
    if record.get("seller"):bits.append(f"Продавец: {record['seller']}.")
    bits.append(f"Статус: {status}.")
    if record.get("asset_region"):bits.append(f"Актив расположен: {record['asset_region']}.")
    return " ".join(bits)

def analyze(deal_id:str)->dict[str,Any]:
    r=_record(deal_id)
    value=_money_m(r.get("value_usd_m"))
    implied=_money_m(r.get("implied_equity_value_usd_m"))
    fx=float(r["fx_rate"]) if r.get("fx_rate") else None
    value_rub_bn=(float(r["value_usd_m"])*fx/1000) if r.get("value_usd_m") and fx else None
    implied_rub_bn=(float(r["implied_equity_value_usd_m"])*fx/1000) if r.get("implied_equity_value_usd_m") and fx else None
    return {
      "version":"4.11","country":"RU",**r,
      "value_usd":value,"implied_equity_value_usd":implied,
      "value_rub_bn":value_rub_bn,"implied_equity_value_rub_bn":implied_rub_bn,
      "summary_ru":_summary(r),
      "financing":_financing(r),
      "scale":_scale(r),
      "market_reaction":market_reaction(r),
      "market_context":_meta("market_context",{}),
      "corporate_finance":{
        "classical_multiples_available":False,
        "classical_multiples_note":"EV/EBITDA и P/E не рассчитываются автоматически: в загруженной базе нет стандартизированной финансовой отчётности объекта сделки.",
        "goodwill_available":False,
        "goodwill_note":"Goodwill не содержится в загруженной базе. Без purchase price allocation достоверно рассчитывать его нельзя.",
        "implied_equity_value_note":"Если известны цена пакета и приобретаемая доля, AllAnalytics рассчитывает подразумеваемую стоимость 100% капитала.",
      },
      "source_note":(
        "Детальная карточка из загруженной исторической базы 2012–2023."
        if r.get("source_quality")=="detailed"
        else "Карточка из обновлённой базы 2024–2025; часть финансовых полей в исходнике отсутствует."
      ),
    }
