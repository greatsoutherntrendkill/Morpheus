
"""AllAnalytics v3.3 — locked champion/challenger benchmark.

This module compares the frozen Logistic Regression champion against LightGBM and
CatBoost using exactly the same feature rows, purged walk-forward splits, fixed
final holdout, non-overlap evaluation and paired block bootstrap.

Important: the final holdout is NEVER used for hyperparameter selection. Challenger
hyperparameters below are frozen constants. A benchmark result can make a challenger
eligible for manual review; it never silently replaces the production champion.
"""
from __future__ import annotations

import math
import os
from dataclasses import dataclass
from typing import Callable
import numpy as np
import pandas as pd

import models as M

CHAMPION_VERSION = "logreg-v3.2.0"
CHALLENGER_VERSIONS = {
    "lightgbm": "lightgbm-v3.3.0",
    "catboost": "catboost-v3.3.0",
}
FEATURE_VERSION = "features-pit-v3.1.0"
VALIDATION_VERSION = "paired-purged-nonoverlap-bootstrap-holdout-v3.3"

# Locked before looking at the final holdout. Changing these requires a new model version.
LOCKED_CONFIGS = {
    "logistic_regression": {
        "lr": 0.25, "n_iter": 350, "l2": 0.02,
        "calibration": "native_probability", "seed": 42,
    },
    "lightgbm": {
        "n_estimators": 80, "learning_rate": 0.035, "num_leaves": 7,
        "max_depth": 3, "min_child_samples": 35, "subsample": 0.85,
        "colsample_bytree": 0.85, "reg_alpha": 0.20, "reg_lambda": 1.00,
        "random_state": 42, "n_jobs": 1, "verbosity": -1,
        "calibration": "none_raw_probability",
    },
    "catboost": {
        "iterations": 80, "depth": 4, "learning_rate": 0.035,
        "l2_leaf_reg": 6.0, "random_seed": 42, "verbose": False,
        "thread_count": 1, "allow_writing_files": False,
        "loss_function": "Logloss", "eval_metric": "Logloss",
        "calibration": "none_raw_probability",
    },
}


class _Logistic:
    def fit(self, X, y):
        c = LOCKED_CONFIGS["logistic_regression"]
        self.m = M.LogReg(lr=c["lr"], n_iter=c["n_iter"], l2=c["l2"]).fit(X, y)
        return self
    def proba(self, X):
        return self.m.proba(X)
    def importance(self):
        return np.abs(np.asarray(self.m.w[1:], dtype=float))


class _LGBM:
    def fit(self, X, y):
        from lightgbm import LGBMClassifier
        cfg = {k:v for k,v in LOCKED_CONFIGS["lightgbm"].items() if k != "calibration"}
        self.m = LGBMClassifier(**cfg)
        self.m.fit(X, np.asarray(y, dtype=int))
        return self
    def proba(self, X):
        return self.m.predict_proba(X)[:,1]
    def importance(self):
        return np.asarray(self.m.feature_importances_, dtype=float)


class _CatBoost:
    def fit(self, X, y):
        from catboost import CatBoostClassifier
        cfg = {k:v for k,v in LOCKED_CONFIGS["catboost"].items() if k != "calibration"}
        self.m = CatBoostClassifier(**cfg)
        self.m.fit(X, np.asarray(y, dtype=int))
        return self
    def proba(self, X):
        return self.m.predict_proba(X)[:,1]
    def importance(self):
        return np.asarray(self.m.get_feature_importance(), dtype=float)


FACTORIES: dict[str, Callable[[], object]] = {
    "logistic_regression": _Logistic,
    "lightgbm": _LGBM,
    "catboost": _CatBoost,
}


def dependency_status() -> dict:
    out = {}
    for name in ("lightgbm", "catboost"):
        try:
            mod = __import__(name)
            out[name] = {"available": True, "version": getattr(mod, "__version__", "unknown")}
        except Exception as exc:
            out[name] = {"available": False, "error": str(exc)}
    return out


def _dataset(close: pd.Series, dxy: pd.Series | None, macro: pd.DataFrame | None,
             horizon: int):
    feats = M.build_features(close, dxy, macro)
    tgt = M.directional_target_frame(close, horizon)
    df = feats.copy().join(tgt[["y","ret_fwd","state","label_end"]])
    df["date"] = df.index
    # Keep the original trading-day axis for purge/holdout timing.  Neutral rows
    # remain in the frame with y=NaN; they may be scored live, but are never used
    # as fake down labels or as directional evaluation outcomes.
    df = df.dropna(subset=list(feats.columns)+["ret_fwd","state","label_end"])
    cols = list(feats.columns)
    return df, cols


def _predict_one_model(model_name: str, X: np.ndarray, y: np.ndarray,
                       dates: np.ndarray, label_ends: np.ndarray,
                       holdout_start: pd.Timestamp | None, min_train: int,
                       retrain_every: int):
    n = len(y)
    holdout_pos = n if holdout_start is None else int(np.searchsorted(
        np.asarray(dates, dtype="datetime64[ns]"),
        np.datetime64(holdout_start, "ns"), side="left"
    ))
    proba = np.full(n, np.nan)
    base = np.full(n, np.nan)
    train_sizes = np.zeros(n, dtype=int)

    dev_model = None
    frozen_model = None
    frozen_base = None
    last_retrain_t = None
    frozen_train_max_date = None

    for t in range(n):
        is_holdout = holdout_start is not None and t >= holdout_pos
        if is_holdout:
            train_idx = M._frozen_holdout_train_indices(label_ends, dates, holdout_start, t)
        else:
            train_idx = M._purged_train_indices(label_ends, dates[t], t)
        if len(train_idx) < min_train:
            continue
        directional_idx = train_idx[np.isfinite(y[train_idx])]
        # ``min_train`` is a chronology/history requirement, not permission to
        # relabel neutral observations.  The binary expert is fitted only on
        # material up/down outcomes.  A lower directional floor preserves the
        # original time-axis requirement while avoiding starvation when a clean
        # three-state target intentionally removes noisy moves.
        min_directional = max(60, int(math.ceil(float(min_train) * 0.50)))
        if len(directional_idx) < min_directional or len(np.unique(y[directional_idx])) < 2:
            continue

        if is_holdout:
            if frozen_model is None:
                frozen_model = FACTORIES[model_name]().fit(X[directional_idx], y[directional_idx])
                frozen_base = float(y[directional_idx].mean())
                frozen_train_max_date = str(pd.Timestamp(dates[directional_idx[-1]]).date())
            proba[t] = float(frozen_model.proba(X[t:t+1])[0])
            base[t] = frozen_base
            train_sizes[t] = len(directional_idx)
        else:
            if dev_model is None or last_retrain_t is None or (t-last_retrain_t) >= retrain_every:
                dev_model = FACTORIES[model_name]().fit(X[directional_idx], y[directional_idx])
                last_retrain_t = t
            proba[t] = float(dev_model.proba(X[t:t+1])[0])
            base[t] = float(y[directional_idx].mean())
            train_sizes[t] = len(directional_idx)
    importance = None
    if frozen_model is not None and hasattr(frozen_model, "importance"):
        try:
            importance = np.asarray(frozen_model.importance(), dtype=float)
        except Exception:
            importance = None
    return {
        "proba": proba, "base": base, "train_sizes": train_sizes,
        "frozen_train_max_date": frozen_train_max_date,
        "feature_importance": importance,
    }


def _metrics(p, y, base, horizon):
    if len(p) == 0:
        return {}
    raw = M._metric_bundle(p, y, base)
    no, n_no, phases = M._phase_nonoverlap_metrics(p, y, base, horizon)
    n_eff = M._effective_oos_n(p, y, base, horizon)
    boot = M._moving_block_bootstrap_ci(p, y, base, horizon=horizon, n_boot=500, seed=42)
    return {
        "n_raw": int(len(p)), "n_nonoverlap": int(n_no), "n_effective": int(n_eff),
        "phases": int(phases),
        "acc": round(no["acc"]*100, 3), "baseline_acc": round(no["base"]*100, 3),
        "edge_pp": round(no["edge"], 3), "brier": round(no["brier"], 6),
        "brier_skill_pct": round(no["brier_skill"], 3), "ece": round(no["ece"], 6),
        "edge_ci95": [round(boot.get("edge_low", np.nan),3), round(boot.get("edge_high",np.nan),3)] if boot else None,
        "brier_skill_ci95": [round(boot.get("brier_skill_low",np.nan),3), round(boot.get("brier_skill_high",np.nan),3)] if boot else None,
    }


def _paired_block_bootstrap(ch_p, cp_p, y, horizon, n_boot=1000, seed=777):
    """Paired CI of challenger minus champion on identical dates.

    Positive acc_delta and positive brier_improvement are better for challenger.
    """
    ch_p=np.asarray(ch_p,float); cp_p=np.asarray(cp_p,float); y=np.asarray(y,float)
    n=len(y)
    if n < 20:
        return {}
    block=max(5, int(horizon))
    block=min(block,n)
    rng=np.random.default_rng(seed + n + 53*int(horizon))
    max_start=max(1,n-block+1)
    acc_d=[]; brier_imp=[]
    for _ in range(int(n_boot)):
        idx=[]
        while len(idx)<n:
            st=int(rng.integers(0,max_start))
            idx.extend(range(st,min(st+block,n)))
        ii=np.asarray(idx[:n],int)
        ch_acc=np.mean((ch_p[ii]>=.5)==y[ii])
        cp_acc=np.mean((cp_p[ii]>=.5)==y[ii])
        acc_d.append((ch_acc-cp_acc)*100)
        ch_b=np.mean((ch_p[ii]-y[ii])**2)
        cp_b=np.mean((cp_p[ii]-y[ii])**2)
        brier_imp.append(cp_b-ch_b)
    a=np.asarray(acc_d); b=np.asarray(brier_imp)
    # one-sided empirical p: H0 delta <= 0. +1 correction avoids zero p-values.
    p_acc=float((np.sum(a<=0)+1)/(len(a)+1))
    p_brier=float((np.sum(b<=0)+1)/(len(b)+1))
    return {
        "acc_delta_pp": round(float(np.mean((ch_p>=.5)==y)-np.mean((cp_p>=.5)==y))*100,3),
        "acc_delta_ci95": [round(float(np.percentile(a,2.5)),3), round(float(np.percentile(a,97.5)),3)],
        "brier_improvement": round(float(np.mean((cp_p-y)**2)-np.mean((ch_p-y)**2)),6),
        "brier_improvement_ci95": [round(float(np.percentile(b,2.5)),6), round(float(np.percentile(b,97.5)),6)],
        "p_one_sided_acc": p_acc, "p_one_sided_brier": p_brier,
        "block_size": int(block), "resamples": int(n_boot),
    }


def _fit_platt_calibrator(dev_p, dev_y):
    """Fit Platt scaling on development OOS predictions only; holdout stays untouched."""
    p=np.clip(np.asarray(dev_p,float),1e-5,1-1e-5)
    y=np.asarray(dev_y,float)
    if len(p)<50 or len(np.unique(y))<2:
        return None
    x=np.log(p/(1-p)).reshape(-1,1)
    return M.LogReg(lr=0.08,n_iter=600,l2=0.10).fit(x,y)


def _apply_platt(cal, p):
    if cal is None:
        return None
    p=np.clip(np.asarray(p,float),1e-5,1-1e-5)
    x=np.log(p/(1-p)).reshape(-1,1)
    return np.asarray(cal.proba(x),float)


def _reliability_bins(p, y, bins=8):
    """Holdout reliability table; diagnostic only, never used for tuning."""
    p=np.asarray(p,float); y=np.asarray(y,float)
    if len(p)==0: return []
    edges=np.linspace(0,1,int(bins)+1); out=[]
    for i,(lo,hi) in enumerate(zip(edges[:-1],edges[1:])):
        mask=(p>=lo)&(p<(hi if i<len(edges)-2 else hi+1e-12))
        if not mask.any(): continue
        out.append({"lo":round(float(lo),3),"hi":round(float(hi),3),"n":int(mask.sum()),
                    "mean_p":round(float(p[mask].mean()),4),
                    "actual_up_rate":round(float(y[mask].mean()),4),
                    "calibration_gap":round(float(p[mask].mean()-y[mask].mean()),4)})
    return out


def _top_importance(values, cols, top_n=10):
    if values is None: return []
    a=np.asarray(values,float)
    if len(a)!=len(cols): return []
    total=float(np.sum(np.abs(a)))
    if total<=1e-12: return []
    order=np.argsort(np.abs(a))[::-1][:int(top_n)]
    return [{"feature":str(cols[i]),"importance":round(float(abs(a[i])/total),6)} for i in order]



def _economic_1d(p, rf, cost_bps=2.0):
    p=np.asarray(p,float); rf=np.asarray(rf,float)
    if len(p)<10: return {}
    pos=(p>=0.5).astype(float)
    turnover=np.abs(np.diff(np.r_[0.0,pos]))
    net=pos*rf-turnover*(float(cost_bps)/10000.0)
    gross=pos*rf
    def sh(x):
        s=float(np.std(x,ddof=1)) if len(x)>1 else 0.0
        return float(np.mean(x)/s*np.sqrt(252)) if s>1e-12 else 0.0
    return {
        "cost_bps_one_way": float(cost_bps),
        "gross_sharpe": round(sh(gross),4),
        "net_sharpe": round(sh(net),4),
        "net_log_return": round(float(np.sum(net)),6),
        "turnover": round(float(np.sum(turnover)),3),
    }


def compare_asset(close: pd.Series, dxy: pd.Series | None=None, macro: pd.DataFrame | None=None,
                  horizon=10, min_train=220, retrain_every=20, cost_bps=2.0):
    """Run the locked benchmark for one asset/horizon."""
    horizon=int(horizon)
    df, cols = _dataset(close, dxy, macro, horizon)
    if len(df) < min_train+60:
        return {}
    X=df[cols].to_numpy(float); y=df["y"].to_numpy(float)
    rf=df["ret_fwd"].to_numpy(float)
    dates=pd.to_datetime(df["date"]).to_numpy()
    label_ends=pd.to_datetime(df["label_end"]).to_numpy()
    holdout_start=M._resolve_final_holdout_start(dates,min_train)
    holdout_pos=len(df) if holdout_start is None else int(np.searchsorted(
        np.asarray(dates,dtype="datetime64[ns]"),np.datetime64(holdout_start,"ns"),side="left"))

    preds={}
    for name in FACTORIES:
        preds[name]=_predict_one_model(name,X,y,dates,label_ends,holdout_start,min_train,retrain_every)

    # Directional benchmark metrics are defined only where the target is
    # significant. Neutral/no-edge observations keep their chronology but do not
    # count as up/down wins or losses.
    all_valid=np.isfinite(y)
    for name in preds:
        all_valid &= ~np.isnan(preds[name]["proba"])
    date_idx=pd.DatetimeIndex(pd.to_datetime(dates))
    if holdout_start is None:
        dev=all_valid; hold=np.zeros(len(df),bool)
    else:
        dev=all_valid & (date_idx<holdout_start)
        hold=all_valid & (date_idx>=holdout_start)
    if int(dev.sum())<30:
        return {}

    result={
        "horizon":horizon, "features":cols,
        "feature_version":FEATURE_VERSION, "validation_version":VALIDATION_VERSION,
        "holdout_start":None if holdout_start is None else str(holdout_start.date()),
        "holdout_used_for_tuning":False, "identical_splits":True,
        "retrain_every":int(retrain_every), "min_train":int(min_train),
        "models":{}, "paired_holdout":{},
    }
    for name, pr in preds.items():
        raw_hold_metrics = _metrics(pr["proba"][hold],y[hold],pr["base"][hold],horizon) if int(hold.sum())>=10 else {}
        cal = _fit_platt_calibrator(pr["proba"][dev], y[dev])
        calibrated_hold = _apply_platt(cal, pr["proba"][hold]) if int(hold.sum())>=10 else None
        calibrated_metrics = _metrics(calibrated_hold,y[hold],pr["base"][hold],horizon) if calibrated_hold is not None else {}
        result["models"][name]={
            "version": CHAMPION_VERSION if name=="logistic_regression" else CHALLENGER_VERSIONS[name],
            "locked_config": LOCKED_CONFIGS[name],
            "development": _metrics(pr["proba"][dev],y[dev],pr["base"][dev],horizon),
            "holdout": raw_hold_metrics,
            "holdout_reliability": _reliability_bins(pr["proba"][hold], y[hold], bins=8) if int(hold.sum())>=10 else [],
            "calibration_method": "platt_fit_on_development_oos_only" if cal is not None else "unavailable",
            "holdout_calibrated": calibrated_metrics,
            "holdout_calibrated_reliability": _reliability_bins(calibrated_hold, y[hold], bins=8) if calibrated_hold is not None else [],
            "calibration_brier_delta": (round(float(raw_hold_metrics.get("brier"))-float(calibrated_metrics.get("brier")),6)
                if raw_hold_metrics.get("brier") is not None and calibrated_metrics.get("brier") is not None else None),
            "top_features_frozen": _top_importance(pr.get("feature_importance"), cols, top_n=10),
            "frozen_train_max_date":pr["frozen_train_max_date"],
        }
        if horizon==1 and int(hold.sum())>=10:
            result["models"][name]["holdout_economic"]=_economic_1d(pr["proba"][hold],rf[hold],cost_bps)
    cp=preds["logistic_regression"]["proba"]
    if int(hold.sum())>=20:
        for name in ("lightgbm","catboost"):
            result["paired_holdout"][name]=_paired_block_bootstrap(
                preds[name]["proba"][hold], cp[hold], y[hold], horizon
            )
    # live prediction is trained on all currently observable labels. It is logged but
    # does not alter historical dev/holdout evidence.
    live_feats=M.build_features(close,dxy,macro).dropna()
    if len(live_feats)>min_train:
        fit_idx=np.where(np.isfinite(y))[0]
        if len(fit_idx)>=max(60,int(math.ceil(float(min_train)*0.50))) and len(np.unique(y[fit_idx]))>=2:
            for name in FACTORIES:
                m=FACTORIES[name]().fit(X[fit_idx],y[fit_idx])
                result["models"][name]["live_p_up"]=round(float(m.proba(live_feats[cols].to_numpy(float)[-1:])[0]),6)
    result["_arrays"]={
        "dates":[str(pd.Timestamp(x).date()) for x in dates],
        "hold_mask":hold.astype(int).tolist(),
    }
    return result


def holm_adjust(pairs: list[tuple[str,float]]) -> dict[str,float]:
    """Holm-Bonferroni family-wise error correction."""
    vals=[(k,min(1.0,max(0.0,float(p)))) for k,p in pairs if p is not None and np.isfinite(p)]
    m=len(vals)
    if not m: return {}
    ordered=sorted(vals,key=lambda kv:kv[1])
    out={}; running=0.0
    for i,(k,p) in enumerate(ordered):
        adj=min(1.0,(m-i)*p)
        running=max(running,adj)
        out[k]=running
    return out


def promotion_summary(rows: list[dict]) -> dict:
    """Portfolio-level research eligibility, not automatic promotion.

    Requires multiplicity-controlled holdout evidence and net economic improvement.
    """
    tests=[]
    for r in rows:
        sym=r.get("symbol"); h=r.get("horizon")
        for c in ("lightgbm","catboost"):
            ph=(r.get("paired_holdout") or {}).get(c) or {}
            if ph.get("p_one_sided_brier") is not None:
                tests.append((f"{c}|{sym}|{h}",ph["p_one_sided_brier"]))
    adjusted=holm_adjust(tests)

    out={}
    for c in ("lightgbm","catboost"):
        comparable=[]; econ_delta=[]
        significant_wins=0; significant_losses=0
        for r in rows:
            ph=(r.get("paired_holdout") or {}).get(c) or {}
            if not ph: continue
            key=f"{c}|{r.get('symbol')}|{r.get('horizon')}"
            adj=adjusted.get(key)
            bi=ph.get("brier_improvement")
            if bi is not None:
                comparable.append(float(bi))
                if adj is not None and adj<0.05 and bi>0: significant_wins+=1
                if adj is not None and adj<0.05 and bi<0: significant_losses+=1
            if r.get("horizon")==1:
                cm=((r.get("models") or {}).get(c) or {}).get("holdout_economic") or {}
                cp=((r.get("models") or {}).get("logistic_regression") or {}).get("holdout_economic") or {}
                if cm.get("net_sharpe") is not None and cp.get("net_sharpe") is not None:
                    econ_delta.append(float(cm["net_sharpe"])-float(cp["net_sharpe"]))
        median_brier=float(np.median(comparable)) if comparable else None
        median_econ=float(np.median(econ_delta)) if econ_delta else None
        eligible=(
            len(comparable)>=6 and significant_wins>=3 and significant_losses==0
            and median_brier is not None and median_brier>0
            and median_econ is not None and median_econ>0.10
        )
        reasons=[]
        if len(comparable)<6: reasons.append("fewer than 6 comparable locked-holdout tests")
        if significant_wins<3: reasons.append("fewer than 3 Holm-significant Brier wins")
        if significant_losses>0: reasons.append("has Holm-significant holdout regression")
        if median_brier is None or median_brier<=0: reasons.append("median holdout Brier improvement <= 0")
        if median_econ is None or median_econ<=0.10: reasons.append("median 1D net-Sharpe improvement <= 0.10")
        out[c]={
            "eligible_for_manual_promotion_review":bool(eligible),
            "comparable_holdout_tests":len(comparable),
            "holm_significant_brier_wins":significant_wins,
            "holm_significant_brier_losses":significant_losses,
            "median_brier_improvement":median_brier,
            "median_1d_net_sharpe_delta":median_econ,
            "reason":"passes locked v3.3 research gate" if eligible else "; ".join(reasons),
        }
    return {"rule_version":"v3.3-paired-holdout-holm-economic","automatic_promotion":False,
            "challengers":out,"holm_adjusted_p":adjusted}
