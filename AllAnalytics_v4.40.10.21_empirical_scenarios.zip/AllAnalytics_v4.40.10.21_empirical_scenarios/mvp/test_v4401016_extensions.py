import numpy as np
import pandas as pd
import pytest
import verified_extensions_v4401016 as E
import evaluation_clock_v4401014 as CLOCK
import models as M

def price(n=500):return pd.Series(100*np.exp(np.cumsum(np.random.default_rng(16).normal(0,.01,n))),index=pd.bdate_range('2023-01-01',periods=n))
def test_research_cannot_change_live():
 with pytest.raises(RuntimeError):
  with E.experiment('without_trend'):pass
 a=M.build_features(price())
 with CLOCK.at('2025-01-01T22:00Z'):
  with E.experiment('without_trend'):
   b=M.build_features(price());assert 'dist_ma200' not in b and b.iloc[:199].isna().all().all()
 pd.testing.assert_frame_equal(a,M.build_features(price()))

@pytest.mark.parametrize('group',list(E.GROUPS))
def test_removed_group_and_target_invariant(group):
 c=price();target=M.directional_target_frame(c,10)
 with CLOCK.at('2025-01-01T22:00Z'):
  with E.experiment('without_'+group):
   f=M.build_features(c);assert not set(E.GROUPS[group])&set(f)
   pd.testing.assert_frame_equal(target,M.directional_target_frame(c,10))

def test_absent_factor_is_not_zero():
 with CLOCK.at('2025-01-01T22:00Z'):
  with E.experiment('plus_market'):
   with pytest.raises(ValueError):M.build_features(price())

def test_unknown_distribution_columns_fail_closed():
 f=pd.DataFrame({'ret_5':[1.],'vol_20':[2.],'dxy_ret_20':[99.],'new_unreviewed_factor':[777.]})
 out,d=E.distribution_features(f,{})
 assert list(out)==['ret_5','vol_20'] and len(d['excluded_external_features'])==2

def test_full_range_ignores_unverified_external_prices(monkeypatch):
 import asset_specialists_v438 as S
 import distributional_forecast_v440 as D
 c=price();idx=c.index
 monkeypatch.setattr(S,'_db_matrix',lambda:pd.DataFrame({'^GSPC':c*2,'DX-Y.NYB':c*.8,'GC=F':c*3},index=idx))
 a,diag=D._build_features(c,'AAPL')
 monkeypatch.setattr(S,'_db_matrix',lambda:pd.DataFrame({'^GSPC':c[::-1].values*90,'DX-Y.NYB':c*40,'GC=F':c*.01},index=idx))
 b,_=D._build_features(c,'AAPL')
 pd.testing.assert_frame_equal(a,b)
 assert not diag['external_features_active'] and 'benchmark_ret_20' not in a

def test_availability_revision_and_staleness():
 rows=[{'observed_at':'2026-01-01T12:00Z','available_at':'2026-01-01T13:00Z','value':1},
       {'observed_at':'2026-01-01T12:00Z','available_at':'2026-01-03T12:00Z','value':3}]
 v,_=E.align_observations(rows,['2026-01-01T12:30Z','2026-01-02T12:00Z','2026-01-03T13:00Z','2026-02-01T12:00Z'])
 assert pd.isna(v.iloc[0]) and v.iloc[1]==1 and v.iloc[2]==3 and pd.isna(v.iloc[3])

def test_future_mutation_cannot_change_past():
 row={'observed_at':'2026-01-05T12:00Z','available_at':'2026-01-06T12:00Z','value':1}
 a,_=E.align_observations([row],['2026-01-01T12:00Z']);row['value']=999
 b,_=E.align_observations([row],['2026-01-01T12:00Z']);pd.testing.assert_series_equal(a,b)

def test_no_unknown_timezone_or_delivery_before_observation():
 rows=[{'observed_at':'2026-01-01','available_at':'2026-01-02','value':1},{'observed_at':'2026-01-02T12:00Z','available_at':'2026-01-01T12:00Z','value':1}]
 v,d=E.align_observations(rows,['2026-01-03T12:00Z']);assert d['rejected']==2 and v.isna().all()

def event():return {'released_at':'2026-01-02T13:30Z','first_available_at':'2026-01-02T13:31Z','consensus_available_at':'2026-01-01T12:00Z','initial_actual':3.,'consensus':2.5,'unit':'percent','source':'fixture','is_initial_release':True}

def test_surprise_not_known_before_release():
 e=event();assert not E.event_surprise(e,'2026-01-02T13:30Z')['available']
 r=E.event_surprise(e,'2026-01-02T13:32Z');assert r['surprise']==.5 and r['direction_adjustment_pp']==0

@pytest.mark.parametrize('field',['released_at','first_available_at','consensus_available_at','initial_actual','consensus','source','unit','is_initial_release'])
def test_missing_event_inputs_stay_missing(field):
 e=event();del e[field];assert not E.event_surprise(e,'2026-01-03T12:00Z')['available']

def test_late_consensus_and_revision_not_substituted():
 e=event();e['consensus_available_at']=e['released_at'];assert not E.event_surprise(e,'2026-01-03T12:00Z')['available']
 e=event();e['revised_actual']=900;assert E.event_surprise(e,'2026-01-03T12:00Z')['surprise']==.5

def test_policy_has_no_automatic_admission():
 p=E.policy();assert not p['automatic_promotion'] and not p['new_sources_active']

def test_conflicting_observations_are_rejected():
 a={'observed_at':'2026-01-01T12:00Z','available_at':'2026-01-01T13:00Z','value':1}
 v,d=E.align_observations([a,{**a,'value':2}],['2026-01-02T12:00Z'])
 assert v.isna().all() and d['rejected']==2

def test_event_flag_must_be_boolean():
 e=event();e['is_initial_release']='False'
 assert not E.event_surprise(e,'2026-01-03T12:00Z')['available']

def test_political_direction_does_not_move_probability():
 import feature_event_v434 as F
 a=F.apply_context_probability(.62,{'event_bias':-1,'event_risk':0,'context_score':0})
 b=F.apply_context_probability(.62,{'event_bias':1,'event_risk':0,'context_score':0})
 assert a==b and a['p_up']==.62 and a['context_p_up']==.5

def test_zero_observed_value_is_real_data():
 v,d=E.align_observations([{'observed_at':'2026-01-01T12:00Z','available_at':'2026-01-01T13:00Z','value':0}],['2026-01-02T12:00Z'])
 assert v.iloc[0]==0 and d['missing']==0
