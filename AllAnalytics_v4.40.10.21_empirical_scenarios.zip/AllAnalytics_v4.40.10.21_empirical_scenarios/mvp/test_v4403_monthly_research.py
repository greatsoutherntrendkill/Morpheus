from pathlib import Path
import research_monthly_v4403 as R


def _payload():
    return {
        'rates': [
            {'country':'США','rate_name':'Ставка ФРС','rate':3.75},
            {'country':'Россия','rate_name':'Ключевая ставка','rate':14.0},
        ],
        'events': [
            {'date':'2026-09-16','cb':'ФРС','event':'Решение по ставке'},
            {'date':'2026-10-28','cb':'ФРС','event':'Решение по ставке'},
            {'date':'2026-12-16','cb':'ФРС','event':'старый seed'},
            {'date':'2026-10-23','cb':'Банк России','event':'Решение по ставке'},
            {'date':'2026-12-18','cb':'Банк России','event':'Решение по ставке'},
        ],
        'news': [],
    }


def _snapshot():
    return {
        'US': dict(R.FALLBACK['US']), 'RU': dict(R.FALLBACK['RU']),
        'source': {'US':'test','RU':'test'}, 'db_live': True,
    }


def test_monthly_outlook_runs_sep_through_dec(monkeypatch):
    monkeypatch.setattr(R, '_real_macro_snapshot', lambda payload: _snapshot())
    out=R.build(_payload(), as_of='2026-09-12', news=[])
    assert [m['id'] for m in out['months']] == ['2026-09','2026-10','2026-11','2026-12']
    assert len(out['macro']) == 6
    assert {x['region'] for x in out['rates']} == {'US','RU'}
    assert all(len(x['path']) == 4 for x in out['macro'] + out['rates'])


def test_official_corrected_meeting_dates_and_no_past_cbr_meeting(monkeypatch):
    monkeypatch.setattr(R, '_real_macro_snapshot', lambda payload: _snapshot())
    out=R.build(_payload(), as_of='2026-09-12', news=[])
    us=next(x for x in out['rates'] if x['region']=='US')
    ru=next(x for x in out['rates'] if x['region']=='RU')
    assert '2026-12-09' in us['meetings']
    assert '2026-12-16' not in us['meetings']
    assert next(x for x in ru['path'] if x['month']=='2026-09')['meeting'] is None
    assert '2026-10-23' in ru['meetings'] and '2026-12-18' in ru['meetings']


def test_rate_scenarios_are_valid_and_discrete_modal_level(monkeypatch):
    monkeypatch.setattr(R, '_real_macro_snapshot', lambda payload: _snapshot())
    out=R.build(_payload(), as_of='2026-09-12', news=[])
    for rate in out['rates']:
        for z in rate['path']:
            p=z['probabilities']
            assert sum(p.values()) == 100
            assert set(p) == {'hike','hold','cut'}
            assert -0.5 <= z['modal_rate'] <= 50
            assert z['display'].endswith('%') and z['modal_display'].endswith('%')


def test_news_adjustment_is_bounded(monkeypatch):
    monkeypatch.setattr(R, '_real_macro_snapshot', lambda payload: _snapshot())
    news=[{'title':'ФРС инфляция ускорилась пошлины геополитическая эскалация','impact_score':100} for _ in range(100)]
    out=R.build(_payload(), as_of='2026-09-12', news=news)
    assert -1 <= out['signals']['US']['hawk'] <= 1
    assert 0 <= out['signals']['US']['geo'] <= 1
    pce=next(x for x in out['macro'] if x['region']=='US' and x['kind']=='inflation')
    assert 2.2 <= pce['path'][-1]['value'] <= 5.5


def test_last_good_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setattr(R, '_real_macro_snapshot', lambda payload: _snapshot())
    out=R.build(_payload(), as_of='2026-09-12', news=[])
    path=tmp_path/'monthly.json'
    assert R.persist_last_good(out,path)
    back=R.load_last_good(path)
    assert back['version']=='4.40.3'
    assert back['rates'][0]['path'][0]['month']=='2026-09'


def test_v4403_ui_and_api_contract():
    root=Path(__file__).parent
    html=(root/'site'/'index.html').read_text(encoding='utf-8')
    api=(root/'api.py').read_text(encoding='utf-8')
    start=(root/'start_v31.command').read_text(encoding='utf-8')
    seed=(root/'seed_cb_calendar.csv').read_text(encoding='utf-8')
    assert '/api/research/monthly-v4403' in api
    assert 'research-refresh' in html
    assert 'researchMonthButtons' in html
    assert "currentPage==='research'" in html
    assert '5*60*1000' in html
    assert "canvas.onclick=hasMonths" in html
    assert '2026-12-09' in seed and '2026-12-16' not in seed
    assert 'AllAnalytics v4.40.3' in start
    assert '.requirements.sha256' in start
    export=(root/'export_site.py').read_text(encoding='utf-8')
    assert 'NEWS_PREPARE_STATIC_MEDIA' in export
