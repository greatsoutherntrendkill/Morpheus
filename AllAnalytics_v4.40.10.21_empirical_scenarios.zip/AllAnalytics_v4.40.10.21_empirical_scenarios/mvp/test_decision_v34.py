
from __future__ import annotations
import json, sqlite3
from pathlib import Path
import db, model_registry as MR

ROOT=Path(__file__).parent

def main():
    b=json.loads((ROOT/"site"/"model_benchmark_v34.json").read_text(encoding="utf-8"))
    d=json.loads((ROOT/"site"/"model_decision_v34.json").read_text(encoding="utf-8"))
    assert len(b["rows"])==132, len(b["rows"])
    assert len({r["symbol"] for r in b["rows"]})==33
    assert set(r["horizon"] for r in b["rows"])=={1,5,10,20}
    assert not b.get("holdout_used_for_tuning")
    assert d["decision"]=="retain"
    assert d["selected_version"]=="logreg-v3.2.0"
    assert not b["promotion"]["challengers"]["lightgbm"]["eligible_for_manual_promotion_review"]
    assert not b["promotion"]["challengers"]["catboost"]["eligible_for_manual_promotion_review"]
    for r in b["rows"]:
        for m in ("logistic_regression","lightgbm","catboost"):
            mm=r["models"][m]
            assert "holdout_reliability" in mm
            assert "top_features_frozen" in mm
            assert "holdout_calibrated" in mm
    con=db.connect()
    try:
        MR.ensure_schema(con)
        row=con.execute("SELECT decision_id,selected_version,action FROM model_decisions WHERE decision_id=?",
                        (d["decision_id"],)).fetchone()
        assert row and row[1]=="logreg-v3.2.0" and row[2]=="retain"
        try:
            con.execute("UPDATE model_decisions SET action='promote' WHERE decision_id=?",(d["decision_id"],))
            raise AssertionError("immutable model decision was mutable")
        except sqlite3.DatabaseError:
            pass
    finally:
        con.close()
    print("OK: v3.4 full-universe evidence + calibration diagnostics + immutable RETAIN decision")

if __name__=="__main__":
    main()
