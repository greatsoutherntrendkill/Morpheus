from __future__ import annotations
import sqlite3
import numpy as np
import pandas as pd

import equity_forecast_v416 as EQ
import forecast_contract_v4406 as FC
import model_integrity_v4406 as MI
import prospective_feedback_v436 as FB
import prospective_selection_v437 as SEL
import target_contract_v4405 as TC


def _forecast_payload(as_of, generation=FC.MODEL_GENERATION):
    f={
        'p_up':.56,'p_down':.44,'conditional_p_up':.60,'p_move':.60,'p_neutral':.40,
        'class_probabilities':{'up':.36,'neutral':.40,'down':.24},
        'model_generation':generation,'target_version':TC.TARGET_VERSION,
        'probability_semantics':FC.PROBABILITY_SEMANTICS_VERSION,'abstain':False,
        'signal_strength':'умеренный','signal_threshold':.55,'regime':'range|normal_vol',
        'components':[{'name':'production','p_up':.55,'conditional_p_up':.58,'p_move':.62,'p_neutral':.38}],
        'prospective_selection_guard':{'version':SEL.VERSION},'guard_version':SEL.VERSION,
    }
    row={'symbol':'AAPL','status':'ok','source':'test','as_of':str(as_of)[:10],
         'history':[],'forecasts':{'10':f},'model':'AllAnalytics'}
    return row,f


def test_cache_rejects_old_asof_even_with_fresh_contract():
    old=(pd.Timestamp.utcnow().tz_localize(None).normalize()-pd.Timedelta(days=45)).date()
    row,f=_forecast_payload(old)
    row['cache_contract']={'version':FC.CACHE_CONTRACT_VERSION,'model_generation':FC.MODEL_GENERATION,
                           'target_version':TC.TARGET_VERSION,'as_of':str(old)}
    assert EQ._cache_payload_valid(row) is False


def test_cache_rejects_wrong_generation_and_accepts_current():
    today=str(pd.Timestamp.utcnow().tz_localize(None).normalize().date())
    row,f=_forecast_payload(today)
    row['cache_contract']={'version':FC.CACHE_CONTRACT_VERSION,'model_generation':FC.MODEL_GENERATION,
                           'target_version':TC.TARGET_VERSION,'as_of':today}
    assert EQ._cache_payload_valid(row) is True
    row['forecasts']['10']['model_generation']='old-generation'
    assert EQ._cache_payload_valid(row) is False


def _hist(asof='2026-06-30', future_return=.03, h=5):
    end=pd.Timestamp(asof)
    idx=pd.bdate_range(end=end,periods=80)
    base=100*np.exp(np.cumsum(np.sin(np.arange(len(idx))/7)*.001 + .0001))
    rows=[{'t':str(d.date()),'c':float(v)} for d,v in zip(idx,base)]
    p=float(base[-1])
    fut=pd.bdate_range(start=end+pd.offsets.BDay(1),periods=h)
    vals=np.linspace(p,p*(1+future_return),h)
    rows += [{'t':str(d.date()),'c':float(v)} for d,v in zip(fut,vals)]
    return rows[:80],rows


def test_shared_target_contract_is_used_for_prospective_settlement(tmp_path):
    before,full=_hist(future_return=.04,h=5)
    led=FB.Ledger(tmp_path/'feedback.sqlite3')
    row,f=_forecast_payload('2026-06-30')
    row['history']=before
    row['forecasts']={'5':f}
    ins=led.record_row(row,'test')
    assert ins['inserted']==1
    fr=led.rows(limit=1)[0]
    expected=TC.band_pct_for_asof(pd.Series([x['c'] for x in before],index=pd.to_datetime([x['t'] for x in before])),5,'2026-06-30')
    assert abs(fr['neutral_band_pct']-expected)<1e-10
    out=led.settle_due(lambda _s: full,limit=10)
    assert out['settled']==1
    st=led.rows(limit=1,settled_only=True)[0]
    expected_outcome=TC.classify_return(st['realized_return_pct']/100.0,fr['neutral_band_pct']/100.0)
    assert st['outcome']==expected_outcome=='up'
    assert st['multiclass_brier'] is not None
    assert st['move_brier'] is not None
    assert st['direction_brier'] is not None


def test_neutral_outcome_has_multiclass_and_move_score_but_no_direction_score(tmp_path):
    before,full=_hist(future_return=.0005,h=5)
    led=FB.Ledger(tmp_path/'feedback.sqlite3')
    row,f=_forecast_payload('2026-06-30'); row['history']=before; row['forecasts']={'5':f}
    led.record_row(row,'test'); led.settle_due(lambda _s: full,limit=10)
    st=led.rows(limit=1,settled_only=True)[0]
    assert st['outcome']=='neutral'
    assert st['multiclass_brier'] is not None and st['move_brier'] is not None
    assert st['direction_brier'] is None


def _manual_settled(led, generation, date, fid_seed):
    before,_=_hist(asof=date,future_return=.03,h=5)
    row,f=_forecast_payload(date,generation=generation); row['history']=before; row['forecasts']={'5':f}
    got=led.record_row(row,'test'); fid=got['ids'][0]
    with led._connect() as con:
        con.execute('''INSERT INTO settlement_ledger(forecast_id,settled_at,target_as_of,target_price,realized_return_pct,outcome,soft_target,
          direction_hit,published_hit,significant_hit,brier,calibration_error,multiclass_brier,multiclass_log_loss,move_brier,direction_brier,direction_log_loss,material_move,target_version,model_generation,error_code,attribution_json)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
          (fid,'2026-09-01T00:00:00Z',date,103,3,'up',1,1,1,1,.01,.1,.1,.1,.1,.1,.1,1,TC.TARGET_VERSION,generation,'correct_signal','{}'))
        con.commit()


def test_leaderboard_and_selection_do_not_mix_generations(tmp_path):
    led=FB.Ledger(tmp_path/'feedback.sqlite3')
    _manual_settled(led,'old-binary-generation','2026-05-01',1)
    _manual_settled(led,FC.MODEL_GENERATION,'2026-05-04',2)
    board=led.leaderboard(window_days=3650,horizon=5)
    assert board['generation_isolated'] is True
    assert board['model_generation']==FC.MODEL_GENERATION
    assert board['settled_forecasts']==1
    rep=SEL.candidate_report('production','production',window_days=3650,horizon=5,ledger=led)
    assert rep['model_generation']==FC.MODEL_GENERATION
    assert rep['paired_n']==1


def test_live_wrapper_uses_current_generation_and_factorized_probabilities(monkeypatch):
    base={'version':'base','p_up':.56,'p_down':.44,'conditional_p_up':.65,'p_move':.60,'p_neutral':.40,
          'components':[],'validation':{},'scorecard':{},'distribution_forecast':{}}
    monkeypatch.setattr(MI.BASE440,'forecast_horizon',lambda *a,**k:dict(base))
    out=MI.forecast_horizon(pd.Series(np.linspace(100,110,300),index=pd.bdate_range('2025-01-01',periods=300)),'AAPL',10)
    assert out['model_generation']==FC.MODEL_GENERATION
    cp=out['class_probabilities']
    assert abs(sum(cp.values())-1)<1e-6
    assert cp['neutral']==.4 and abs(cp['up']-.39)<1e-6
