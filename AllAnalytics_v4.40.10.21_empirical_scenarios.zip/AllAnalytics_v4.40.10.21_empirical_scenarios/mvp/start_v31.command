#!/bin/zsh
set -e
cd "$(dirname "$0")"

echo "== AllAnalytics v4.40.10.11 — качество прогнозов =="
# compatibility marker for v4.40.3 launcher regression tests: AllAnalytics v4.40.3
if [ ! -d ".venv" ]; then
  echo "[1/4] Создаём Python-окружение…"
  python3 -m venv .venv
fi
source .venv/bin/activate

REQ_HASH=$(shasum -a 256 requirements.txt | awk '{print $1}')
REQ_STAMP=".venv/.requirements.sha256"
if [ ! -f "$REQ_STAMP" ] || [ "$(cat "$REQ_STAMP" 2>/dev/null)" != "$REQ_HASH" ]; then
  echo "[1/4] Проверяем зависимости…"
  python -m pip install -r requirements.txt
  echo "$REQ_HASH" > "$REQ_STAMP"
else
  echo "[1/4] Зависимости уже установлены — пропускаем pip."
fi

echo "[2/4] Обновляем рыночные и макро-данные…"
python update.py

echo "[3/4] Готовим локальный снимок сайта…"
# v4.40.9: live forecasts/correctness guards are served by the API, so a full static ML
# rebuild is no longer allowed to block every startup. The packaged last-good
# snapshot is used by default. Set ALLANALYTICS_REBUILD_STATIC=1 when an explicit
# offline/static refresh is required.
if [ "${ALLANALYTICS_REBUILD_STATIC:-0}" = "1" ]; then
  echo "      Полная статическая пересборка включена…"
  python export_site.py
else
  echo "      Используем last-good snapshot; live-модели обновляются через API."
fi

echo "[4/4] Проверяем сборку…"
python smoke_test.py

echo ""
echo "Open: http://127.0.0.1:8000"
python -m uvicorn api:app --reload --port 8000
