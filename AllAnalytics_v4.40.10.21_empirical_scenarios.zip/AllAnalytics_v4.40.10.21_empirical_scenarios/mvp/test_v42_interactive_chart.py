
from __future__ import annotations
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).parent

def main():
    import market_data_v41 as M

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    lab=(ROOT/"site"/"technical_lab_v42.html").read_text(encoding="utf-8")
    assert ("technical_lab_v42.html" in html) or ("technical_lab_v43.html" in html) or ("technical_lab_v44.html" in html) or ("technical_lab_v45.html" in html) or ("technical_lab_v46.html" in html) or ("technical_lab_v47.html" in html) or ("technical_lab_v411.html" in html)
    assert "market-chart-preview" in html
    assert "simple-chart-tip" in html
    assert "chartPoint(x)" in html
    assert "x?.c??x?.close" in html
    assert "График инструмента" in html

    for token in [
        "ICT / структура и ликвидность","Тренд и импульс","Возврат к среднему",
        "Горизонтальный уровень","Линия тренда","RSI","MACD","Полосы Боллинджера",
        "regime_familiarity"
    ]:
        if token=="regime_familiarity":
            continue
        assert token in lab, token

    # API route exists and long-history fallback is isolated behind the server.
    api_src=(ROOT/"api.py").read_text(encoding="utf-8")
    assert '@app.get("/api/chart/history")' in api_src

    # Quote payload supports a longer daily preview.
    df=pd.DataFrame([{
        "date":pd.Timestamp("2026-01-01")+pd.Timedelta(days=i),
        "open":100+i,"high":102+i,"low":99+i,"close":101+i
    } for i in range(150)])
    q=M.quote_from_frame("^GSPC",df,"test")
    assert len(q["history"])==150
    assert q["history"][0]["t"]=="2026-01-01"
    assert q["history"][-1]["c"]==250.0

    print("OK: v4.2 daily live charts + hover + technical-analysis workspace")

if __name__=="__main__":
    main()
