from pathlib import Path

ROOT = Path(__file__).resolve().parent


def test_resilient_transport_present():
    t=(ROOT/'resilient_http_v429.py').read_text(encoding='utf-8')
    assert 'direct-no-env' in t
    assert 'system-env' in t
    assert 'ALLANALYTICS_EGRESS_PROXY' in t


def test_news_is_stale_while_revalidate():
    t=(ROOT/'api.py').read_text(encoding='utf-8')
    assert 'stale-while-revalidate' in t.lower()
    assert 'news_last_good_v429.json' in t
    assert '@app.get("/api/map/geo")' in t


def test_overview_live_price_called_by_active_renderer():
    t=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
    # There are historical duplicate renderer definitions; the final active one must call the price updater.
    tail=t[t.rfind('function applyOverviewForecast(f,isShort=false)'):]
    assert 'animateForecastLivePriceV428(a)' in tail
    assert "histLast" in t


def test_map_has_local_and_api_fallback():
    t=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
    assert "'/world_map_geo.json'" in t
    assert "'/api/map/geo'" in t
    assert 'allanalytics.news.lastgood.v429' in t
