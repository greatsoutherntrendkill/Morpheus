
"""One-command AllAnalytics v3.7 refresh.

1) update prices + macro;
2) rebuild champion snapshot and settle matured forecasts;
3) rebuild v3.6 pooled cross-asset challengers;
4) rebuild v3.7 Regime MoE / OOD challenger.

The v3.6 and v3.7 builders can take a while because they rerun honest
walk-forward research validation.
"""
from __future__ import annotations
import subprocess, sys

def run(cmd):
    print("\\n>>>"," ".join(cmd))
    subprocess.run(cmd,check=True)

def main():
    args=sys.argv[1:]
    run([sys.executable,"update.py",*args])
    run([sys.executable,"export_site.py"])
    run([sys.executable,"build_cross_asset_v36.py"])
    run([sys.executable,"build_regime_v37.py"])
    print("\\nAllAnalytics v3.7 refresh complete.")

if __name__=="__main__":
    main()
