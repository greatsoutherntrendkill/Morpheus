from __future__ import annotations
import json
from pathlib import Path
import alternative_data_v38 as A

ROOT=Path(__file__).parent

def test_crypto_parser():
    old=A._cg
    def fake(path,params):
        if 'open-interest' in path:
            return [
                {'time':1_700_000_000_000,'close':'100'},
                {'time':1_700_086_400_000,'close':'110'},
                {'time':1_700_172_800_000,'close':'121'},
            ]
        if 'funding-rate' in path:
            return [
                {'time':1_700_000_000_000,'close':'0.008'},
                {'time':1_700_086_400_000,'close':'0.012'},
            ]
        return [
            {'time':1_700_000_000_000,'aggregated_long_liquidation_usd':'80','aggregated_short_liquidation_usd':'20'},
            {'time':1_700_086_400_000,'aggregated_long_liquidation_usd':'60','aggregated_short_liquidation_usd':'40'},
        ]
    A._cg=fake
    try:
        x=A._crypto_one('BTC')
        assert x['open_interest_usd']==121
        assert round(x['oi_change_1d_pct'],3)==10.0
        assert x['funding_oi_weighted']==0.012
        assert x['crowding']=='long-heavy'
        assert x['liquidation_bias_7d']=='long-liquidations'
    finally:
        A._cg=old

def test_options_parser():
    old=A._massive_chain
    def fake(_):
        rows=[]
        exp='2026-10-09'
        for typ,delta,iv,oi,strike in [
            ('call',.25,.20,100,100),('put',-.25,.26,160,100),
            ('call',.45,.21,200,95),('put',-.45,.24,100,105),
        ]:
            rows.append({'details':{'contract_type':typ,'expiration_date':exp,'strike_price':strike},
                         'greeks':{'delta':delta,'gamma':.02,'vega':.1},
                         'implied_volatility':iv,'open_interest':oi,
                         'underlying_asset':{'price':100}})
        return rows
    A._massive_chain=fake
    try:
        x=A._options_one('SPY')
        assert x['put_open_interest']==260
        assert x['call_open_interest']==300
        assert round(x['put_call_oi_ratio'],3)==round(260/300,3)
        assert round(x['skew_25d_put_minus_call'],3)==.06
        assert len(x['top_strikes'])>0
    finally:
        A._massive_chain=old

def main():
    st=A.provider_status()
    assert st['coinglass']['configured']
    assert st['massive']['configured']
    assert st['eia']['configured']
    test_crypto_parser(); test_options_parser()

    site=(ROOT/'site')
    cache=json.loads((site/'altdata_v38.json').read_text(encoding='utf-8'))
    assert cache['version']=='3.8'
    assert cache['providers']['coinglass']['configured'] is True
    data=json.loads((site/'data.json').read_text(encoding='utf-8'))
    assert data['version']=='3.8' and data['altdata_version']=='3.8'

    # Strong secret-leak test: browser/static files may know configuration state,
    # but never credential values.
    env={}
    for line in (ROOT/'.env').read_text(encoding='utf-8').splitlines():
        if '=' in line and not line.lstrip().startswith('#'):
            k,v=line.split('=',1); env[k.strip()]=v.strip()
    secrets=[env.get(k,'') for k in ('COINGLASS_API_KEY','OPTIONS_API_KEY','EIA_API_KEY')]
    static='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in site.rglob('*') if p.is_file())
    for s in secrets:
        assert s and s not in static

    html=(site/'index.html').read_text(encoding='utf-8')
    assert 'Alternative Data Terminal' in html
    assert 'data.js?v=3.8' in html
    assert '/api/altdata/live' in html
    print('OK: v3.8 CoinGlass + Massive + EIA server-side integrations; no secrets leak to site')

if __name__=='__main__': main()
