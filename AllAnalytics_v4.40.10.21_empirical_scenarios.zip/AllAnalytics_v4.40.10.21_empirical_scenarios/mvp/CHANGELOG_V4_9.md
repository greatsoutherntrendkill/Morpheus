# AllAnalytics v4.9 — SEC EDGAR Deals Engine

## Что изменилось

Раздел «Сделки и IPO» больше не показывает демонстрационные M&A/IPO.

Единственный источник discovery и transaction filings в v4.9:

**SEC EDGAR**

SEC API key не нужен. Для корректного scripted access нужно только указать
declared User-Agent с реальным контактным e-mail:

```env
SEC_USER_AGENT=AllAnalytics Research your-real-email@example.com
```

## M&A

AllAnalytics индексирует SEC forms:

- DEFM14A;
- PREM14A;
- S-4 / S-4/A;
- F-4 / F-4/A;
- SC TO-T / amendments;
- SC 14D9 / amendments.

DEFM14A/PREM14A считаются сильным SEC-сигналом сделки по типу формы.
Остальные формы дополнительно проверяются по содержимому документа.

Из filing по возможности извлекаются:

- issuer;
- counterparty;
- transaction value;
- price per share;
- статус / стадия документа;
- CIK;
- accession number;
- ссылка на оригинальный SEC filing.

Если показатель нельзя уверенно извлечь, UI показывает
`не раскрыто / не извлечено`, а не демонстрационное число.

## IPO

Discovery идёт через 424B4.

Но запись появляется в пользовательском списке только после текстовой проверки,
что prospectus прямо относится к `initial public offering`.

Это исключает обычные follow-on и resale prospectuses.

По возможности извлекаются:

- issuer;
- ticker;
- биржа;
- offer price;
- shares offered;
- gross proceeds;
- CIK / accession;
- ссылка на оригинал SEC.

## История

Переключатели работают по реальному локальному индексу SEC:

- Последние;
- 1 год;
- с 2000 года.

Для истории используются квартальные `master.zip` индексы EDGAR.

Полная история с 2000 года индексируется в фоне и сохраняется в:

```text
sec_deals.db
```

После первого backfill повторно скачивать всю историю не нужно.

## Производительность

Архитектура двухступенчатая:

1. сначала загружается компактный master index;
2. большие filing documents скачиваются только для видимых карточек или при
   открытии конкретной сделки.

Это снижает число SEC requests и делает последующие открытия истории быстрыми.

## Endpoints

```text
GET /api/corpfin/deal-provider-status
GET /api/corpfin/transactions?kind=mna&range=latest
GET /api/corpfin/transactions?kind=ipo&range=1y
GET /api/corpfin/transactions?kind=mna&range=2000
GET /api/corpfin/transactions/{accession}
```

Подробная настройка: `SEC_EDGAR_SETUP.md`.
