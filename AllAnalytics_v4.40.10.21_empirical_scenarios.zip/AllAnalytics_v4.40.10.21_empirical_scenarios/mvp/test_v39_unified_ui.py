from __future__ import annotations
import json, re
from pathlib import Path
import alternative_data_v39 as AD

ROOT=Path(__file__).parent

def main():
    data=json.loads((ROOT/'site'/'data.json').read_text(encoding='utf-8'))
    assert data.get('unified_forecast_version')=='3.9'
    assert len(data.get('assets') or [])==33
    for a in data['assets']:
        u=a.get('unified_forecast_v39') or {}
        assert set(u)>={'1','5','10','20'}
        for h in ('1','5','10','20'):
            z=u[h]
            if z['p_up'] is not None:
                assert 0 <= z['p_up'] <= 1
                assert z['p_down'] is not None
                assert abs(z['p_up']+z['p_down']-1)<1e-6
                assert 0 <= z['agreement'] <= 1
                assert 0 <= z['confidence_score'] <= 1
            assert z['status'] in ('подтверждён','исследовательский') or z['p_up'] is None

    html=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
    assert 'data.js?v=4.11' in html
    for needle in ['Обсидиан','Атлас','Сигнал','Единый прогноз','Новости и карта','Альтернативные данные','Календарь','Исследования']:
        assert needle in html
    assert 'id="map-world"' in html and 'world_map_geo.json' in html
    assert 'Market News Terminal' not in html
    assert 'Alternative Data Terminal' not in html
    assert 'Model Lab' not in html

    geo=json.loads((ROOT/'site'/'world_map_geo.json').read_text(encoding='utf-8'))
    assert len(geo.get('features') or [])>=170

    # v3.9 regression: one unavailable CoinGlass metric must not erase the whole coin.
    old=AD._cg
    def fake(path,params):
        if 'open-interest' in path:
            return [
                {'time':1700000000000,'close':'100'},
                {'time':1700086400000,'close':'110'},
            ]
        raise RuntimeError('метрика временно недоступна')
    AD._cg=fake
    try:
        x=AD._crypto_one('BTC')
        assert x['open_interest_usd']==110
        assert x['availability']['открытый интерес'] is True
        assert x['availability']['ставка фондирования'] is False
        assert x['availability']['ликвидации'] is False
        assert x['metric_errors']
    finally:
        AD._cg=old

    # API keys may live in .env, but never in public browser files.
    env=(ROOT/'.env').read_text(encoding='utf-8')
    vals=[]
    for line in env.splitlines():
        if '=' in line and not line.lstrip().startswith('#'):
            k,v=line.split('=',1)
            if k.endswith('API_KEY') and v.strip(): vals.append(v.strip())
    public=html+(ROOT/'site'/'data.js').read_text(encoding='utf-8')+(ROOT/'site'/'altdata_v39.json').read_text(encoding='utf-8')
    assert all(v not in public for v in vals)
    print('OK: v3.9 единый прогноз + русскоязычный интерфейс + карта новостей + устойчивый CoinGlass refresh')

if __name__=='__main__':
    main()
