from copy import deepcopy
import pytest
import quality_contract_v4401011 as Q
import robustness_v4407 as R

def fixture():
    return {'p_up':.59,'p_down':.41,'conditional_p_up':.65,
            'class_probabilities':{'up':.39,'neutral':.4,'down':.21},
            'signal_threshold':.6,'abstain':False,'summary':'Сигнал подтверждён',
            'quality':{'trusted':True},'reliability':{'probability':.955,'trained':True,'validated_on_untouched_eval':True}}

def test_final_threshold_uses_neutral_aware_score_not_conditional():
    out=Q.forecast(fixture())
    assert out['abstain'] and not out['quality']['trusted']
    assert out['signal_strength']=='нет преимущества'
    assert 'Сигнал подтверждён' not in out['summary']
    assert out['conditional_p_up']==.65
    assert out['class_probabilities']==fixture()['class_probabilities']

def test_intermediate_validation_does_not_authorize_final_confidence():
    out=Q.forecast(fixture())
    assert out['confidence_score'] is None
    assert out['reliability']['probability'] is None

@pytest.mark.parametrize('value',[0,.7,1])
def test_valid_final_confidence_preserves_real_zero(value):
    f=fixture();f['p_up']=.7;f['reliability']['probability']=value
    f['final_evaluation']={'contract_version':Q.VERSION,'scope':'final_published_pipeline','passed':True}
    out=Q.forecast(f)
    assert out['confidence_score']==value
    assert out['confidence_status']=='validated'

@pytest.mark.parametrize('value',[None,True,'0.8',float('nan'),float('inf'),-1,2])
def test_bad_confidence_never_reaches_public_percentage(value):
    f=fixture();f['reliability']['probability']=value
    f['final_evaluation']={'contract_version':Q.VERSION,'scope':'final_published_pipeline','passed':True}
    assert Q.forecast(f)['confidence_score'] is None

def test_macro_guard_overrides_confirmation_without_changing_probabilities():
    f=fixture();f['p_up']=.8;f['event_signal_guard']=True
    out=Q.forecast(f)
    assert out['abstain'] and not out['quality']['trusted']
    assert out['p_up']==.8 and out['quality']['bias']=='neutral'

def test_distribution_keeps_scale_but_not_false_final_metrics():
    d={'status':'ok','quality_ok':True,'expected_abs_move_pct':2.1,
       'quantiles':{'q10_return_pct':-3,'q50_return_pct':.2,'q90_return_pct':4},
       'evaluation':{'coverage_80':.81,'effective_n':30}}
    out=Q.distribution(d)
    assert out['expected_abs_move_pct']==2.1 and out['quantiles']==d['quantiles']
    assert not out['quality_ok'] and 'coverage_80' not in out['evaluation']
    assert out['development_evaluation']==d['evaluation']
    assert Q.distribution(out)==out

def test_contract_is_idempotent_and_does_not_mutate_cached_objects():
    f=fixture();original=deepcopy(f);out=Q.forecast(f)
    assert f==original and Q.forecast(out)==out

def test_old_snapshot_cannot_restore_confidence():
    out=Q.snapshot({'assets':[{'unified_forecast_v39':{'10':fixture()}}]})
    assert out['assets'][0]['unified_forecast_v39']['10']['confidence_score'] is None

@pytest.mark.parametrize('side',[-1,1])
@pytest.mark.parametrize('magnitude',[.01,.49,.50,.99,1,2])
def test_percent_units_are_symmetric(side,magnitude):
    out={'conditional_p_up':.75 if side<0 else .25,'distribution_forecast':{'status':'ok','quality_ok':True,'q50_return_pct':side*magnitude,'evaluation':{'effective_n':20}}}
    assert R.consistency_gate(out)['action']==('shrink' if magnitude<1 else 'abstain')

def test_snapshot_routes_use_public_contract(monkeypatch):
    import api
    import json
    monkeypatch.setattr(api,'payload',lambda:Q.snapshot({'assets':[{'unified_forecast_v39':{'10':fixture()}}]}))
    assert json.loads(api.quality_snapshot_json().body)['quality_contract_version']==Q.VERSION
    script=api.quality_snapshot_js().body.decode()
    assert script.startswith('window.FORECASTS = ')
    assert '"confidence_score": null' in script
