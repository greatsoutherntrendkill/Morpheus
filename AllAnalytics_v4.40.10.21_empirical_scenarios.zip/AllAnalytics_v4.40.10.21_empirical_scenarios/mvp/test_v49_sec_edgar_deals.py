
from __future__ import annotations
from pathlib import Path
import io, zipfile, tempfile, os, json

ROOT=Path(__file__).parent

def make_master_zip():
    text="""Description: Master Index of EDGAR Dissemination Feed
Last Data Received: 2026-09-08
Comments: webmaster@sec.gov
CIK|Company Name|Form Type|Date Filed|Filename
--------------------------------------------------------------------------------
1001|ACME TARGET CORP|DEFM14A|2026-09-01|edgar/data/1001/0001001-26-000001.txt
1002|NOVA SYSTEMS INC|424B4|2026-09-02|edgar/data/1002/0001002-26-000002.txt
1003|OLDCO INC|424B4|2026-09-03|edgar/data/1003/0001003-26-000003.txt
1004|RANDOM REGISTRANT|S-4|2026-09-04|edgar/data/1004/0001004-26-000004.txt
1005|OTHER CO|10-K|2026-09-05|edgar/data/1005/0001005-26-000005.txt
"""
    bio=io.BytesIO()
    with zipfile.ZipFile(bio,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("master.idx",text)
    return bio.getvalue()

MNA=b"""
<SEC-DOCUMENT>
<html><body>
ACME TARGET CORP has entered into an AGREEMENT AND PLAN OF MERGER and will
merge with Big Buyer Inc. The transaction value is approximately $2.5 billion.
The merger consideration is $45.00 per share.
</body></html>
"""
IPO=b"""
<html><body>
This is an initial public offering of 10,000,000 shares of common stock.
The initial public offering price is $20.00 per share.
Our common stock has been approved for listing on Nasdaq under the symbol "NOVA".
</body></html>
"""
SECONDARY=b"""
<html><body>
This prospectus relates to the resale by selling stockholders of 5,000,000 shares.
The public offering price is $12.00 per share. This is not an initial public offering.
</body></html>
"""
NOT_MNA=b"""
<html><body>
This registration statement covers an exchange of securities and employee benefit plan.
No merger agreement, acquisition of a company, or business combination agreement is described.
</body></html>
"""

def main():
    import sec_edgar_deals_v49 as S

    with tempfile.TemporaryDirectory() as td:
        S.DB_PATH=Path(td)/"sec_deals_test.db"
        os.environ["SEC_USER_AGENT"]="AllAnalytics Research analyst@example.org"

        master=make_master_zip()
        original=S._get_bytes
        def fake_get(url,timeout=30):
            if url.endswith("master.zip"):
                return master
            if "0001001-26-000001" in url:return MNA
            if "0001002-26-000002" in url:return IPO
            if "0001003-26-000003" in url:return SECONDARY
            if "0001004-26-000004" in url:return NOT_MNA
            raise AssertionError(url)
        S._get_bytes=fake_get
        try:
            q=S.sync_quarter(2026,3)
            assert q["candidates"]==4

            m=S.list_events("mna","latest",limit=20,enrich=20)
            assert m["provider"]=="SEC EDGAR"
            assert len(m["rows"])==1
            md=m["rows"][0]
            assert md["verified"] is True
            assert md["company"]=="ACME TARGET CORP"
            assert abs(md["headline_value"]-2_500_000_000)<1
            assert abs(md["per_share"]-45)<.001
            assert "SEC EDGAR" in md["source"]

            ip=S.list_events("ipo","latest",limit=20,enrich=20)
            assert len(ip["rows"])==1, ip["rows"]
            d=ip["rows"][0]
            assert d["company"]=="NOVA SYSTEMS INC"
            assert d["ticker"]=="NOVA"
            assert d["exchange"]=="Nasdaq"
            assert abs(d["offer_price"]-20)<.001
            assert abs(d["shares_offered"]-10_000_000)<1
            assert abs(d["gross_proceeds"]-200_000_000)<1

            st=S.status()
            assert st["configured"] is True
            assert st["api_key_required"] is False
            assert st["indexed_quarters"]==1
        finally:
            S._get_bytes=original

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    for token in [
        "SEC EDGAR only","SEC EDGAR · нужен SEC_USER_AGENT",
        "/api/corpfin/transactions?kind=",
        "Открыть оригинал SEC",
    ]:
        assert token in html, token
    assert "Демо-данные ·" not in html
    assert "лицензированного deals API" not in html

    cf=(ROOT/"site"/"corpfin_data.js").read_text(encoding="utf-8")
    assert '"transactions":{"mna":[],"ipo":[]}' in cf

    api=(ROOT/"api.py").read_text(encoding="utf-8")
    assert "SEC49.list_events" in api
    assert '@app.get("/api/corpfin/transactions/{accession}")' in api

    env=(ROOT/".env.example").read_text(encoding="utf-8")
    assert "SEC_USER_AGENT=" in env

    print("OK: v4.9 SEC-only M&A/IPO, official-index discovery, IPO text verification, no demo rows")

if __name__=="__main__":
    main()
