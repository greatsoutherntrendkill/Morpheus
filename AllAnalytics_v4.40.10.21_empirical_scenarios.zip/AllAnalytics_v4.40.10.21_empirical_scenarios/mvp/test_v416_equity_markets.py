from pathlib import Path
import pandas as pd
import numpy as np

import market_universe_v416 as U
import equity_forecast_v416 as E
import market_data_v41 as M

ROOT=Path(__file__).parent
HTML=(ROOT/'site'/'index.html').read_text(encoding='utf-8')

assert len(U.US_EQUITIES) >= 16
assert len(U.RU_EQUITIES) >= 16
assert U.is_us_equity('AAPL')
assert U.is_ru_equity('SBER.ME')
assert U.moex_secid('GAZP.ME') == 'GAZP'

# Equity live path must be independent from full six-month history.
assert 'v4.16: 30-секундный контур акций' in Path(M.__file__).read_text(encoding='utf-8')
assert 'fetch_moex_security_snapshot' in Path(M.__file__).read_text(encoding='utf-8')
assert '_yahoo_live_meta' in Path(M.__file__).read_text(encoding='utf-8')

# UI: sectors, short metric labels, overflow-safe cards, model loader.
for token in ['Акции США','Акции Мосбиржи','Валютные пары','Металлы','Фьючерсы','loadEquityForecastSingle','loadEquityForecasts']:
    assert token in HTML
for token in ['<span>Активы</span>','<span>Live</span>','<span>Δ 1д</span>']:
    assert token in HTML
assert 'text-overflow:ellipsis' in HTML
assert 'overflow:hidden' in HTML

# Forecast pipeline: same modelling module, with a deterministic synthetic history.
idx=pd.date_range('2021-01-01',periods=850,freq='B')
rng=np.random.default_rng(11)
close=100*np.exp(np.cumsum(rng.normal(0,0.012,len(idx))))
df=pd.DataFrame({'date':idx,'open':close,'high':close*1.01,'low':close*.99,'close':close})
orig=E.MD41.fetch_history
try:
    E.MD41.fetch_history=lambda symbol,long_history=False: M.MarketResult(symbol,df,'synthetic',[])
    out=E.forecast('AAPL',(1,5,10,20),force=True)
finally:
    E.MD41.fetch_history=orig
assert out['status']=='ok'
assert set(out['forecasts'])=={'1','5','10','20'}
assert len(out['history'])==190
assert out['stats'].get('momentum_20d_pct') is not None
assert out['model'].startswith('AllAnalytics')
print('OK: v4.16 equity live pipeline, expanded universe, model forecasts and overflow-safe market UI')
