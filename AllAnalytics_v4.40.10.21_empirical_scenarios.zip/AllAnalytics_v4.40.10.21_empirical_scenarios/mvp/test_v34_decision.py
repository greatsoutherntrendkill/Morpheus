from pathlib import Path
import json, sqlite3, tempfile
import model_registry as MR

ROOT=Path(__file__).parent

def test_benchmark_snapshot():
    p=json.loads((ROOT/'site'/'model_benchmark_v34.json').read_text())
    assert p['version']=='3.4'
    assert len(p['scope']['symbols'])==33
    assert len(p['scope']['symbols']) * len(p['scope']['horizons']) == 132
    assert len(p['rows'])==132
    assert len(p['errors'])==0
    assert p['holdout_used_for_tuning'] is False
    assert p['automatic_promotion'] is False
    assert p['champion']=='logreg-v3.2.0'
    promo=p['promotion']['challengers']
    assert promo['lightgbm']['comparable_holdout_tests']==132
    assert promo['catboost']['comparable_holdout_tests']==132
    assert promo['lightgbm']['eligible_for_manual_promotion_review'] is False
    assert promo['catboost']['eligible_for_manual_promotion_review'] is False

def test_decision_immutable():
    with tempfile.TemporaryDirectory() as td:
        con=sqlite3.connect(Path(td)/'x.db'); MR.ensure_schema(con)
        did=MR.record_model_decision(con,'test','a','a','KEEP_CHAMPION',{'x':1},'test')
        assert did
        try:
            con.execute('update model_decisions set action="X" where decision_id=?',(did,))
            raise AssertionError('decision mutation not blocked')
        except sqlite3.DatabaseError:
            pass
        try:
            con.execute('delete from model_decisions where decision_id=?',(did,))
            raise AssertionError('decision delete not blocked')
        except sqlite3.DatabaseError:
            pass

if __name__=='__main__':
    test_benchmark_snapshot(); test_decision_immutable()
    print('OK: v3.4 full-universe decision + calibration diagnostics + immutable decision audit')
