"""AllAnalytics v4.40.4 — integrity-gated monthly macro + central-bank research outlook.

Purpose
-------
Produce a compact month-by-month research path through year-end for the US and
Russia, using only information available to the running AllAnalytics instance:

* current local macro snapshot (FRED/ALFRED current data after ``update.py``);
* current policy-rate snapshot and the structured central-bank calendar;
* live/last-good news flow as a small, bounded context adjustment;
* explicit fallback anchors when a provider is unavailable or the local DB is a
  demo/old snapshot.

This is deliberately a scenario-research layer, not a trained meeting-level
probability model and not a promise about an official future rate.  Until a
point-in-time meeting dataset is large enough for honest rolling validation, the
rate chart uses bounded scenario weights and exposes the modal decision for each
meeting. News/geopolitics can adjust the path, but the adjustment is capped so a
headline cannot overpower the macro state.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from pathlib import Path
import json
import math
import re
import sqlite3
import io
from typing import Iterable

import requests

import numpy as np
import pandas as pd

import config as C

VERSION = "4.40.3"  # API payload compatibility; see INTEGRITY_VERSION
INTEGRITY_VERSION = "4.40.10.10"
MODEL_LABEL = "Macro-Policy Scenario Research v4.40.4"
PROBABILITY_SEMANTICS = "scenario_weights_not_calibrated_probabilities"

# Public official anchors used only when the local data refresh is unavailable.
# They are intentionally explicit so the UI never mistakes a synthetic/demo
# database for a real current observation.
FALLBACK = {
    "US": {
        "pce_yoy": 3.7,            # BEA, July 2026 release
        "unemployment": 4.1,       # BLS, August 2026
        "gdp_2026": 2.2,           # June 2026 FOMC SEP median
        "policy_rate": 3.75,       # target upper bound; never the effective rate
        "target_lower": 3.50, "target_upper": 3.75,
        "target_as_of": "2026-07-29",
        "target_source": "ФРС, решение 29.07.2026 (резервный снимок)",
        "inflation_target": 2.0,
        "as_of": "2026-09-04",
    },
    "RU": {
        "cpi_yoy": 6.33,           # Rosstat, August 2026
        "unemployment": 2.2,       # CBR September 2026 macro survey
        "gdp_2026": 0.5,           # CBR September 2026 macro survey
        "policy_rate": 14.0,       # CBR decision 11 Sep 2026
        "inflation_target": 4.0,
        "as_of": "2026-09-11",
    },
}

# Known 2026 meeting dates act as a fallback if the structured calendar has not
# yet been refreshed.  The payload calendar always wins when a matching date is
# available.
MEETING_FALLBACK_2026 = {
    "US": ["2026-09-16", "2026-10-28", "2026-12-09"],
    "RU": ["2026-09-11", "2026-10-23", "2026-12-18"],
}

MONTH_RU = {
    1:"Янв",2:"Фев",3:"Мар",4:"Апр",5:"Май",6:"Июн",
    7:"Июл",8:"Авг",9:"Сен",10:"Окт",11:"Ноя",12:"Дек",
}


def _clip(v, lo, hi):
    try:
        return float(np.clip(float(v), lo, hi))
    except Exception:
        return float(lo)


def _sigmoid(x):
    x=_clip(x,-12,12)
    return 1.0/(1.0+math.exp(-x))


def _softmax(logits: dict[str,float]) -> dict[str,float]:
    if not logits:
        return {}
    mx=max(logits.values())
    vals={k:math.exp(_clip(v-mx,-30,30)) for k,v in logits.items()}
    s=sum(vals.values()) or 1.0
    raw={k:100.0*v/s for k,v in vals.items()}
    rounded={k:int(round(v)) for k,v in raw.items()}
    diff=100-sum(rounded.values())
    if diff:
        winner=max(raw,key=raw.get)
        rounded[winner]+=diff
    return rounded


def _month_starts(as_of: date) -> list[pd.Timestamp]:
    """Current month through December.  v4.40.3 is a year-end research view."""
    start=pd.Timestamp(as_of.year,as_of.month,1)
    end=pd.Timestamp(as_of.year,12,1)
    if start>end:
        return [start]
    return list(pd.date_range(start,end,freq="MS"))


def _month_meta(months: Iterable[pd.Timestamp]) -> list[dict]:
    out=[]
    for m in months:
        out.append({
            "id":m.strftime("%Y-%m"),
            "label":MONTH_RU.get(int(m.month),m.strftime("%b")),
            "full_label":f"{MONTH_RU.get(int(m.month),m.strftime('%b'))} {m.year}",
            "year":int(m.year),"month":int(m.month),
        })
    return out


def _db_con():
    try:
        return sqlite3.connect(str(C.DB_PATH))
    except Exception:
        return None


def _meta(con) -> dict:
    if con is None:return {}
    try:return dict(con.execute("SELECT key,value FROM meta").fetchall())
    except Exception:return {}


def _series(con, sid: str) -> pd.Series:
    if con is None:return pd.Series(dtype=float)
    try:
        d=pd.read_sql_query("SELECT date,value FROM macro WHERE series=? ORDER BY date",con,params=[sid])
        if d.empty:return pd.Series(dtype=float)
        d["date"]=pd.to_datetime(d["date"],errors="coerce")
        d["value"]=pd.to_numeric(d["value"],errors="coerce")
        d=d.dropna().drop_duplicates("date",keep="last")
        return pd.Series(d["value"].to_numpy(float),index=d["date"]).sort_index()
    except Exception:
        return pd.Series(dtype=float)


def _latest(s: pd.Series, lo: float, hi: float):
    if s is None or s.empty:return None
    v=float(s.iloc[-1])
    return v if math.isfinite(v) and lo<=v<=hi else None


def _yoy(s: pd.Series, lo: float=-20, hi: float=30):
    if s is None or len(s)<5:return None
    s=pd.Series(s,dtype=float).dropna().sort_index()
    if len(s)<2:return None
    last_date=pd.Timestamp(s.index[-1])
    target=last_date-pd.DateOffset(years=1)
    prev=s.loc[s.index<=target]
    if prev.empty:return None
    a=float(s.iloc[-1]);b=float(prev.iloc[-1])
    if not b:return None
    v=(a/b-1.0)*100.0
    return v if math.isfinite(v) and lo<=v<=hi else None


def _growth_yoy(s: pd.Series):
    return _yoy(s,-8,12)


def _current_rate(payload: dict, country: str, fallback: float):
    for r in payload.get("rates") or []:
        if str(r.get("country"))==country:
            try:
                v=float(r.get("rate"))
                if -1<=v<=50:return v
            except Exception:pass
    return float(fallback)


def _target_range(lower: pd.Series, upper: pd.Series):
    """Use two published bounds from the same date, never infer from EFFR."""
    pair=pd.concat([lower.rename("lower"),upper.rename("upper")],axis=1).dropna().sort_index()
    if pair.empty:return None
    pair=pair.loc[pair.index<=pd.Timestamp.now().normalize()]
    if pair.empty:return None
    row=pair.iloc[-1];lo=float(row["lower"]);hi=float(row["upper"])
    if not (math.isfinite(lo) and math.isfinite(hi) and 0<=lo<hi<=20):return None
    stamp=pair.index[-1].strftime("%Y-%m-%d")
    if stamp<FALLBACK["US"]["target_as_of"]:return None
    return {"target_lower":lo,"target_upper":hi,"target_as_of":stamp,
            "target_source":f"FRED · DFEDTARL / DFEDTARU · {stamp}"}


def add_ffr_corridor(row: dict, lower=None, upper=None) -> dict:
    """Legacy monthly values are explicitly upper bounds; retain their weights."""
    if row.get("region")!="US":return row
    if lower is None and "current_lower" in row:return row
    upper=float(row["current"] if upper is None else upper)
    width=float(FALLBACK["US"]["target_upper"]-FALLBACK["US"]["target_lower"]) if lower is None else upper-float(lower)
    def display(lo,hi):return f"{lo:.2f}–{hi:.2f}%".replace(".",",")
    row.update(rate_name="FFR · целевой коридор",current_lower=round(upper-width,3),
               current_upper=upper,corridor_width=round(width,3),current_display=display(upper-width,upper))
    for z in row.get("path",[]):
        hi=float(z["value"]);modal=float(z.get("modal_rate",hi))
        z.update(lower=round(hi-width,3),upper=hi,modal_lower=round(modal-width,3),modal_upper=modal,
                 display=display(hi-width,hi),modal_display=display(modal-width,modal))
    row["note"]="Границы целевого коридора FFR, а не интервал неопределённости. Ширина коридора сохраняется; обе границы меняются на одинаковое число базисных пунктов."
    return row


def _real_macro_snapshot(payload: dict) -> dict:
    """Use refreshed local macro data only when the DB carries live-mode metadata."""
    con=_db_con();meta=_meta(con)
    live_mode=(str(meta.get("macro_model_mode") or "").startswith("point_in_time") or str(meta.get("research_current_mode") or "") == "live_current")
    us=dict(FALLBACK["US"]);ru=dict(FALLBACK["RU"])
    source={"US":"official fallback","RU":"official fallback"}
    try:
        if live_mode:
            pce=_yoy(_series(con,"PCEPI"),0,12)
            un=_latest(_series(con,"UNRATE"),2,12)
            gdp=_growth_yoy(_series(con,"GDPC1"))
            rcpi=_yoy(_series(con,"RUSCPIALLMINMEI"),0,25)
            run=_latest(_series(con,"LRHUTTTTRUM156S"),1,10)
            pair=_target_range(_series(con,"DFEDTARL"),_series(con,"DFEDTARU"))
            if pair:
                us.update(pair)
                us["policy_rate"]=pair["target_upper"]
            cbr_live=_latest(_series(con,"CBR_KEYRATE"),0,40)
            if pce is not None:us["pce_yoy"]=pce
            if un is not None:us["unemployment"]=un
            if gdp is not None:us["gdp_2026"]=gdp
            if rcpi is not None:ru["cpi_yoy"]=rcpi
            if run is not None:ru["unemployment"]=run
            if cbr_live is not None:
                ru["policy_rate"]=cbr_live
            # There is no robust monthly real-Russia GDP series in the default
            # universe, so keep the transparent survey anchor for GDP.
            source={"US":"FRED current + official fallback","RU":"FRED/OECD current + CBR survey fallback"}
    finally:
        try:
            if con is not None:con.close()
        except Exception:pass
    # Curated snapshot is the fallback.  A live current series, when available,
    # has already overwritten policy_rate above.
    if not live_mode:
        ru["policy_rate"]=_current_rate(payload,"Россия",ru["policy_rate"])
    return {"US":us,"RU":ru,"source":source,"db_live":live_mode}


def _text(row: dict) -> str:
    return " ".join(str(row.get(k) or "") for k in ("title","summary","source","category","map_region","map_country")).lower()


def _news_signals(news: Iterable[dict]) -> dict:
    """Small bounded policy-context signal from recent headlines.

    The news layer is an adjustment only.  It cannot move a monthly macro path by
    more than a few tenths or force a large policy action on its own.
    """
    out={
        "US":{"hawk":0.0,"growth":0.0,"labor":0.0,"geo":0.0,"items":[]},
        "RU":{"hawk":0.0,"growth":0.0,"labor":0.0,"geo":0.0,"items":[]},
    }
    rows=list(news or [])[:80]
    for row in rows:
        t=_text(row)
        impact=_clip(row.get("impact_score") or row.get("relevance_score") or row.get("map_impact") or 30,1,100)/100.0
        is_geo=bool(re.search(r"санкц|war|войн|эскалац|геополит|middle east|ближн|иран|израил|пошлин|tariff|trade war",t))
        regions=[]
        if re.search(r"фрс|fomc|fed\b|сша|америк|united states|pce|payroll|nonfarm|wall street",t):regions.append("US")
        if re.search(r"банк россии|цб рф|росси|рубл|мосбирж|russia|инфляц",t):regions.append("RU")
        if is_geo and not regions:regions=["US","RU"]
        if not regions:continue
        for reg in set(regions):
            hawk=0.0;growth=0.0;labor=0.0
            if re.search(r"инфляц.*(ускор|выше)|price.*acceler|ppi.*(?:rise|jump)|pce.*(?:rise|above)|fuel|energy.*(?:rise|spike)|топлив|пошлин|tariff",t):hawk+=1
            if re.search(r"инфляц.*(замед|сниж)|disinfl|cooling inflation|price.*eas",t):hawk-=1
            if re.search(r"занятост.*силь|payroll.*(?:beat|strong|rise)|jobs.*strong|wage.*(?:rise|strong)|рынок труда.*устойчив",t):hawk+=.45;labor+=1
            if re.search(r"безработ.*рост|payroll.*(?:miss|weak)|jobs.*weak|рынок труда.*охлаж",t):hawk-=.35;labor-=1
            if re.search(r"gdp.*(?:strong|beat|grow)|рост.*эконом|спрос.*силь",t):growth+=1;hawk+=.2
            if re.search(r"recession|рецесс|gdp.*(?:weak|contract)|спад|слаб.*спрос",t):growth-=1;hawk-=.2
            if reg=="RU":
                if re.search(r"рубл.*(слаб|пад)|санкц|бюджет.*(?:расход|дефиц)|кредит.*(?:ускор|рост)",t):hawk+=.55
                if re.search(r"рубл.*укреп|кредит.*(?:замед|сжат)|спрос.*охлаж",t):hawk-=.35
            out[reg]["hawk"] += impact*hawk
            out[reg]["growth"] += impact*growth
            out[reg]["labor"] += impact*labor
            if is_geo:out[reg]["geo"] += impact
            if (abs(hawk)+abs(growth)+abs(labor)+(1 if is_geo else 0))>0 and len(out[reg]["items"])<5:
                out[reg]["items"].append({
                    "title":str(row.get("title") or "")[:150],
                    "impact":int(round(impact*100)),
                    "category":str(row.get("category") or ""),
                })
    # Normalize the headline stack: many similar headlines should not dominate.
    for reg in ("US","RU"):
        for k in ("hawk","growth","labor"):
            out[reg][k]=round(_clip(out[reg][k]/2.4,-1,1),4)
        out[reg]["geo"]=round(_clip(out[reg]["geo"]/2.0,0,1),4)
    return out


def _interp(current: float, target: float, n: int, curve: float=1.0) -> list[float]:
    if n<=1:return [float(current)]
    out=[]
    for i in range(n):
        t=i/(n-1)
        t=t**curve
        out.append(float(current+(target-current)*t))
    return out


def _macro_paths(snapshot: dict, signals: dict, months: list[pd.Timestamp]) -> list[dict]:
    n=len(months)
    us=snapshot["US"];ru=snapshot["RU"]
    ush=signals["US"];ruh=signals["RU"]

    # News is deliberately capped.  Official/observed macro remains the anchor.
    us_pce_target=_clip(us["pce_yoy"] + (2.9-us["pce_yoy"])*0.36 + .18*ush["hawk"] + .08*ush["geo"],2.2,5.5)
    us_un_target=_clip(us["unemployment"] + .12 - .07*ush["labor"] - .03*ush["growth"],3.4,5.4)
    us_gdp_target=_clip(us["gdp_2026"] - .08 + .16*ush["growth"] - .06*ush["geo"],.2,4.2)

    # CBR September baseline: 2026 Dec/Dec inflation 6.0–7.0%; survey median 6.6%.
    ru_cpi_target=_clip(6.6 + .28*ruh["hawk"] + .12*ruh["geo"],5.4,8.2)
    ru_un_target=_clip(ru["unemployment"] + .06 - .04*ruh["growth"],1.8,3.2)
    ru_gdp_target=_clip(ru["gdp_2026"] + .10*ruh["growth"] - .05*ruh["geo"],-.5,2.0)

    specs=[
        ("US","США","Инфляция PCE, г/г",us["pce_yoy"],us_pce_target,"%","inflation",[
            "Инфляция остаётся выше цели ФРС 2%.",
            "Траектория учитывает последние PCE/ценовые данные и новостной инфляционный сигнал.",
        ]),
        ("US","США","Безработица",us["unemployment"],us_un_target,"%","labor",[
            "Рынок труда остаётся важным ограничителем для решения ФРС.",
            "Рост безработицы усиливает пространство для смягчения; устойчивый найм — наоборот.",
        ]),
        ("US","США","Рост ВВП, 2026",us["gdp_2026"],us_gdp_target,"%","growth",[
            "Показатель — модельная оценка годового роста, обновляемая по активности и новостному фону.",
        ]),
        ("RU","Россия","Инфляция, г/г",ru["cpi_yoy"],ru_cpi_target,"%","inflation",[
            "Цель Банка России — 4%; текущая инфляция остаётся выше цели.",
            "В модель входят топливные, бюджетные, валютные и санкционные риски.",
        ]),
        ("RU","Россия","Безработица",ru["unemployment"],ru_un_target,"%","labor",[
            "Низкая безработица отражает напряжённый рынок труда и может поддерживать ценовое давление.",
        ]),
        ("RU","Россия","Рост ВВП, 2026",ru["gdp_2026"],ru_gdp_target,"%","growth",[
            "Базовый рост слабый; более слабый спрос увеличивает пространство для снижения ставки.",
        ]),
    ]
    rows=[]
    for reg,country,indicator,cur,target,unit,kind,base_factors in specs:
        vals=_interp(float(cur),float(target),n,curve=.88 if kind=="inflation" else 1.0)
        path=[]
        for i,(m,v) in enumerate(zip(months,vals)):
            path.append({
                "month":m.strftime("%Y-%m"),"label":MONTH_RU[int(m.month)],
                "value":round(v,3),"display":f"{v:.2f}%",
                "is_current":i==0,
            })
        sig=signals[reg]
        news_factor=(sig.get("items") or [{}])[0].get("title") if sig.get("items") else None
        factors=list(base_factors)
        if news_factor:factors.append(f"Новостной контекст: {news_factor}")
        rows.append({
            "region":reg,"country":country,"indicator":indicator,"kind":kind,
            "current":round(float(cur),3),"current_display":f"{float(cur):.2f}%",
            "path":path,"factors":factors[:3],
            "source":snapshot["source"].get(reg),
            "confidence":"умеренная" if snapshot.get("db_live") else "умеренная · fallback anchor",
        })
    return rows


def _meeting_dates(payload: dict, region: str, as_of: date) -> list[str]:
    cb="ФРС" if region=="US" else "Банк России"
    rows=[]
    for e in payload.get("events") or []:
        if str(e.get("cb"))!=cb:continue
        d=str(e.get("date") or "")[:10]
        try:
            if pd.Timestamp(d).date()>=as_of:rows.append(d)
        except Exception:pass
    # Merge fallback dates, de-duplicate, prefer the official corrected fallback
    # for the Fed December 2026 meeting if an old seed still says Dec 16.
    if as_of.year==2026:
        rows.extend(d for d in MEETING_FALLBACK_2026[region] if pd.Timestamp(d).date()>=as_of)
        if region=="US" and "2026-12-09" in rows:
            rows=[d for d in rows if d!="2026-12-16"]
    return sorted(set(rows))


def _macro_map(macros: list[dict], region: str, month: str) -> dict[str,float]:
    out={}
    for r in macros:
        if r.get("region")!=region:continue
        z=next((x for x in r.get("path") or [] if x.get("month")==month),None)
        if z:out[r.get("kind")]=float(z.get("value"))
    return out


def _rate_probs(region: str, macro: dict, rate: float, signal: dict) -> tuple[dict,int,float]:
    """Return bounded scenario weights, modal bp step, diagnostic score.

    These weights are deliberately *not* described as calibrated probabilities.
    A trained meeting-level classifier remains gated until a sufficient PIT
    historical meeting matrix can be validated honestly.
    """
    if region=="US":
        infl=float(macro.get("inflation",3.5));un=float(macro.get("labor",4.2));growth=float(macro.get("growth",2.0))
        score=(.56*((infl-2.0)/1.8)+.18*((4.2-un)/.8)+.10*((growth-2.0)/1.6)
               +.12*float(signal.get("hawk") or 0)+.04*float(signal.get("geo") or 0))
        score=_clip(score,-1.6,1.6)
        probs=_softmax({
            "hike":2.0*(score-.72),
            "hold":1.45-.45*abs(score-.18),
            "cut":2.0*(-score-.55),
        })
        action=max(probs,key=probs.get)
        step={"hike":25,"hold":0,"cut":-25}[action]
        return probs,step,score

    infl=float(macro.get("inflation",6.4));un=float(macro.get("labor",2.2));growth=float(macro.get("growth",.5))
    # A very restrictive real rate creates room to ease, while inflation, labour
    # tightness and geopolitical/fiscal pressure push in the opposite direction.
    real_restrict=(rate-infl)-4.0
    ease=(.42*(real_restrict/3.5)+.18*((1.2-growth)/1.5)+.08*((un-2.2)/.8)
          -.28*((infl-4.0)/3.0)-.18*float(signal.get("hawk") or 0)-.06*float(signal.get("geo") or 0))
    ease=_clip(ease,-1.6,1.6)
    probs=_softmax({
        "cut":2.35*(ease-.04),
        "hold":1.18-.35*abs(ease-.08),
        "hike":2.35*(-ease-.62),
    })
    action=max(probs,key=probs.get)
    step={"hike":25,"hold":0,"cut":-50}[action]
    return probs,step,ease


def _factor_lines(region: str, macro: dict, signal: dict, rate: float, probs: dict, meeting: str|None) -> list[dict]:
    if region=="US":
        infl=macro.get("inflation");un=macro.get("labor");g=macro.get("growth")
        rows=[
            {"label":"Инфляция","text":f"PCE ~{infl:.2f}% против цели 2% — аргумент за осторожность ФРС.","direction":"hawk" if infl>2.5 else "dove"},
            {"label":"Рынок труда","text":f"Безработица ~{un:.2f}% — {'рынок остаётся плотным' if un<4.2 else 'охлаждение постепенно усиливается'}.","direction":"hawk" if un<4.2 else "dove"},
            {"label":"Рост","text":f"Рост ВВП ~{g:.2f}% — {'не требует срочного смягчения' if g>=1.8 else 'повышает риск замедления'}.","direction":"neutral"},
        ]
    else:
        infl=macro.get("inflation");un=macro.get("labor");g=macro.get("growth")
        rows=[
            {"label":"Инфляция","text":f"Инфляция ~{infl:.2f}% против цели 4% — снижение ставки требует подтверждения дезинфляции.","direction":"hawk"},
            {"label":"Жёсткость ДКП","text":f"Ставка {rate:.2f}% заметно выше инфляции — сохраняется пространство для осторожного смягчения.","direction":"dove"},
            {"label":"Экономика","text":f"Рост ВВП ~{g:.2f}%, безработица ~{un:.2f}% — слабый рост спорит с напряжённым рынком труда.","direction":"neutral"},
        ]
    if signal.get("geo",0)>.12:
        rows.append({"label":"Геополитика","text":"Повышенный геополитический/торговый риск увеличивает неопределённость и инфляционную премию.","direction":"hawk"})
    if signal.get("items"):
        rows.append({"label":"Новости","text":str(signal["items"][0].get("title") or "")[:170],"direction":"neutral"})
    if meeting:
        likely=max(probs,key=probs.get)
        ru={"hike":"повышение","hold":"сохранение","cut":"снижение"}[likely]
        rows.append({"label":"Заседание","text":f"{meeting}: базовый сценарий — {ru} ({probs[likely]}%).","direction":"neutral"})
    return rows[:5]


def _rate_paths(payload: dict, snapshot: dict, signals: dict, months: list[pd.Timestamp], macros: list[dict], as_of: date) -> list[dict]:
    rows=[]
    for reg,country,name in (("US","США","Ставка ФРС"),("RU","Россия","Ключевая ставка")):
        cur=float(snapshot[reg]["policy_rate"])
        meetings=_meeting_dates(payload,reg,as_of)
        path=[];running=cur
        for i,m in enumerate(months):
            mid=m.strftime("%Y-%m")
            macro=_macro_map(macros,reg,mid)
            month_meetings=[d for d in meetings if d.startswith(mid)]
            meeting=month_meetings[-1] if month_meetings else None
            if meeting:
                probs,modal_bp,score=_rate_probs(reg,macro,running,signals[reg])
                if reg=="US":
                    expected_bp=25.0*((probs.get("hike",0)-probs.get("cut",0))/100.0)
                else:
                    expected_bp=(25.0*probs.get("hike",0)-50.0*probs.get("cut",0))/100.0
                expected=running+expected_bp/100.0
                # Quantize the probability mean lightly for a readable research chart,
                # while retaining exact scenario weights in the point payload.
                expected=round(expected*20)/20.0
                modal_rate=running+modal_bp/100.0
                factors=_factor_lines(reg,macro,signals[reg],running,probs,meeting)
                path.append({
                    "month":mid,"label":MONTH_RU[int(m.month)],"value":round(expected,3),
                    "display":f"{expected:.2f}%","meeting":meeting,
                    "probabilities":probs,"modal_bp":modal_bp,"modal_rate":round(modal_rate,3),
                    "modal_display":f"{modal_rate:.2f}%","score":round(float(score),4),
                    "factors":factors,
                })
                # The next month starts from the modal policy decision, not from the
                # fractional probability mean. This keeps the path economically coherent.
                running=max(-.5,modal_rate)
            else:
                probs={"hike":0,"hold":100,"cut":0}
                factors=_factor_lines(reg,macro,signals[reg],running,probs,None)
                path.append({
                    "month":mid,"label":MONTH_RU[int(m.month)],"value":round(running,3),
                    "display":f"{running:.2f}%","meeting":None,"probabilities":probs,
                    "modal_bp":0,"modal_rate":round(running,3),"modal_display":f"{running:.2f}%",
                    "score":None,"factors":factors,
                })
        rows.append({
            "region":reg,"country":country,"rate_name":name,"current":cur,
            "current_display":f"{cur:.2f}%","path":path,"meetings":meetings,
            "source":snapshot["source"].get(reg),
            "note":"Линия — взвешенное среднее исследовательских сценариев; веса сценариев не являются статистически откалиброванными вероятностями.",
        })
    us=rows[0]
    add_ffr_corridor(us,snapshot["US"].get("target_lower",us["current"]-.25),snapshot["US"].get("target_upper",us["current"]))
    us["source"]=snapshot["US"].get("target_source",us["source"])
    us["target_as_of"]=snapshot["US"].get("target_as_of")
    return rows


def _meeting_model_status() -> dict:
    """Readiness of a future trained Fed/CBR meeting classifier.

    v4.40.4 refuses to fabricate a training sample from today's revised macro
    values.  We only count locally archived, resolved policy meetings here; a
    separate PIT feature matrix is still required before activation.
    """
    counts={"fed_rate":0,"cbr_rate":0,"ecb_rate":0}
    try:
        import event_response_v439 as ER439
        for e in ER439.sync_event_archive(persist=False):
            t=str(e.get("type") or "")
            if t in counts and bool(e.get("surprise_known")):
                counts[t]+=1
    except Exception:
        pass
    minimum=40
    enough_counts=counts.get("fed_rate",0)>=minimum and counts.get("cbr_rate",0)>=minimum
    try:
        import policy_meeting_evidence_v4404 as PME4404
        evidence=PME4404.status()
    except Exception:
        evidence={"snapshots":0,"settled":0,"pending":0}
    return {
        "active":False,
        "status":"collecting_pit_meeting_evidence",
        "minimum_resolved_meetings_per_bank":minimum,
        "resolved_event_archive_counts":counts,
        "persistent_meeting_evidence":evidence,
        "counts_sufficient":bool(enough_counts),
        "pit_feature_matrix_ready":False,
        "reason":"Нужна отдельная point-in-time матрица макро- и рыночных признаков до каждого заседания; текущие пересмотренные значения нельзя честно переносить назад в историю. v4.40.4 начинает собирать такие pre-meeting snapshots автоматически.",
    }


def build(payload: dict, *, as_of: date|str|None=None, news: Iterable[dict]|None=None) -> dict:
    if as_of is None:as_of=date.today()
    if isinstance(as_of,str):as_of=pd.Timestamp(as_of).date()
    months=_month_starts(as_of)
    snapshot=_real_macro_snapshot(payload)
    rows_news=list(news) if news is not None else list(payload.get("news") or [])
    signals=_news_signals(rows_news)
    macros=_macro_paths(snapshot,signals,months)
    rates=_rate_paths(payload,snapshot,signals,months,macros,as_of)
    return {
        "version":VERSION,"integrity_version":INTEGRITY_VERSION,"model":MODEL_LABEL,
        "generated_at":datetime.now(timezone.utc).isoformat(),
        "as_of":str(as_of),"year":int(as_of.year),
        "months":_month_meta(months),"macro":macros,"rates":rates,
        "signals":signals,
        "probability_semantics":PROBABILITY_SEMANTICS,
        "scenario_weights_calibrated":False,
        "trained_meeting_model":_meeting_model_status(),
        "input_status":{
            "macro_db_live":bool(snapshot.get("db_live")),
            "macro_source_us":snapshot["source"].get("US"),
            "macro_source_ru":snapshot["source"].get("RU"),
            "news_items":len(rows_news),
        },
        "method_note":(
            "Помесячная исследовательская траектория: текущие макро-данные → ограниченная сценарная экстраполяция → "
            "контекст заседаний → capped news/geopolitical adjustment. Ставка на графике — взвешенное среднее сценариев; "
            "веса сценариев пока не являются статистически откалиброванными вероятностями. Рядом показывается базовое дискретное решение."
        ),
        "refresh_seconds":300,
    }


def _fetch_fred_public_csv(series_id: str, start: str = "2015-01-01") -> pd.DataFrame:
    """Keyless current-series fallback using FRED's public graph CSV endpoint.

    This is only for the live research snapshot. It is never written to the
    revision-aware ALFRED/PIT tables used by model validation.
    """
    try:
        r=requests.get(
            "https://fred.stlouisfed.org/graph/fredgraph.csv",
            params={"id":series_id,"cosd":str(start)},
            timeout=8,
            headers={"User-Agent":"AllAnalytics/4.40.4 research"},
        )
        r.raise_for_status()
        d=pd.read_csv(io.StringIO(r.text))
        if d.empty or len(d.columns)<2:return pd.DataFrame(columns=["date","value"])
        date_col=d.columns[0]; value_col=series_id if series_id in d.columns else d.columns[1]
        out=pd.DataFrame({"date":pd.to_datetime(d[date_col],errors="coerce"),"value":pd.to_numeric(d[value_col],errors="coerce")}).dropna()
        return out[out["date"]>=pd.Timestamp(start)].sort_values("date")
    except Exception:
        return pd.DataFrame(columns=["date","value"])


def refresh_current_inputs() -> dict:
    """Refresh only the *current-state* research inputs.

    This deliberately does not mutate ALFRED/PIT training history.  It is a
    lightweight operational refresh for the research page, normally scheduled
    no more than once every six hours by the API.
    """
    status={"fred":"skipped","cbr":"skipped","updated":[]}
    try:
        from dotenv import load_dotenv
        load_dotenv()
        import os
        import sources as S
        import db
        key=os.getenv("FRED_API_KEY","").strip()
        con=db.connect()
        try:
            series=("DFEDTARL","DFEDTARU","FEDFUNDS","PCEPI","UNRATE","GDPC1","RUSCPIALLMINMEI","LRHUTTTTRUM156S")
            used_public=False
            for sid in series:
                try:
                    df=S.fetch_fred(sid,key,C.FRED_START) if key else _fetch_fred_public_csv(sid,C.FRED_START)
                    if df is not None and not df.empty:
                        db.replace_macro(con,sid,df)
                        status["updated"].append(sid)
                        used_public=used_public or not bool(key)
                except Exception:
                    pass
            if status["updated"]:
                status["fred"]="public_csv" if used_public else "ok"
                # Current-state refresh must not pretend to be ALFRED/PIT history.
                db.set_meta(con,"research_current_mode","live_current")
                db.stamp(con,"research_macro_updated_v4404")
            else:
                status["fred"]="no_update" if key else "public_unavailable"
            try:
                kr=S.fetch_cbr_key_rate_series(C.FRED_START)
                if kr is not None and not kr.empty:
                    db.replace_macro(con,C.CBR_KEYRATE_SERIES,kr)
                    status["updated"].append(C.CBR_KEYRATE_SERIES)
                    status["cbr"]="ok"
            except Exception:
                status["cbr"]="error"
        finally:
            con.close()
    except Exception as exc:
        status["error"]=type(exc).__name__
    return status


def persist_last_good(result: dict, path: str|Path|None=None):
    try:
        if path is None:
            root=Path.home()/"AllAnalytics_Data"/"research"
            path=root/"monthly_outlook_v4404.json"
        p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
        tmp=p.with_suffix(p.suffix+".tmp")
        tmp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
        tmp.replace(p)
        return str(p)
    except Exception:
        return None


def load_last_good(path: str|Path|None=None):
    try:
        if path:
            candidates=[Path(path)]
        else:
            root=Path.home()/"AllAnalytics_Data"/"research"
            candidates=[root/"monthly_outlook_v4404.json",root/"monthly_outlook_v4403.json"]
        for p in candidates:
            if p.exists():
                result=json.loads(p.read_text(encoding="utf-8"))
                for row in result.get("rates",[]):add_ffr_corridor(row)
                return result
    except Exception:pass
    return None
