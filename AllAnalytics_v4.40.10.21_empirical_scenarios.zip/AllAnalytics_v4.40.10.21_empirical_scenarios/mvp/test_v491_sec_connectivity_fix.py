
from __future__ import annotations
from pathlib import Path
import os
import sec_edgar_deals_v49 as S

def main():
    os.environ["SEC_USER_AGENT"]="AllAnalytics Research crazycrazydancer27@gmail.com"
    assert S.configured() is True
    h=S._headers()
    assert h["User-Agent"].endswith("@gmail.com")
    assert "Host" not in h
    assert S.MAX_RPS < 10
    api=(Path(__file__).parent/"api.py").read_text(encoding="utf-8")
    assert "/api/corpfin/sec-diagnostic" in api
    html=(Path(__file__).parent/"site"/"index.html").read_text(encoding="utf-8")
    assert "Проблема в сетевом запросе к SEC" in html
    print("OK: SEC email accepted; robust HTTP client/diagnostics enabled")
if __name__=="__main__":
    main()
