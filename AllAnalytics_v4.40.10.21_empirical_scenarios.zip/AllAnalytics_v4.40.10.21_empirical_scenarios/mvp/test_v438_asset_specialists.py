import math
import numpy as np
import pandas as pd

import asset_specialists_v438 as SP
import prospective_selection_v438 as SEL


def _close(n=520, seed=438):
    rng=np.random.default_rng(seed)
    r=0.00025+0.011*rng.standard_normal(n)
    p=100*np.exp(np.cumsum(r))
    return pd.Series(p,index=pd.date_range('2024-01-02',periods=n,freq='B'))


def test_asset_class_specs_are_distinct():
    assert SP.SPECS['equity'].feature_names != SP.SPECS['fx'].feature_names
    assert 'universe_rank_20' in SP.SPECS['equity'].feature_names
    assert 'dxy_ret_20' in SP.SPECS['commodity'].feature_names
    assert 'crypto_breadth_20' in SP.SPECS['crypto'].feature_names


def test_target_contains_neutral_state():
    s=_close(420)
    y,neutral,fut,band=SP._target(s,10)
    assert len(y)==len(s)
    assert neutral.sum()>0
    significant=y.isin([0.0,1.0]).sum()
    assert significant>50
    assert (band.dropna()>0).all()


def test_equity_cross_section_ignores_user_populated_forecast_cache(monkeypatch):
    own=_close(160)
    idx=own.index
    peers=pd.DataFrame({
        'MSFT':110*np.exp(np.cumsum(np.full(len(idx),.0004))),
        'NVDA':90*np.exp(np.cumsum(np.full(len(idx),.0007))),
        'AVGO':80*np.exp(np.cumsum(np.full(len(idx),.0002))),
    },index=idx)
    monkeypatch.setattr(SP,'_cached_equity_matrix',lambda:peers)
    monkeypatch.setattr(SP,'_db_matrix',lambda:pd.DataFrame(index=idx))
    profile=SP.FE434.asset_profile('AAPL')
    X,diag=SP._build_features(own,'AAPL',profile)
    assert diag['equity_peer_count']==0
    assert X['universe_rank_20'].notna().sum()==0
    # No fabricated sector peers: only cached real histories count.
    assert diag['sector_peer_count']==0


def test_specialist_guard_starts_at_zero_weight(monkeypatch):
    report={'eligible_for_human_review':False,'reason':'not enough data','report_hash':'x'}
    monkeypatch.setattr(SEL,'specialist_report',lambda **kwargs:report)
    monkeypatch.setattr(SEL.BASE437.REVIEW,'latest',lambda *args,**kwargs:None)
    SEL._CACHE.clear()
    g=SEL.specialist_gate('AAPL',10,max_live_weight=.16,cache_seconds=0)
    assert g['active'] is False
    assert g['weight']==0.0
    assert g['automatic_promotion'] is False


def test_wrapper_logs_specialist_but_does_not_blend_without_guard(monkeypatch):
    base={
        'version':'core','p_up':.61,'p_down':.39,'signal_threshold':.58,'abstain':False,
        'signal_strength':'слабый','regime':'trend_up|normal_vol','components':[{'name':'production','p_up':.60}],
        'reliability':{'probability':.62},'validation':{},'scorecard':{},
    }
    monkeypatch.setattr(SP.CORE437,'forecast_horizon',lambda *a,**k:dict(base))
    monkeypatch.setattr(SP,'specialist_forecast',lambda *a,**k:{
        'p_up':.72,'quality_ok':True,'max_live_weight':.16,'asset_class':'equity','route':'equity:US:test',
        'development_metrics':{'brier_skill':4.0},'feature_coverage':.9,
    })
    monkeypatch.setattr(SP.SEL438,'specialist_gate',lambda *a,**k:{'active':False,'eligible':False,'human_approved':False,'weight':0.0})
    out=SP.forecast_horizon(_close(420),'AAPL',10)
    assert math.isclose(out['p_up'],.61,abs_tol=1e-9)
    comp=[x for x in out['components'] if x['name']=='asset_specialist'][0]
    assert comp['p_up']==.72
    assert comp['weight']==0.0
    assert out['specialist_weight_status']=='challenger_only_pending_guard'


def test_wrapper_allows_only_guarded_bounded_blend(monkeypatch):
    base={
        'version':'core','p_up':.60,'p_down':.40,'signal_threshold':.56,'abstain':False,
        'signal_strength':'слабый','regime':'trend_up|normal_vol','components':[],
        'reliability':{'probability':.65},'validation':{},'scorecard':{},
    }
    monkeypatch.setattr(SP.CORE437,'forecast_horizon',lambda *a,**k:dict(base))
    monkeypatch.setattr(SP,'specialist_forecast',lambda *a,**k:{
        'p_up':.70,'quality_ok':True,'max_live_weight':.16,'asset_class':'equity','route':'equity:US:test',
        'development_metrics':{'brier_skill':5.0},'feature_coverage':.9,
    })
    monkeypatch.setattr(SP.SEL438,'specialist_gate',lambda *a,**k:{'active':True,'eligible':True,'human_approved':True,'weight':.16})
    out=SP.forecast_horizon(_close(420),'AAPL',10)
    assert .60 < out['p_up'] < .70
    assert abs(out['p_up']-(.84*.60+.16*.70))<1e-6
    assert out['validation']['automatic_promotion'] is False
