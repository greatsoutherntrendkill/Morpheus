"""AllAnalytics v4.16 — расширенный equity universe для экрана «Рынки».

Список намеренно ограничен ликвидными крупными бумагами: интерфейс остаётся
простым, а 30-секундный quote loop не превращается в сотни внешних запросов.
"""
from __future__ import annotations

US_EQUITIES = [
    ("AAPL", "Apple Inc."),
    ("MSFT", "Microsoft Corp."),
    ("NVDA", "NVIDIA Corp."),
    ("AMZN", "Amazon.com Inc."),
    ("GOOGL", "Alphabet Class A"),
    ("META", "Meta Platforms"),
    ("BRK-B", "Berkshire Hathaway B"),
    ("JPM", "JPMorgan Chase"),
    ("V", "Visa"),
    ("MA", "Mastercard"),
    ("TSLA", "Tesla"),
    ("AVGO", "Broadcom"),
    ("WMT", "Walmart"),
    ("XOM", "Exxon Mobil"),
    ("COST", "Costco Wholesale"),
    ("NFLX", "Netflix"),
]

RU_EQUITIES = [
    ("SBER.ME", "Сбербанк"),
    ("GAZP.ME", "Газпром"),
    ("LKOH.ME", "ЛУКОЙЛ"),
    ("ROSN.ME", "Роснефть"),
    ("NVTK.ME", "НОВАТЭК"),
    ("GMKN.ME", "Норникель"),
    ("TATN.ME", "Татнефть"),
    ("YDEX.ME", "Яндекс"),
    ("OZON.ME", "Ozon"),
    ("MOEX.ME", "Московская биржа"),
    ("MTSS.ME", "МТС"),
    ("ALRS.ME", "АЛРОСА"),
    ("CHMF.ME", "Северсталь"),
    ("NLMK.ME", "НЛМК"),
    ("PLZL.ME", "Полюс"),
    ("PHOR.ME", "ФосАгро"),
]

EXTRA_MARKET_ASSETS = [
    *({"symbol": s, "name": n, "category": "Акции США", "market": "US"} for s, n in US_EQUITIES),
    *({"symbol": s, "name": n, "category": "Акции Мосбиржи", "market": "RU"} for s, n in RU_EQUITIES),
]

US_SYMBOLS = {s for s, _ in US_EQUITIES}
RU_SYMBOLS = {s for s, _ in RU_EQUITIES}


def is_us_equity(symbol: str) -> bool:
    return str(symbol or "").upper() in US_SYMBOLS


def is_ru_equity(symbol: str) -> bool:
    return str(symbol or "").upper() in RU_SYMBOLS


def moex_secid(symbol: str) -> str:
    s = str(symbol or "").upper()
    return s[:-3] if s.endswith(".ME") else s
