from pathlib import Path

ROOT=Path(__file__).resolve().parent
HTML=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
PYCODE=(ROOT/'equity_forecast_v416.py').read_text(encoding='utf-8')

def test_unified_falls_back_to_model_horizons():
    assert 'x.model_horizons' in HTML
    assert 'x.live_market_forecasts' in HTML

def test_all_market_sectors_are_forecastable():
    for label in ['Крипто','Фьючерсы','Валютные пары','Металлы','Энергия и сырьё','Индексы']:
        assert label in HTML
    assert 'isForecastableMarketAsset' in HTML

def test_general_market_endpoint_is_used():
    assert '/api/markets/forecast?symbol=' in HTML
    assert 'fetchGeneralMarketForecast' in HTML

def test_market_cards_have_clear_states():
    for text in ['Рассчитываем прогноз…','Исследовательская оценка','Подтверждён','Нет данных · повторим позже']:
        assert text in HTML

def test_browser_forecast_cache_is_versioned():
    assert 'aa-market-forecast-v4.40.10.16' in HTML
    assert 'MARKET_FORECAST_BROWSER_TTL' in HTML

def test_model_metadata_no_longer_claims_v4408_as_current():
    assert 'AllAnalytics Fast WF · v4.40.10.16 Quality Contract' in PYCODE
    assert 'AllAnalytics Fast WF · v4.40.8 Data-Driven Routing' not in PYCODE
