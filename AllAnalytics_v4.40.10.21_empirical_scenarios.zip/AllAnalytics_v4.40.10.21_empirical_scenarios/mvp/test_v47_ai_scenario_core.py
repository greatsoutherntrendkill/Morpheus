
from __future__ import annotations
from pathlib import Path
import json

ROOT=Path(__file__).parent

def main():
    import scenario_ai_core_v47 as CORE
    import scenario_contract_v47 as CONTRACT

    data=json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))
    caps=CORE.CORE.capabilities()
    assert caps["version"]=="4.7"
    assert caps["mode"]=="local"
    assert caps["external_ai_connected"] is False
    assert caps["provider_slot"]["planned_version"]=="4.8"

    parsed=CORE.CORE.parser.parse(
        "Что будет с нефтью, если завтра начнётся война в районе Ормузского пролива?"
    )
    norm=CONTRACT.normalize_intent(parsed)
    assert norm["conditions"]
    assert norm["conditions"][0]["event_type"] in {"военная эскалация","энергетический шок"}
    assert "CL=F" in norm["conditions"][0]["assets"]
    assert norm["parser"]=="local-v4.7"

    result=CORE.CORE.analyze(
        data,
        "Что будет с Биткоином, если Сатоши переведёт крупный объём BTC на биржу?"
    )
    assert result["core"]["version"]=="4.7"
    assert result["answer_style"]=="simple-analytical-v4.7"
    assert result["headline"]["label"] in {"Скорее рост","Скорее падение","Скорее высокая волатильность"}
    assert result["simple_answer"]["what_changes_forecast"]
    assert result["simple_answer"]["related_assets"]
    assert result["scenario_intent"]["conditions"]

    follow=CORE.CORE.analyze(
        data,
        "А если он ещё и продаст часть этих монет?",
        result["combined_question"],
    )
    assert len(follow["combined_question"])>len(result["combined_question"])

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    for token in [
        "Умный разбор AllAnalytics",
        "локальный режим v4.7",
        "Что может изменить прогноз",
        "Связанные рынки",
        "Показать детали анализа",
        "Архитектура v4.7 готова к следующему шагу",
        "/api/scenario/analyze",
    ]:
        assert token in html, token
    assert "OpenAI API не подключён" not in html  # UI phrasing stays provider-neutral/simple

    api=(ROOT/"api.py").read_text(encoding="utf-8")
    assert '@app.get("/api/scenario/capabilities")' in api
    assert "SC47.CORE.analyze" in api

    roadmap=(ROOT/"SCENARIO_ROADMAP.md").read_text(encoding="utf-8")
    for v in ["v4.7","v4.8","v4.9","v5.0","v5.1"]:
        assert v in roadmap

    print("OK: v4.7 ScenarioIntent + provider slot + simple presenter + follow-up + future architecture")

if __name__=="__main__":
    main()
