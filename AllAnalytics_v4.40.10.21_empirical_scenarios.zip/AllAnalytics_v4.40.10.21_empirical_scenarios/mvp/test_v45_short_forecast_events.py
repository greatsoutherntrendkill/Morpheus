
from __future__ import annotations
from pathlib import Path
import pandas as pd
import numpy as np

ROOT=Path(__file__).parent

def leg(base,step=0.01,n=120):
    t=pd.date_range("2026-05-12",periods=n,freq="D")
    rows=[]
    for i,d in enumerate(t):
        c=base+i*step
        rows.append({"date":d,"open":c-.03,"high":c+.08,"low":c-.09,"close":c})
    return pd.DataFrame(rows)

def intraday(up=True,n=240):
    t=pd.date_range("2026-09-07 09:30",periods=n,freq="5min")
    rows=[]
    for i,d in enumerate(t):
        drift=(i*.015 if up else -i*.015)
        c=100+drift+np.sin(i/8)*.15
        rows.append({"date":d,"open":c-.04,"high":c+.12,"low":c-.11,"close":c})
    return pd.DataFrame(rows)

def main():
    import market_data_v41 as D
    import short_forecast_v45 as S

    # CNY/RUB: direct pair unavailable -> real OHLC cross from USD legs,
    # not the flat CBR fixing.
    old_yahoo=D.yahoo_chart
    try:
        def fake_yahoo(symbol,*args,**kwargs):
            if symbol=="CNYRUB=X":
                return D._empty(),"",["direct unavailable"]
            if symbol=="RUB=X":
                return leg(80,0.05),"Yahoo RUB",[]
            if symbol=="CNY=X":
                return leg(7.1,0.001),"Yahoo CNY",[]
            return D._empty(),"",[]
        D.yahoo_chart=fake_yahoo
        r=D.fetch_history("CNYRUB",long_history=False)
        assert r.source=="расчёт USD/RUB ÷ USD/CNY"
        assert len(r.frame)>50
        assert (r.frame["high"]-r.frame["low"]).median()>0.01
        assert (r.frame["close"]-r.frame["open"]).abs().median()>0
    finally:
        D.yahoo_chart=old_yahoo

    # Short-term forecast changes direction with intraday market structure.
    old_fetch=S.MD43.fetch_intraday
    try:
        asset={"drivers":[{"label":"Δ ставки ФРС 3м","contribution":0.1}]}
        S.MD43.fetch_intraday=lambda *a,**k:D.MarketResult("^GSPC",intraday(True),"test 5m",[])
        up=S.forecast("^GSPC","1h",asset)
        assert up["status"]=="ok" and up["p_up"]>.5
        assert up["target"]>float(intraday(True).iloc[-1]["close"])
        assert up["reason_type"] in {"технический","макро","смешанный"}

        S.MD43.fetch_intraday=lambda *a,**k:D.MarketResult("^GSPC",intraday(False),"test 5m",[])
        dn=S.forecast("^GSPC","2h",asset)
        assert dn["status"]=="ok" and dn["p_up"]<.5
    finally:
        S.MD43.fetch_intraday=old_fetch

    index=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    for token in ["30м","1ч","2ч","4ч","overview-asset-events","Что происходило в периоде",
                  "/api/forecast/short","loadOverviewShortForecast"]:
        assert token in index, token

    lab=(ROOT/"site"/"technical_lab_v45.html").read_text(encoding="utf-8")
    assert 'id="short-forecast-horizon"' in lab
    assert "loadShortForecast" in lab
    assert "официальный фиксинг · линия" in lab

    api=(ROOT/"api.py").read_text(encoding="utf-8")
    assert '@app.get("/api/forecast/short")' in api
    assert "SF45.forecast" in api

    print("OK: v4.5 CNY/RUB OHLC fix + period events + 30m–4h short forecast")

if __name__=="__main__":
    main()
