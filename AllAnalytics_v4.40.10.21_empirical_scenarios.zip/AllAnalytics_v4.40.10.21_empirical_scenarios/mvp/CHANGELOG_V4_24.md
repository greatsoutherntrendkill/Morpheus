# AllAnalytics v4.24 — Forecast Data Pipeline Rebuild

## What was actually broken

1. The fast Russian-equity forecast was single-homed to MOEX history. If MOEX history failed while MOEX live quotes still worked, every stock card returned `unavailable`.
2. The fast path requested only ~3–5 months of data (about 60–100 sessions). The real AllAnalytics walk-forward model needs roughly 390+ closes because its feature set contains MA200 plus a purged OOS window. Therefore the real model could not run on that history by design.
3. Russian cards were silently falling back to `scenario_paths()`, even though `models.py` explicitly describes that block-bootstrap routine as a scenario distribution, not the forecast model.
4. Unit tests mocked history frames and therefore never validated the real network/provider contract. Green tests did not prove production history delivery.
5. There was no independent long-history provider in the UI-critical Russian forecast path, and no dedicated persistent 3-year equity-history cache.

## v4.24 architecture

Live price remains MOEX ISS. Forecast history is resolved independently:

1. 24h local equity-history cache.
2. For Russian indices: existing 600-row `market.db` history.
3. Yahoo daily chart, 3 years, using direct and environment sessions in parallel waves.
4. MOEX recent board history for an immediate scenario fallback.
5. `apimoex.get_board_history()` as a cursor-aware recovery route when installed.
6. Stale local history cache as a final last-good fallback.

If 390+ closes are available, the card uses the actual AllAnalytics purged walk-forward model. If only 61–389 closes are available, the UI shows a clearly marked scenario fallback instead of no result.

## Other changes

- Forecast caches moved to a v4.24 namespace so older generated results cannot be reused accidentally.
- Russian history is saved independently from live quotes, so page reloads no longer require re-downloading three years once a provider has succeeded.
- Forecast request timeout increased moderately while failed-state retry was shortened.
- Added production-oriented tests for independent long-history fallback, real walk-forward output, recent-history fallback and local Russian-index history.
- `apimoex>=1.4.0,<1.5.0` added to `requirements.txt` for Python 3.10–3.13 compatibility; the forecast pipeline only uses APIs already present in 1.4.0.
