from pathlib import Path
import math
import pandas as pd
import pytest

import prospective_feedback_v436 as F
import prospective_selection_v437 as S
import model_registry as MR


def _history(as_of):
    idx=pd.bdate_range(end=as_of,periods=25)
    vals=[100+i*.2 for i in range(len(idx))]
    return [{'t':str(d.date()),'o':v,'h':v*1.002,'l':v*.998,'c':v} for d,v in zip(idx,vals)]


def _seed_settled(led,n=90):
    dates=pd.bdate_range('2025-01-02',periods=n)
    for i,d in enumerate(dates):
        y=1 if i%2==0 else 0
        prod=.58 if y else .42
        vol=.60 if y else .40
        core=.62 if y else .38
        ctx=.92 if y else .08
        f={
            'p_up':core,'p_down':1-core,'abstain':False,'signal_strength':'умеренный',
            'signal_threshold':.57,'regime':'trend_up|normal_vol' if y else 'trend_down|normal_vol',
            'model_version':'dynamic-meta-ensemble-v4.35.0','model_generation':S.CURRENT_MODEL_GENERATION,'target_version':S.CURRENT_TARGET_VERSION,
            'probability_semantics':'three-state-factorized-v4.40.6','p_move':1.0,'p_neutral':0.0,'conditional_p_up':core,
            'class_probabilities':{'up':core,'neutral':0.0,'down':1-core},
            'prospective_selection_guard':{'version':S.VERSION,'active':False},'guard_version':S.VERSION,'confidence_score':.66,
            'reliability':{'probability':.66},
            'components':[
                {'name':'production','p_up':prod,'conditional_p_up':prod,'p_move':1.0,'p_neutral':0.0,'weight':.55},
                {'name':'vol_regime','p_up':vol,'conditional_p_up':vol,'p_move':1.0,'p_neutral':0.0,'weight':.45},
                {'name':'core_meta','p_up':core,'conditional_p_up':core,'p_move':1.0,'p_neutral':0.0,'weight':1.0},
                {'name':'context_advisory','p_up':ctx,'conditional_p_up':ctx,'p_move':1.0,'p_neutral':0.0,'weight':0.0,'validated':False},
            ],
            'dynamic_weights':{'production':.55,'vol_regime':.45},
            'quality':{'trusted':True},'validation':{'automatic_promotion':False},
        }
        row={'symbol':'AAPL','status':'ok','source':'synthetic','as_of':str(d.date()),'history':_history(d),
             'forecasts':{'10':f},'model':'AllAnalytics v4.37 Dynamic Ensemble'}
        r=led.record_row(row,'test-v437')
        fid=r['ids'][0]
        outcome='up' if y else 'down';target=float(y)
        p=core
        with led._connect() as con:
            con.execute("""INSERT INTO settlement_ledger(forecast_id,settled_at,target_as_of,target_price,realized_return_pct,outcome,soft_target,
                         direction_hit,published_hit,significant_hit,brier,calibration_error,error_code,attribution_json)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (fid,'2026-01-01T00:00:00Z',str((d+pd.offsets.BDay(10)).date()),110 if y else 90,10 if y else -10,
                         outcome,target,1,1,1,(p-target)**2,abs(p-target),'correct_signal','{}'))
            con.commit()


def test_paired_bootstrap_and_stability_make_good_ensemble_reviewable(tmp_path,monkeypatch):
    led=F.Ledger(tmp_path/'ledger.sqlite3');_seed_settled(led,90)
    monkeypatch.setattr(S,'REVIEW',S.ReviewStore(tmp_path/'review.sqlite3'))
    r=S.candidate_report('dynamic_ensemble_v437','production',window_days=3650,symbol='AAPL',horizon=10,ledger=led,current_v437_only=True)
    assert r['paired_n']==90
    assert r['gates']['sample_size'] is True
    assert r['paired_bootstrap']['brier_improvement']['ci95'][0] > 0
    assert r['stability']['stable'] is True
    assert r['eligible_for_human_review'] is True
    assert r['automatic_promotion'] is False


def test_context_needs_both_evidence_and_explicit_human_approval(tmp_path,monkeypatch):
    led=F.Ledger(tmp_path/'ledger.sqlite3');_seed_settled(led,90)
    store=S.ReviewStore(tmp_path/'review.sqlite3');monkeypatch.setattr(S,'REVIEW',store);S._CACHE.clear()
    report=S.context_report(window_days=3650,symbol='AAPL',horizon=10,ledger=led)
    assert report['eligible_for_human_review'] is True
    assert 0 < report['context_weight'] <= .20
    assert report['data_driven_weight']['learned'] is True
    before=S.context_gate('AAPL',10,window_days=3650,ledger=led)
    assert before['eligible'] is True and before['human_approved'] is False and before['weight']==0
    out=S.review('context_blend','approve','approved after prospective review',window_days=3650,symbol='AAPL',horizon=10,ledger=led)
    assert out['review']['decision']=='approve'
    after=S.context_gate('AAPL',10,window_days=3650,ledger=led)
    assert after['active'] is True and after['weight']>0


def test_insufficient_sample_cannot_be_approved(tmp_path,monkeypatch):
    led=F.Ledger(tmp_path/'ledger.sqlite3');_seed_settled(led,20)
    store=S.ReviewStore(tmp_path/'review.sqlite3');monkeypatch.setattr(S,'REVIEW',store);S._CACHE.clear()
    report=S.context_report(window_days=3650,symbol='AAPL',horizon=10,ledger=led)
    assert report['eligible_for_human_review'] is False
    with pytest.raises(ValueError):
        S.review('context_blend','approve','too early',window_days=3650,symbol='AAPL',horizon=10,ledger=led)


def test_registry_records_v437_without_promoting_champion(tmp_path):
    import sqlite3
    con=sqlite3.connect(tmp_path/'registry.sqlite3')
    try:
        MR.register_champion(con);MR.register_v433_models(con);MR.register_v434_models(con);MR.register_v435_models(con);MR.register_v437_models(con)
        rows={r[0]:r[1] for r in con.execute('select model_version,role from model_registry')}
        assert MR.V437_ENSEMBLE_VERSION in rows and rows[MR.V437_ENSEMBLE_VERSION]=='challenger'
        assert MR.V437_GUARD_VERSION in rows and rows[MR.V437_GUARD_VERSION]=='challenger'
    finally:con.close()


def test_api_ui_and_forecast_expose_v437_contract():
    root=Path(__file__).parent
    api=(root/'api.py').read_text(encoding='utf-8')
    eq=(root/'equity_forecast_v416.py').read_text(encoding='utf-8')
    tech=(root/'site'/'technical_lab_v411.html').read_text(encoding='utf-8')
    dyn=(root/'dynamic_ensemble_v437.py').read_text(encoding='utf-8')
    assert '/api/models/selection-v437' in api
    assert '/api/models/promotion-v437/review' in api
    assert 'dynamic_ensemble_v437 as META435' in eq
    assert 'loadSelectionStatsV437' in tech
    assert 'Автоматическая смена основной модели' in tech
    assert 'SEL437.context_gate' in dyn
    assert 'core_meta' in dyn
