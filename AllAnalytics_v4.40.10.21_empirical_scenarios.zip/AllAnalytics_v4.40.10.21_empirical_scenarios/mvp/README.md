
## v4.40.10.2 — Explainable Movement Ranges

The Markets detail panel now translates the existing 3-state + distributional forecast into a user-facing material-move threshold and, only when statistically validated, a directional scenario range. See `CHANGELOG_V4_40_10_2.md`. The model generation itself remains v4.40.10.

# AllAnalytics v4.40.10.1 — Market Forecast Coverage

This patch is built on v4.40.10 Champion & Validation Upgrade. Model mathematics and generation are unchanged; the Markets interface now exposes the same forecast pipeline across supported indices, FX, metals, commodities, futures, crypto and equities.

## Main change

Market cards first use the packaged `model_horizons` last-good forecast and then refresh through the live API when the card becomes visible or the asset is opened. This removes false `Нет расчёта` states caused by the old UI reading only `unified_forecast_v39` and limiting live requests to equities/Russian indices.

Forecast states are now explicit: `Рассчитываем прогноз`, `Исследовательская оценка`, `Подтверждённый сигнал`, `Нет преимущества`, or genuine `Нет данных`.

The live request queue remains capped at four concurrent calculations and a versioned browser session cache prevents repeated recalculation while navigating the site.

## Model identity

- predictive model: v4.40.10 Champion & Validation Upgrade
- generation: `directional-3state-move-champion-validation-v4.40.10`
- UI integration patch: `v4.40.10.1-market-forecast-coverage`

## Run on macOS

Open `mvp/start_v31.command`, then open `http://127.0.0.1:8000`.

This package intentionally includes the user's `.env` as requested. Keep the ZIP private because it contains API credentials.

Do not delete `~/AllAnalytics_Data/`; prospective evidence, event history, governance decisions and shadow audit data persist there.
