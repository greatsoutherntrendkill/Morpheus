import pandas as pd
import numpy as np
import event_response_v439 as EV
import prospective_selection_v439 as SEL


def test_rate_surprise_uses_actual_minus_expectation():
    row={"date":"2024-06-12","title":"ФРС снизила ставку на 25 б.п.","expected_bp":0}
    x=EV.surprise_from_event(row,calendar=[])
    assert x["known"] is True
    assert x["type"]=="fed_rate"
    assert x["actual"]==-25
    assert x["expected"]==0
    assert x["score"]==-1


def test_inflation_surprise_parses_fact_vs_forecast():
    row={"date":"2024-07-11","title":"CPI США составил 3.2%, прогноз 3.0%"}
    x=EV.surprise_from_event(row,calendar=[])
    assert x["known"] is True
    assert x["type"]=="inflation_us"
    assert abs(x["score"]-1.0)<1e-9


def test_historical_response_is_strictly_point_in_time():
    idx=pd.bdate_range("2024-01-01","2024-04-30")
    close=pd.Series(100+np.arange(len(idx))*0.2,index=idx)
    events=[
        {"date":"2024-01-10","type":"fed_rate","actor":"fed","title":"ФРС решение по ставке","surprise_known":True,"surprise_score":1.0},
        {"date":"2024-03-20","type":"fed_rate","actor":"fed","title":"ФРС решение по ставке","surprise_known":True,"surprise_score":1.0},
        {"date":"2024-04-25","type":"fed_rate","actor":"fed","title":"ФРС решение по ставке","surprise_known":True,"surprise_score":1.0},
    ]
    x=EV.historical_event_responses(close,"AAPL","fed_rate",3,as_of="2024-04-01",events=events)
    assert x["n"]==2
    assert all(r["date"]<"2024-04-01" for r in x["rows"])


def test_event_model_learns_only_from_observed_same_type_events():
    idx=pd.bdate_range("2023-01-02","2024-12-31")
    base=np.linspace(100,150,len(idx))
    close=pd.Series(base,index=idx)
    dates=["2023-02-01","2023-03-22","2023-05-03","2023-06-14","2023-07-26","2023-09-20","2023-11-01","2023-12-13"]
    events=[]
    for i,d in enumerate(dates):
        actual=25 if i%2==0 else -25
        events.append({"date":d,"title":f"ФРС {'повысила' if actual>0 else 'снизила'} ставку на 25 б.п.","expected_bp":0,"actual_bp":actual})
    events.append({"date":"2024-12-18","title":"ФРС повысила ставку на 25 б.п.","expected_bp":0,"actual_bp":25})
    x=EV.event_response_forecast(close,"AAPL",3,as_of="2024-12-18",events=events)
    assert x["status"] in {"ok","insufficient_event_history"}
    assert (x.get("historical_sensitivity") or {}).get("n",0)>=6
    if x["status"]=="ok":
        assert 0.18 <= x["p_up"] <= 0.82
        assert x["event_sample_n"]>=6


def test_unresolved_event_never_invents_direction():
    idx=pd.bdate_range("2024-01-02","2024-12-31")
    close=pd.Series(np.linspace(100,120,len(idx)),index=idx)
    events=[{"date":"2024-12-18","cb":"ФРС","event":"Решение по ставке","expected_bp":0}]
    x=EV.event_response_forecast(close,"AAPL",5,as_of="2024-12-17",events=events)
    assert x["status"]=="awaiting_surprise"
    assert x["p_up"] is None


def test_event_component_has_zero_weight_without_guard(monkeypatch):
    idx=pd.bdate_range("2023-01-02",periods=420)
    close=pd.Series(np.linspace(100,130,len(idx)),index=idx)
    monkeypatch.setattr(EV.BASE438,"forecast_horizon",lambda *a,**k:{
        "version":"base","model_version":"base","p_up":.62,"p_down":.38,"signal_threshold":.58,"abstain":False,
        "signal_strength":"слабый","components":[{"name":"core_meta","p_up":.62,"weight":1.0}],"validation":{},"scorecard":{}
    })
    monkeypatch.setattr(EV,"event_response_forecast",lambda *a,**k:{"version":EV.VERSION,"status":"ok","p_up":.70,"quality_ok":True,"max_live_weight":.10,"event":{"type":"fed_rate"},"event_sample_n":12})
    monkeypatch.setattr(EV.SEL439,"event_gate",lambda *a,**k:{"active":False,"eligible":False,"human_approved":False,"weight":0.0,"version":SEL.VERSION})
    out=EV.forecast_horizon(close,"AAPL",10)
    assert out["p_up"]==.62
    comp=[c for c in out["components"] if c["name"]=="event_response"][0]
    assert comp["weight"]==0
    assert out["event_weight_status"]=="challenger_only_pending_guard"


def test_event_gate_requires_human_approval(monkeypatch):
    monkeypatch.setattr(SEL,"event_report",lambda **k:{"eligible_for_human_review":True,"report_hash":"abc","reason":"готов"})
    monkeypatch.setattr(SEL.BASE437.REVIEW,"latest",lambda *a,**k:None)
    x=SEL.event_gate("AAPL",10,ledger=object())
    assert x["eligible"] is True
    assert x["human_approved"] is False
    assert x["active"] is False
    assert x["weight"]==0
