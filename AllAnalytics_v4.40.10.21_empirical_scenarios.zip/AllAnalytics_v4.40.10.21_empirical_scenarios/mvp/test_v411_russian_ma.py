
from pathlib import Path
import russian_ma_v411 as R

ROOT=Path(__file__).parent

def main():
    st=R.status()
    assert st["version"]=="4.11"
    assert st["count"]==6192
    assert st["min_year"]==2012 and st["max_year"]==2025
    assert st["market_context"]["years"]["2025"]["count"]==290
    assert st["market_context"]["years"]["2025"]["value_usd_bn"]==27.6

    rows=R.list_deals(range_id="2012",limit=20,q="Comedy Club")
    assert rows["total"]>=1
    d=rows["rows"][0]
    assert "Comedy Club" in d["target"]

    old_market=R.market_reaction
    try:
        R.market_reaction=lambda rec:{
            "available":True,"mode":"month","ticker":"GAZP","role":"покупатель",
            "previous_close":100.0,"month_end_close":105.0,"month_pct":5.0,
            "source":"MOEX ISS","note":"test"
        }
        detail=R.analyze(d["id"])
    finally:
        R.market_reaction=old_market

    assert detail["country"]=="RU"
    assert detail["buyer"]
    assert detail["target"]
    assert detail["value_usd_m"]==246.6
    assert abs(detail["stake_pct"]-75)<1e-9
    assert abs(detail["implied_equity_value_usd_m"]-328.8)<1e-6
    assert detail["corporate_finance"]["classical_multiples_available"] is False
    assert detail["corporate_finance"]["goodwill_available"] is False
    assert detail["scale"]["vs_year_median_x"] is not None

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    for token in [
        'data-deal-country="us"','data-deal-country="ru"',
        'Российский рынок M&A · 2025','M&A · Россия',
        'Кто участвует в сделке','Implied value 100% капитала',
        'К медиане отрасли','Динамика рынка в месяц сделки',
        '/api/corpfin/russia-ma'
    ]:
        assert token in html, token

    api=(ROOT/"api.py").read_text(encoding="utf-8")
    assert '@app.get("/api/corpfin/russia-ma/status")' in api
    assert '@app.get("/api/corpfin/russia-ma/{deal_id}")' in api

    print("OK: v4.11 Russian M&A 2012–2025 + analytics + market context + MOEX policy")

if __name__=="__main__":
    main()
