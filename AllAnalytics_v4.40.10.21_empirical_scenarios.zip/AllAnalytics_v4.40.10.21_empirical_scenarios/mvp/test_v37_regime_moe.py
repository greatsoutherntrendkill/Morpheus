
from __future__ import annotations
import json
from pathlib import Path
import db, model_registry as MR
import config as C

ROOT=Path(__file__).parent

def main():
    p=json.loads((ROOT/"site"/"regime_v37.json").read_text(encoding="utf-8"))
    assert p["version"]=="3.7"
    assert p["model_version"]=="regime-moe-v3.7.0"
    assert len(p["data_meta"]["symbols"])==33
    assert p["data_meta"]["regime_features_point_in_time"] is True
    assert p["data_meta"]["regime_thresholds_expanding_and_shifted"] is True
    assert p["data_meta"]["ood_reference_pre_holdout_only"] is True
    assert p["data_meta"]["last_date"] < p["prospective_holdout_start"]
    assert p["decision"]["production_champion"]=="logreg-v3.2.0"
    assert p["decision"]["action"]=="retain"

    n=0; low_ood=False; disagreement_seen=False
    for h in p["horizons"]:
        assert h["holdout_used_for_tuning"] is False
        ho=h["prospective_holdout"]
        assert ho["used_for_tuning"] is False
        assert ho["n_realized_rows"]==0
        assert ho["status"]=="awaiting_new_data"
        assert h["cluster_date_bootstrap"]["global_dates"]>0
        assert "platt" in h["calibration_check"]
        for r in h["live"]:
            n+=1
            cal=float(r["calibrated_p_up"]); final=float(r["final_research_p_up"])
            assert abs(final-.5) <= abs(cal-.5)+1e-9
            assert 0 <= float(r["regime_familiarity"]) <= 100
            assert 0 <= float(r["total_shrink_alpha"]) <= 1
            assert 0 <= float(r["evidence_alpha"]) <= 1
            assert 0 <= float(r["ood_alpha"]) <= 1
            assert 0 <= float(r["agreement_alpha"]) <= 1
            assert r["risk_regime"] in ("risk_on","risk_off","mixed")
            assert r["expert_class"] in ("equities","crypto","commodities","fx","russia","other")
            low_ood |= float(r["regime_familiarity"])<25
            disagreement_seen |= float(r["expert_disagreement"])>0
    assert n==33*4
    assert low_ood and disagreement_seen

    data=json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))
    assert data.get("regime_model_version")=="3.7"
    assert all("regime_moe_v37" in a for a in data["assets"])

    for sid in ("DGS2","DGS5","DGS30","T10Y3M","BAMLH0A0HYM2","BAMLC0A4CBBB","NFCI"):
        assert sid in C.FRED_US

    con=db.connect()
    try:
        reg=con.execute("SELECT role,status FROM model_registry WHERE model_version=?",
                        ("regime-moe-v3.7.0",)).fetchone()
        assert reg==("challenger","frozen")
        cnt=con.execute("SELECT COUNT(*) FROM prediction_ledger WHERE model_version=?",
                        ("regime-moe-v3.7.0",)).fetchone()[0]
        assert cnt==132
        d=con.execute("SELECT action,selected_version FROM model_decisions WHERE decision_id=?",
                      (p["decision"]["decision_id"],)).fetchone()
        assert d==("retain","logreg-v3.2.0")
    finally:
        con.close()

    print("OK: v3.7 Regime MoE + PIT regimes + OOD guard + immutable prospective challenger")

if __name__=="__main__":
    main()
