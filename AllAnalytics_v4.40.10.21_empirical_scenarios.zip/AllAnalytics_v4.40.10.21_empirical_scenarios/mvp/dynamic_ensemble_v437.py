"""AllAnalytics v4.37 — Dynamic Ensemble + Prospective Selection Guard.

This layer learns how to combine the champion and volatility/regime challenger
from their *past OOS predictions*. It never promotes a model by itself.

Key properties
--------------
- horizon-specific and regime-aware OOS weighting;
- sequential meta learner trained only on already-observed OOS component outputs;
- probability calibration from a later calibration slice;
- signal threshold selected from a final development evaluation slice;
- reliability model estimates whether the current directional call deserves trust;
- context/event layer gets non-zero weight only after v4.37 prospective evidence + explicit human approval.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd

import feature_event_v434 as FE434
import meta_forecast_v434 as META434
import prospective_selection_v437 as SEL437
import target_contract_v4405 as TARGET4405
import routing_policy_v4408 as ROUTE4408
import temporal_validation_v4401012 as TV

VERSION = "dynamic-meta-ensemble-v4.40.8-routing"
GUARD_VERSION = SEL437.VERSION
RELIABILITY_VERSION = "reliability-meta-v4.40.8-data-routing"
VALIDATION_VERSION = "four-slice-calibration-threshold-eval-data-routing-v4.40.8"


def _finite(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _clip_p(p):
    return float(np.clip(float(p), 0.02, 0.98))


def _logit(p):
    p=float(np.clip(float(p),1e-5,1-1e-5))
    return math.log(p/(1-p))


def _sigmoid(x):
    return float(1/(1+math.exp(-float(np.clip(x,-30,30)))))


def _ece(p, y, bins=8):
    p=np.asarray(p,float); y=np.asarray(y,float)
    if len(p)<5:return None
    edges=np.linspace(0,1,bins+1); out=0.0
    for a,b in zip(edges[:-1],edges[1:]):
        mask=(p>=a)&(p<(b if b<1 else b+1e-12))
        if mask.any():out+=float(mask.mean())*abs(float(p[mask].mean())-float(y[mask].mean()))
    return float(out)


def _metrics(p, y):
    p=np.asarray(p,float); y=np.asarray(y,float)
    ok=np.isfinite(p)&np.isfinite(y);p,y=p[ok],y[ok]
    if len(p)<5:return {"n":len(p),"accuracy":None,"edge_pp":None,"brier":None,"brier_skill":None,"ece":None}
    pred=(p>=.5).astype(float); acc=float(np.mean(pred==y)); base=max(float(np.mean(y)),1-float(np.mean(y)))
    brier=float(np.mean((p-y)**2)); bp=np.full(len(y),float(np.mean(y))); bb=float(np.mean((bp-y)**2))
    skill=(1-brier/bb)*100 if bb>1e-12 else 0.0
    return {"n":int(len(p)),"accuracy":acc,"base_accuracy":base,"edge_pp":(acc-base)*100,
            "brier":brier,"brier_skill":skill,"ece":_ece(p,y)}


def _records_map(rows: Iterable[dict]):
    """Normalize OOS rows to the shared significant-direction contract.

    v4.40.4 prefers ``conditional_p_up`` and ignores neutral rows.  Legacy rows
    without state/conditional probability remain readable for old ledgers/tests.
    """
    out={}
    for r in rows or []:
        d=str(r.get("date") or "")[:10]
        state=r.get("state")
        if state in (0,0.0,"0"):
            continue
        p=_finite(r.get("conditional_p_up"))
        if p is None:
            p=_finite(r.get("p_up"))
        if state in (-1,-1.0,"-1"):
            y=0
        elif state in (1,1.0,"1"):
            y=1
        else:
            y=r.get("y")
            if y not in (0,1,0.0,1.0):
                continue
            y=int(y)
        if not d or p is None:
            continue
        if not r.get("label_end") or not r.get("feature_available_at"): continue
        out[d]={**r,"date":d,"p_up":p,"y":int(y),"state":1 if int(y)==1 else -1}
    return out


def _aligned_records(champion: dict, challenger: dict) -> pd.DataFrame:
    a=_records_map((champion or {}).get("oos_records") or [])
    b=_records_map((challenger or {}).get("oos_records") or [])
    dates=sorted(set(a)&set(b));rows=[]
    for d in dates:
        # Both components now share the exact significant-move target.  If an old
        # cache still disagrees, skip it rather than silently choosing one label.
        if int(a[d]["y"])!=int(b[d]["y"]):
            continue
        rows.append({"date":pd.Timestamp(d), "label_end":max(pd.Timestamp(a[d]["label_end"]),pd.Timestamp(b[d]["label_end"])), "feature_available_at":max(pd.Timestamp(a[d]["feature_available_at"]),pd.Timestamp(b[d]["feature_available_at"])), "p_champion":a[d]["p_up"],"p_challenger":b[d]["p_up"],
                     "y":int(a[d]["y"]),"regime":str(b[d].get("regime") or "unknown")})
    return pd.DataFrame(rows).sort_values("date") if rows else pd.DataFrame()


def _component_reliability(p, y) -> tuple[float,dict]:
    m=_metrics(p,y);n=int(m.get("n") or 0)
    if n<12:return .25,m
    edge=float(m.get("edge_pp") or 0); skill=float(m.get("brier_skill") or 0); ece=float(m.get("ece") or .20)
    n_term=min(1.0,math.log1p(n)/math.log(180))
    z=-.65 + .13*edge + .045*skill - 2.2*ece + .75*n_term
    return float(np.clip(_sigmoid(z),.12,.92)),m


def _meta_features(df: pd.DataFrame) -> np.ndarray:
    pc=np.clip(df["p_champion"].to_numpy(float),1e-5,1-1e-5)
    pq=np.clip(df["p_challenger"].to_numpy(float),1e-5,1-1e-5)
    return np.column_stack([
        np.log(pc/(1-pc)),np.log(pq/(1-pq)),
        np.abs(pc-pq),np.abs(pc-.5)*2,np.abs(pq-.5)*2,
    ])


def _fit_lr(X,y,sample_weight=None):
    if len(X)<20 or len(np.unique(y))<2:return None
    try:
        from sklearn.linear_model import LogisticRegression
        mdl=LogisticRegression(C=.75,max_iter=350,solver="lbfgs",random_state=435)
        mdl.fit(X,y,sample_weight=sample_weight)
        return mdl
    except Exception:return None


@dataclass
class _Platt:
    coef: float
    intercept: float
    def apply(self,p):
        arr=np.clip(np.asarray(p,float),1e-5,1-1e-5);z=np.log(arr/(1-arr))
        return 1/(1+np.exp(-np.clip(self.intercept+self.coef*z,-30,30)))


def _fit_platt(p,y):
    p=np.asarray(p,float);y=np.asarray(y,float);ok=np.isfinite(p)&np.isfinite(y);p,y=p[ok],y[ok]
    if len(p)<24 or len(np.unique(y))<2:return None
    try:
        from sklearn.linear_model import LogisticRegression
        z=np.log(np.clip(p,1e-5,1-1e-5)/(1-np.clip(p,1e-5,1-1e-5))).reshape(-1,1)
        mdl=LogisticRegression(C=1.0,max_iter=250,solver="lbfgs",random_state=435).fit(z,y)
        return _Platt(float(mdl.coef_[0,0]),float(mdl.intercept_[0]))
    except Exception:return None


def _select_regime_rows(df,current_regime):
    if df.empty:return df,"all"
    same=df[df["regime"]==str(current_regime)]
    if len(same)>=90:return same,"current_regime"
    prefix=str(current_regime).split("|")[0]
    partial=df[df["regime"].astype(str).str.startswith(prefix+"|")]
    if len(partial)>=90:return partial,"trend_regime"
    return df,"all"


def _split_meta(df):
    """Four chronological slices: fit -> calibration -> threshold -> final eval."""
    return TV.split(df, (.50,.68,.84), (40,16,14,12))


def _meta_fit_and_eval(df,pc_live,pq_live):
    split=_split_meta(df)
    if split is None:return None
    train,cal,thr,ev=split
    Xtr=_meta_features(train);ytr=train["y"].to_numpy(int)
    decay=np.exp(-np.arange(len(train)-1,-1,-1)/180.0)
    mdl=_fit_lr(Xtr,ytr,decay)
    if mdl is None:return None
    pcal_raw=mdl.predict_proba(_meta_features(cal))[:,1]
    calibrator=_fit_platt(pcal_raw,cal["y"].to_numpy(int))
    def pred(frame):
        p=mdl.predict_proba(_meta_features(frame))[:,1]
        return calibrator.apply(p) if calibrator is not None else p
    pthr=np.asarray(pred(thr),float)
    pev=np.asarray(pred(ev),float)

    # Deployment calibration is fitted to predictions from the *same* deployment
    # model.  We intentionally reserve a recent tail instead of fitting a new model
    # on all rows and reusing a calibrator learned from an older fit.
    # Use the audited estimator and its dedicated calibration sample.
    live_train=train.copy(); live_cal=cal.copy()
    if len(live_train)<55 or len(np.unique(live_train["y"]))<2:
        return None
    decay_live=np.exp(-np.arange(len(live_train)-1,-1,-1)/220.0)
    live_mdl=_fit_lr(_meta_features(live_train),live_train["y"].to_numpy(int),decay_live)
    if live_mdl is None:return None
    live_cal_raw=live_mdl.predict_proba(_meta_features(live_cal))[:,1]
    live_calibrator=_fit_platt(live_cal_raw,live_cal["y"].to_numpy(int))
    live_df=pd.DataFrame([{"p_champion":pc_live,"p_challenger":pq_live}])
    live_raw=float(live_mdl.predict_proba(_meta_features(live_df))[:,1][0])
    live_p=float(live_calibrator.apply([live_raw])[0]) if live_calibrator is not None else live_raw
    base_thr=(thr["p_champion"].to_numpy(float)+thr["p_challenger"].to_numpy(float))/2
    base_ev=(ev["p_champion"].to_numpy(float)+ev["p_challenger"].to_numpy(float))/2
    return {
        "p_up":_clip_p(live_p),"raw_p_up":_clip_p(live_raw),
        "threshold_p":pthr,"threshold_y":thr["y"].to_numpy(int),
        "threshold_pc":thr["p_champion"].to_numpy(float),"threshold_pq":thr["p_challenger"].to_numpy(float),
        "threshold_baseline":base_thr,
        "eval_p":pev,"eval_y":ev["y"].to_numpy(int),"eval_pc":ev["p_champion"].to_numpy(float),
        "eval_pq":ev["p_challenger"].to_numpy(float),"eval_baseline":base_ev,
        "calibrated":calibrator is not None,"live_calibrated":live_calibrator is not None,
        "coef":[float(x) for x in live_mdl.coef_[0]],"intercept":float(live_mdl.intercept_[0]),
        "temporal_split":train.attrs.get("temporal_split"),"train_n":len(train),"cal_n":len(cal),"threshold_n":len(thr),"eval_n":len(ev),
        "production_fit_n":len(live_train),"production_calibration_n":len(live_cal),
    }


def _empirical_threshold(p,y,default=.58):
    p=np.asarray(p,float);y=np.asarray(y,int)
    if len(p)<16:return float(default),{"source":"fallback","coverage":None,"accuracy":None}
    base=max(float(np.mean(y)),1-float(np.mean(y)));best=None
    for th in np.arange(.53,.721,.01):
        mask=np.maximum(p,1-p)>=th;n=int(mask.sum())
        if n<max(10,int(len(p)*.18)):continue
        acc=float(np.mean(((p[mask]>=.5).astype(int))==y[mask]));coverage=n/len(p);edge=acc-base
        if edge<=0:continue
        score=edge*math.sqrt(n)+.08*coverage-.08*max(0,th-.64)
        if best is None or score>best[0]:best=(score,float(th),acc,coverage,n,edge)
    if best is None:return float(max(default,.66)),{"source":"no_positive_oos_edge","coverage":None,"accuracy":None}
    _,th,acc,cov,n,edge=best
    return float(np.clip(th,.53,.72)),{"source":"separate_threshold_slice","coverage":round(cov,4),"accuracy":round(acc,4),"n":n,"edge_pp":round(edge*100,3)}


def _reliability_model(meta,pc_live,pq_live):
    """Fit trust model on threshold slice, validate it on untouched eval slice."""
    p=meta["threshold_p"];y=meta["threshold_y"];pc=meta["threshold_pc"];pq=meta["threshold_pq"]
    if len(p)<16:return None
    correct=((p>=.5).astype(int)==y).astype(int)
    X=np.column_stack([np.maximum(p,1-p),np.abs(pc-pq),np.abs(p-.5)*2])
    mdl=_fit_lr(X,correct)
    if mdl is None:
        return {"probability":float(np.mean(correct)),"trained":False,"validated":False,"n":len(correct)}
    ep=meta["eval_p"];ey=meta["eval_y"];epc=meta["eval_pc"];epq=meta["eval_pq"]
    ecorrect=((ep>=.5).astype(int)==ey).astype(int)
    EX=np.column_stack([np.maximum(ep,1-ep),np.abs(epc-epq),np.abs(ep-.5)*2])
    pred=mdl.predict_proba(EX)[:,1] if len(EX) else np.array([])
    brier=float(np.mean((pred-ecorrect)**2)) if len(pred) else None
    base=float(np.mean((float(np.mean(correct))-ecorrect)**2)) if len(ecorrect) else None
    validated=bool(brier is not None and base is not None and brier<=base+1e-9)
    return {"model":mdl,"trained":True,"validated":validated,"n":len(correct),
            "historical_accuracy":float(np.mean(correct)),"evaluation_n":int(len(ecorrect)),
            "evaluation_brier":brier,"evaluation_baseline_brier":base}


def forecast_horizon(close: pd.Series,symbol: str,horizon: int=10,fast: bool=True,context: dict|None=None) -> dict:
    h=int(horizon)
    base=META434.forecast_horizon(close,symbol=symbol,horizon=h,fast=fast,context=context)
    if not base or base.get("p_up") is None:return {}
    bm=(base.get("base_meta") or {})
    champion=bm.get("champion") or {}; challenger=bm.get("challenger") or base.get("base_meta",{}).get("challenger") or {}
    pc_soft=_finite(champion.get("live_p_up")); pq_soft=_finite(challenger.get("p_up"))
    pc=_finite(champion.get("conditional_p_up")); pq=_finite(challenger.get("conditional_p_up"))
    if pc is None: pc=pc_soft
    if pq is None: pq=pq_soft
    # Old cached/reduced outputs may not expose raw components. Fall back to the
    # v4.34 components so the API stays robust.
    if pc is None or pq is None:
        comp={x.get("name"):x for x in (base.get("components") or [])}
        pc=pc if pc is not None else _finite((comp.get("production") or {}).get("conditional_p_up") or (comp.get("production") or {}).get("p_up"))
        pq=pq if pq is not None else _finite((comp.get("vol_regime") or {}).get("conditional_p_up") or (comp.get("vol_regime") or {}).get("p_up"))
    if pc is None and pq is None:return base
    if pc is None:pc=pq
    if pq is None:pq=pc

    aligned=_aligned_records(champion,challenger)
    current_regime=base.get("regime") or challenger.get("regime") or "unknown"
    selected,scope=_select_regime_rows(aligned,current_regime)
    rel_c,mc=_component_reliability(selected.get("p_champion",pd.Series(dtype=float)),selected.get("y",pd.Series(dtype=float))) if not selected.empty else (.25,{"n":0})
    rel_q,mq=_component_reliability(selected.get("p_challenger",pd.Series(dtype=float)),selected.get("y",pd.Series(dtype=float))) if not selected.empty else (.25,{"n":0})
    asset_class=FE434.asset_profile(symbol).asset_class
    # v4.40.8: no asset-class prior.  The fallback champion/regime route is
    # learned directly from chronological OOS Brier loss and must beat an equal
    # blend on a recent untouched validation tail.  Otherwise it is exactly 50/50.
    core_route=ROUTE4408.fit_oos_blend(selected,"p_champion","p_challenger","y") if not selected.empty else {"learned":False,"weight_a":.5,"weight_b":.5,"n":0,"reason":"no_oos_evidence"}
    dynamic_weights={"production":float(core_route.get("weight_a",.5)),"vol_regime":float(core_route.get("weight_b",.5))}
    weighted=_clip_p(pc*dynamic_weights["production"]+pq*dynamic_weights["vol_regime"])
    # v4.40.6: neutral mass is no longer a trailing historical share. Both the
    # production champion and the regime challenger expose feature-conditioned
    # Move/No-Move probabilities; combine those on the same live routing weights.
    cmove=_finite(champion.get("p_move")); qmove=_finite(challenger.get("p_move"))
    move_frame=ROUTE4408.aligned_move_frame(champion,challenger)
    move_route=ROUTE4408.fit_oos_blend(move_frame,"p_champion_move","p_challenger_move","y_move") if not move_frame.empty else {"learned":False,"weight_a":dynamic_weights["production"],"weight_b":dynamic_weights["vol_regime"],"n":0,"reason":"no_move_oos_evidence"}
    move_sources=[]
    if cmove is not None: move_sources.append(("production_move_model",cmove,float(move_route.get("weight_a",dynamic_weights["production"]))))
    if qmove is not None: move_sources.append(("regime_move_model",qmove,float(move_route.get("weight_b",dynamic_weights["vol_regime"]))))
    if move_sources:
        mw=sum(w for _,_,w in move_sources) or 1.0
        p_move=float(np.clip(sum(v*w for _,v,w in move_sources)/mw,.03,.97))
        move_probability_source="learned_move_no_move_ensemble"
    else:
        # Compatibility-only fallback for very short/legacy cached histories. It is
        # explicit and cannot masquerade as a learned neutral probability.
        legacy_neutral=_finite((base.get("scorecard") or {}).get("p_neutral"))
        p_move=float(np.clip(1.0-(legacy_neutral if legacy_neutral is not None else .20),.18,.92))
        move_probability_source="legacy_prior_fallback"
    p_neutral=1.0-p_move

    learned=_meta_fit_and_eval(selected,pc,pq) if not selected.empty else None
    if learned:
        p_meta=learned["p_up"];threshold,threshold_diag=_empirical_threshold(learned["threshold_p"],learned["threshold_y"],default=float(base.get("signal_threshold") or .58))
        mmeta=_metrics(learned["eval_p"],learned["eval_y"]); mbase=_metrics(learned["eval_baseline"],learned["eval_y"])
        reliability_obj=_reliability_model(learned,pc,pq)
    else:
        p_meta=weighted;threshold=float(base.get("signal_threshold") or .58);threshold_diag={"source":"fallback","coverage":None,"accuracy":None};mmeta={"n":0};mbase={"n":0};reliability_obj=None

    # Reliability score is itself learned from past correctness when possible.
    disagreement=abs(pc-pq)
    if reliability_obj and reliability_obj.get("trained") and reliability_obj.get("validated"):
        mdl=reliability_obj["model"]
        liveX=np.array([[max(p_meta,1-p_meta),disagreement,abs(p_meta-.5)*2]],float)
        reliability=float(mdl.predict_proba(liveX)[:,1][0])
        reliability_trained=True
    else:
        # No hand-tuned disagreement penalty in v4.40.8.  When the learned trust
        # model is unavailable, reliability is a transparent OOS diagnostic only.
        observed=[_finite(mc.get("accuracy")),_finite(mq.get("accuracy"))]
        observed=[x for x in observed if x is not None]
        reliability=float(np.clip(np.mean(observed) if observed else .5,.0,1.0))
        reliability_trained=False

    # v4.37: context/event information is no longer allowed to affect the live
    # probability merely because it is available. It needs prospective evidence
    # *and* an explicit human approval for the exact asset/horizon (or global
    # scope). Until then it stays diagnostic-only.
    ctx=context or FE434.build_context(symbol,own_close=close,as_of=pd.Timestamp(close.index[-1]) if len(close) else None)
    context_adjust=FE434.apply_context_probability(p_meta,ctx) or {}
    context_p=_finite(context_adjust.get("context_p_up"))
    if context_p is None:context_p=_finite(context_adjust.get("p_up"))
    if context_p is not None and p_move>1e-6:
        context_p=_clip_p(.5+(context_p-.5)/p_move)
    ctx_conf=float(ctx.get("context_confidence") or 0);drift=float(ctx.get("drift_score") or 0);event_risk=float(ctx.get("event_risk") or 0)
    try:
        selection_guard=SEL437.context_gate(symbol,h,window_days=180)
    except Exception as exc:
        selection_guard={"version":SEL437.VERSION,"active":False,"eligible":False,"human_approved":False,"weight":0.0,"reason":f"selection guard unavailable: {type(exc).__name__}"}
    approved_weight=float(selection_guard.get("weight") or 0.0)
    # Current context confidence/drift no longer trigger hand-written routing cutoffs.
    # The approved weight comes from prospective evidence; current drift/event state
    # is handled by the learned prospective publish router and robustness safety layer.
    context_weight=approved_weight
    if context_p is not None and context_weight>0 and (context_p>=.5)==(p_meta>=.5):
        p_final=_clip_p((1-context_weight)*p_meta+context_weight*context_p)
    else:p_final=p_meta
    context_disagreement=bool(context_p is not None and (context_p>=.5)!=(p_meta>=.5) and abs(context_p-.5)>=.03)

    # v4.40.8: routing penalties are no longer hand tuned.  The calibrated meta
    # probability remains the directional estimate; prospective history may add a
    # separate publication/trust gate only after passing a chronological untouched
    # audit.  Drift/event/disagreement enter that learned router as features instead
    # of adding fixed threshold deltas.
    threshold=float(np.clip(threshold,.50,.90))
    p_cond_final=_clip_p(p_final)
    p_final=float(np.clip(.5+p_move*(p_cond_final-.5),.02,.98))
    dir_prob=max(p_final,1-p_final)
    routing_live={"conditional_p_up":p_cond_final,"p_move":p_move,"disagreement":disagreement,"drift":drift,
                  "event_risk":event_risk,"context_disagreement":context_disagreement,"reliability":reliability}
    prospective_route=ROUTE4408.prospective_publish_router(symbol=symbol,horizon=h,live=routing_live)
    prospective_blocks=bool(prospective_route.get("active") and not prospective_route.get("publish"))
    abstain=bool(dir_prob<threshold or prospective_blocks)
    if dir_prob>=.72:strength="выраженный"
    elif dir_prob>=max(.64,threshold):strength="умеренный"
    elif dir_prob>=threshold:strength="слабый"
    else:strength="нет преимущества"
    if abstain:strength="нет преимущества"
    trusted=bool(not abstain and (mmeta.get("edge_pp") or -999)>0 and (not prospective_route.get("active") or prospective_route.get("publish")))

    components=[
        {"name":"production","p_up":round(float(pc_soft if pc_soft is not None else (.5+p_move*(pc-.5))),6),"conditional_p_up":round(pc,6),"p_move":None if cmove is None else round(cmove,6),"p_neutral":None if cmove is None else round(1-cmove,6),"weight":round(dynamic_weights["production"],4),"reliability":round(rel_c,4),"oos":mc},
        {"name":"vol_regime","p_up":round(float(pq_soft if pq_soft is not None else (.5+p_move*(pq-.5))),6),"conditional_p_up":round(pq,6),"p_move":None if qmove is None else round(qmove,6),"p_neutral":None if qmove is None else round(1-qmove,6),"weight":round(dynamic_weights["vol_regime"],4),"reliability":round(rel_q,4),"oos":mq},
        {"name":"core_meta","p_up":round(float(.5+p_move*(p_meta-.5)),6),"conditional_p_up":round(float(p_meta),6),
         "p_move":round(float(p_move),6),"p_neutral":round(float(p_neutral),6),"weight":1.0,"reliability":round(reliability,4),"validated":True},
        {"name":"context_advisory","p_up":round(float(.5+p_move*((context_p if context_p is not None else .5)-.5)),6),
         "conditional_p_up":round(context_p if context_p is not None else .5,6),"p_move":round(float(p_move),6),"p_neutral":round(float(p_neutral),6),
         "weight":round(context_weight,4),"reliability":None,"validated":bool(selection_guard.get("active")),"selection_guard":{k:selection_guard.get(k) for k in ("eligible","human_approved","active","reason","report_hash")}},
    ]

    return {
        "version":VERSION,"guard_version":GUARD_VERSION,"reliability_version":RELIABILITY_VERSION,"feature_version":base.get("feature_version"),"horizon":h,
        # p_up/p_down are retained as the legacy neutral-aware directional score
        # for downstream compatibility.  The normalized three-state probability
        # mass is exposed separately and always sums to one.
        "p_up":round(float(p_final),6),"p_down":round(float(1-p_final),6),"conditional_p_up":round(float(p_cond_final),6),
        "p_neutral":round(float(p_neutral),6),"p_move":round(float(p_move),6),"move_probability_source":move_probability_source,
        "class_probabilities":{"up":round(float(p_move*p_cond_final),6),"neutral":round(float(p_neutral),6),"down":round(float(p_move*(1-p_cond_final)),6)},
        "directional_score_up":round(float(p_final),6),"directional_score_down":round(float(1-p_final),6),
        "target_version":TARGET4405.TARGET_VERSION,"abstain":abstain,
        "signal_strength":strength,"signal_threshold":round(threshold,3),"regime":current_regime,
        "quality":{"trusted":trusted,"confidence":"средняя" if trusted else "низкая","bias":"neutral" if abstain else ("bullish" if p_final>=.5 else "bearish"),
                   "reason":("prospective routing gate: NO EDGE" if prospective_blocks else ("нет достаточного преимущества" if abstain else "динамический ансамбль подтверждён OOS/meta routing"))},
        "components":components,"dynamic_weights":{k:round(v,4) for k,v in dynamic_weights.items()},
        "data_driven_routing":{"version":ROUTE4408.VERSION,"core_blend":core_route,"move_blend":move_route,"prospective_publish":prospective_route,
                               "asset_prior_removed":True,"fixed_disagreement_penalty_removed":True,"fixed_drift_event_threshold_penalties_removed":True},
        "meta_learning":{"temporal_split":learned.get("temporal_split") if learned else None,"used":bool(learned),"scope":scope,"aligned_oos_n":int(len(selected)),"raw_weighted_p_up":round(weighted,6),
                         "meta_raw_p_up":round(float(learned['raw_p_up']),6) if learned else None,"meta_calibrated":bool(learned and learned.get('calibrated')),
                         "train_n":learned.get('train_n') if learned else 0,"calibration_n":learned.get('cal_n') if learned else 0,
                         "threshold_n":learned.get('threshold_n') if learned else 0,"evaluation_n":learned.get('eval_n') if learned else 0,
                         "production_fit_n":learned.get('production_fit_n') if learned else 0,"production_calibration_n":learned.get('production_calibration_n') if learned else 0,
                         "coefficients":learned.get('coef') if learned else None},
        "reliability":{"probability":round(reliability,4),"trained":reliability_trained,"validated_on_untouched_eval":bool(reliability_obj and reliability_obj.get("validated")),"min_required":None,
                       "historical_accuracy":None if not reliability_obj else round(float(reliability_obj.get('historical_accuracy',reliability_obj.get('probability',0))),4),
                       "version":RELIABILITY_VERSION},
        "threshold_selection":{**threshold_diag,"final_threshold":round(threshold,3)},
        "context_features":base.get("context_features") or {},"event_context":base.get("event_context") or {},
        "context_freshness":base.get("context_freshness") or {},
        "context_p_up":round(context_p if context_p is not None else .5,6),"context_weight_status":("prospective_validated_human_approved" if selection_guard.get("active") else "diagnostic_only_pending_v4.37_guard"),
        "prospective_selection_guard":selection_guard,
        "context_disagreement":context_disagreement,"event_risk":base.get("event_risk"),"event_bias":base.get("event_bias"),
        "feature_drift":base.get("feature_drift") or {},
        "scorecard":{**(base.get("scorecard") or {}),"p_neutral":round(float(p_neutral),6),"meta_oos_n":mmeta.get("n"),"meta_accuracy":mmeta.get("accuracy"),"meta_edge_pp":mmeta.get("edge_pp"),
                     "meta_brier_skill":mmeta.get("brier_skill"),"meta_ece":mmeta.get("ece"),"equal_weight_brier_skill":mbase.get("brier_skill"),
                     "ensemble_reliability":round(reliability,4)},
        "validation":{**(base.get("validation") or {}),"meta_training_uses_component_oos_only":True,"meta_time_ordered_split":True,
                      "calibration_slice_precedes_threshold":True,"threshold_slice_precedes_evaluation":True,
                      "threshold_selected_from_separate_development_slice":True,"reliability_validated_on_untouched_eval":bool(reliability_obj and reliability_obj.get("validated")),
                      "deployment_calibration_matches_deployment_fit":True,"shared_three_state_target":True,"regime_scope":scope,
                      "move_probability_modelled_from_current_features":move_probability_source=="learned_move_no_move_ensemble",
                      "move_probability_source":move_probability_source,
                      "context_expert_prospective_validated":bool(selection_guard.get("eligible")),"context_expert_human_approved":bool(selection_guard.get("human_approved")),
                      "automatic_promotion":False,"data_driven_core_blend":True,"prospective_publish_router":True,
                      "manual_asset_prior_removed":True,"manual_disagreement_penalty_removed":True,
                      "manual_drift_event_threshold_penalties_removed":True,"validation_version":VALIDATION_VERSION},
        "base_v434":base,
    }
