
"""AllAnalytics v4.5 — короткий прогноз 30м–4ч.

Это отдельная исследовательская intraday-оценка. Она не заменяет дневную
production-модель и не использует будущие данные.

Основной сигнал:
- EMA 9/21;
- импульс на масштабе выбранного горизонта;
- RSI 14;
- MACD histogram;
- реализованная волатильность;
- ближайший внутридневной уровень.

Макро-поправка отключена без независимой проверки. Выход — технический
балл, а не калиброванная вероятность. Импульс не пересекает разрыв истории.
"""
from __future__ import annotations

import math
import re
import data_contract_v4401013 as DATA13
import numpy as np
import pandas as pd

import market_data_v43 as MD43
import short_horizon_contract_v4401017 as SHORT17
from intraday_movement_v440105 import build as build_intraday_movement

HORIZONS={
    "30m":{"bars":6,"label":"30 минут","tech_weight":0.96,"macro_weight":0.04},
    "1h":{"bars":12,"label":"1 час","tech_weight":0.94,"macro_weight":0.06},
    "2h":{"bars":24,"label":"2 часа","tech_weight":0.90,"macro_weight":0.10},
    "4h":{"bars":48,"label":"4 часа","tech_weight":0.86,"macro_weight":0.14},
}

MACRO_RE=re.compile(
    r"ставк|фрс|ецб|банк росс|доходност|крив|инфляц|занятост|безработ|"
    r"ввп|ликвидност|кредит|спред|реальн.*доход",
    re.I,
)

def _ema(s,n):
    return pd.Series(s,dtype=float).ewm(span=n,adjust=False).mean().to_numpy()

def _rsi(s,n=14):
    x=pd.Series(s,dtype=float)
    d=x.diff()
    up=d.clip(lower=0).ewm(alpha=1/n,adjust=False).mean()
    dn=(-d.clip(upper=0)).ewm(alpha=1/n,adjust=False).mean()
    rs=up/(dn+1e-12)
    return (100-100/(1+rs)).to_numpy()

def _atr(df,n=14):
    c=df["close"].to_numpy(float)
    h=df["high"].to_numpy(float)
    l=df["low"].to_numpy(float)
    prev=np.r_[np.nan,c[:-1]]
    tr=np.nanmax(np.vstack([h-l,np.abs(h-prev),np.abs(l-prev)]),axis=0)
    return pd.Series(tr).ewm(span=n,adjust=False).mean().to_numpy()

def _macro_bias(asset):
    vals=[]
    for d in (asset or {}).get("drivers") or []:
        if MACRO_RE.search(str(d.get("label",""))):
            try:
                vals.append(float(d.get("contribution",0)))
            except Exception:
                pass
    if not vals:
        return 0.0
    return float(np.tanh(sum(vals)/3.0))

def _technical_score(df,bars,interval_minutes=5):
    c=df["close"].to_numpy(float)
    if len(c)<max(80,bars+25):
        return None
    e9=_ema(c,9);e21=_ema(c,21)
    R=_rsi(c,14)
    e12=_ema(c,12);e26=_ema(c,26)
    mac=e12-e26
    sig=_ema(mac,9)
    hist=mac-sig
    ret=np.diff(np.log(c))
    gaps=pd.to_datetime(df.date,utc=True).diff().dt.total_seconds().div(60).to_numpy()[1:]
    ret=ret[gaps==interval_minutes]
    if len(ret)<30:return None
    vol=float(np.std(ret[-72:])+1e-9)

    mom=float(np.log(c[-1]/c[-1-bars]))
    mom_z=np.clip(mom/(vol*math.sqrt(max(1,bars))+1e-9),-2.5,2.5)
    trend_z=np.clip((e9[-1]/e21[-1]-1)/(vol*2.5+1e-9),-2.5,2.5)
    rsi_z=np.clip((R[-1]-50)/18,-1.5,1.5)
    hist_scale=float(np.std(hist[-72:])+1e-9)
    macd_z=np.clip(hist[-1]/hist_scale,-2,2)

    score=0.38*mom_z+0.30*trend_z+0.17*rsi_z+0.15*macd_z
    return {
        "score":float(np.clip(score,-3,3)),
        "rsi":float(R[-1]),
        "vol":vol,
        "ema9":float(e9[-1]),
        "ema21":float(e21[-1]),
        "macd_hist":float(hist[-1]),
    }

def _nearest_target(df,up,bars):
    c=float(df.iloc[-1]["close"])
    a=float(_atr(df,14)[-1])
    window=df.tail(max(60,bars*3))
    if up:
        candidates=sorted({float(x) for x in window["high"] if float(x)>c*1.001})
        level=candidates[0] if candidates else c+a*math.sqrt(max(1,bars/6))
        projected=c+a*math.sqrt(max(1,bars/6))*1.15
        return min(level,projected) if level>c else projected
    candidates=sorted({float(x) for x in window["low"] if float(x)<c*.999},reverse=True)
    level=candidates[0] if candidates else c-a*math.sqrt(max(1,bars/6))
    projected=c-a*math.sqrt(max(1,bars/6))*1.15
    return max(level,projected) if level<c else projected

def forecast(symbol,horizon,asset):
    horizon=str(horizon or "").lower()
    if horizon not in HORIZONS:
        raise ValueError("horizon must be 30m, 1h, 2h or 4h")
    cfg=HORIZONS[horizon]

    interval_minutes=5
    rr=MD43.fetch_intraday(symbol,"5m")
    if rr.frame.empty and horizon=="4h":
        interval_minutes=60
        rr=MD43.fetch_intraday(symbol,"1h")
    if rr.frame.empty:
        return {
            "status":"unavailable","symbol":symbol,"horizon":horizon,
            "label":cfg["label"],"reason":"Внутридневные данные сейчас недоступны.",
            "source":None,"errors":list(rr.errors or [])[-5:],
        }

    df,data_audit=DATA13.prepare(rr.frame,symbol,rr.source,interval_minutes=interval_minutes)
    df=df.tail(600).copy()
    bars=cfg["bars"]
    if interval_minutes==60 and horizon=="4h":
        bars=4
    signal_frame=SHORT17.contiguous_tail(df,interval_minutes)
    tech=_technical_score(df,bars,interval_minutes) if len(signal_frame)>=bars+1 else None
    if not tech:
        return {
            "status":"unavailable","symbol":symbol,"horizon":horizon,
            "label":cfg["label"],"reason":"Недостаточно непрерывных завершённых свечей текущего отрезка. Ночной разрыв не считается внутридневным импульсом.",
            "source":rr.source,"errors":[],
        }

    macro=0.0  # No independently validated intraday macro contribution.
    score=tech["score"]
    # Conservative technical direction score: numerically probability-shaped for
    # backward API compatibility, but not statistically calibrated as P(up).
    p_up=float(np.clip(.5+.15*np.tanh(score/1.65),.35,.65))
    up=p_up>=.5
    p_dir=p_up if up else 1-p_up
    target=_nearest_target(signal_frame,up,bars)
    movement=build_intraday_movement(df,horizon,interval_minutes)
    paths=SHORT17.path_diagnostics(df,horizon,interval_minutes,movement.get("material_move_threshold_pct"))

    tech_direction=1 if tech["score"]>=0 else -1
    macro_direction=1 if macro>=0 else -1
    if abs(macro)>=0.45 and macro_direction==(1 if up else -1) and cfg["macro_weight"]>=.10:
        reason=("Макро-факторы поддерживают рост в ближайшие часы."
                if up else "Макро-факторы усиливают давление в ближайшие часы.")
        reason_type="макро"
    elif abs(tech["score"])<.20:
        reason="Технические сигналы смешанные, преимущество небольшое."
        reason_type="смешанный"
    else:
        reason=("Техническая картина поддерживает рост в ближайшие часы."
                if up else "Техническая картина указывает на давление вниз в ближайшие часы.")
        reason_type="технический"

    confidence=float(np.clip(.24+abs(p_up-.5)*2.3, .24,.58))
    return {
        "status":"ok","symbol":symbol,"horizon":horizon,"label":cfg["label"],
        "p_up":round(p_up,4),"p_down":round(1-p_up,4),
        "technical_direction_score_up":round(p_up,4),
        "technical_direction_score_down":round(1-p_up,4),
        "probability_semantics":"uncalibrated_technical_direction_score",
        "calibrated_probability":False,
        "direction":"up" if up else "down",
        "direction_probability":round(p_dir,4),
        "target":round(float(target),8),
        "confidence_score":None,
        "confidence_status":"unconfirmed",
        "movement_guidance":movement,
        "path_diagnostics":paths,
        "target_semantics":"historical_level_not_calibrated_hit_target",
        "technical_score_points":round(p_dir*100,1),
        "signal_contiguous_bars":len(signal_frame),
        "interval_minutes":interval_minutes,
        "reference_price":float(df.close.iloc[-1]),
        "as_of_semantics":"last_completed_bar_start_utc",
        "intraday_contract_version":SHORT17.VERSION,
        "data_integrity":data_audit,
        "calculation_identity":{"key":DATA13.calculation_key(data_audit,horizon,"intraday","4.40.10.17",{"macro_bias":macro}),"mode":"intraday"},
        "reason":reason,"reason_type":reason_type,
        "source":rr.source,
        "as_of":pd.Timestamp(df.iloc[-1]["date"]).isoformat(timespec="minutes"),
        "technical":{
            "rsi14":round(tech["rsi"],2),
            "ema9":round(tech["ema9"],8),
            "ema21":round(tech["ema21"],8),
            "macd_hist":round(tech["macd_hist"],8),
            "score":round(tech["score"],4),
        },
        "macro_bias":round(macro,4),
        "research_only":True,
        "integrity_note":"Intraday output is a technical score, not a historically calibrated probability.",
    }
