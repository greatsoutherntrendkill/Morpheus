from pathlib import Path
from bs4 import BeautifulSoup

ROOT = Path(__file__).parent
html = (ROOT / 'site' / 'index.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html, 'html.parser')

expected = ['overview','markets','world','altdata','calendar','research','scenario','learning','valuation','deals','trainer']
assert [x.get('data-page-view') for x in soup.select('.page')] == expected
assert [x.get('data-page') for x in soup.select('.side-nav button')] == expected
assert soup.find('style', id='v412-signal-glass') is None
style = soup.find('style', id='signal-glass-v413')
assert style is not None
css = style.get_text()
for token in [
    '--bg:#070d0a', '--accent:#c0fb50', '--glass:', 'border-radius:24px',
    'backdrop-filter:blur(24px)', 'radial-gradient', '.deals-layout',
    '.valuation-layout', '.research-forecast-card', '.scenario-input-card',
    "grid-template-columns:210px minmax(0,1fr)", 'glassIn'
]:
    assert token in css, token
assert "localStorage.getItem('aa-theme-v413')||'signal'" in html
assert (ROOT / '.env').exists()
print('OK: v4.13 Signal Glass full-site design adaptation; sections/data preserved')
