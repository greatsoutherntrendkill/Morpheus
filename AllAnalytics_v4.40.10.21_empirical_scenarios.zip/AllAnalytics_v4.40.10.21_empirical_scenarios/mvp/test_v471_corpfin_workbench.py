
from __future__ import annotations
from pathlib import Path
import json, math

ROOT=Path(__file__).parent

def main():
    import corporate_finance_v471 as C

    assert {"AAPL","MSFT","KO","JPM"}.issubset(C.COMPANIES)
    for t,c in C.COMPANIES.items():
        assert c["revenue"]>0 and c["shares"]>0
        assert c["model"] in {"DCF","DDM"}

    tx=C.transactions()
    assert len(tx["mna"])>=3 and len(tx["ipo"])>=3
    for d in tx["mna"]:
        assert d["headline_value"]>0
        assert d["target_ebitda"]>0
        assert sum(d["financing"].values())==100

    cases=C.training_cases()
    assert len(cases)>=4
    for c in cases:
        assert c["tolerance"]>0
        assert "answer" in c and "formula" in c
    a=next(x for x in cases if x["title"]=="EV / EBITDA")
    expected=(a["raw"]["market_cap"]+a["raw"]["debt"]-a["raw"]["cash"])/a["raw"]["ebitda"]
    assert abs(expected-a["answer"])<1e-3

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    for token in [
        'data-page="valuation"','data-page="deals"','data-page="trainer"',
        'data-page-view="valuation"','data-page-view="deals"','data-page-view="trainer"',
        'Valuation <em>Sandbox.</em>','Деконструктор <em>сделок.</em>',
        'Тренажер <em>фреймворков.</em>',
        'Оборотный капитал','data-export-canvas="price-chart"',
        'data-export-canvas="market-chart"','SVG · вектор без фона',
        'PNG · прозрачный фон','corpfin_data.js?v=4.8'
    ]:
        assert token in html, token
    assert 'Видеть связи.<br>Понимать риск.' not in html
    assert "nwc_method" in html and "DSO + DIO − DPO" in html
    assert "dcfCalc" in html and "ddmCalc" in html
    assert "renderDealDetail" in html and "checkTrainer" in html

    lab=(ROOT/"site"/"technical_lab_v49.html").read_text(encoding="utf-8")
    for token in ["export-tech-chart","SVG · вектор без фона","PNG · прозрачный фон","techSvg()"]:
        assert token in lab, token

    api=(ROOT/"api.py").read_text(encoding="utf-8")
    for route in ["/api/corpfin/company","/api/corpfin/transactions","/api/trainer/cases"]:
        assert route in api

    data=json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))
    assert data["ui_version"]=="4.8"
    assert data["scenario_core_version"]=="4.7"

    print("OK: v4.7.1 valuation sandbox + deals/IPO + vector export + framework trainer")

if __name__=="__main__":
    main()
