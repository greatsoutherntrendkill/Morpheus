from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd

import distribution_feedback_v440 as DIST
import evidence_readiness_v4401 as READY
import evidence_store_v4401 as STORE
import prospective_feedback_v436 as DIR


def _history(as_of='2026-01-15'):
    idx = pd.bdate_range(end=as_of, periods=40)
    return [{'t': str(d.date()), 'c': 100.0 + i} for i, d in enumerate(idx)]


def _direction_row(as_of='2026-01-15'):
    return {
        'symbol': 'AAPL', 'as_of': as_of, 'history': _history(as_of), 'model': 'AllAnalytics',
        'forecasts': {'5': {
            'p_up': .62, 'p_down': .38, 'abstain': False, 'signal_strength': 'слабый',
            'signal_threshold': .58, 'regime': 'trend_up|normal_vol', 'model_version': 'test-v1',
            'components': [], 'reliability': {'probability': .60},
        }}
    }


def _distribution_row(as_of='2026-01-15'):
    return {
        'symbol': 'AAPL', 'as_of': as_of, 'history': _history(as_of),
        'forecasts': {'5': {
            'regime': 'trend_up|normal_vol',
            'asset_specialist': {'asset_class': 'equity'},
            'event_response': {'status': 'ok', 'event': {'type': 'fed_rate', 'actor': 'FED'}},
            'distribution_version': 'distributional-v4.40',
            'distribution_forecast': {
                'version': 'distributional-v4.40', 'status': 'ok', 'quality_ok': True,
                'quantiles': {
                    'q10_return_pct': -3.0, 'q25_return_pct': -1.0, 'q50_return_pct': .5,
                    'q75_return_pct': 2.0, 'q90_return_pct': 4.0,
                },
                'expected_abs_move_pct': 2.1, 'evaluation': {}, 'calibration': {}, 'options_benchmark': {},
            }
        }}
    }


def test_default_store_can_be_outside_release(monkeypatch, tmp_path):
    root = tmp_path / 'AllAnalytics_Data' / 'evidence'
    monkeypatch.setenv('ALLANALYTICS_EVIDENCE_DIR', str(root))
    assert STORE.evidence_root() == root.resolve()
    assert STORE.ledger_path('x.sqlite3').parent == root.resolve()
    assert STORE.store_status()['persistent'] is True


def test_distribution_v2_records_point_in_time_context(tmp_path):
    led = DIST.Ledger(tmp_path / 'distribution.sqlite3')
    rec = led.record_row(_distribution_row(), 'test')
    assert rec['inserted'] == 1
    row = led.rows(limit=1)[0]
    assert row['asset_class'] == 'equity'
    assert row['regime'] == 'trend_up|normal_vol'
    assert row['event_active'] == 1
    assert row['event_type'] == 'fed_rate'
    assert row['event_actor'] == 'FED'


def test_directional_legacy_migration_is_idempotent(monkeypatch, tmp_path):
    legacy = tmp_path / 'old' / 'prospective_feedback_v436.sqlite3'
    legacy.parent.mkdir()
    old = DIR.Ledger(legacy)
    assert old.record_row(_direction_row(), 'legacy')['inserted'] == 1

    target = tmp_path / 'persistent' / 'directional_feedback.sqlite3'
    monkeypatch.setenv('ALLANALYTICS_FEEDBACK_DB', str(target))
    monkeypatch.setattr(STORE, 'legacy_db_candidates', lambda *a, **k: [legacy])
    first = DIR.Ledger()
    assert first.status()['forecasts'] == 1
    assert first.migration_report['forecasts_imported'] == 1
    second = DIR.Ledger()
    assert second.status()['forecasts'] == 1
    assert second.migration_report['forecasts_imported'] == 0


def test_distribution_forward_migrates_old_v440_schema(monkeypatch, tmp_path):
    legacy = tmp_path / 'old' / 'distribution_feedback_v440.sqlite3'
    legacy.parent.mkdir()
    con = sqlite3.connect(legacy)
    con.executescript('''
    CREATE TABLE distribution_forecast_ledger(
      id INTEGER PRIMARY KEY AUTOINCREMENT, forecast_key TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL,
      symbol TEXT NOT NULL,horizon INTEGER NOT NULL,data_as_of TEXT NOT NULL,entry_price REAL NOT NULL,
      distribution_version TEXT NOT NULL,q10 REAL NOT NULL,q25 REAL NOT NULL,q50 REAL NOT NULL,q75 REAL NOT NULL,q90 REAL NOT NULL,
      expected_abs_move REAL,quality_ok INTEGER NOT NULL,options_json TEXT NOT NULL,diagnostics_json TEXT NOT NULL,origin TEXT NOT NULL);
    CREATE TABLE distribution_settlement_ledger(
      id INTEGER PRIMARY KEY AUTOINCREMENT,forecast_id INTEGER NOT NULL UNIQUE,settled_at TEXT NOT NULL,target_as_of TEXT NOT NULL,
      target_price REAL NOT NULL,realized_return_pct REAL NOT NULL,covered50 INTEGER NOT NULL,covered80 INTEGER NOT NULL,
      pinball_mean REAL NOT NULL,crps_like REAL NOT NULL,median_abs_error REAL NOT NULL,abs_move_error REAL);
    ''')
    con.execute("INSERT INTO distribution_forecast_ledger(forecast_key,created_at,symbol,horizon,data_as_of,entry_price,distribution_version,q10,q25,q50,q75,q90,expected_abs_move,quality_ok,options_json,diagnostics_json,origin) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                ('abc','2026-01-15T00:00:00Z','AAPL',5,'2026-01-15',100,'v4.40',-3,-1,.5,2,4,2.1,1,'{}','{}','legacy'))
    con.execute("INSERT INTO distribution_settlement_ledger(forecast_id,settled_at,target_as_of,target_price,realized_return_pct,covered50,covered80,pinball_mean,crps_like,median_abs_error,abs_move_error) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (1,'2026-01-23T00:00:00Z','2026-01-22',102,1.98,1,1,.4,.8,1.48,.12))
    con.commit(); con.close()

    target = tmp_path / 'persistent' / 'distribution_feedback.sqlite3'
    monkeypatch.setenv('ALLANALYTICS_DISTRIBUTION_FEEDBACK_DB', str(target))
    monkeypatch.setattr(STORE, 'legacy_db_candidates', lambda *a, **k: [legacy])
    led = DIST.Ledger()
    st = led.status()
    assert st['forecasts'] == 1 and st['settled'] == 1
    row = led.rows(limit=1, settled_only=True)[0]
    assert row['asset_class'] is None and row['regime'] is None and row['event_active'] == 0


def test_readiness_requires_dates_and_context_not_only_row_count(monkeypatch):
    rows = []
    dates = pd.bdate_range('2026-01-02', periods=50)
    for i, d in enumerate(dates):
        for j in range(8):
            rows.append({
                'data_as_of': str(d.date()), 'horizon': 5 if j < 4 else 10,
                'regime': 'trend_up|normal_vol' if j % 2 == 0 else 'range|high_vol',
                'asset_class': 'equity' if j < 6 else 'crypto',
                'event_active': 1 if i % 10 == 0 else 0,
                'event_type': 'fed_rate' if i % 10 == 0 else None,
                'covered50': 1 if j % 2 == 0 else 0,
                'covered80': 0 if j == 0 else 1,
                'pinball_mean': .5, 'median_abs_error': 1.2,
            })
    monkeypatch.setattr(READY.DIST.LEDGER, 'rows', lambda **k: rows)
    monkeypatch.setattr(READY.DIST, 'status', lambda: {'forecasts': 400, 'settled': 400, 'persistent_store': True})
    monkeypatch.setattr(READY.DIRECTION, 'status', lambda: {'forecasts': 400, 'settled': 400, 'persistent_store': True})
    monkeypatch.setattr(READY.STORE, 'store_status', lambda: {'persistent': True, 'writable': True, 'root': '/tmp/evidence'})
    report = READY.readiness()
    assert report['ready_for_v441_regime_review'] is True
    assert report['ready_for_v441_event_review'] is True
    assert report['label'] == 'READY'
    assert report['base_evidence']['unique_forecast_dates'] == 50
    assert report['mature_segment_counts']['regimes'] >= 2


def test_v4401_api_and_ui_contract():
    root = Path(__file__).parent
    api = (root / 'api.py').read_text(encoding='utf-8')
    ui = (root / 'site' / 'technical_lab_v411.html').read_text(encoding='utf-8')
    assert '/api/models/evidence-v4401/status' in api
    assert '/api/models/evidence-v4401/readiness' in api
    assert 'Model Evidence / Readiness v4.40.1' in ui
    assert 'loadEvidenceReadinessV4401' in ui
