"""
models.py — аналитический движок AllAnalytics v3.1.

Ключевые принципы:
- исторический сценарий != ML-прогноз;
- ML оценивается только walk-forward / out-of-sample;
- directional bias публикуется только после quality gate;
- поддерживаются горизонты 1/5/10/20 торговых дней;
- вероятности сопровождаются Brier skill, calibration error и block-bootstrap CI;
- overlapping H-day targets не считаются независимыми: есть non-overlap stream и effective N.

Ни одна функция не обещает точную будущую цену.
"""
from __future__ import annotations

import os
import numpy as np
import pandas as pd
import temporal_validation_v4401012 as TV

import target_contract_v4405 as TARGET4405
import freshness_contract_v4409 as FRESH4409
import champion_validation_v44010 as CV44010


# ---------------------------------------------------------------------------
# ИСТОРИЧЕСКИЙ СЦЕНАРИЙ: block bootstrap вместо Gaussian random walk
# ---------------------------------------------------------------------------
def scenario_paths(close: pd.Series, horizon=10, n_sims=3000, seed=42, block_size=5):
    """Историческое распределение сценариев через block bootstrap лог-доходностей.

    В отличие от нормального random walk не навязывает Gaussian tails и частично
    сохраняет краткосрочные кластеры доходностей. Это НЕ forecast model: результат
    отвечает на вопрос «что давала похожая историческая вариативность».
    """
    r = np.log(close / close.shift(1)).dropna().to_numpy(dtype=float)
    if len(r) < 60:
        return None, None
    last = float(close.iloc[-1])
    rng = np.random.default_rng(seed)
    bs = max(1, min(int(block_size), len(r), horizon))
    max_start = max(1, len(r) - bs + 1)
    sims = np.empty((n_sims, horizon), dtype=float)
    for i in range(n_sims):
        chunks = []
        while sum(len(x) for x in chunks) < horizon:
            st = int(rng.integers(0, max_start))
            chunks.append(r[st:st + bs])
        sims[i] = np.concatenate(chunks)[:horizon]
    paths = last * np.exp(np.cumsum(sims, axis=1))
    pct = np.percentile(paths, [5, 25, 50, 75, 95], axis=0)
    fan = pd.DataFrame({
        "step": np.arange(1, horizon + 1),
        "p05": pct[0], "p25": pct[1], "p50": pct[2],
        "p75": pct[3], "p95": pct[4],
    })
    end = paths[:, -1]
    summary = {
        "last": last,
        "p_up": float((end > last).mean()),
        "exp_move_pct": float((np.median(end) / last - 1) * 100),
        "lo_pct": float((np.percentile(end, 10) / last - 1) * 100),
        "hi_pct": float((np.percentile(end, 90) / last - 1) * 100),
        "method": "historical_block_bootstrap",
        "block_size": bs,
    }
    return fan, summary


# ---------------------------------------------------------------------------
# РЕЖИМ РЫНКА — интерпретируемый контекст, не торговый сигнал
# ---------------------------------------------------------------------------
def regime(close: pd.Series) -> dict:
    if len(close) < 210:
        return {}
    ma50 = close.rolling(50).mean().iloc[-1]
    ma200 = close.rolling(200).mean().iloc[-1]
    price = float(close.iloc[-1])
    if price > ma200 and ma50 > ma200:
        trend = "восходящий"
    elif price < ma200 and ma50 < ma200:
        trend = "нисходящий"
    else:
        trend = "боковой / смена"
    r = np.log(close / close.shift(1)).dropna()
    vol20 = r.rolling(20).std().dropna()
    if vol20.empty:
        return {"Тренд (MA200)": trend}
    cur = vol20.iloc[-1]
    pctile = float((vol20 < cur).mean() * 100)
    volband = "низкая" if pctile < 33 else "высокая" if pctile > 66 else "средняя"
    mom20 = float((close.iloc[-1] / close.iloc[-21] - 1) * 100)
    return {
        "Тренд (MA200)": trend,
        "Волатильность": f"{volband} ({pctile:.0f}-й перцентиль)",
        "Моментум 20д, %": round(mom20, 1),
    }


# ---------------------------------------------------------------------------
# ЛОГИСТИЧЕСКАЯ РЕГРЕССИЯ на numpy — L2 + стандартизация
# ---------------------------------------------------------------------------
class LogReg:
    def __init__(self, lr=0.25, n_iter=350, l2=2e-2):
        self.lr, self.n_iter, self.l2 = lr, n_iter, l2

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        self.mu = X.mean(0)
        self.sd = X.std(0) + 1e-9
        Xs = np.c_[np.ones(len(X)), (X - self.mu) / self.sd]
        w = np.zeros(Xs.shape[1])
        y = np.asarray(y, float)
        for _ in range(self.n_iter):
            z = np.clip(Xs @ w, -30, 30)
            p = 1 / (1 + np.exp(-z))
            reg = self.l2 * np.r_[0.0, w[1:]]
            w -= self.lr * (Xs.T @ (p - y) / len(y) + reg)
        self.w = w
        return self

    def proba(self, X):
        X = np.asarray(X, dtype=float)
        Xs = np.c_[np.ones(len(X)), (X - self.mu) / self.sd]
        return 1 / (1 + np.exp(-np.clip(Xs @ self.w, -30, 30)))


# ---------------------------------------------------------------------------
# ПРИЗНАКИ
# ---------------------------------------------------------------------------
def build_features(close: pd.Series, dxy: pd.Series | None = None,
                   macro: pd.DataFrame | None = None) -> pd.DataFrame:
    r = np.log(close / close.shift(1))
    f = pd.DataFrame(index=close.index)
    f["r1"] = r
    f["mom5"] = np.log(close / close.shift(5))
    f["mom20"] = np.log(close / close.shift(20))
    f["mom60"] = np.log(close / close.shift(60))
    f["vol20"] = r.rolling(20).std()
    f["vol60"] = r.rolling(60).std()
    f["vol_ratio"] = f["vol20"] / f["vol60"].replace(0, np.nan)
    f["dist_ma50"] = close / close.rolling(50).mean() - 1
    f["dist_ma200"] = close / close.rolling(200).mean() - 1
    freshness_sources = {}
    as_of = close.index[-1] if len(close) else None
    if dxy is not None and len(dxy) > 60:
        # v4.40.9: never forward-fill a market factor indefinitely. Five target
        # trading rows is enough to bridge provider/calendar gaps without turning
        # an old DXY observation into a current feature.
        d = FRESH4409.bounded_reindex_series(dxy, close.index, FRESH4409.MARKET_FILL_LIMIT).shift(1)
        f["dxy_ret20"] = np.log(d / d.shift(20))
        freshness_sources["dxy"] = FRESH4409.source_meta(
            "dxy", dxy, as_of, warning_days=FRESH4409.MARKET_WARNING_DAYS,
            hard_days=FRESH4409.MARKET_HARD_DAYS, critical=True)
    if macro is not None and not macro.empty:
        # Monthly/slow macro data is allowed a longer carry window, but it is
        # still bounded and its actual source age is retained as metadata.
        mf = FRESH4409.bounded_reindex_frame(macro, close.index, FRESH4409.MACRO_FILL_LIMIT)
        f = f.join(mf)
        for c in macro.columns:
            freshness_sources[f"macro:{c}"] = FRESH4409.source_meta(
                f"macro:{c}", macro[c], as_of, warning_days=FRESH4409.MACRO_WARNING_DAYS,
                hard_days=FRESH4409.MACRO_HARD_DAYS, critical=False)
    f = f.replace([np.inf, -np.inf], np.nan)
    f.attrs["freshness"] = FRESH4409.summarize_sources(freshness_sources)
    from verified_extensions_v4401016 import core_features
    return core_features(f)




# ---------------------------------------------------------------------------
# v4.40.5+ — единая семантика цели из одного target contract
# ---------------------------------------------------------------------------
TARGET_NEUTRAL_SIGMA = TARGET4405.NEUTRAL_SIGMA
TARGET_MIN_ABS_MOVE = TARGET4405.MIN_ABS_MOVE
TARGET_MAX_ABS_MOVE = TARGET4405.MAX_ABS_MOVE
TARGET_VERSION = TARGET4405.TARGET_VERSION


def directional_target_frame(close: pd.Series, horizon: int, neutral_sigma: float = TARGET_NEUTRAL_SIGMA) -> pd.DataFrame:
    return TARGET4405.target_frame(close, horizon, neutral_sigma=neutral_sigma)


def movement_probability(states) -> float:
    """Legacy historical prior retained only as an explicit fallback.

    v4.40.6 production neutral mass is estimated by a learned Move/No-Move
    classifier. This helper must not be treated as a live model probability.
    """
    st = np.asarray(states, float)
    st = st[np.isfinite(st)]
    if not len(st):
        return 0.5
    moves = int(np.sum(st != 0))
    p = (moves + 8.0) / (len(st) + 16.0)
    return float(np.clip(p, 0.18, 0.92))


class _ProbCalibrator:
    def __init__(self, coef: float, intercept: float):
        self.coef=float(coef); self.intercept=float(intercept)
    def apply(self, p):
        q=np.clip(np.asarray(p,float),1e-5,1-1e-5)
        z=np.log(q/(1-q))
        return 1/(1+np.exp(-np.clip(self.intercept+self.coef*z,-30,30)))


def _fit_probability_calibrator(p, y, min_n: int = 45):
    p=np.asarray(p,float); y=np.asarray(y,float)
    ok=np.isfinite(p)&np.isfinite(y); p,y=p[ok],y[ok]
    if len(p)<int(min_n) or len(np.unique(y))<2:
        return None
    try:
        from sklearn.linear_model import LogisticRegression
        q=np.clip(p,1e-5,1-1e-5)
        z=np.log(q/(1-q)).reshape(-1,1)
        mdl=LogisticRegression(C=1.0,max_iter=280,solver="lbfgs",random_state=4406).fit(z,y.astype(int))
        return _ProbCalibrator(float(mdl.coef_[0,0]),float(mdl.intercept_[0]))
    except Exception:
        return None

def _ece(proba: np.ndarray, y: np.ndarray, bins=10) -> float:
    """Expected calibration error: 0 = идеальная калибровка."""
    if len(proba) == 0:
        return float("nan")
    edges = np.linspace(0, 1, bins + 1)
    total = len(proba)
    err = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (proba >= lo) & (proba < hi if hi < 1 else proba <= hi)
        if mask.any():
            err += mask.mean() * abs(float(proba[mask].mean()) - float(y[mask].mean()))
    return float(err)




def _metric_bundle(proba: np.ndarray, y: np.ndarray, base_probs: np.ndarray) -> dict:
    """Core probabilistic metrics for one evaluation stream."""
    proba=np.asarray(proba,float); y=np.asarray(y,float); base_probs=np.asarray(base_probs,float)
    if len(proba)==0:
        return {"acc":np.nan,"base":np.nan,"edge":np.nan,"brier":np.nan,"brier_base":np.nan,"brier_skill":np.nan,"ece":np.nan}
    pred=(proba>=0.5).astype(float)
    base_pred=(base_probs>=0.5).astype(float)
    acc=float((pred==y).mean())
    base=float((base_pred==y).mean())
    brier=float(np.mean((proba-y)**2))
    brier_base=float(np.mean((base_probs-y)**2))
    bskill=float((1-brier/brier_base)*100) if brier_base>1e-12 else 0.0
    return {"acc":acc,"base":base,"edge":(acc-base)*100,"brier":brier,"brier_base":brier_base,"brier_skill":bskill,"ece":_ece(proba,y)}


def _nonoverlap_indices(n: int, horizon: int) -> np.ndarray:
    """Deterministic non-overlapping OOS stream: one forecast every H rows.

    This intentionally sacrifices sample size so an H-day label is not counted as H
    independent daily observations. The full stream remains available for diagnostics.
    """
    h=max(1,int(horizon))
    return np.arange(0,int(n),h,dtype=int)


def _phase_nonoverlap_metrics(proba: np.ndarray, y: np.ndarray, base_probs: np.ndarray, horizon: int) -> tuple[dict, int, int]:
    """Robust non-overlap point estimate across all H possible phases.

    Each phase (0, H, 2H...), (1, H+1, ...) contains internally non-overlapping
    forward labels. Reporting the median across phases avoids making the result depend
    on an arbitrary choice of the first OOS date. Effective N is still capped at ~N/H.
    """
    n=len(proba); h=max(1,int(horizon))
    if n==0:
        return _metric_bundle(np.array([]),np.array([]),np.array([])),0,0
    metrics=[]; sizes=[]
    for phase in range(min(h,n)):
        ii=np.arange(phase,n,h,dtype=int)
        if len(ii)<2:
            continue
        metrics.append(_metric_bundle(proba[ii],y[ii],base_probs[ii]))
        sizes.append(len(ii))
    if not metrics:
        ii=_nonoverlap_indices(n,h)
        return _metric_bundle(proba[ii],y[ii],base_probs[ii]),len(ii),1
    keys=metrics[0].keys()
    med={k:float(np.nanmedian([m[k] for m in metrics])) for k in keys}
    return med,int(np.median(sizes)),len(metrics)


def _autocorr_ess(x: np.ndarray, max_lag: int) -> float:
    """Conservative effective sample size using positive serial correlation only."""
    x=np.asarray(x,float)
    n=len(x)
    if n<3:
        return float(n)
    x=x-np.nanmean(x)
    var=float(np.nanvar(x))
    if not np.isfinite(var) or var<1e-14:
        return float(n)
    s=0.0
    L=min(max(1,int(max_lag)),n-2)
    for k in range(1,L+1):
        a=x[:-k]; b=x[k:]
        if len(a)<2: break
        rho=float(np.nanmean(a*b)/var)
        if not np.isfinite(rho): continue
        # Positive dependence reduces evidence. Negative correlation is not used to
        # inflate the effective N.
        if rho>0:
            s += (1-k/n)*rho
    return float(max(1.0,min(n,n/(1+2*s))))


def _effective_oos_n(proba: np.ndarray, y: np.ndarray, base_probs: np.ndarray, horizon: int) -> int:
    """Effective evidence count for overlapping H-day forecasts.

    The cap at ceil(N/H) is deliberate: regardless of low empirical autocorrelation,
    H-day targets built every day share future returns and must not be presented as N
    independent trials.
    """
    n=len(proba); h=max(1,int(horizon))
    if n==0: return 0
    loss_diff=(base_probs-y)**2-(proba-y)**2
    ess=_autocorr_ess(loss_diff,max_lag=max(h-1,1))
    overlap_cap=max(1,int(n//h)) if h>1 else n
    return int(max(1,min(overlap_cap,int(np.floor(ess)))))


def _moving_block_bootstrap_ci(proba: np.ndarray, y: np.ndarray, base_probs: np.ndarray,
                               horizon: int, n_boot: int=500, seed: int=42) -> dict:
    """95% moving-block bootstrap intervals preserving serial/overlap dependence.

    Blocks are at least H observations long, so the resampling unit respects the
    dependence induced by overlapping H-day forward labels.
    """
    p=np.asarray(proba,float); yt=np.asarray(y,float); bp=np.asarray(base_probs,float)
    n=len(p)
    if n<20:
        return {}
    block=max(1,min(n,max(int(horizon),5)))
    rng=np.random.default_rng(seed+31*int(horizon)+n)
    vals={k:[] for k in ("acc","base","edge","brier_skill","ece")}
    max_start=max(1,n-block+1)
    for _ in range(int(n_boot)):
        idx=[]
        while len(idx)<n:
            st=int(rng.integers(0,max_start))
            idx.extend(range(st,min(st+block,n)))
        ii=np.asarray(idx[:n],dtype=int)
        m=_metric_bundle(p[ii],yt[ii],bp[ii])
        for k in vals: vals[k].append(m[k])
    out={"block_size":block,"n_boot":int(n_boot)}
    for k,a in vals.items():
        a=np.asarray(a,float)
        out[k+"_low"]=float(np.nanpercentile(a,2.5))
        out[k+"_high"]=float(np.nanpercentile(a,97.5))
    return out


def quality_gate(scorecard: dict | None, live_p: float | None) -> dict:
    """Publish directional bias only when skill is credible after dependence correction.

    v2.9 deliberately gates on effective/non-overlapping evidence and on the lower
    95% bootstrap bound, not on a favourable raw point estimate.
    """
    if not scorecard or live_p is None:
        return {"trusted":False,"confidence":"низкая","bias":"neutral",
                "label":"нет подтвержденного сигнала","reason":"недостаточно данных"}

    n_eff=int(scorecard.get("Наблюдений (effective)",0))
    edge=float(scorecard.get("Преимущество non-overlap, п.п.",-999))
    bskill=float(scorecard.get("Brier skill non-overlap, %",-999))
    ece=float(scorecard.get("Calibration error non-overlap",1.0))
    edge_lo=float(scorecard.get("Edge CI95 low, п.п.",-999))
    bskill_lo=float(scorecard.get("Brier skill CI95 low, %",-999))

    trusted=(n_eff>=30 and edge>0 and bskill>0 and edge_lo>0 and bskill_lo>0 and ece<=0.15)
    if trusted and n_eff>=80 and edge_lo>=1.0 and bskill_lo>=1.0 and ece<=0.08:
        conf="высокая"
    elif trusted:
        conf="средняя"
    else:
        conf="низкая"

    if trusted and live_p>=0.56:
        bias,label="bullish","бычий уклон"
    elif trusted and live_p<=0.44:
        bias,label="bearish","медвежий уклон"
    else:
        bias,label="neutral","нейтрально"

    if not trusted:
        reason="недостаточно независимого OOS evidence или 95% CI skill включает ноль"
    elif bias=="neutral":
        reason="модель прошла статистический gate, но вероятность близка к 50%"
    else:
        reason="non-overlap skill и нижние 95% CI проходят пороги"
    return {"trusted":trusted,"confidence":conf,"bias":bias,"label":label,"reason":reason}


# ---------------------------------------------------------------------------
# WALK-FORWARD на любом горизонте
# ---------------------------------------------------------------------------
def _purged_train_indices(label_end_dates, prediction_date, t: int) -> np.ndarray:
    """Indices whose forward label is fully observable at prediction time.

    `label_end_dates` is chronological, so searchsorted gives the legal prefix in O(log N).
    A row j is legal only when its H-day target ended strictly before prediction date T.
    """
    le = np.asarray(label_end_dates, dtype="datetime64[ns]")
    pred = np.datetime64(pd.Timestamp(prediction_date), "ns")
    cutoff = int(np.searchsorted(le, pred, side="left"))
    cutoff = min(cutoff, int(t))
    return np.arange(cutoff, dtype=int)


def _resolve_final_holdout_start(dates, min_train: int) -> pd.Timestamp | None:
    """Fixed final holdout boundary for this model generation.

    The default is intentionally date-based (not "last 20%"), so repeated runs do
    not slide the final test window and quietly turn yesterday's holdout into train.
    """
    d = pd.DatetimeIndex(pd.to_datetime(dates))
    if len(d) < min_train + 80:
        return None
    raw = os.getenv("FINAL_HOLDOUT_START", "2026-04-01").strip()
    try:
        start = pd.Timestamp(raw).normalize()
    except Exception:
        start = pd.Timestamp("2026-04-01")
    pos = int(np.searchsorted(d.values, np.datetime64(start), side="left"))
    # If the configured boundary leaves too little development history, disable
    # the holdout rather than silently moving it.
    if pos < min_train + 60 or pos >= len(d) - 20:
        return None
    return start


def _frozen_holdout_train_indices(label_end_dates, dates, holdout_start, t: int) -> np.ndarray:
    """Legal labels for holdout prediction, frozen strictly before holdout start."""
    legal = _purged_train_indices(label_end_dates, dates[t], t)
    if holdout_start is None:
        return legal
    cutoff = int(np.searchsorted(
        np.asarray(dates, dtype="datetime64[ns]"),
        np.datetime64(pd.Timestamp(holdout_start), "ns"),
        side="left",
    ))
    return legal[(legal < cutoff) & (np.asarray(label_end_dates, dtype="datetime64[ns]")[legal] < np.datetime64(pd.Timestamp(holdout_start), "ns"))]


def walk_forward_direction(close: pd.Series, dxy: pd.Series | None = None,
                           macro: pd.DataFrame | None = None, horizon=1,
                           min_train=220, retrain_every=20, bootstrap_resamples=500) -> dict:
    """Purged directional validation on the shared three-state target.

    The classifier learns P(up | material move).  Neutral moves never become fake
    down labels.  The published ``live_p_up`` remains backward-compatible as a
    soft directional score around 50% and is shrunk by P(material move); the exact
    neutral probability and conditional probability are returned separately.
    """
    horizon = int(horizon)
    feats = build_features(close, dxy, macro)
    target = directional_target_frame(close, horizon)

    df = feats.copy().join(target)
    df["date"] = df.index
    required = list(feats.columns) + ["ret_fwd", "threshold", "state", "label_end"]
    df = df.dropna(subset=required)
    if len(df) < min_train + 60:
        return {}

    df = df[pd.to_datetime(df.label_end) < TV.SEALED_START].copy()
    Xcols = list(feats.columns)
    X = df[Xcols].to_numpy(dtype=float)
    state = df["state"].to_numpy(dtype=float)
    y_dir = np.where(state > 0, 1.0, np.where(state < 0, 0.0, np.nan))
    y_move = (state != 0).astype(float)
    rf = df["ret_fwd"].to_numpy(dtype=float)
    dates = pd.to_datetime(df["date"]).to_numpy()
    label_ends = pd.to_datetime(df["label_end"]).to_numpy()
    n = len(df)
    min_directional = max(70, int(min_train * 0.60))

    holdout_start = _resolve_final_holdout_start(dates, min_train)
    holdout_pos = (n if holdout_start is None else int(np.searchsorted(
        np.asarray(dates, dtype="datetime64[ns]"),
        np.datetime64(holdout_start, "ns"), side="left")))

    p_cond = np.full(n, np.nan)
    p_soft = np.full(n, np.nan)
    p_move_arr = np.full(n, np.nan)
    base_probs = np.full(n, np.nan)
    base_move_probs = np.full(n, np.nan)
    train_sizes = np.zeros(n, dtype=int)

    dev_model = None
    dev_move_model = None
    last_retrain_t = None
    frozen_model = None
    frozen_move_model = None
    frozen_base = None
    frozen_move_base = None
    frozen_train_max_date = None
    dev_solver_diag = None
    dev_move_solver_diag = None
    frozen_solver_diag = None
    frozen_move_solver_diag = None

    for t in range(n):
        is_holdout = holdout_start is not None and t >= holdout_pos
        train_idx = (_frozen_holdout_train_indices(label_ends, dates, holdout_start, t)
                     if is_holdout else _purged_train_indices(label_ends, dates[t], t))
        if len(train_idx) < min_train:
            continue
        directional = train_idx[np.isfinite(y_dir[train_idx])]
        if len(directional) < min_directional or len(np.unique(y_dir[directional])) < 2:
            continue

        move_y = y_move[train_idx]
        move_can_fit = len(np.unique(move_y)) >= 2
        if is_holdout:
            if frozen_model is None:
                frozen_model, frozen_solver_diag = CV44010.fit_chronological_selected(
                    X[directional], y_dir[directional], dates=dates[directional],
                    label_ends=label_ends[directional], seed=44010 + horizon
                )
                frozen_base = float(np.mean(y_dir[directional]))
                frozen_train_max_date = str(pd.Timestamp(dates[directional[-1]]).date())
            if frozen_move_model is None and move_can_fit:
                frozen_move_model, frozen_move_solver_diag = CV44010.fit_chronological_selected(
                    X[train_idx], move_y, dates=dates[train_idx], label_ends=label_ends[train_idx],
                    seed=44110 + horizon
                )
                frozen_move_base = float(np.mean(move_y))
            raw = float(frozen_model.proba(X[t:t + 1])[0])
            pmove = float(frozen_move_model.proba(X[t:t + 1])[0]) if frozen_move_model is not None else movement_probability(state[train_idx])
            base_probs[t] = frozen_base
            base_move_probs[t] = frozen_move_base if frozen_move_base is not None else movement_probability(state[train_idx])
            train_sizes[t] = len(directional)
        else:
            base_probs[t] = float(np.mean(y_dir[directional]))
            base_move_probs[t] = float(np.mean(move_y))
            train_sizes[t] = len(directional)
            if dev_model is None or last_retrain_t is None or (t-last_retrain_t) >= retrain_every:
                dev_model, dev_solver_diag = CV44010.fit_chronological_selected(
                    X[directional], y_dir[directional], dates=dates[directional],
                    label_ends=label_ends[directional], seed=44210 + horizon
                )
                if move_can_fit:
                    dev_move_model, dev_move_solver_diag = CV44010.fit_chronological_selected(
                        X[train_idx], move_y, dates=dates[train_idx], label_ends=label_ends[train_idx],
                        seed=44310 + horizon
                    )
                else:
                    dev_move_model = None; dev_move_solver_diag = None
                last_retrain_t = t
            raw = float(dev_model.proba(X[t:t + 1])[0])
            pmove = float(dev_move_model.proba(X[t:t + 1])[0]) if dev_move_model is not None else movement_probability(state[train_idx])
        p_cond[t] = raw
        p_move_arr[t] = float(np.clip(pmove,.03,.97))
        p_soft[t] = float(np.clip(.5 + p_move_arr[t] * (raw - .5), .02, .98))

    all_mask = np.isfinite(p_cond)
    date_idx = pd.DatetimeIndex(pd.to_datetime(dates))
    if holdout_start is None:
        dev_mask = all_mask
        hold_mask = np.zeros(n, dtype=bool)
    else:
        dev_mask = all_mask & (date_idx < holdout_start) & (pd.DatetimeIndex(label_ends) < holdout_start)
        hold_mask = all_mask & (date_idx >= holdout_start)

    dir_dev = dev_mask & np.isfinite(y_dir) & np.isfinite(base_probs)
    if int(dir_dev.sum()) < 30:
        return {}

    # ---------- development / quality-gate metrics: significant outcomes only ----------
    p = p_cond[dir_dev]
    yt = y_dir[dir_dev]
    rft = rf[dir_dev]
    bp = base_probs[dir_dev]
    raw_m = _metric_bundle(p, yt, bp)
    no_m, n_nonoverlap, n_phases = _phase_nonoverlap_metrics(p, yt, bp, horizon)
    n_eff = _effective_oos_n(p, yt, bp, horizon)
    boot = _moving_block_bootstrap_ci(p, yt, bp, horizon=horizon,
                                      n_boot=int(bootstrap_resamples), seed=42)

    # Rolling recent OOS audit complements (never replaces) the immutable final
    # holdout.  This prevents the quality view from becoming stale as the market
    # evolves, while keeping model selection off the frozen audit window.
    recent_oos = {"enabled": False, "used_for_quality_gate": False, "window_n": 0}
    recent_n = min(len(p), 120)
    if recent_n >= 30:
        rp, ry, rb = p[-recent_n:], yt[-recent_n:], bp[-recent_n:]
        rno, rn, rphases = _phase_nonoverlap_metrics(rp, ry, rb, horizon)
        rboot = _moving_block_bootstrap_ci(rp, ry, rb, horizon=horizon,
                                           n_boot=int(bootstrap_resamples), seed=2718)
        recent_dates = pd.DatetimeIndex(pd.to_datetime(dates[dir_dev]))[-recent_n:]
        recent_oos = {
            "enabled": True, "used_for_quality_gate": False, "window_n": int(recent_n),
            "n_nonoverlap": int(rn), "phases": int(rphases),
            "start": str(pd.Timestamp(recent_dates[0]).date()),
            "end": str(pd.Timestamp(recent_dates[-1]).date()),
            "acc": round(rno["acc"]*100, 1), "base": round(rno["base"]*100, 1),
            "edge": round(rno["edge"], 1), "brier_skill": round(rno["brier_skill"], 1),
            "ece": round(rno["ece"], 3),
            "edge_ci": [round(rboot.get("edge_low", np.nan), 1), round(rboot.get("edge_high", np.nan), 1)] if rboot else None,
            "brier_skill_ci": [round(rboot.get("brier_skill_low", np.nan), 1), round(rboot.get("brier_skill_high", np.nan), 1)] if rboot else None,
            "bootstrap_block_size": int((rboot or {}).get("block_size", max(1,horizon))),
        }

    # ---------- Move / No-Move model audit ----------
    move_dev = dev_mask & np.isfinite(p_move_arr) & np.isfinite(base_move_probs)
    move_metrics = _metric_bundle(p_move_arr[move_dev], y_move[move_dev], base_move_probs[move_dev]) if int(move_dev.sum()) else {}
    move_no, move_nonoverlap_n, move_phases = _phase_nonoverlap_metrics(
        p_move_arr[move_dev], y_move[move_dev], base_move_probs[move_dev], horizon
    ) if int(move_dev.sum()) >= 5 else ({"acc":np.nan,"base":np.nan,"edge":np.nan,"brier":np.nan,"brier_base":np.nan,"brier_skill":np.nan,"ece":np.nan},0,0)

    # Soft three-state score is diagnostic: neutral outcome is 0.5.
    soft_target = np.where(state[dev_mask] > 0, 1.0, np.where(state[dev_mask] < 0, 0.0, .5))
    soft_brier = float(np.mean((p_soft[dev_mask] - soft_target) ** 2)) if dev_mask.any() else None
    neutral_share = float(np.mean(state[dev_mask] == 0)) if dev_mask.any() else None

    equity = None
    sharpe_strat = sharpe_bh = None
    if horizon == 1:
        pos = (p_soft[dir_dev] > 0.5).astype(float)
        strat = pos * rft
        eq_strat = np.exp(np.cumsum(strat)); eq_bh = np.exp(np.cumsum(rft))
        def sharpe(x):
            ss = x.std()
            return float(x.mean()/ss*np.sqrt(252)) if ss > 0 else 0.0
        sharpe_strat, sharpe_bh = sharpe(strat), sharpe(rft)
        equity = pd.DataFrame({"date": dates[dir_dev], "Стратегия": eq_strat, "Buy&Hold": eq_bh})

    # ---------- frozen final holdout audit ----------
    holdout = {
        "enabled": bool(holdout_start is not None), "start": None if holdout_start is None else str(holdout_start.date()),
        "used_for_quality_gate": False, "frozen_model": True, "n_raw": int(hold_mask.sum()),
        "n_directional": int(np.sum(hold_mask & np.isfinite(y_dir))), "train_max_date": frozen_train_max_date,
        "target_version": TARGET_VERSION,
    }
    dir_hold = hold_mask & np.isfinite(y_dir) & np.isfinite(base_probs)
    if int(dir_hold.sum()) >= 10:
        hp, hy, hb = p_cond[dir_hold], y_dir[dir_hold], base_probs[dir_hold]
        hno, hn, hphases = _phase_nonoverlap_metrics(hp, hy, hb, horizon)
        hboot = _moving_block_bootstrap_ci(hp, hy, hb, horizon=horizon,
                                           n_boot=int(bootstrap_resamples), seed=314)
        holdout.update({
            "n_nonoverlap": int(hn), "phases": int(hphases),
            "acc": round(hno["acc"]*100, 1), "base": round(hno["base"]*100, 1),
            "edge": round(hno["edge"], 1), "brier_skill": round(hno["brier_skill"], 1),
            "ece": round(hno["ece"], 3),
            "edge_ci": [round(hboot.get("edge_low", np.nan), 1), round(hboot.get("edge_high", np.nan), 1)] if hboot else None,
            "brier_skill_ci": [round(hboot.get("brier_skill_low", np.nan), 1), round(hboot.get("brier_skill_high", np.nan), 1)] if hboot else None,
        })

    # Live deployment refit: direction uses material outcomes; Move/No-Move uses
    # every resolved three-state outcome. The neutral mass is therefore a current
    # feature-conditioned model estimate, not a historical neutral-share lookup.
    live_feats = build_features(close, dxy, macro).dropna()
    live_p = live_cond = live_pmove = live_pmove_raw = None
    live_solver_diag = live_move_solver_diag = None
    directional_all = np.where(np.isfinite(y_dir))[0]
    move_all = np.where(np.isfinite(y_move))[0]
    move_calibrator = _fit_probability_calibrator(p_move_arr[move_dev], y_move[move_dev], min_n=45) if int(move_dev.sum()) else None
    if len(live_feats) > min_train and len(directional_all) >= min_directional and len(np.unique(y_dir[directional_all])) >= 2:
        live_model, live_solver_diag = CV44010.fit_chronological_selected(
            X[directional_all], y_dir[directional_all], dates=dates[directional_all],
            label_ends=label_ends[directional_all], seed=44410 + horizon
        )
        live_cond = float(live_model.proba(live_feats[Xcols].to_numpy(dtype=float)[-1:])[0])
        if len(move_all) >= min_train and len(np.unique(y_move[move_all])) >= 2:
            live_move_model, live_move_solver_diag = CV44010.fit_chronological_selected(
                X[move_all], y_move[move_all], dates=dates[move_all], label_ends=label_ends[move_all],
                seed=44510 + horizon
            )
            live_pmove_raw = float(live_move_model.proba(live_feats[Xcols].to_numpy(dtype=float)[-1:])[0])
            live_pmove = float(move_calibrator.apply([live_pmove_raw])[0]) if move_calibrator is not None else live_pmove_raw
            live_pmove = float(np.clip(live_pmove,.03,.97))
        else:
            live_pmove = movement_probability(state)
            live_pmove_raw = live_pmove
        live_p = float(np.clip(.5 + live_pmove * (live_cond - .5), .02, .98))

    used_train_sizes = train_sizes[dir_dev]
    scorecard = {
        "Горизонт, дн.": horizon,
        "Наблюдений (OOS)": int(dir_dev.sum()), "Наблюдений (OOS raw)": int(dir_dev.sum()),
        "Наблюдений (non-overlap)": int(n_nonoverlap), "Наблюдений (effective)": int(n_eff),
        "Non-overlap phases": int(n_phases),
        "Точность модели, %": round(raw_m["acc"]*100, 1), "Базовый ориентир, %": round(raw_m["base"]*100, 1),
        "Преимущество, п.п.": round(raw_m["edge"], 1), "Brier": round(raw_m["brier"], 3),
        "Brier baseline": round(raw_m["brier_base"], 3), "Brier skill, %": round(raw_m["brier_skill"], 1),
        "Calibration error": round(raw_m["ece"], 3),
        "Точность модели non-overlap, %": round(no_m["acc"]*100, 1),
        "Базовый ориентир non-overlap, %": round(no_m["base"]*100, 1),
        "Преимущество non-overlap, п.п.": round(no_m["edge"], 1),
        "Brier non-overlap": round(no_m["brier"], 3), "Brier baseline non-overlap": round(no_m["brier_base"], 3),
        "Brier skill non-overlap, %": round(no_m["brier_skill"], 1),
        "Calibration error non-overlap": round(no_m["ece"], 3),
        "Accuracy CI95 low, %": round(boot.get("acc_low", np.nan)*100, 1),
        "Accuracy CI95 high, %": round(boot.get("acc_high", np.nan)*100, 1),
        "Edge CI95 low, п.п.": round(boot.get("edge_low", np.nan), 1),
        "Edge CI95 high, п.п.": round(boot.get("edge_high", np.nan), 1),
        "Brier skill CI95 low, %": round(boot.get("brier_skill_low", np.nan), 1),
        "Brier skill CI95 high, %": round(boot.get("brier_skill_high", np.nan), 1),
        "Calibration CI95 low": round(boot.get("ece_low", np.nan), 3),
        "Calibration CI95 high": round(boot.get("ece_high", np.nan), 3),
        "Bootstrap block size": int(boot.get("block_size", max(1,horizon))), "Bootstrap resamples": int(boot.get("n_boot",0)),
        "Purged walk-forward": True, "Non-overlap evaluation": True,
        "Final holdout": bool(holdout_start is not None), "Final holdout start": holdout["start"],
        "Holdout used for quality gate": False, "Holdout frozen model": True,
        "Purge horizon, дн.": horizon, "Мин. train observations": int(used_train_sizes.min()) if len(used_train_sizes) else 0,
        "Target version": TARGET_VERSION, "Neutral share OOS": None if neutral_share is None else round(neutral_share, 4),
        "Champion solver": CV44010.SOLVER_VERSION,
        "Champion selected C": None if live_solver_diag is None else live_solver_diag.get("selected_c"),
        "Move solver selected C": None if live_move_solver_diag is None else live_move_solver_diag.get("selected_c"),
        "Soft three-state Brier": None if soft_brier is None else round(soft_brier, 5),
        "Move model OOS n": int(move_dev.sum()),
        "Move model non-overlap n": int(move_nonoverlap_n),
        "Move model accuracy, %": None if not np.isfinite(move_metrics.get("acc",np.nan)) else round(move_metrics["acc"]*100,1),
        "Move model Brier": None if not np.isfinite(move_metrics.get("brier",np.nan)) else round(move_metrics["brier"],5),
        "Move model Brier skill, %": None if not np.isfinite(move_metrics.get("brier_skill",np.nan)) else round(move_metrics["brier_skill"],2),
        "Move model non-overlap Brier skill, %": None if not np.isfinite(move_no.get("brier_skill",np.nan)) else round(move_no["brier_skill"],2),
        "Move model calibration error": None if not np.isfinite(move_metrics.get("ece",np.nan)) else round(move_metrics["ece"],5),
        "Recent OOS enabled": bool(recent_oos.get("enabled")),
        "Recent OOS n": int(recent_oos.get("window_n") or 0),
        "Recent OOS edge, п.п.": recent_oos.get("edge"),
        "Recent OOS Brier skill, %": recent_oos.get("brier_skill"),
    }
    if sharpe_strat is not None:
        scorecard["Sharpe стратегии"] = round(sharpe_strat,2); scorecard["Sharpe buy&hold"] = round(sharpe_bh,2)

    oos_records=[]
    dev_positions=np.where(dir_dev & np.isfinite(p_cond))[0]
    for j in dev_positions[-480:]:
        oos_records.append({
            "date":str(pd.Timestamp(dates[j]).date()),
            "feature_available_at":str(pd.Timestamp(dates[j])), "label_end":str(pd.Timestamp(label_ends[j])), "p_up":round(float(p_soft[j]),8),
            "conditional_p_up":round(float(p_cond[j]),8), "p_move":round(float(p_move_arr[j]),8), "p_neutral":round(float(1-p_move_arr[j]),8),
            "y":int(y_dir[j]), "state":int(state[j]), "ret_fwd":round(float(rf[j]),10),
            "base_p":round(float(base_probs[j]),8) if np.isfinite(base_probs[j]) else None,
            "target_version":TARGET_VERSION,
        })

    quality = quality_gate(scorecard, live_p)
    return {
        "scorecard": scorecard, "equity": equity, "live_p_up": live_p,
        "conditional_p_up": live_cond, "p_move": live_pmove, "p_move_raw": live_pmove_raw,
        "p_neutral": None if live_pmove is None else float(1-live_pmove),
        "move_model": {
            "version":"move-sklearn-logreg-v4.40.10", "trained": live_pmove is not None,
            "calibrated": bool(move_calibrator is not None), "oos_n": int(move_dev.sum()),
            "nonoverlap_n": int(move_nonoverlap_n),
            "brier_skill": None if not np.isfinite(move_metrics.get("brier_skill",np.nan)) else round(float(move_metrics["brier_skill"]),4),
            "nonoverlap_brier_skill": None if not np.isfinite(move_no.get("brier_skill",np.nan)) else round(float(move_no["brier_skill"]),4),
            "solver_selection": live_move_solver_diag,
        },
        "champion_solver": {"version":CV44010.VERSION,"solver":CV44010.SOLVER_VERSION,"direction":live_solver_diag,"move":live_move_solver_diag},
        "oos_records":oos_records, "features": Xcols, "quality": quality, "holdout": holdout,
        "recent_oos": recent_oos, "target_version": TARGET_VERSION,
        "validation": {
            "method": "purged_significant_direction_nonoverlap_block_bootstrap_with_frozen_final_holdout",
            "target_semantics": "up / neutral / down; direction trained only on material moves",
            "target_version": TARGET_VERSION, "horizon": horizon, "nonoverlap_stride": max(1,horizon),
            "n_raw": int(dir_dev.sum()), "n_nonoverlap": int(n_nonoverlap), "n_effective": int(n_eff),
            "nonoverlap_aggregation": "median_across_phases", "nonoverlap_phases": int(n_phases),
            "bootstrap_block_size": int(boot.get("block_size",max(1,horizon))), "bootstrap_resamples": int(boot.get("n_boot",0)),
            "first_oos_date": str(pd.Timestamp(dates[dir_dev][0]).date()) if dir_dev.any() else None,
            "last_oos_date": str(pd.Timestamp(dates[dir_dev][-1]).date()) if dir_dev.any() else None,
            "final_holdout_start": holdout["start"], "final_holdout_used_for_gate": False, "holdout_frozen_model": True,
            "rolling_recent_oos_audit": recent_oos, "rolling_recent_used_for_gate": False,
            "neutral_not_labelled_down": True,
            "move_probability_modelled_from_current_features": True,
            "move_model_version": "move-sklearn-logreg-v4.40.10",
            "champion_solver_version": CV44010.SOLVER_VERSION,
            "nested_chronological_regularization": True,
            "historical_neutral_share_not_used_as_primary_live_probability": True,
        },
    }

def walk_forward_daily(close: pd.Series, dxy: pd.Series | None = None,
                       macro: pd.DataFrame | None = None,
                       min_train=220, retrain_every=20) -> dict:
    return walk_forward_direction(close, dxy, macro, 1, min_train, retrain_every)


def multi_horizon_forecasts(close: pd.Series, dxy=None, macro=None,
                            horizons=(1, 5, 10, 20)) -> dict:
    out = {}
    for h in horizons:
        r = walk_forward_direction(close, dxy, macro, horizon=h)
        if r:
            sc = r["scorecard"]
            out[str(h)] = {
                "horizon": h,
                "p_up": None if r["live_p_up"] is None else round(r["live_p_up"], 3),
                "conditional_p_up": None if r.get("conditional_p_up") is None else round(float(r["conditional_p_up"]), 3),
                "p_neutral": None if r.get("p_neutral") is None else round(float(r["p_neutral"]), 3),
                "quality": r["quality"],
                "scorecard": {
                    # v2.9 primary UI metrics are dependence-aware/non-overlapping.
                    "n": sc["Наблюдений (OOS raw)"],
                    "n_raw": sc["Наблюдений (OOS raw)"],
                    "n_nonoverlap": sc["Наблюдений (non-overlap)"],
                    "n_eff": sc["Наблюдений (effective)"],
                    "nonoverlap_phases": sc.get("Non-overlap phases", max(1, h)),
                    "acc": sc["Точность модели non-overlap, %"],
                    "base": sc["Базовый ориентир non-overlap, %"],
                    "edge": sc["Преимущество non-overlap, п.п."],
                    "brier": sc["Brier non-overlap"],
                    "brier_base": sc["Brier baseline non-overlap"],
                    "brier_skill": sc["Brier skill non-overlap, %"],
                    "ece": sc["Calibration error non-overlap"],
                    "acc_raw": sc["Точность модели, %"],
                    "base_raw": sc["Базовый ориентир, %"],
                    "edge_raw": sc["Преимущество, п.п."],
                    "brier_skill_raw": sc["Brier skill, %"],
                    "ece_raw": sc["Calibration error"],
                    "acc_ci": [sc["Accuracy CI95 low, %"], sc["Accuracy CI95 high, %"]],
                    "edge_ci": [sc["Edge CI95 low, п.п."], sc["Edge CI95 high, п.п."]],
                    "brier_skill_ci": [sc["Brier skill CI95 low, %"], sc["Brier skill CI95 high, %"]],
                    "ece_ci": [sc["Calibration CI95 low"], sc["Calibration CI95 high"]],
                    "bootstrap_block": sc["Bootstrap block size"],
                    "bootstrap_n": sc["Bootstrap resamples"],
                    "purged": bool(sc.get("Purged walk-forward", False)),
                    "nonoverlap": bool(sc.get("Non-overlap evaluation", False)),
                },
                "validation": r.get("validation", {}),
                "holdout": r.get("holdout", {}),
            }
    return out


FEATURE_LABELS = {
    "r1": "Дневная доходность", "mom5": "Моментум 5д", "mom20": "Моментум 20д",
    "mom60": "Моментум 60д", "vol20": "Волатильность 20д", "vol60": "Волатильность 60д",
    "vol_ratio": "Ускорение волатильности",
    "dist_ma50": "Отклонение от MA50", "dist_ma200": "Отклонение от MA200",
    "dxy_ret20": "DXY, 20д", "carry_diff": "Дифференциал ставок",
    "carry_chg3m": "Δ дифференциала 3м", "us_real10y": "Реальная дох-ть US 10л",
    "slope_10y_ff": "Наклон кривой 10л−ФРС", "us_cpi_yoy": "Инфляция US г/г",
    "us_cpi_accel": "Инфляционный импульс US", "us_ff_chg3m": "Δ ставки ФРС 3м",
    "us_indpro_yoy": "Промпроизв. US г/г", "us_unrate_chg3m": "Δ безработицы US 3м",
    "us_payems_yoy": "Занятость US г/г", "us_vix": "Индекс страха VIX",
    "curve_2s10s": "Наклон кривой 2–10л", "us_sentiment": "Потреб. настроения US",
    "ru_key": "Ключевая ставка ЦБ РФ", "ru_key_chg3m": "Δ ключевой ставки 3м",
}


def feature_importance(close, dxy=None, macro=None, min_train=220, horizon=10):
    """Стандартизованные коэффициенты; ассоциация, не причинность."""
    feats = build_features(close, dxy, macro)
    tgt = directional_target_frame(close, horizon)
    df = feats.copy(); df["y"] = tgt["y"]
    df = df.dropna(subset=list(feats.columns)+["y"])
    if len(df) < min_train:
        return None
    Xcols = list(feats.columns)
    m = LogReg().fit(df[Xcols].values, df["y"].values)
    imp = pd.DataFrame({"feature": Xcols, "coef": m.w[1:]})
    imp["label"] = imp["feature"].map(lambda c: FEATURE_LABELS.get(c, c))
    imp["abs"] = imp["coef"].abs()
    return imp.sort_values("abs", ascending=False).reset_index(drop=True)


def event_reaction(close: pd.Series, event_dates) -> dict | None:
    """Сравнение абсолютного движения в дни событий с обычными днями."""
    r = np.log(close / close.shift(1)).dropna()
    if len(r) < 50:
        return None
    trading = pd.DatetimeIndex(r.index)
    ev = []
    for d in event_dates:
        d = pd.Timestamp(d).normalize()
        fut = trading[trading.normalize() >= d]
        if len(fut):
            ev.append(fut[0])
    ev = list(dict.fromkeys(ev))
    if len(ev) < 3:
        return None
    is_ev = r.index.isin(ev)
    em = r[is_ev].abs().dropna()
    bm = r[~is_ev].abs().dropna()
    if len(em) < 3 or bm.empty:
        return None
    return {
        "Событий в истории": int(len(em)),
        "Ср. |движение| в день заседания, %": round(float(em.mean() * 100), 2),
        "Ср. |движение| в обычный день, %": round(float(bm.mean() * 100), 2),
    }


def explain_latest(close: pd.Series, dxy=None, macro=None, min_train=220, horizon=10):
    """Разложение текущего ML score по признакам на выбранном горизонте."""
    feats = build_features(close, dxy, macro)
    tgt = directional_target_frame(close, horizon)
    df = feats.copy(); df["y"] = tgt["y"]
    df = df.dropna(subset=list(feats.columns)+["y"])
    if len(df) < min_train:
        return None
    Xcols = list(feats.columns)
    m = LogReg().fit(df[Xcols].values, df["y"].values)
    live = feats.dropna()
    if live.empty:
        return None
    xraw = live.iloc[-1][Xcols].astype(float).values
    z = (xraw - m.mu) / m.sd
    contrib = m.w[1:] * z
    p = float(1 / (1 + np.exp(-np.clip(m.w[0] + contrib.sum(), -30, 30))))
    out = pd.DataFrame({
        "label": [FEATURE_LABELS.get(c, c) for c in Xcols],
        "value": xraw, "contribution": contrib,
    })
    out["abs"] = out["contribution"].abs()
    out = out.sort_values("abs", ascending=False).reset_index(drop=True)
    return {"p_up": p, "drivers": out, "horizon": horizon,
            "scope":"base_directional_model_association",
            "note":"Feature contributions explain the base directional model, not the final guarded ensemble."}


def verdict(sc: dict) -> tuple[str, str]:
    q = quality_gate(sc, 0.5)
    if q["trusted"]:
        return ("ok", "Модель проходит минимальный OOS quality gate, но edge всё равно может быть хрупким.")
    return ("warn", "Модель не проходит OOS quality gate; directional signal публиковать нельзя.")
