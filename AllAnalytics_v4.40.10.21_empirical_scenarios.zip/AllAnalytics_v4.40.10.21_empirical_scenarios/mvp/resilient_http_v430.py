"""AllAnalytics v4.30 resilient HTTP transport.

A small transport layer for public market/news APIs.  It keeps the UI usable when
one OS/VPN/proxy route is unhealthy by trying independent Requests routes, reusing
connection pools, applying finite default timeouts, and temporarily skipping a
route after repeated network failures.  Provider modules still own semantic
fallbacks and last-good data.
"""
from __future__ import annotations

import os
import threading
import time
from typing import Any

import requests

_ORIG_GET = requests.get
_ORIG_POST = requests.post
_PATCHED = False
_LOCK = threading.RLock()
_STATS = {
    "attempts": 0,
    "success": 0,
    "fallback_success": 0,
    "errors": 0,
    "last_route": None,
    "last_error": None,
}
_ROUTE_STATE: dict[str, dict[str, Any]] = {}


def _new_session(trust_env: bool, proxy: str | None = None) -> requests.Session:
    s = requests.Session()
    s.trust_env = trust_env
    if proxy:
        s.proxies.update({"http": proxy, "https": proxy})
    return s


_TLS = threading.local()

def _thread_session(name: str, trust_env: bool, proxy: str | None = None) -> requests.Session:
    # Quote refresh uses worker threads. Requests.Session is not guaranteed to be
    # thread-safe, so each worker reuses its own connection pool.
    sessions = getattr(_TLS, "sessions", None)
    if sessions is None:
        sessions = {}
        _TLS.sessions = sessions
    key=(name,proxy or "")
    s=sessions.get(key)
    if s is None:
        s=_new_session(trust_env, proxy)
        sessions[key]=s
    return s


def _timeout(kwargs: dict[str, Any]) -> None:
    # Never allow a provider that forgot a timeout to hang a UI-facing request.
    kwargs.setdefault("timeout", (3.5, 8.0))


def _route_available(name: str) -> bool:
    st = _ROUTE_STATE.get(name) or {}
    return float(st.get("blocked_until") or 0.0) <= time.time()


def _mark_success(name: str) -> None:
    with _LOCK:
        _ROUTE_STATE[name] = {"failures": 0, "blocked_until": 0.0, "last_success": time.time(), "last_error": None}


def _mark_failure(name: str, exc: Exception | str) -> None:
    with _LOCK:
        old = _ROUTE_STATE.get(name) or {}
        failures = int(old.get("failures") or 0) + 1
        # Short circuit-breaker only after repeated failures.  It heals automatically.
        cooldown = min(60.0, 5.0 * max(0, failures - 1)) if failures >= 2 else 0.0
        _ROUTE_STATE[name] = {
            **old,
            "failures": failures,
            "blocked_until": time.time() + cooldown,
            "last_error": str(exc)[:220],
        }


def _request_via(name: str, method: str, url: str, kwargs: dict[str, Any], proxy: str | None):
    if name == "caller-proxy":
        return (_ORIG_GET if method == "GET" else _ORIG_POST)(url, **kwargs)
    if name == "direct-no-env":
        return _thread_session("direct-no-env", False).request(method, url, **kwargs)
    if name == "system-env":
        return _thread_session("system-env", True).request(method, url, **kwargs)
    if name == "dedicated-egress" and proxy:
        return _thread_session("dedicated-egress", False, proxy).request(method, url, **kwargs)
    raise requests.RequestException(f"Unknown transport route: {name}")


def _do(method: str, url: str, **kwargs: Any):
    explicit_proxies = kwargs.get("proxies")
    egress = os.getenv("ALLANALYTICS_EGRESS_PROXY", "").strip() or None
    routes: list[tuple[str, str | None]] = []
    if explicit_proxies:
        routes.append(("caller-proxy", None))
    else:
        # direct-no-env avoids broken HTTP(S)_PROXY variables. system-env still
        # supports corporate/VPN proxy setups. A dedicated egress can be supplied
        # for networks where the OS tunnel itself geoblocks a provider.
        routes.extend([("direct-no-env", None), ("system-env", None)])
        if egress:
            routes.append(("dedicated-egress", egress))

    last_exc: Exception | None = None
    last_resp = None
    retry_statuses = {403, 407, 408, 425, 429, 451, 500, 502, 503, 504, 520, 521, 522, 523, 524}
    local_kwargs = dict(kwargs)
    _timeout(local_kwargs)

    for idx, (name, proxy) in enumerate(routes):
        if name != "caller-proxy" and not _route_available(name) and idx < len(routes) - 1:
            continue
        with _LOCK:
            _STATS["attempts"] += 1
        try:
            resp = _request_via(name, method, url, local_kwargs, proxy)
            last_resp = resp
            if resp.status_code in retry_statuses and idx < len(routes) - 1:
                _mark_failure(name, f"HTTP {resp.status_code}")
                continue
            _mark_success(name)
            with _LOCK:
                _STATS["success"] += 1
                if idx:
                    _STATS["fallback_success"] += 1
                _STATS["last_route"] = name
                _STATS["last_error"] = None
            return resp
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
            _mark_failure(name, f"{type(exc).__name__}: {exc}")
            with _LOCK:
                _STATS["last_error"] = f"{type(exc).__name__}: {str(exc)[:180]}"
            continue

    with _LOCK:
        _STATS["errors"] += 1
    if last_resp is not None:
        return last_resp
    if last_exc is not None:
        raise last_exc
    raise requests.RequestException(f"No HTTP route available for {url}")


def resilient_get(url: str, **kwargs: Any):
    return _do("GET", url, **kwargs)


def resilient_post(url: str, **kwargs: Any):
    return _do("POST", url, **kwargs)


def install_global_patch() -> None:
    global _PATCHED
    if _PATCHED:
        return
    requests.get = resilient_get  # type: ignore[assignment]
    requests.post = resilient_post  # type: ignore[assignment]
    _PATCHED = True


def status() -> dict:
    now = time.time()
    with _LOCK:
        route_state = {
            k: {
                **v,
                "blocked_for_seconds": max(0.0, round(float(v.get("blocked_until") or 0) - now, 1)),
            }
            for k, v in _ROUTE_STATE.items()
        }
        return {
            "version": "4.30",
            "patched": _PATCHED,
            **dict(_STATS),
            "routes": route_state,
            "dedicated_egress_configured": bool(os.getenv("ALLANALYTICS_EGRESS_PROXY", "").strip()),
        }
