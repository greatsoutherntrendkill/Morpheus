from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
HTML=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
API=(ROOT/'api.py').read_text(encoding='utf-8')
ENV=(ROOT/'.env').read_text(encoding='utf-8')
NEWS=(ROOT/'news.py').read_text(encoding='utf-8')


def test_market_card_header_and_logo_cleanup():
    assert 'class="asset-card-head"' in HTML
    assert 'position:static' in HTML
    assert 'body[data-theme=signal] .asset-card h3{font-size:16px' in HTML
    assert '<div class="nav-label">РАЗДЕЛЫ</div>' not in HTML
    assert "body[data-theme=signal] .brand{font-family:'Onest'" in HTML


def test_30_second_refresh_contract():
    assert 'const LIVE_REFRESH_MS=30000' in HTML
    assert "setInterval(()=>{if(document.visibilityState==='visible')loadQuotes(false)},LIVE_REFRESH_MS)" in HTML
    assert "setInterval(()=>{if(document.visibilityState==='visible')loadNews(false)},LIVE_REFRESH_MS)" in HTML
    assert 'QUOTE_REFRESH_SECONDS=30' in ENV
    assert 'NEWS_REFRESH_SECONDS=30' in ENV
    assert 'ttl=max(30,int(os.getenv("QUOTE_REFRESH_SECONDS","30")))' in API
    assert 'ttl = max(30, int(os.getenv("NEWS_REFRESH_SECONDS", "30")))' in API
    assert 'def news_map(category: str | None = None, min_impact: int = 0, force: int = 0):' in API


def test_signal_probability_contrast():
    assert "${Number(v)===max?'dominant':''}" in HTML
    assert 'body[data-theme=signal] .rate-scenario.dominant b{color:#17270d!important' in HTML
    assert 'body[data-theme=signal] .rate-scenario.dominant span{color:#536344' in HTML


def test_asset_valid_news_and_synced_selector():
    assert 'id="overview-dynamics-asset"' in HTML
    assert 'function selectOverviewAsset(sym,force=true)' in HTML
    assert 'const ASSET_NEWS_GROUPS=' in HTML
    assert "basis='прямая связь'" in HTML
    assert "basis='ключевой драйвер'" in HTML
    assert 'Региональные новости без связи с инструментом сюда не попадают.' in HTML
    assert 'body[data-theme=signal] .overview-dynamics-grid{grid-column:1/-1' in HTML
    # backend tags policy news to the full equity benchmark group, not just one index
    assert '"fed": ["^GSPC", "^NDX", "^DJI", "^RUT", "ES=F", "NQ=F"' in NEWS
    assert '"bank of japan": ["^N225", "JPY=X"]' in NEWS


if __name__=='__main__':
    for name,obj in list(globals().items()):
        if name.startswith('test_') and callable(obj): obj()
    print('OK: v4.14 live refresh, market cards, Signal contrast, asset-valid news and logo')
