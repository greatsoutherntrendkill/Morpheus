
from __future__ import annotations
from pathlib import Path
import datetime as dt
import os, tempfile

ROOT=Path(__file__).parent

TEXT="""
On September 1, 2026, Acquirer Inc. announced that it entered into an
Agreement and Plan of Merger by and among Acquirer Inc., Merger Sub Inc. and
Target Corp. The transaction is valued at approximately $2.5 billion.
The merger consideration is $45.00 per share in cash. Acquirer Inc. has
obtained debt financing commitments for the transaction. The transaction is
expected to close in the second quarter of 2027.
"""

def main():
    import sec_edgar_deals_v49 as S
    import sec_deal_analysis_v410 as A

    # The old false-positive shape from the screenshot must be rejected.
    bad="Business Combination Agreement. PubCo due to forfeiture of service providers of Agility."
    assert S._extract_counterparty(bad,"CubeBio Co., Ltd") is None

    # Patch network-facing enrichment helpers.
    old_sub=A._submissions
    old_fun=A._fundamentals
    old_mkt=A._market_reaction
    old_gw=A._post_close_goodwill
    try:
        A._submissions=lambda cik:{"tickers":["ACQ"],"exchanges":["NYSE"]}
        A._fundamentals=lambda cik,event:{
            "revenue":1_000_000_000.0,
            "operating_income":200_000_000.0,
            "da":50_000_000.0,
            "ebitda_proxy":250_000_000.0,
            "net_income":120_000_000.0,
            "source":"SEC XBRL companyfacts",
        }
        A._market_reaction=lambda ticker,event:{
            "ticker":"ACQ","source":"Massive","previous_close":40.0,
            "first_close":42.0,"fifth_close":41.0,"day1_pct":5.0,"day5_pct":2.5,
        }
        A._post_close_goodwill=lambda cik,target,event:{"value":600_000_000.0,"status":"reported","form":"10-Q"}

        detail={
            "accession":"0001-26-000001","kind":"mna","date":"2026-09-04",
            "company":"Acquirer Inc.","issuer":"Acquirer Inc.","cik":"1001",
            "form":"S-4","sec_url":"https://www.sec.gov/example",
            "counterparty":None,"headline_value":300_000_000.0,"per_share":None,
            "source":"SEC EDGAR","verified":True,
        }
        out=A._mna_analysis(detail,TEXT)
        assert out["counterparty"]=="Target Corp"
        assert out["announcement_date"]=="2026-09-01"
        assert out["expected_close"]=="2 кв. 2027"
        assert out["headline_value"]==2_500_000_000.0
        assert out["roles"]["buyer"]=="Acquirer Inc."
        assert out["roles"]["target"]=="Target Corp"
        assert "денежные средства" in out["consideration"]["methods"]
        assert "долговое финансирование" in out["consideration"]["methods"]
        assert abs(out["multiples"]["deal_value_to_revenue"]-2.5)<1e-9
        assert abs(out["multiples"]["deal_value_to_ebitda"]-10.0)<1e-9
        assert out["goodwill"]["value"]==600_000_000.0
        assert out["market_reaction"]["day1_pct"]==5.0
        assert "Acquirer Inc." in out["summary_ru"]
        assert "Target Corp" in out["summary_ru"]
    finally:
        A._submissions=old_sub
        A._fundamentals=old_fun
        A._market_reaction=old_mkt
        A._post_close_goodwill=old_gw

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    for token in [
        "Кто участвует в сделке","Условия сделки","Корпоративные финансы",
        "Первичная реакция рынка","Deal value / EBITDA","Goodwill",
        "Источники и методика анализа","analysis_version!=='4.10'"
    ]:
        assert token in html, token
    assert "due to forfeiture" not in html

    api=(ROOT/"api.py").read_text(encoding="utf-8")
    assert "SDA410.analyze" in api
    print("OK: v4.10 Russian deal presentation + SEC/XBRL fundamentals + market reaction + goodwill policy")

if __name__=="__main__":
    main()
