
from __future__ import annotations
import json
from pathlib import Path
import db, model_registry as MR

ROOT=Path(__file__).parent

def main():
    data=json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))
    assert data.get("version") in {"3.5","3.6","3.7","3.8","3.9","4.0"}
    assert len(data.get("assets") or [])==33
    for a in data["assets"]:
        views=a.get("model_views") or {}
        assert set(views)>={"1","5","10","20"}
        for h in ("1","5","10","20"):
            v=views[h]
            assert "raw" in v and "status" in v and "evidence" in v
            if v["raw"]["p_up"] is not None:
                assert v["raw"]["direction"] in ("up","down")
            if not v["status"]["validated"]:
                assert "подтвержд" in v["status"]["label"].lower()
            e=v["evidence"]
            assert e["target_effective_n"]==30
            assert 0 <= e["n_progress_pct"] <= 100
            assert "live_track_record" in e

    con=db.connect()
    try:
        tr=MR.live_track_record(con,MR.MODEL_VERSION,data["assets"][0]["symbol"],10)
        assert set(tr)>={"predictions","realized","pending","directional_accuracy","brier"}
        assert tr["predictions"]==tr["realized"]+tr["pending"]
    finally:
        con.close()
    print("OK: v3.5 raw forecast visibility + separate validation + live track record")

if __name__=="__main__":
    main()
