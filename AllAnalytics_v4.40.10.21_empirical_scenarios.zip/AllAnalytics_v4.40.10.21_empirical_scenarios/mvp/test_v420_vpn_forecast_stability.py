from pathlib import Path
import importlib.util

ROOT=Path(__file__).resolve().parent

def test_frontend_has_stable_forecast_state():
    t=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
    assert 'EQUITY_FORECAST_RETRY_MS=' in t
    assert "status==='failed'" in t
    assert 'scheduleRussianForecasts' in t
    assert "content:' · модель…'" not in t

def test_moex_has_vpn_resilient_ladder():
    t=(ROOT/'moex_fast_v419.py').read_text(encoding='utf-8')
    assert '_resolve_iss_doh' in t
    assert '_request_json_relay' in t
    assert 'MOEX_PUBLIC_RELAY_ENABLED' in t

def test_forecast_has_disk_cache_and_stale_guard():
    t=(ROOT/'equity_forecast_v416.py').read_text(encoding='utf-8')
    assert 'equity_forecast_v420' in t
    assert '_save_disk' in t
    assert 'history stale' in t
