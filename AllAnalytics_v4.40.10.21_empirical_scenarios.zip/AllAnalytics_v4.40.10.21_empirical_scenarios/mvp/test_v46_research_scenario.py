
from __future__ import annotations
from pathlib import Path
import json

ROOT=Path(__file__).parent

def main():
    import research_forecast_v46 as R
    import scenario_engine_v46 as S

    data=json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))
    out=R.build(data)
    assert len(out["macro"])==len(data["macro_stats"])==8
    assert len(out["rates"])==len(data["rates"])==13
    for row in out["macro"]:
        assert [x["horizon"] for x in row["path"]]==["now","1m","6m","1y"]
    for row in out["rates"]:
        assert [x["horizon"] for x in row["path"]]==["now","1m","6m","1y"]
        assert "не утверждённое решение" in row["note"]

    sc=S.analyze(data,"Как изменится нефть, если начнётся война в районе Ормузского пролива?")
    assert any(x["symbol"]=="CL=F" for x in sc["impacts"])
    oil=next(x for x in sc["impacts"] if x["symbol"]=="CL=F")
    assert oil["range_pct"][0] > 0
    assert len(sc["scenarios"])==3
    follow=S.analyze(data,"А если одновременно полностью заблокируют экспорт из Ирана?",sc["combined_question"])
    assert len(follow["combined_question"])>len(sc["combined_question"])

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    for token in [
        'data-page="scenario"','data-page="learning"',
        'data-page-view="scenario"','data-page-view="learning"',
        'Макроэкономический прогноз','Траектория показателей','Траектория ставок',
        'Скоро тут что-то будет...','/api/scenario/analyze','scenario-followup-input'
    ]:
        assert token in html, token
    assert '<div class="side-status">' not in html
    assert 'research_outlook_v46' in json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))

    api=(ROOT/"api.py").read_text(encoding="utf-8")
    assert '@app.get("/api/research/outlook")' in api
    assert '@app.post("/api/scenario/analyze")' in api

    print("OK: v4.6 research forecasts + all rate trajectories + scenario follow-up + learning shell")

if __name__=="__main__":
    main()
