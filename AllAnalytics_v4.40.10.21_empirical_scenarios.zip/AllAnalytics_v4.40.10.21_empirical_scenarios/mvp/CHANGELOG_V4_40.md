# AllAnalytics v4.40 — Distributional Forecast & Expected Move

## Главная идея
v4.40 перестаёт описывать прогноз только одной вероятностью роста/падения. Поверх guarded directional core v4.39 добавлен независимый distributional risk layer: он оценивает диапазон будущей доходности, expected move и асимметрию хвостов, но **не имеет права менять `p_up`, threshold, abstention или веса directional-ансамбля**.

## Что добавлено
- `distributional_forecast_v440.py` — прогноз квантилей будущей h-session log-return:
  - q10 / q25 / q50 / q75 / q90;
  - 50% и 80% prediction intervals;
  - соответствующие ценовые уровни;
  - expected absolute move;
  - upside/downside tail и tail asymmetry.
- Хронологическая development-схема `train → purge → calibration → purge → untouched evaluation`.
- Split-conformal widening для 50% и 80% интервалов; correction обучается только на calibration slice.
- Отдельная проверка interval coverage, mean pinball loss, CRPS-like metric, median MAE и pinball skill относительно простого historical-quantile baseline.
- Консервативный volatility floor: слабая distribution-модель не может показывать неправдоподобно узкий диапазон.
- `expected_abs_move_pct` объединяет прямой absolute-return estimator и realised-volatility conditioning.
- Options IV используется только как внешний benchmark из уже сохранённого локального alt-data snapshot. При отсутствии реального mapped IV поле остаётся unavailable; сеть из forecast-модуля не вызывается.
- `distribution_feedback_v440.py` — отдельный append-only prospective ledger для диапазонов и expected move.
- Исправлен cache discovery v4.38 equity cross-sectional specialist: теперь peer-history читается и из текущих v4.39/v4.40 cache namespaces, а не только из v4.35/v4.37.

## Governance
Distribution layer не является ещё одним голосом за рост/падение:
- directional weight = 0;
- `p_up` v4.39 сохраняется без изменений;
- automatic promotion запрещён;
- prospective scoring не меняет модель автоматически;
- options IV не подмешивается скрыто в направление.

## Новые API
- `/api/models/quality-v440?symbol=SBER.ME&horizon=10`
- `/api/models/distribution-v440?symbol=SBER.ME&horizon=10`
- `/api/models/distribution-score-v440?symbol=SBER.ME&horizon=10&window_days=365`
- `/api/models/distribution-status-v440`

Старые diagnostic endpoints v4.33–v4.39 сохранены.

## Technical Lab
В подробном разборе теперь показываются:
- калиброванный 80% ценовой диапазон;
- медианный ценовой ориентир q50;
- expected absolute move;
- фактический development coverage 50%/80%;
- pinball skill;
- асимметрия верхнего и нижнего хвоста;
- options-IV benchmark, когда он действительно доступен.

## Validation
- новый `test_v440_distributional.py` проверяет quantile ordering, purge gaps, directional-invariance, options benchmark и prospective settlement;
- Python `py_compile` для новых/изменённых модулей;
- active inline JavaScript `node --check`;
- regression suite: **105/105** тест-кейсов пройдены при запуске непересекающимися группами;
- старый cold-start `<2.0 s` fast-pipeline тест снова проходит после переноса импорта LightGBM/CatBoost на startup;
- единый `pytest` в данном контейнере зависает из-за test-order/environment interaction, поэтому итог подтверждён chunked-run без пересечения тестов.
