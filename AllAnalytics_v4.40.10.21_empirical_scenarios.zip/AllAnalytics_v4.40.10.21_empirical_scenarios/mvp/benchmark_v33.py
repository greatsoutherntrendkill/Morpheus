
"""Run AllAnalytics v3.3 champion/challenger benchmark.

Examples:
  python benchmark_v33.py
  python benchmark_v33.py --symbols "^GSPC,BTC-USD,EURUSD=X" --horizons "1,5,10,20"

Outputs:
  site/model_benchmark_v33.json
  model_benchmark_v33.csv
and appends challenger live predictions to the immutable ledger.
"""
from __future__ import annotations
import argparse, json
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
import numpy as np

import config as C
import db
import export_site as ES
import macro_features as MF
import model_registry as MR
import challenger_models as CM

ROOT=Path(__file__).parent
JSON_OUT=ROOT/"site"/"model_benchmark_v33.json"
CSV_OUT=ROOT/"model_benchmark_v33.csv"


def _jsonable(x):
    if isinstance(x,(np.integer,)): return int(x)
    if isinstance(x,(np.floating,)): return None if not np.isfinite(x) else float(x)
    if isinstance(x,(pd.Timestamp,)): return x.isoformat()
    raise TypeError(type(x).__name__)


def _symbols(con):
    available=set(db.symbols(con))
    public=[s for s in ES.PUBLIC if s in available]
    return public


def run(symbols=None,horizons=(1,5,10,20),cost_bps=2.0):
    con=db.connect()
    try:
        MR.register_champion(con)
        MR.register_challenger(
            con,CM.CHALLENGER_VERSIONS["lightgbm"],"lightgbm",
            CM.FEATURE_VERSION,CM.LOCKED_CONFIGS["lightgbm"],
            "v3.3 locked challenger; final holdout never used for tuning",
            validation_version=CM.VALIDATION_VERSION)
        MR.register_challenger(
            con,CM.CHALLENGER_VERSIONS["catboost"],"catboost",
            CM.FEATURE_VERSION,CM.LOCKED_CONFIGS["catboost"],
            "v3.3 locked challenger; final holdout never used for tuning",
            validation_version=CM.VALIDATION_VERSION)

        deps=CM.dependency_status()
        missing=[k for k,v in deps.items() if not v.get("available")]
        if missing:
            raise RuntimeError("Missing challenger dependencies: "+", ".join(missing))

        syms=symbols or _symbols(con)
        rows=[]; errors=[]
        dxy_df=ES.sanitize_price_df(db.read_prices(con,"DX-Y.NYB"),"DX-Y.NYB")
        dxy_all=dxy_df.set_index("date")["close"] if not dxy_df.empty else None

        for sym in syms:
            try:
                df=ES.sanitize_price_df(db.read_prices(con,sym),sym)
                if df.empty or len(df)<300:
                    continue
                close=df.set_index("date")["close"]
                dxy=None if sym=="DX-Y.NYB" else dxy_all
                macro=MF.macro_features_for(con,sym,close.index)
                macro_audit=MF.macro_data_audit(con)
                cutoff=str(pd.Timestamp(close.index[-1]).date())
                for h in horizons:
                    try:
                        r=CM.compare_asset(close,dxy,macro,horizon=int(h),cost_bps=cost_bps)
                        if not r: continue
                        arrays=r.pop("_arrays",None)
                        r["symbol"]=sym
                        r["name"]=ES.NAMES.get(sym,sym)
                        rows.append(r)
                        for name in ("lightgbm","catboost"):
                            mm=r["models"][name]
                            MR.append_prediction_for_model(
                                con,mm["version"],CM.FEATURE_VERSION,sym,int(h),cutoff,
                                mm.get("live_p_up"),
                                quality={"research_challenger":True,"promotion_status":"not_promoted"},
                                macro_provenance=macro_audit,
                                holdout_status="research_challenger")
                        print(f"{sym} {h}D: ok")
                    except Exception as e:
                        errors.append({"symbol":sym,"horizon":int(h),"error":repr(e)})
                        print(f"{sym} {h}D: ERROR {e}")
            except Exception as e:
                errors.append({"symbol":sym,"error":repr(e)})
                print(f"{sym}: ERROR {e}")

        promotion=CM.promotion_summary(rows)
        # attach Holm-adjusted p values into each paired test
        adj=promotion.get("holm_adjusted_p",{})
        for r in rows:
            for c in ("lightgbm","catboost"):
                ph=(r.get("paired_holdout") or {}).get(c)
                if ph is not None:
                    ph["p_holm_brier"]=adj.get(f"{c}|{r['symbol']}|{r['horizon']}")
                    ph["multiplicity_pass"]=bool(ph["p_holm_brier"] is not None and ph["p_holm_brier"]<0.05)

        payload={
            "version":"3.3",
            "generated_at":datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
            "champion":CM.CHAMPION_VERSION,
            "challengers":CM.CHALLENGER_VERSIONS,
            "feature_version":CM.FEATURE_VERSION,
            "validation_version":CM.VALIDATION_VERSION,
            "holdout_used_for_tuning":False,
            "hyperparameters_locked_before_holdout":True,
            "automatic_promotion":False,
            "scope":{"symbols":syms,"horizons":[int(x) for x in horizons],"cost_bps":float(cost_bps)},
            "dependency_status":deps,
            "promotion":promotion,
            "rows":rows,
            "errors":errors,
        }
        JSON_OUT.parent.mkdir(parents=True,exist_ok=True)
        JSON_OUT.write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=_jsonable),encoding="utf-8")

        flat=[]
        for r in rows:
            for name,m in r["models"].items():
                flat.append({
                    "symbol":r["symbol"],"name":r["name"],"horizon":r["horizon"],
                    "model":name,"model_version":m["version"],
                    **{f"dev_{k}":v for k,v in (m.get("development") or {}).items() if not isinstance(v,(list,dict))},
                    **{f"holdout_{k}":v for k,v in (m.get("holdout") or {}).items() if not isinstance(v,(list,dict))},
                    **{f"econ_{k}":v for k,v in (m.get("holdout_economic") or {}).items() if not isinstance(v,(list,dict))},
                })
        pd.DataFrame(flat).to_csv(CSV_OUT,index=False)
        return payload
    finally:
        con.close()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--symbols",default="")
    ap.add_argument("--horizons",default="1,5,10,20")
    ap.add_argument("--cost-bps",type=float,default=2.0)
    args=ap.parse_args()
    syms=[x.strip() for x in args.symbols.split(",") if x.strip()] or None
    hs=tuple(int(x) for x in args.horizons.split(",") if x.strip())
    p=run(syms,hs,args.cost_bps)
    print(json.dumps({
        "rows":len(p["rows"]),"errors":len(p["errors"]),
        "promotion":p["promotion"]["challengers"],
        "json":str(JSON_OUT),"csv":str(CSV_OUT)
    },ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
