import numpy as np
import pandas as pd
import pytest
import independent_evaluation_v4401014 as E
import evaluation_clock_v4401014 as CLOCK


def close(n=220):
 return pd.Series(100*np.exp(np.cumsum(np.sin(np.arange(n)*.3)*.008+.0005)),index=pd.bdate_range('2020-01-01',periods=n))

def row(i=0,state=1,abstain=False):
 f={'prob':{'down':.2,'neutral':.2,'up':.6},'abstain':abstain,'interval80':[-.02,.03]}
 return {'symbol':'X','mode':'fast','horizon':3,'origin_index':i,'target_index':i+3,'origin':str(i),'target_date':str(i+3),'period':i//10,'regime':'uptrend','status':'ok','state':state,'realized_log_return':.01,'next_open_to_target_return':.02,'forecasts':{n:dict(f) for n in ('model',*E.BASELINES)}}

def test_multiclass_losses_known_values():
 b,l=E.losses([[1/3]*3,[0,0,1]],[-1,1])
 assert b==pytest.approx([2/3,0]);assert l==pytest.approx([np.log(3),0])
 assert E.vector({'up':.6,'down':.5,'neutral':0}) is None
 assert E.vector({'up':float('nan'),'down':0,'neutral':0}) is None

def test_baselines_have_strictly_resolved_labels_and_no_future_input():
 x=close();b=E.baselines(x.iloc[:180],10)
 assert pd.Timestamp(b['training']['label_end_max'])<x.index[179]
 assert all(sum(b[n]['prob'].values())==pytest.approx(1) for n in E.BASELINES)
 x.iloc[180:]*=100
 assert b==E.baselines(x.iloc[:180],10)

def test_neutral_outcomes_excluded_only_from_conditional_score():
 rs=[row(0,0),row(4,1)]
 m=E.metrics(rs,'model');assert m['n']==2 and m['conditional_direction']['n']==1
 assert m['conditional_direction']['brier']==pytest.approx((.75-1)**2)

def test_probabilities_scored_even_when_model_abstains():
 assert E.metrics([row(abstain=True)],'model')['n']==1
 assert E.metrics([row(abstain=True)],'model')['signal_share']==0

def test_interval_width_uses_price_and_score_penalizes_misses():
 r=row();m=E.interval_metrics([r],'model')
 assert m['coverage80']==1 and m['width_price_pct']==pytest.approx(100*(np.exp(.03)-np.exp(-.02)))
 r['realized_log_return']=.1
 assert E.interval_metrics([r],'model')['interval_score_log_pct']>m['interval_score_log_pct']

def test_execution_no_overlap_no_same_close_and_cost_subtracted():
 rs=[row(i) for i in range(10)]
 result=E.paper_execution(rs,'model',15)
 assert result['n']==3
 assert result['mean_net_pct']==pytest.approx(1.85)
 rs[0]['next_open_to_target_return']=None
 result=E.paper_execution(rs[:1],'model',15)
 assert result['n']==0 and result['skipped_no_open']==1

def test_nonoverlap_count_not_raw_forecast_count():
 assert len(E.nonoverlap([row(i) for i in range(12)]))==3

def test_bootstrap_small_sample_unknown_and_reproducible():
 assert E.bootstrap_difference([1,2,3],2)['low'] is None
 a=E.bootstrap_difference(np.arange(30)/100+1,3)
 assert a==E.bootstrap_difference(np.arange(30)/100+1,3)
 assert a['low']>0 and a['p_one_sided']<.05

def test_holm_controls_full_comparison_family():
 assert E.holm([.01,.03,.2])==pytest.approx([.03,.06,.2])
 assert E.holm([.01,.03,.2,1,1])[0]>.03

def test_replay_clock_restored_after_failure_and_early_close():
 import robustness_v4407 as R
 x=close()
 with pytest.raises(RuntimeError):
  with CLOCK.at(x.index[-1]+pd.Timedelta(hours=22)):
   assert R.freshness_guard(x)['market_age_days']==0
   assert not CLOCK.available({'published_at':'2019-01-01'})
   assert not CLOCK.available({'first_seen_at':'2099-01-01'})
   assert CLOCK.available({'first_seen_at':'2019-01-01'})
   raise RuntimeError()
 assert not CLOCK.active()

def test_historical_results_cannot_promote_even_with_good_metrics():
 rows=[row(i) for i in range(30)]
 protocol={'criteria':E.CRITERIA,'evidence_scope':'historical_development_replay','point_in_time_archive_verified':False}
 g=E.evaluate_group(rows,protocol);d=E.decision(g,protocol)
 assert not d['passed'];assert 'historical_development_only' in d['reasons'];assert 'point_in_time_archive_incomplete' in d['reasons']

def test_missing_and_invalid_forecasts_are_visible_not_silently_scored():
 rows=[row(0),row(4)];rows[1]['status']='error';rows[1]['error']='data unavailable'
 g=E.evaluate_group(rows,{'criteria':E.CRITERIA})
 assert g['attempted']==2 and g['paired']==1 and g['unavailable']==1

def test_regime_uses_prefix_only():
 x=close();r=E.regime(x.iloc[:150]);x.iloc[150:]*=100
 assert E.regime(x.iloc[:150])==r
