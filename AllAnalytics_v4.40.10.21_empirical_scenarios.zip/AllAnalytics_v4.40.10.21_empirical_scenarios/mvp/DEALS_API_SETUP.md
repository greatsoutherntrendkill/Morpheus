# Важно

В v4.9 этот документ заменён `SEC_EDGAR_SETUP.md`. Раздел «Сделки и IPO» сейчас работает только через SEC EDGAR и не требует LSEG/FactSet.

---

# AllAnalytics v4.8 — Deals provider setup

Текущий интерфейс M&A / IPO готов к live-провайдеру, но демонстрационные записи
не выдаются за полную актуальную базу.

## Предпочтительный единый провайдер: LSEG

Для полной истории M&A с 2000 года и актуальных IPO удобнее всего подключить
LSEG Deals / Equity Capital Raising через разрешённый API-продукт.

Ожидаемые переменные окружения после выдачи доступа:

```text
LSEG_CLIENT_ID=...
LSEG_CLIENT_SECRET=...
```

Точный OAuth/endpoint mapping зависит от выданного LSEG продукта и entitlement,
поэтому он подключается после получения credentials/product name.

## Альтернатива: FactSet

Подходящий набор:
- FactSet Mergers DataFeed / Mergers & Acquisitions content;
- FactSet Corporate New Issues для IPO.

После выдачи доступа можно подключить через FactSet API/Formula/DataFeed в
зависимости от entitlement.

## Почему не подменяем это бесплатным scraping

Для исторической базы с 2000 года нужны стабильные идентификаторы сделки,
статусы, deal terms, payment method, premiums, advisors, transaction multiples,
IPO offer data и последующие обновления. Неподтверждённый web-scraping не даёт
достаточной полноты и воспроизводимости для аналитического продукта.
