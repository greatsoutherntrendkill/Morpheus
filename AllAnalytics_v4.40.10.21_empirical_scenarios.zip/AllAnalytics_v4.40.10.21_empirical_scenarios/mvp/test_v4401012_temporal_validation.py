import numpy as np
import pandas as pd
import pytest
import temporal_validation_v4401012 as TV


def sample(n=900,h=20):
    ix=pd.bdate_range('2020-01-01',periods=n)
    f=pd.DataFrame({'y':np.arange(n)%2,'p':.4+.2*(np.arange(n)%2)},index=ix)
    return TV.attach(f,ix,h)


@pytest.mark.parametrize('h',[1,5,10,20,30,60])
def test_actual_target_ends_purged(h):
    d=sample(h=h).iloc[::3] # filtering must not redefine trading horizons
    chunks=TV.split(d,(.5,.7,.85),(30,10,10,10))
    assert chunks is not None
    for a,b in zip(chunks,chunks[1:]):assert a.label_end.max()<b.date.min()
    assert chunks[0].attrs['temporal_split']['final_validation_passed'] is False


def test_same_date_assets_and_revisions_do_not_cross_splits():
    d=sample();a=d.assign(symbol='A');b=d.assign(symbol='B')
    chunks=TV.split(pd.concat([a,b,a]),(.6,.8),(30,10,10))
    for z in chunks:
        assert not z.duplicated(['date','symbol']).any()
        assert z.groupby('date').symbol.nunique().eq(2).all()
    for a,b in zip(chunks,chunks[1:]):assert set(a.date).isdisjoint(set(b.date))


def test_future_feature_unknown_end_and_unsettled_are_rejected():
    d=sample(100,5);d.iloc[10,d.columns.get_loc('feature_available_at')]=d.date.iloc[11]
    d.iloc[11,d.columns.get_loc('label_end')]=pd.NaT
    z=TV.legal(d,as_of=d.date.iloc[60])
    assert d.index[10] not in z.index and d.index[11] not in z.index
    assert z.label_end.max()<d.date.iloc[60]
    assert TV.legal(d.drop(columns='label_end')).empty


def test_sealed_boundary_fixed_across_assets_and_runs(monkeypatch):
    import sealed_shadow_v44010 as S
    monkeypatch.setenv('ALLANALYTICS_SHADOW_START','2030-01-01')
    rows=[{'data_as_of':'2026-09-18','symbol':s,'forecast_key':str(i)} for i,s in enumerate(['A','B','BTC-USD'])]
    assert not S.training_rows(rows)
    assert S.is_shadow_row({'data_as_of':'2026-09-10','target_as_of':'2026-09-20'})
    assert not S.is_shadow_row({'data_as_of':'2026-09-01','target_as_of':'2026-09-10'})


def test_frozen_fit_cannot_consume_pre_origin_post_boundary_label():
    import models as M
    ds=pd.bdate_range('2020-01-01',periods=40)
    le=pd.Series(ds).shift(-10).to_numpy()
    got=M._frozen_holdout_train_indices(le,ds,ds[20],35)
    assert all(pd.Timestamp(le[i])<ds[20] for i in got)
    assert 10 not in got


def test_router_rejects_legacy_evidence_without_clock():
    import routing_policy_v4408 as R
    d=pd.DataFrame({'a':[.6]*100,'b':[.4]*100,'y':[1,0]*50})
    assert not R.fit_oos_blend(d,'a','b','y')['learned']


def test_meta_split_and_deployment_keep_actual_boundaries():
    import dynamic_ensemble_v437 as M
    d=sample(1200,20).assign(p_champion=.65,p_challenger=.45,regime='x')
    z=M._split_meta(d)
    assert z is not None
    for a,b in zip(z,z[1:]):assert a.label_end.max()<b.date.min()
    assert M._split_meta(d.drop(columns='label_end')) is None


def test_nested_selection_groups_dates_and_purges(monkeypatch):
    import champion_validation_v44010 as C
    d=sample(500,20).dropna();d=pd.concat([d,d]).sort_values('date')
    X=np.column_stack([np.arange(len(d)),d.y]);y=d.y.to_numpy(int)
    _,diag=C.fit_chronological_selected(X,y,dates=d.date.to_numpy(),label_ends=d.label_end.to_numpy())
    assert diag['purged_inner_split']
    assert diag['fit_n']+diag['validation_n']<len(d)


def test_fast_distribution_audit_does_not_select_by_future_regime():
    import distributional_forecast_v440 as D
    rng=np.random.default_rng(42);ix=pd.bdate_range('2020-01-01',periods=800)
    p=pd.Series(100*np.exp(np.cumsum(rng.normal(0,.01,len(ix)))),index=ix)
    a=D.distribution_forecast(p,'TEST',20,fast=True)
    q=p.copy();q.iloc[-1]*=3
    b=D.distribution_forecast(q,'TEST',20,fast=True)
    assert a['status']=='ok' and b['status']=='ok'
    bounds=a['temporal_split']['boundaries']
    for x,y in zip(bounds,bounds[1:]):assert x['target_end_max']<y['origin_start']
    assert a['feature_diagnostics']['conditioning']==b['feature_diagnostics']['conditioning']
    assert a['temporal_split']==b['temporal_split']
    assert not a['quality_ok']


def test_online_calibration_waits_for_outcome(monkeypatch):
    import model_quality_v433 as Q
    calls=[];original=Q._fit_platt
    def record(p,y):
        calls.append(len(p));return original(p,y)
    monkeypatch.setattr(Q,'_fit_platt',record)
    # An integration smoke exercises the resolved-outcome queue at H=20.
    rng=np.random.default_rng(16);ix=pd.bdate_range('2020-01-01',periods=650)
    close=pd.Series(100*np.exp(np.cumsum(rng.normal(0,.014,len(ix)))),index=ix)
    out=Q.walk_forward_regime(close,horizon=20,min_train=140,retrain_every=60)
    assert out and calls
    assert out['temporal_calibration_audit']
    for fit in out['temporal_calibration_audit']:
        assert pd.Timestamp(fit['max_target_end'])<pd.Timestamp(fit['prediction_date'])
    for r in out['oos_records']:
        assert pd.Timestamp(r['feature_available_at'])<=pd.Timestamp(r['date'])<pd.Timestamp(r['label_end'])


def test_provider_named_date_index_is_supported():
    d=sample();d.index.name='date'
    assert TV.split(d) is not None


def test_old_snapshot_probabilities_are_not_rebranded_as_new_generation():
    import quality_contract_v4401011 as Q
    out=Q.snapshot({'assets':[{'unified_forecast_v39':{'10':{'p_up':.8,'model_generation':'old'}}}]})
    f=out['assets'][0]['unified_forecast_v39']['10']
    assert f['p_up'] is None and f['requires_recalculation']


def test_manifest_stores_each_sample_clock(tmp_path,monkeypatch):
    import json
    monkeypatch.setenv('ALLANALYTICS_DATA_DIR',str(tmp_path))
    chunks=TV.split(sample())
    m=chunks[0].attrs['temporal_split']
    saved=json.loads((tmp_path/'temporal_manifests'/m['sample_manifest']).read_text())
    assert len(saved['samples'])==sum(len(c) for c in chunks)
    assert all(set(TV.META).issubset(r) for r in saved['samples'])


def test_revised_macro_history_cannot_bypass_vintage_requirement(monkeypatch):
    import macro_features as F
    monkeypatch.setenv('MACRO_ALLOW_LEGACY_LAG','1')
    monkeypatch.setattr(F,'_raw_daily_pit',lambda *a:pd.DataFrame())
    monkeypatch.setattr(F,'_raw_daily_legacy',lambda *a:(_ for _ in ()).throw(AssertionError('legacy must not train')))
    assert F._raw_daily(None,pd.bdate_range('2020-01-01',periods=20)).empty


def test_date_only_macro_release_cannot_enter_same_day_features():
    import macro_features as F
    g=pd.DataFrame({'available_date':['2020-01-03'],'observation_date':['2019-12-01'],'value':[100.]})
    x=F._series_revision_metrics(g,pd.date_range('2020-01-01',periods=6))
    assert pd.isna(x.loc['2020-01-03','level'])
    assert x.loc['2020-01-04','level']==100
