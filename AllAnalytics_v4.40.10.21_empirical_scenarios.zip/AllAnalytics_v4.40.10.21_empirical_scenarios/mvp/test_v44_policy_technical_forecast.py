
from __future__ import annotations
from pathlib import Path
import json, re

ROOT=Path(__file__).parent

def main():
    data=json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))
    ev=data["events"][0]
    probs=ev["rate_probabilities"]
    assert set(probs)=={"hike","cut","hold"}
    assert sum(probs.values())==100
    assert "probability_note" in ev

    index=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    assert "Повышение" in index and "Снижение" in index and "Сохранение" in index
    assert "Ключевые события и факторы" in index
    assert "Текущая ставка" in index
    assert "rate-scenarios" in index

    lab=(ROOT/"site"/"technical_lab_v44.html").read_text(encoding="utf-8")
    assert "<strong>Текущий прогноз</strong>" in lab
    assert "<strong>Текущие значения</strong>" in lab
    assert lab.index("<strong>Текущий прогноз</strong>") < lab.index("<strong>Текущие значения</strong>")
    for token in ["Вероятность роста","Вероятность падения","Ближайшая цель",
                  "Геополитический риск","risk-scale","geoRiskForAsset","renderCompactForecast"]:
        assert token in lab, token
    assert "modelный" not in lab.lower()

    export=(ROOT/"export_site.py").read_text(encoding="utf-8")
    assert "def rate_decision_probabilities" in export
    assert "rate_probabilities" in export

    print("OK: v4.4 rate scenarios + policy drivers + compact technical forecast + geopolitical risk")

if __name__=="__main__":
    main()
