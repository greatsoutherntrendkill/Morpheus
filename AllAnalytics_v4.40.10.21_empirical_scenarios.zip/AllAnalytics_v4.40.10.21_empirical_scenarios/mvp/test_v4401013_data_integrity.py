import numpy as np
import pandas as pd
import pytest
import data_contract_v4401013 as D


def frame(dates, values=None):
    c=list(values if values is not None else range(100,100+len(dates)))
    return pd.DataFrame({'date':dates,'open':c,'high':c,'low':c,'close':c})


def test_us_close_dst_and_early_close():
    for day, hour in [('2026-03-06',21),('2026-03-09',20),('2026-11-27',18)]:
        assert D.session_close('^GSPC',day).hour==hour
        f=frame([day]);close=D.session_close('^GSPC',day)
        assert D.prepare(f,'^GSPC',now=close)[0].empty
        assert len(D.prepare(f,'^GSPC',now=close+pd.Timedelta(minutes=2))[0])==1


def test_holidays_weekends_and_crypto_target():
    assert D.target_period('^GSPC','2026-11-25',1)['target_date']=='2026-11-27'
    assert D.target_period('^GSPC','2026-07-02',1)['target_date']=='2026-07-06'
    assert D.target_period('BTC-USD','2026-07-03',1)['target_date']=='2026-07-04'
    assert D.target_period('PLZL.ME','2026-07-03',1)['target_date'] is None


def test_crypto_current_daily_candle_excluded():
    d,a=D.prepare(frame(['2026-09-15','2026-09-16']),'BTC-USD',now='2026-09-16T16:00Z')
    assert len(d)==1 and a['unfinished_or_non_session_rows']==1


def test_provider_timestamp_timezone_and_date_only():
    # Tokyo midnight is previous day in UTC; preserve the local trade date.
    x=frame(['2026-09-14T00:00:00+09:00']);x.attrs['timestamp_kind']='utc_instant'
    d,a=D.prepare(x,'^N225',now='2026-09-15T00:00Z')
    assert str(d.date.iloc[0].date())=='2026-09-14'
    d,_=D.prepare(frame(['2026-09-14']),'^N225',now='2026-09-15T00:00Z')
    assert str(d.date.iloc[0].date())=='2026-09-14'


def test_intraday_final_bar_excluded():
    d,a=D.prepare(frame(['2026-09-15T12:00Z','2026-09-15T12:05Z']),'BTC-USD',interval_minutes=5,now='2026-09-15T12:08Z')
    assert len(d)==1 and a['unfinished_or_non_session_rows']==1


def test_conflicting_duplicate_and_invalid_ohlc_not_silently_repaired():
    x=frame(['2026-09-10','2026-09-10','2026-09-11','2026-09-12'],[100,101,102,103]);x.loc[2,'high']=90
    d,a=D.prepare(x,'BTC-USD',now='2026-09-15')
    assert len(d)==1 and a['conflicting_dates']==1 and a['invalid_rows']==1


def test_unknown_split_quarantines_prior_segment_without_invented_adjustment():
    x=frame(pd.date_range('2026-01-01',periods=5),[100,102,10.2,10.3,10.4])
    d,a=D.prepare(x,'PLZL.ME',now='2026-09-15')
    assert list(d.close)==[10.2,10.3,10.4] and a['quarantined_rows']==2


def test_adjusted_split_does_not_get_adjusted_twice_and_dividend_gap_preserved():
    f=frame(pd.date_range('2026-01-01',periods=3),[100,101,98])
    f=D.yahoo_price_frame(f,{'events':{'splits':{'x':{'numerator':10,'denominator':1}},'dividends':{'y':{'amount':3}}}})
    d,a=D.prepare(f,'BTC-USD',now='2026-09-15')
    assert list(d.close)==[100,101,98] and a['price_basis']=='split_adjusted_price'
    assert a['target_basis']=='price_return_excluding_cash_dividends'


def test_future_roll_not_misrepresented_as_verified():
    _,a=D.prepare(frame(['2026-01-01','2026-01-02']),'CL=F',now='2026-09-15')
    assert a['roll_policy']=='provider_continuous_unverified'


def test_cache_keys_change_on_revision_source_mode_horizon_generation():
    f=frame(pd.date_range('2026-01-01',periods=5));d,a=D.prepare(f,'BTC-USD','A',now='2026-09-15')
    rev=f.copy();rev.loc[1,['open','high','low','close']]=107
    _,b=D.prepare(rev,'BTC-USD','A',now='2026-09-15')
    _,c=D.prepare(f,'BTC-USD','B',now='2026-09-15')
    keys=[D.calculation_key(x,h,m,g) for x,h,m,g in [(a,1,'fast','v1'),(b,1,'fast','v1'),(c,1,'fast','v1'),(a,2,'fast','v1'),(a,1,'full','v1'),(a,1,'fast','v2')]]
    assert len(set(keys))==6
    assert D.series_hash(pd.Series([1,2,3]))!=D.series_hash(pd.Series([1,4,3]))


def test_same_snapshot_has_same_fingerprint_and_persists(monkeypatch,tmp_path):
    monkeypatch.setenv('ALLANALYTICS_DATA_DIR',str(tmp_path))
    f=frame(pd.date_range('2026-01-01',periods=5))
    a,ma=D.prepare(f,'BTC-USD','A',now='2026-09-15')
    b,mb=D.prepare(f.iloc[::-1],'BTC-USD','A',now='2026-09-15')
    assert ma['data_hash']==mb['data_hash'];ma=D.persist_input(a,ma,'BTC-USD')
    assert ma['snapshot_saved'] and (tmp_path/'input_snapshots'/ma['snapshot_file']).exists()


def test_live_quote_not_inserted(monkeypatch):
    import equity_forecast_v416 as E
    monkeypatch.setattr(E.MOEX419,'get_snapshot',lambda *a,**k:pytest.fail('live quote queried'))
    x=frame(['2026-09-10']);pd.testing.assert_frame_equal(E._append_live_ru(x,'PLZL.ME'),x)


def test_short_forecast_uses_closed_data(monkeypatch):
    import short_forecast_v45 as S
    from market_data_v41 import MarketResult
    x=frame(pd.date_range('2026-01-01',periods=120,freq='5min'),100+np.sin(np.arange(120)/3))
    monkeypatch.setattr(S.MD43,'fetch_intraday',lambda *a:MarketResult('BTC-USD',x,'fixture',[]))
    a=S.forecast('BTC-USD','1h',{});b=S.forecast('BTC-USD','1h',{})
    assert a['p_up']==b['p_up'];assert a['data_integrity']['accepted_rows']==120
    assert a['calculation_identity']==b['calculation_identity']


def test_component_cache_changes_on_old_revision(monkeypatch):
    import distributional_forecast_v440 as M
    rng=np.random.default_rng(123);x=pd.Series(100*np.exp(np.cumsum(rng.normal(0,.01,850))),index=pd.bdate_range('2021-01-01',periods=850))
    M._CACHE.clear();a=M.distribution_forecast(x,'TEST',10,fast=True)
    y=x.copy();y.iloc[100:120]*=1.08;M.distribution_forecast(y,'TEST',10,fast=True)
    assert len(M._CACHE)==2
    b=M.distribution_forecast(x,'TEST',10,fast=True)
    assert a==b


def test_missing_sessions_cannot_shorten_target():
    x=frame(['2026-09-10','2026-09-11','2026-09-15','2026-09-16'])
    d,a=D.prepare(x,'^GSPC',now='2026-09-17T23:00Z')
    assert a['missing_session_dates']==['2026-09-14']
    assert list(d.date.dt.strftime('%Y-%m-%d'))==['2026-09-15','2026-09-16']


@pytest.mark.parametrize('symbol',['^GSPC','^N225','^HSI','^GDAXI','^FCHI','^FTSE','BTC-USD'])
def test_supported_calendars_have_target_and_closed_bar(symbol):
    t=D.target_period(symbol,'2026-09-17',20)
    assert t['date_status']=='scheduled' and t['target_date']>'2026-09-17'


def test_macro_context_does_not_mutate_cached_forecast(monkeypatch):
    import equity_forecast_v416 as E
    original={'forecasts':{'10':{'p_up':.6,'quality':{'trusted':True}}},'history':[]}
    def mutator(f,*a):f['quality']['trusted']=False;return f
    monkeypatch.setattr(E.MACRO109,'apply',mutator)
    E._with_macro_events(original,'TEST')
    assert original['forecasts']['10']['quality']['trusted'] is True


def test_dependency_change_changes_calculation_identity():
    a={'data_hash':'same','as_of':'2026-09-17','dependency_hash':'old'}
    assert D.calculation_key(a,10,'fast','v')!=D.calculation_key({**a,'dependency_hash':'new'},10,'fast','v')


def test_moex_intraday_local_time_and_complete_five_minute_groups():
    import market_data_v43 as M
    x = frame(pd.date_range('2026-09-16 10:00', periods=8, freq='min'))
    d = M._moex_candle_frame(x.to_dict('records'), '5m')
    assert len(d) == 1
    assert pd.to_datetime(d.iloc[0]['date'], utc=True) == pd.Timestamp('2026-09-16T07:00Z')
    assert d.iloc[0]['open'] == 100 and d.iloc[0]['close'] == 104
    assert D.prepare(d, 'PLZL.ME', interval_minutes=5, now='2026-09-16T07:04Z')[0].empty
    assert len(D.prepare(d, 'PLZL.ME', interval_minutes=5, now='2026-09-16T07:06Z')[0]) == 1
    hour = M._moex_candle_frame(x.iloc[:1].to_dict('records'), '1h')
    assert pd.to_datetime(hour.iloc[0]['date'], utc=True) == pd.Timestamp('2026-09-16T07:00Z')
