"""Register AllAnalytics v4.40 distributional forecast artifacts."""
import db
import model_registry as MR

if __name__ == "__main__":
    con=db.connect()
    try:
        MR.register_champion(con)
        MR.register_v433_models(con)
        MR.register_v434_models(con)
        MR.register_v435_models(con)
        MR.register_v437_models(con)
        MR.register_v438_models(con)
        MR.register_v439_models(con)
        MR.register_v440_models(con)
        rows=con.execute(
            "SELECT model_version,role,status FROM model_registry WHERE model_version IN (?,?) ORDER BY model_version",
            (MR.V440_DISTRIBUTION_VERSION,MR.V440_MONITOR_VERSION),
        ).fetchall()
        print(rows)
    finally:
        con.close()
