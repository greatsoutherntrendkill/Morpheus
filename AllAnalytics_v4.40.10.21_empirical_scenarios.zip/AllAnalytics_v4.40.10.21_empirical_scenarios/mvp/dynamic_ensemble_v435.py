"""AllAnalytics v4.35 — Dynamic Ensemble & Meta-Learning.

This layer learns how to combine the champion and volatility/regime challenger
from their *past OOS predictions*. It never promotes a model by itself.

Key properties
--------------
- horizon-specific and regime-aware OOS weighting;
- sequential meta learner trained only on already-observed OOS component outputs;
- probability calibration from a later calibration slice;
- signal threshold selected from a final development evaluation slice;
- reliability model estimates whether the current directional call deserves trust;
- context/event layer stays advisory until v4.36 prospective ledger can validate it.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd

import feature_event_v434 as FE434
import meta_forecast_v434 as META434

VERSION = "dynamic-meta-ensemble-v4.35.0"
RELIABILITY_VERSION = "reliability-meta-v4.35.0"
VALIDATION_VERSION = "oos-stacked-calibrated-threshold-v4.35"


def _finite(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _clip_p(p):
    return float(np.clip(float(p), 0.02, 0.98))


def _logit(p):
    p=float(np.clip(float(p),1e-5,1-1e-5))
    return math.log(p/(1-p))


def _sigmoid(x):
    return float(1/(1+math.exp(-float(np.clip(x,-30,30)))))


def _ece(p, y, bins=8):
    p=np.asarray(p,float); y=np.asarray(y,float)
    if len(p)<5:return None
    edges=np.linspace(0,1,bins+1); out=0.0
    for a,b in zip(edges[:-1],edges[1:]):
        mask=(p>=a)&(p<(b if b<1 else b+1e-12))
        if mask.any():out+=float(mask.mean())*abs(float(p[mask].mean())-float(y[mask].mean()))
    return float(out)


def _metrics(p, y):
    p=np.asarray(p,float); y=np.asarray(y,float)
    ok=np.isfinite(p)&np.isfinite(y);p,y=p[ok],y[ok]
    if len(p)<5:return {"n":len(p),"accuracy":None,"edge_pp":None,"brier":None,"brier_skill":None,"ece":None}
    pred=(p>=.5).astype(float); acc=float(np.mean(pred==y)); base=max(float(np.mean(y)),1-float(np.mean(y)))
    brier=float(np.mean((p-y)**2)); bp=np.full(len(y),float(np.mean(y))); bb=float(np.mean((bp-y)**2))
    skill=(1-brier/bb)*100 if bb>1e-12 else 0.0
    return {"n":int(len(p)),"accuracy":acc,"base_accuracy":base,"edge_pp":(acc-base)*100,
            "brier":brier,"brier_skill":skill,"ece":_ece(p,y)}


def _records_map(rows: Iterable[dict]):
    out={}
    for r in rows or []:
        d=str(r.get("date") or "")[:10]; p=_finite(r.get("p_up")); y=r.get("y")
        if not d or p is None or y not in (0,1,0.0,1.0):continue
        out[d]={**r,"date":d,"p_up":p,"y":int(y)}
    return out


def _aligned_records(champion: dict, challenger: dict) -> pd.DataFrame:
    a=_records_map((champion or {}).get("oos_records") or [])
    b=_records_map((challenger or {}).get("oos_records") or [])
    dates=sorted(set(a)&set(b))
    rows=[]
    for d in dates:
        if int(a[d]["y"])!=int(b[d]["y"]):
            # Different target definitions can occasionally disagree around zero;
            # the challenger uses the actual sign for y, so prefer that sign.
            y=int(b[d]["y"])
        else:y=int(a[d]["y"])
        rows.append({"date":pd.Timestamp(d),"p_champion":a[d]["p_up"],"p_challenger":b[d]["p_up"],
                     "y":y,"regime":str(b[d].get("regime") or "unknown")})
    return pd.DataFrame(rows).sort_values("date") if rows else pd.DataFrame()


def _component_reliability(p, y) -> tuple[float,dict]:
    m=_metrics(p,y);n=int(m.get("n") or 0)
    if n<12:return .25,m
    edge=float(m.get("edge_pp") or 0); skill=float(m.get("brier_skill") or 0); ece=float(m.get("ece") or .20)
    n_term=min(1.0,math.log1p(n)/math.log(180))
    z=-.65 + .13*edge + .045*skill - 2.2*ece + .75*n_term
    return float(np.clip(_sigmoid(z),.12,.92)),m


def _meta_features(df: pd.DataFrame) -> np.ndarray:
    pc=np.clip(df["p_champion"].to_numpy(float),1e-5,1-1e-5)
    pq=np.clip(df["p_challenger"].to_numpy(float),1e-5,1-1e-5)
    return np.column_stack([
        np.log(pc/(1-pc)),np.log(pq/(1-pq)),
        np.abs(pc-pq),np.abs(pc-.5)*2,np.abs(pq-.5)*2,
    ])


def _fit_lr(X,y,sample_weight=None):
    if len(X)<20 or len(np.unique(y))<2:return None
    try:
        from sklearn.linear_model import LogisticRegression
        mdl=LogisticRegression(C=.75,max_iter=350,solver="lbfgs",random_state=435)
        mdl.fit(X,y,sample_weight=sample_weight)
        return mdl
    except Exception:return None


@dataclass
class _Platt:
    coef: float
    intercept: float
    def apply(self,p):
        arr=np.clip(np.asarray(p,float),1e-5,1-1e-5);z=np.log(arr/(1-arr))
        return 1/(1+np.exp(-np.clip(self.intercept+self.coef*z,-30,30)))


def _fit_platt(p,y):
    p=np.asarray(p,float);y=np.asarray(y,float);ok=np.isfinite(p)&np.isfinite(y);p,y=p[ok],y[ok]
    if len(p)<24 or len(np.unique(y))<2:return None
    try:
        from sklearn.linear_model import LogisticRegression
        z=np.log(np.clip(p,1e-5,1-1e-5)/(1-np.clip(p,1e-5,1-1e-5))).reshape(-1,1)
        mdl=LogisticRegression(C=1.0,max_iter=250,solver="lbfgs",random_state=435).fit(z,y)
        return _Platt(float(mdl.coef_[0,0]),float(mdl.intercept_[0]))
    except Exception:return None


def _select_regime_rows(df,current_regime):
    if df.empty:return df,"all"
    same=df[df["regime"]==str(current_regime)]
    if len(same)>=90:return same,"current_regime"
    prefix=str(current_regime).split("|")[0]
    partial=df[df["regime"].astype(str).str.startswith(prefix+"|")]
    if len(partial)>=90:return partial,"trend_regime"
    return df,"all"


def _split_meta(df):
    n=len(df)
    if n<90:return None
    a=max(55,int(n*.58)); b=max(a+24,int(n*.79)); b=min(b,n-18)
    if b<=a or n-b<16:return None
    return df.iloc[:a].copy(),df.iloc[a:b].copy(),df.iloc[b:].copy()


def _meta_fit_and_eval(df,pc_live,pq_live):
    split=_split_meta(df)
    if split is None:return None
    train,cal,ev=split
    Xtr=_meta_features(train);ytr=train["y"].to_numpy(int)
    decay=np.exp(-np.arange(len(train)-1,-1,-1)/180.0)
    mdl=_fit_lr(Xtr,ytr,decay)
    if mdl is None:return None
    pcal=mdl.predict_proba(_meta_features(cal))[:,1]
    calibrator=_fit_platt(pcal,cal["y"].to_numpy(int))
    pev=mdl.predict_proba(_meta_features(ev))[:,1]
    if calibrator is not None:pev=calibrator.apply(pev)
    # Final fit uses every already-observed OOS row; calibration remains fitted
    # only on the pre-evaluation calibration slice.
    Xall=_meta_features(df);yall=df["y"].to_numpy(int)
    decay_all=np.exp(-np.arange(len(df)-1,-1,-1)/220.0)
    live_mdl=_fit_lr(Xall,yall,decay_all)
    if live_mdl is None:return None
    live_df=pd.DataFrame([{"p_champion":pc_live,"p_challenger":pq_live}])
    live_raw=float(live_mdl.predict_proba(_meta_features(live_df))[:,1][0])
    live_p=float(calibrator.apply([live_raw])[0]) if calibrator is not None else live_raw
    base_ev=(ev["p_champion"].to_numpy(float)+ev["p_challenger"].to_numpy(float))/2
    return {"p_up":_clip_p(live_p),"raw_p_up":_clip_p(live_raw),"eval_p":np.asarray(pev,float),
            "eval_y":ev["y"].to_numpy(int),"eval_pc":ev["p_champion"].to_numpy(float),
            "eval_pq":ev["p_challenger"].to_numpy(float),"eval_baseline":base_ev,
            "calibrated":calibrator is not None,"coef":[float(x) for x in live_mdl.coef_[0]],
            "intercept":float(live_mdl.intercept_[0]),"train_n":len(train),"cal_n":len(cal),"eval_n":len(ev)}


def _empirical_threshold(p,y,default=.58):
    p=np.asarray(p,float);y=np.asarray(y,int)
    if len(p)<18:return float(default),{"source":"fallback","coverage":None,"accuracy":None}
    base=max(float(np.mean(y)),1-float(np.mean(y)))
    best=None
    for th in np.arange(.53,.721,.01):
        mask=np.maximum(p,1-p)>=th;n=int(mask.sum())
        if n<max(12,int(len(p)*.18)):continue
        acc=float(np.mean(((p[mask]>=.5).astype(int))==y[mask]));coverage=n/len(p)
        edge=acc-base
        if edge<=0:
            continue
        score=edge*math.sqrt(n)+.08*coverage-.08*max(0,th-.64)
        if best is None or score>best[0]:best=(score,float(th),acc,coverage,n,edge)
    if best is None:return float(max(default,.66)),{"source":"no_positive_oos_edge","coverage":None,"accuracy":None}
    _,th,acc,cov,n,edge=best
    return float(np.clip(th,.53,.72)),{"source":"development_oos","coverage":round(cov,4),"accuracy":round(acc,4),"n":n,"edge_pp":round(edge*100,3)}


def _reliability_model(meta,pc_live,pq_live):
    p=meta["eval_p"];y=meta["eval_y"];pc=meta["eval_pc"];pq=meta["eval_pq"]
    if len(p)<20:return None
    correct=((p>=.5).astype(int)==y).astype(int)
    X=np.column_stack([np.maximum(p,1-p),np.abs(pc-pq),np.abs(p-.5)*2])
    mdl=_fit_lr(X,correct)
    if mdl is None:
        return {"probability":float(np.mean(correct)),"trained":False,"n":len(correct)}
    # live p is injected by caller after final meta probability is known
    return {"model":mdl,"trained":True,"n":len(correct),"historical_accuracy":float(np.mean(correct))}


def _asset_prior(symbol):
    c=FE434.asset_profile(symbol).asset_class
    return {"equity":1.0,"index":1.04,"fx":.96,"commodity":.94,"crypto":.90}.get(c,.92),c


def forecast_horizon(close: pd.Series,symbol: str,horizon: int=10,fast: bool=True,context: dict|None=None) -> dict:
    h=int(horizon)
    base=META434.forecast_horizon(close,symbol=symbol,horizon=h,fast=fast,context=context)
    if not base or base.get("p_up") is None:return {}
    bm=(base.get("base_meta") or {})
    champion=bm.get("champion") or {}; challenger=bm.get("challenger") or base.get("base_meta",{}).get("challenger") or {}
    pc=_finite(champion.get("live_p_up"));pq=_finite(challenger.get("p_up"))
    # Old cached/reduced outputs may not expose raw components. Fall back to the
    # v4.34 components so the API stays robust.
    if pc is None or pq is None:
        comp={x.get("name"):x for x in (base.get("components") or [])}
        pc=pc if pc is not None else _finite((comp.get("production") or {}).get("p_up"))
        pq=pq if pq is not None else _finite((comp.get("vol_regime") or {}).get("p_up"))
    if pc is None and pq is None:return base
    if pc is None:pc=pq
    if pq is None:pq=pc

    aligned=_aligned_records(champion,challenger)
    current_regime=base.get("regime") or challenger.get("regime") or "unknown"
    selected,scope=_select_regime_rows(aligned,current_regime)
    rel_c,mc=_component_reliability(selected.get("p_champion",pd.Series(dtype=float)),selected.get("y",pd.Series(dtype=float))) if not selected.empty else (.25,{"n":0})
    rel_q,mq=_component_reliability(selected.get("p_challenger",pd.Series(dtype=float)),selected.get("y",pd.Series(dtype=float))) if not selected.empty else (.25,{"n":0})
    prior,asset_class=_asset_prior(symbol);rel_c=float(np.clip(rel_c*prior,.10,.94));rel_q=float(np.clip(rel_q*prior,.10,.94))
    sw=rel_c+rel_q or 1;dynamic_weights={"production":rel_c/sw,"vol_regime":rel_q/sw}
    weighted=_clip_p(pc*dynamic_weights["production"]+pq*dynamic_weights["vol_regime"])

    learned=_meta_fit_and_eval(selected,pc,pq) if not selected.empty else None
    if learned:
        p_meta=learned["p_up"];threshold,threshold_diag=_empirical_threshold(learned["eval_p"],learned["eval_y"],default=float(base.get("signal_threshold") or .58))
        mmeta=_metrics(learned["eval_p"],learned["eval_y"]); mbase=_metrics(learned["eval_baseline"],learned["eval_y"])
        reliability_obj=_reliability_model(learned,pc,pq)
    else:
        p_meta=weighted;threshold=float(base.get("signal_threshold") or .58);threshold_diag={"source":"fallback","coverage":None,"accuracy":None};mmeta={"n":0};mbase={"n":0};reliability_obj=None

    # Reliability score is itself learned from past correctness when possible.
    disagreement=abs(pc-pq)
    if reliability_obj and reliability_obj.get("trained"):
        mdl=reliability_obj["model"]
        liveX=np.array([[max(p_meta,1-p_meta),disagreement,abs(p_meta-.5)*2]],float)
        reliability=float(mdl.predict_proba(liveX)[:,1][0])
        reliability_trained=True
    else:
        historical=(reliability_obj or {}).get("probability") if reliability_obj else None
        reliability=float(np.clip((historical if historical is not None else (rel_c+rel_q)/2)-.30*min(1,disagreement/.35),.25,.82))
        reliability_trained=False

    # Context remains advisory until v4.36 prospective settlement can prove its
    # own edge. It can confirm a signal or raise caution, but cannot dominate it.
    ctx=context or FE434.build_context(symbol,own_close=close,as_of=pd.Timestamp(close.index[-1]) if len(close) else None)
    context_adjust=FE434.apply_context_probability(p_meta,ctx) or {}
    context_p=_finite(context_adjust.get("context_p_up"))
    if context_p is None:context_p=_finite(context_adjust.get("p_up"))
    ctx_conf=float(ctx.get("context_confidence") or 0);drift=float(ctx.get("drift_score") or 0);event_risk=float(ctx.get("event_risk") or 0)
    context_weight=.04 if ctx_conf>=.55 and drift<.7 else 0.0
    if context_p is not None and context_weight>0 and (context_p>=.5)==(p_meta>=.5):
        p_final=_clip_p((1-context_weight)*p_meta+context_weight*context_p)
    else:p_final=p_meta
    context_disagreement=bool(context_p is not None and (context_p>=.5)!=(p_meta>=.5) and abs(context_p-.5)>=.03)

    # Disagreement-aware routing and uncertainty gates.
    if disagreement>=.18:
        p_final=.5+.72*(p_final-.5);threshold+=.015
    if context_disagreement:threshold+=.012
    threshold+=.020*min(1,drift)+.015*min(1,event_risk)
    threshold=float(np.clip(threshold,.53,.74))
    min_reliability=.52 if (mmeta.get("n") or 0)>=18 else .56
    # A poorly validated meta call is not allowed to keep an extreme displayed
    # probability. Reliability therefore controls both publication and distance
    # from 50%, making the number itself honest rather than merely tagging it.
    if reliability < min_reliability:
        rel_shrink=float(np.clip(reliability/max(min_reliability,1e-9),.35,1.0))
        p_final=float(.5+rel_shrink*(p_final-.5))
    dir_prob=max(p_final,1-p_final)
    abstain=bool(dir_prob<threshold or reliability<min_reliability)
    if dir_prob>=.72:strength="выраженный"
    elif dir_prob>=max(.64,threshold):strength="умеренный"
    elif dir_prob>=threshold:strength="слабый"
    else:strength="нет преимущества"
    if abstain:strength="нет преимущества"
    trusted=bool(not abstain and reliability>=.56 and (mmeta.get("edge_pp") or -999)>0 and not context_disagreement)

    components=[
        {"name":"production","p_up":round(pc,6),"weight":round(dynamic_weights["production"],4),"reliability":round(rel_c,4),"oos":mc},
        {"name":"vol_regime","p_up":round(pq,6),"weight":round(dynamic_weights["vol_regime"],4),"reliability":round(rel_q,4),"oos":mq},
        {"name":"context_advisory","p_up":round(context_p if context_p is not None else .5,6),"weight":round(context_weight,4),"reliability":None,"validated":False},
    ]

    return {
        "version":VERSION,"reliability_version":RELIABILITY_VERSION,"feature_version":base.get("feature_version"),"horizon":h,
        "p_up":round(float(p_final),6),"p_down":round(float(1-p_final),6),"abstain":abstain,
        "signal_strength":strength,"signal_threshold":round(threshold,3),"regime":current_regime,
        "quality":{"trusted":trusted,"confidence":"средняя" if trusted else "низкая","bias":"neutral" if abstain else ("bullish" if p_final>=.5 else "bearish"),
                   "reason":"надёжность ниже порога" if reliability<min_reliability else ("нет достаточного преимущества" if abstain else "динамический ансамбль подтверждён OOS meta-learning")},
        "components":components,"dynamic_weights":{k:round(v,4) for k,v in dynamic_weights.items()},
        "meta_learning":{"used":bool(learned),"scope":scope,"aligned_oos_n":int(len(selected)),"raw_weighted_p_up":round(weighted,6),
                         "meta_raw_p_up":round(float(learned['raw_p_up']),6) if learned else None,"meta_calibrated":bool(learned and learned.get('calibrated')),
                         "train_n":learned.get('train_n') if learned else 0,"calibration_n":learned.get('cal_n') if learned else 0,"evaluation_n":learned.get('eval_n') if learned else 0,
                         "coefficients":learned.get('coef') if learned else None},
        "reliability":{"probability":round(reliability,4),"trained":reliability_trained,"min_required":min_reliability,
                       "historical_accuracy":None if not reliability_obj else round(float(reliability_obj.get('historical_accuracy',reliability_obj.get('probability',0))),4),
                       "version":RELIABILITY_VERSION},
        "threshold_selection":{**threshold_diag,"final_threshold":round(threshold,3)},
        "context_features":base.get("context_features") or {},"event_context":base.get("event_context") or {},
        "context_p_up":round(context_p if context_p is not None else .5,6),"context_weight_status":"advisory_until_v4.36_prospective_validation",
        "context_disagreement":context_disagreement,"event_risk":base.get("event_risk"),"event_bias":base.get("event_bias"),
        "feature_drift":base.get("feature_drift") or {},"p_neutral":(base.get("scorecard") or {}).get("p_neutral"),
        "scorecard":{**(base.get("scorecard") or {}),"meta_oos_n":mmeta.get("n"),"meta_accuracy":mmeta.get("accuracy"),"meta_edge_pp":mmeta.get("edge_pp"),
                     "meta_brier_skill":mmeta.get("brier_skill"),"meta_ece":mmeta.get("ece"),"equal_weight_brier_skill":mbase.get("brier_skill"),
                     "ensemble_reliability":round(reliability,4)},
        "validation":{**(base.get("validation") or {}),"meta_training_uses_component_oos_only":True,"meta_time_ordered_split":True,
                      "calibration_slice_precedes_evaluation":True,"threshold_selected_from_development_oos":True,"regime_scope":scope,
                      "context_expert_prospective_validated":False,"automatic_promotion":False,"validation_version":VALIDATION_VERSION},
        "base_v434":base,
    }
