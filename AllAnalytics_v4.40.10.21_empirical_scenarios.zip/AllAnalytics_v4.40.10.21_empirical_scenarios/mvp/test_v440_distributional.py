import math
import numpy as np
import pandas as pd

import distributional_forecast_v440 as D
import distribution_feedback_v440 as FB


def _close(n=460):
    idx=pd.bdate_range('2023-01-02',periods=n)
    rng=np.random.default_rng(440)
    # stationary but heteroskedastic synthetic path: enough structure to exercise
    # quantile ordering/calibration without asserting fake alpha.
    vol=np.where(np.arange(n)%90<18,.018,.008)
    r=.00025+rng.normal(0,vol,n)
    return pd.Series(100*np.exp(np.cumsum(r)),index=idx)


def test_distribution_quantiles_are_ordered_and_intervals_coherent():
    x=_close()
    out=D.distribution_forecast(x,'AAPL',10)
    assert out['status']=='ok'
    q=out['quantiles']
    vals=[q['q10_return_pct'],q['q25_return_pct'],q['q50_return_pct'],q['q75_return_pct'],q['q90_return_pct']]
    assert vals==sorted(vals)
    p=out['price_quantiles']
    prices=[p['q10_price'],p['q25_price'],p['q50_price'],p['q75_price'],p['q90_price']]
    assert prices==sorted(prices)
    assert out['expected_abs_move_pct']>0
    assert 0 <= out['development_evaluation']['coverage_80'] <= 1
    assert out['evaluation']['scope'] == 'not_validated'
    assert out['quality_ok'] is False
    assert 0 <= out['development_evaluation']['coverage_50'] <= 1
    assert out['development_split']['purge_train_cal']==10
    assert out['development_split']['purge_cal_eval']==10


def test_v440_never_changes_guarded_direction(monkeypatch):
    x=_close(420)
    base={
        'version':'event-response-models-v4.39.0','model_version':'event-response-models-v4.39.0',
        'p_up':.637,'p_down':.363,'abstain':False,'signal_threshold':.59,
        'signal_strength':'слабый','components':[{'name':'core_meta','p_up':.637,'weight':1.0}],
        'validation':{},'scorecard':{}
    }
    monkeypatch.setattr(D.BASE439,'forecast_horizon',lambda *a,**k:dict(base))
    monkeypatch.setattr(D,'distribution_forecast',lambda *a,**k:{
        'version':D.VERSION,'status':'ok','quality_ok':True,'quantiles':{'q10_return_pct':-2,'q50_return_pct':.3,'q90_return_pct':2.6},
        'evaluation':{'coverage_80':.8,'pinball_skill_pct':3.0},'expected_abs_move_pct':1.5
    })
    out=D.forecast_horizon(x,'AAPL',10)
    assert out['p_up']==base['p_up']
    assert out['p_down']==base['p_down']
    assert out['abstain']==base['abstain']
    assert out['signal_threshold']==base['signal_threshold']
    assert out['components']==base['components']
    assert out['validation']['distributional_changes_directional_probability'] is False


def test_options_benchmark_is_benchmark_only(monkeypatch, tmp_path):
    snap=tmp_path/'alt.json'
    snap.write_text('{"options": {"underlyings": {"SPY": {"underlying":"SPY","linked_assets":["AAPL"],"median_iv":0.2,"nearest_30d_expiration":"2026-10-16","source":"test"}}}}')
    monkeypatch.setattr(D,'ALT_SNAPSHOT',snap)
    out=D._options_benchmark('AAPL',10)
    assert out['available'] is True
    assert math.isclose(out['implied_move_pct_1sigma'],0.2*math.sqrt(10/252)*100,rel_tol=1e-4)


def test_distribution_feedback_settles_quantiles(tmp_path):
    ledger=FB.Ledger(tmp_path/'dist.sqlite3')
    idx=pd.bdate_range('2026-01-02',periods=30)
    prices=100*np.exp(np.linspace(0,.06,len(idx)))
    hist=[{'t':str(d.date()),'c':float(v)} for d,v in zip(idx[:10],prices[:10])]
    row={'symbol':'AAPL','as_of':str(idx[9].date()),'history':hist,'forecasts':{'5':{
        'distribution_version':D.VERSION,
        'distribution_forecast':{'version':D.VERSION,'status':'ok','quality_ok':True,
          'quantiles':{'q10_return_pct':-3,'q25_return_pct':-1,'q50_return_pct':1,'q75_return_pct':3,'q90_return_pct':6},
          'expected_abs_move_pct':2.0,'evaluation':{},'calibration':{},'options_benchmark':{}}
    }}}
    rec=ledger.record_row(row,'test')
    assert rec['inserted']==1
    full=pd.DataFrame({'date':idx,'close':prices})
    settled=ledger.settle_due(lambda s:full,limit=10)
    # data_as_of is historical relative to current test date, so it is mature.
    assert settled['settled']==1
    sc=ledger.scorecard(window_days=3650,symbol='AAPL',horizon=5)
    assert sc['n']==1
    assert 0 <= sc['coverage_80'] <= 1
    assert sc['mean_pinball']>=0
