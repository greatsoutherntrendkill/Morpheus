# AllAnalytics v4.24.1 — apimoex compatibility fix

- Fixed an invalid dependency pin from `apimoex>=1.5.0` to `apimoex>=1.4.0,<1.5.0`.
- `apimoex 1.5.0` requires Python 3.14+, while the project environment may use Python 3.13.
- The forecast code uses `get_board_history`, which is available in apimoex 1.4.0.
- No market-data, forecast, UI, M&A, or API logic was changed.
