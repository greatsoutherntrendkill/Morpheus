# SEC EDGAR setup — AllAnalytics v4.9

## Главное

SEC EDGAR не требует API key для публичных data APIs и архивов.

Для автоматического доступа SEC просит объявленный `User-Agent` с контактными
данными приложения. В `.env` добавьте:

```env
SEC_USER_AGENT=AllAnalytics Research your-real-email@example.com
```

Используйте реальный контактный e-mail. Это не секрет и не API key.

## Что AllAnalytics берёт из SEC

### M&A discovery

Используются формы:

- `DEFM14A` — definitive proxy statement relating to merger/acquisition;
- `PREM14A` — preliminary proxy statement relating to merger/acquisition;
- `S-4`, `S-4/A`, `F-4`, `F-4/A` — business-combination registrations,
  которые дополнительно проверяются по тексту;
- `SC TO-T`, `SC 14D9` и amendments — tender-offer / target response filings,
  также проверяются по тексту.

`DEFM14A` и `PREM14A` считаются сильным SEC-сигналом сделки уже по форме.
Остальные типы проходят текстовую проверку.

### IPO discovery

В индекс берутся `424B4`, но в пользовательский список запись попадает только
если текст prospectus содержит прямое указание на `initial public offering`.
Так обычные follow-on / secondary offerings не выдаются за IPO.

## История

AllAnalytics читает квартальные SEC EDGAR master indexes.

Переключатели:

- `Последние` — текущий квартал, интерфейс показывает последние ~120 дней;
- `1 год` — квартальные индексы примерно за последние 12 месяцев;
- `с 2000` — фоновая индексация кварталов начиная с 2000-01-01.

Полная историческая индексация происходит один раз. Метаданные сохраняются в:

```text
sec_deals.db
```

После этого история читается локально, а новые кварталы только дополняются.

## Двухступенчатая загрузка

Чтобы не скачивать тысячи больших SEC filings сразу:

1. `master.zip` индексирует CIK / company / form / date / accession;
2. текст конкретного filing загружается только для видимых строк или когда
   пользователь открывает карточку.

Это значительно уменьшает сетевой трафик и ускоряет интерфейс.

## Ограничения

SEC — отличный официальный источник для американских публичных компаний и
регистрационных событий, но это не глобальная коммерческая база всех private
M&A.

Если поле нельзя уверенно извлечь из filing, AllAnalytics показывает
`не раскрыто / не извлечено` и не подставляет демонстрационное число.

## Endpoints

```text
GET /api/corpfin/deal-provider-status
GET /api/corpfin/transactions?kind=mna&range=latest
GET /api/corpfin/transactions?kind=ipo&range=1y
GET /api/corpfin/transactions?kind=mna&range=2000
GET /api/corpfin/transactions/{accession}
```
