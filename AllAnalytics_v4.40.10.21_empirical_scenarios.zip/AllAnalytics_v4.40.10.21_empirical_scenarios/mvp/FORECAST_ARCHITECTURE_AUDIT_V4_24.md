# Forecast Architecture Audit — v4.24

## End-to-end chain audited

`market universe -> live quote -> forecast trigger -> history resolver -> normalization -> feature construction -> model -> API schema -> frontend state -> cache`

## Root causes found

### 1. Data-source coupling
The Russian live-price path and the Russian forecast-history path depended on the same MOEX domain. A successful board marketdata request does not guarantee that multiple historical requests will complete on the same VPN/network route. The forecast had no independent long-history source in its fast path.

### 2. Impossible history/model contract
`models.build_features()` contains `dist_ma200`, so roughly the first 200 observations are unavailable. `walk_forward_direction(..., min_train=120)` then requires another 180 valid development rows. In practice the fast model needs about 390–400 closes. v4.23 fetched ~132 calendar days (~90 sessions), so the real walk-forward model was structurally unable to run from that input.

### 3. Scenario model was presented as forecast
For Russian assets `forecast_fast()` directly used `models.scenario_paths()` whenever >=61 closes existed. But `models.py` itself describes that function as a historical block-bootstrap scenario distribution and explicitly says it is not a forecast model. This was a modelling-contract mismatch.

### 4. Tests did not test production data delivery
The v4.21–v4.23 tests monkeypatched `history_recent()` with synthetic DataFrames. They proved the model functions worked once data already existed, but not that MOEX/Yahoo history actually reached those functions. That is why tests could pass while every production card showed `Прогноз временно недоступен`.

### 5. No durable full-history equity cache
Live prices had last-good caching, but newly added Russian equities did not have a dedicated persistent multi-year history cache. Reloading the page could therefore repeat the same network failure even though a history download had succeeded earlier.

## Corrected contract

### Data layer
- MOEX ISS remains authoritative for the displayed current Russian price.
- Forecast history is a separate concern and has multiple providers.
- The preferred long-history route is a one-request Yahoo daily chart, because it is independent from MOEX routing and supplies enough observations for the real model.
- `apimoex` is retained as the official cursor-aware MOEX history recovery client.
- Recent MOEX history is used only when long history is unavailable.

### Model layer
- `>=390 closes`: AllAnalytics purged walk-forward logistic model + quality gate.
- `61–389 closes`: historical block-bootstrap scenario fallback, explicitly marked as fallback.
- `<61 closes`: unavailable, with diagnostics; no fake probability.

### Persistence
- Full forecast history is cached for 24h.
- Forecast output is cached separately for 3h.
- v4.24 uses new cache namespaces to avoid accidental reuse of previous-version outputs.

## Validation

The new tests cover:
- long independent history -> actual walk-forward probability;
- short MOEX history -> scenario probability rather than failure;
- local Russian-index history -> actual walk-forward probability;
- previous Russian forecast tests without live network access.

Relevant forecast/market regression set: 22/22 passed.
Full repository test suite: 41 passed, 1 old unrelated failure in `test_v34_decision.py` because `site/model_benchmark_v34.json` lacks the legacy `scope.assets` field. This predates the forecast rebuild and was not modified.
