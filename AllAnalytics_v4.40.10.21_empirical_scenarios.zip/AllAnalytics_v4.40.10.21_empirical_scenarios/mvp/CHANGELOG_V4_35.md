# AllAnalytics v4.35 — Dynamic Ensemble & Meta-Learning

## Главная идея

v4.35 перестаёт использовать фиксированные веса между основной и режимной моделями. Теперь вес каждого компонента зависит от его фактического OOS-качества на текущем горизонте и, при достаточной истории, в текущем режиме рынка.

## Модельные изменения

- Добавлен `dynamic_ensemble_v435.py`.
- Production model и volatility/regime challenger сохраняют последние point-in-time OOS-прогнозы.
- Компонентные веса рассчитываются по OOS accuracy / edge / Brier skill / calibration error и effective sample size.
- Если по текущему режиму накоплено достаточно OOS-наблюдений, веса считаются именно в этом режиме; иначе используется более широкий трендовый режим или весь OOS-набор.
- Добавлен time-ordered stacked meta-learner: входами служат только уже полученные OOS-прогнозы компонентов.
- Добавлена отдельная calibration slice перед финальной evaluation slice; финальная live-модель переобучается на всех уже известных OOS-компонентах, но calibration не смотрит в evaluation.
- Порог публикации сигнала выбирается из development OOS, а не задаётся одной константой для всех рынков.
- Добавлен reliability meta-model: оценивает вероятность того, что текущий направленный сигнал заслуживает доверия.
- При низкой reliability вероятность не только маркируется как ненадёжная, но и автоматически сжимается к 50%.
- При сильном расхождении production и regime model итоговая вероятность дополнительно сжимается, а порог публикации повышается.
- v4.34 event/context layer сохранён, но до prospective validation v4.36 остаётся только advisory-компонентом и не может доминировать над OOS-валидированными моделями.

## UI / объяснимость

Technical Lab теперь может показывать:
- текущую reliability ансамбля;
- динамические веса базовой и режимной моделей;
- сколько OOS-наблюдений использовал meta-learning;
- область обучения: текущий режим / похожий трендовый режим / вся история;
- фактический OOS-derived threshold публикации сигнала.

Overview дополнительно получает reliability и динамические веса в рыночном контексте прогноза.

## API

Новый endpoint:

`/api/models/quality-v435?symbol=SBER.ME&horizon=10`

Он возвращает итоговый forecast, dynamic weights, meta-learning diagnostics, reliability и threshold selection.

Старые `/api/models/quality-v434` и `/api/models/quality-v433` оставлены как compatibility aliases.

## Governance

В registry добавлены:
- `dynamic-meta-ensemble-v4.35.0`
- `reliability-meta-v4.35.0`

Обе модели остаются challenger/research layers. Автоматического promotion champion нет.

## Проверка

Полный проектный test suite: **76/76 passed**.
Python-модули проходят `py_compile`, активный frontend JavaScript проходит `node --check`.
