# AllAnalytics v4.29 — Resilient Network Layer + News/Map + Live Price Fix

- Added a project-wide resilient Requests transport: direct/no-env, system/env and optional dedicated egress proxy.
- Added `/api/network/status` diagnostics.
- News/map now uses stale-while-revalidate: the UI returns immediately from last-good/generated data and refreshes live news in background.
- Image/Pexels downloads no longer block or erase map/news content.
- Added persistent news last-good cache and browser localStorage fallback.
- Added `/api/map/geo` fallback for the local world geometry file.
- Fixed Overview current-price widget: the active renderer now actually updates it; latest chart close is used until a live quote arrives.
- Live-price transitions remain animated when new quotes arrive.
