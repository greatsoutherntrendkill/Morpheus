# AllAnalytics v3.8 — Alternative Data Intelligence

v3.8 turns the external-data slots from v3.7 into a real user-facing live intelligence layer.

## Providers wired server-side

- **CoinGlass V4** — BTC / ETH / SOL / XRP derivatives:
  - aggregated open interest history;
  - OI-weighted funding history;
  - aggregated long/short liquidations;
  - 1D / 7D OI change;
  - 7D funding average;
  - liquidation imbalance and crowding interpretation.
- **Massive Options** — option-chain snapshots for SPY, QQQ, IWM, DIA, GLD, SLV and USO:
  - call/put open interest;
  - put/call OI ratio;
  - median implied volatility;
  - near-30D 25-delta skew;
  - IV term structure;
  - top strikes by OI;
  - gross gamma-intensity diagnostic from the sampled chain.
- **EIA API v2** — physical energy market:
  - WTI spot;
  - Henry Hub spot;
  - U.S. commercial crude stocks;
  - Lower-48 gas storage;
  - U.S. crude production.
- **CFTC** — UI/architecture slot retained. CFTC public reporting does not require a private API key, but exact TFF/Disaggregated contract mapping remains deliberately separate rather than mixing incompatible trader categories.

## Security

All credentials live only in `.env` and are consumed by the FastAPI server. They are never written into `data.js`, `altdata_v38.json`, HTML, or browser requests.

The test suite explicitly scans the static site and fails if any configured credential leaks into browser-visible files.

## Interactive UX

Homepage now contains **Alternative Data Terminal** with tabs:

1. Crypto Derivatives
2. Options Surface
3. Energy Fundamentals
4. CFTC Positioning

The terminal includes selectors, live refresh, status badges, charts, user-readable interpretations and asset-level integrations.

Examples:
- BTC / ETH / SOL / XRP asset pages receive CoinGlass OI/funding/liquidation context.
- S&P 500 / Nasdaq / Russell / Dow and selected commodity asset pages receive Massive options-proxy context.
- WTI and natural gas pages receive EIA physical-market context.

Dedicated page:

`/altdata_lab_v38.html`

## API endpoints

- `GET /api/altdata/live`
- `GET /api/altdata/live?force=1`
- `GET /api/altdata/asset/{symbol}`
- `GET /api/altdata/providers`

The live endpoint uses a server-side cache (default 15 minutes) and preserves the last good provider payload if one vendor temporarily fails.

## Refresh

```bash
python update_altdata_v38.py
```

or full project refresh:

```bash
python refresh_v38.py
```

## Model-governance rule

Alternative data is **not silently injected into the production model** in v3.8.

That would invalidate previous backtests unless historical vendor data is reconstructed point-in-time with correct release timestamps. v3.8 first creates the data warehouse + live user layer. A later model generation can promote a feature only after historical coverage and leakage tests are sufficient.

Production champion remains `logreg-v3.2.0`; v3.6/v3.7 challengers remain unchanged.
