import numpy as np, pandas as pd
import robustness_v4407 as R
import asset_specialists_v438 as S

def _series(n=520):
    idx=pd.bdate_range(end=pd.Timestamp.today().normalize(),periods=n)
    rng=np.random.default_rng(7);r=rng.normal(.00025,.011,n)
    return pd.Series(100*np.exp(np.cumsum(r)),index=idx)

def test_freshness_guard_recent_data_is_not_hard_stale():
    x=_series();g=R.freshness_guard(x,now=x.index[-1]);assert not g['hard_stale']

def test_freshness_guard_old_data_is_hard_stale():
    x=_series();g=R.freshness_guard(x,now=x.index[-1]+pd.Timedelta(days=20));assert g['hard_stale']

def test_soft_regime_is_probability_simplex():
    q=R.soft_regime(_series());assert abs(q['trend']+q['range']+q['high_vol']-1)<2e-4

def test_consistency_gate_detects_opposite_median():
    x={'conditional_p_up':.76,'distribution_forecast':{'status':'ok','quality_ok':True,'quantiles':{'q50_return_pct':-2.0},'evaluation':{'effective_n':20}}}
    g=R.consistency_gate(x);assert 'disagreement' in g['status'] and g['severity']>0

def test_subpercent_medians_do_not_change_units():
    actions=[]
    for median in [-.01,-.49,-.50,-.99,-1.0]:
        out={'conditional_p_up':.75,'distribution_forecast':{'status':'ok','quality_ok':True,'q50_return_pct':median,'evaluation':{'effective_n':20}}}
        actions.append(R.consistency_gate(out)['action'])
    assert actions==['shrink','shrink','shrink','shrink','abstain']

def test_equity_peer_matrix_uses_synchronized_db(monkeypatch):
    idx=pd.bdate_range('2026-01-01',periods=40);db=pd.DataFrame({'AAPL':range(40),'MSFT':range(1,41)},index=idx)
    monkeypatch.setattr(S,'_db_matrix',lambda:db)
    monkeypatch.setattr(S,'_cached_equity_matrix',lambda:(_ for _ in ()).throw(AssertionError('legacy cache used')))
    m=S._equity_peer_matrix('AAPL',pd.Series(range(40),index=idx));assert 'MSFT' in m.columns
