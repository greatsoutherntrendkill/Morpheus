import copy
import json
from pathlib import Path
import pandas as pd
import pytest
import research_monthly_v4403 as R
from test_v4403_monthly_research import _payload, _snapshot


def test_bounds_shift_together_and_weights_unchanged(monkeypatch):
    monkeypatch.setattr(R,'_real_macro_snapshot',lambda _: _snapshot())
    full=R.build(_payload(),as_of='2026-09-12',news=[])
    us,ru=full['rates']
    assert us['current_display']=='3,50–3,75%'
    assert us['current_upper']-us['current_lower']==pytest.approx(.25)
    for z in us['path']:
        assert z['upper']-z['lower']==pytest.approx(.25)
        assert z['modal_upper']-z['modal_lower']==pytest.approx(.25)
        assert z['value']==z['upper'] and z['modal_rate']==z['modal_upper']
        assert sum(z['probabilities'].values())==100
    assert all('lower' not in z for z in ru['path'])
    baseline=copy.deepcopy(full)
    for row in full['rates']:R.add_ffr_corridor(row)
    assert full==baseline


def test_pair_uses_same_observation_date():
    lo=pd.Series([3.5,3.25],index=pd.to_datetime(['2026-09-10','2026-09-11']))
    hi=pd.Series([3.75],index=pd.to_datetime(['2026-09-10']))
    result=R._target_range(lo,hi)
    assert result['target_as_of']=='2026-09-10'
    assert result['target_lower']==3.5 and result['target_upper']==3.75


@pytest.mark.parametrize('lo,hi',[(4,3),(-1,0),(float('nan'),3),(3,3),(3,float('inf'))])
def test_invalid_pair_is_not_published(lo,hi):
    ix=pd.to_datetime(['2026-09-10'])
    assert R._target_range(pd.Series([lo],index=ix),pd.Series([hi],index=ix)) is None


def test_effective_rate_does_not_replace_target(monkeypatch):
    monkeypatch.setattr(R,'_db_con',lambda:None)
    monkeypatch.setattr(R,'_meta',lambda _: {'research_current_mode':'live_current'})
    monkeypatch.setattr(R,'_series',lambda _,sid:pd.Series([9],index=pd.to_datetime(['2026-09-10'])) if sid=='FEDFUNDS' else pd.Series(dtype=float))
    out=R._real_macro_snapshot(_payload())
    assert out['US']['policy_rate']==3.75
    assert out['US']['target_lower']==3.5


def test_static_fallback_has_both_bounds():
    root=Path(__file__).parent/'site'
    out=json.loads((root/'data.json').read_text())
    for key in ('research_monthly_v4403','research_outlook_v46'):
        assert out[key]['status']=='replaced_by_macro_policy_v19'
        assert out[key]['rates']==[]
    trained=json.loads((root/'macro_policy_v19_results.json').read_text())
    for h in (1,2,3):
        lo=next(f for f in trained['forecasts'] if f['series']=='DFEDTARL' and f['horizon']==h)
        hi=next(f for f in trained['forecasts'] if f['series']=='DFEDTARU' and f['horizon']==h)
        assert lo['status']==hi['status']=='ok'
        assert lo['value']<hi['value']
        assert lo['period']==hi['period']
        assert lo['target_semantics']==hi['target_semantics']=='month_end_policy_target'


def test_old_last_good_cache_upgrades_without_changing_weights(tmp_path):
    row={'region':'US','current':3.75,'path':[{'value':3.7,'modal_rate':3.75,'probabilities':{'cut':20,'hold':80,'hike':0}}]}
    p=tmp_path/'old.json';p.write_text(json.dumps({'rates':[row]}))
    result=R.load_last_good(p)['rates'][0]
    assert result['path'][0]['lower']==3.45
    assert result['path'][0]['probabilities']==row['path'][0]['probabilities']
