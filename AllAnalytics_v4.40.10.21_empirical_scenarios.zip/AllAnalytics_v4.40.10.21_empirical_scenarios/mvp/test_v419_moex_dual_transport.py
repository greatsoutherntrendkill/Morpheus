import moex_fast_v419 as M


def test_board_snapshot_uses_one_combined_request(monkeypatch):
    calls=[]
    def fake(path, params):
        calls.append((path, dict(params)))
        return ({
            'securities': {'columns':['SECID','SHORTNAME','PREVPRICE','PREVLEGALCLOSEPRICE'],
                           'data':[['SBER','Сбербанк',311.4,None],['GAZP','Газпром',128.5,None]]},
            'marketdata': {'columns':['SECID','LAST','LASTCHANGEPRCNT','LASTTOPREVPRICE','UPDATETIME','SYSTIME'],
                           'data':[['SBER',315.2,1.22,None,'18:00:00','18:00:01'],['GAZP',None,None,None,None,'18:00:01']]}
        }, 'https-direct')
    monkeypatch.setattr(M,'_request_json',fake)
    rows,tr=M._board_snapshot('shares','TQBR')
    assert len(calls)==1
    assert calls[0][1]['iss.only']=='securities,marketdata'
    assert rows['SBER']['last']==315.2
    assert rows['GAZP']['last']==128.5
    assert rows['GAZP']['stale'] is True
    assert tr=='https-direct'


def test_marketdata_survives_without_security_metadata(monkeypatch):
    def fake(path, params):
        return ({
            'marketdata': {'columns':['SECID','LAST','LASTCHANGEPRCNT','LASTTOPREVPRICE','UPDATETIME','SYSTIME'],
                           'data':[['SBER',315.2,1.22,None,'18:00:00','18:00:01']]}
        }, 'http-direct')
    monkeypatch.setattr(M,'_request_json',fake)
    rows,tr=M._board_snapshot('shares','TQBR')
    assert rows['SBER']['last']==315.2
    assert tr=='http-direct'
