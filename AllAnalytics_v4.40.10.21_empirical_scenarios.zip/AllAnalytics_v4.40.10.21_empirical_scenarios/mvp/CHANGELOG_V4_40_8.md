# AllAnalytics v4.40.8 — Data-Driven Routing

v4.40.8 is a routing/governance release. It does not add another directional algorithm. Instead, it replaces the remaining performance-routing constants around the existing champion/regime/specialist/event stack with weights learned from chronological OOS or settled prospective evidence.

## Core routing

- Champion vs regime-expert fallback weights are learned from chronological OOS probabilities by minimizing Brier loss.
- The fitted OOS weight must beat a 50/50 blend on a recent untouched validation tail; otherwise production falls back to 50/50.
- Move/No-Move probabilities receive an independent OOS-learned blend, so direction routing and material-move routing are not assumed to have the same optimal weights.
- Removed asset-class routing priors from the production blend.
- Removed the fixed disagreement shrink and fixed drift/event threshold increments from performance routing.

## Prospective publish router

- Settled prospective forecasts can train a separate trust/publish router after enough observations exist.
- Features include directional conviction, `P(material move)`, component disagreement, feature drift, event risk, context disagreement and base reliability.
- The router uses three chronological slices: model fit → publication-threshold selection → untouched audit.
- It must beat the model's own factorized trust baseline on Brier loss and retain positive publication utility on the untouched audit slice before it can affect live publication.
- With insufficient evidence or a failed audit the router remains inactive; no small-sample weight is invented.

## Satellite weights and governance

- Context, asset-specialist and event-response weights are learned from paired prospective Brier performance after their existing governance gates are satisfied.
- Governance caps remain hard safety ceilings, not performance preferences.
- A human approval from an older model generation cannot automatically carry forward to the v4.40.8 generation.
- Old prospective evidence remains immutable for audit. Routing can use compatible target semantics where explicitly allowed, while candidate promotion remains isolated to the current model generation.

## Identity and cache safety

- Model generation: `directional-3state-move-routing-v4.40.8`.
- Forecast contract: `forecast-contract-v4.40.8`.
- Cache contract: `forecast-cache-v4.40.8`.
- Old forecast caches are invalid for the new generation.

## Diagnostics

New endpoint:

`/api/models/routing-v4408/status?symbol=AAPL&horizon=10`

Live forecast responses also expose a `data_driven_routing` block showing whether core/move blends were learned and whether the prospective publish router is active.

## Startup/export reliability

- Full static multi-asset ML export is no longer a mandatory blocking startup step. The packaged last-good snapshot loads immediately while live v4.40.8 forecasts are served by the API.
- Set `ALLANALYTICS_REBUILD_STATIC=1` only when an explicit offline/static snapshot rebuild is required.
- The optional exporter contains an isolated batch-worker path so native numerical backend state is not allowed to accumulate across the whole asset universe.
- This startup change does not alter forecast mathematics or prospective evidence.
