
from __future__ import annotations
import json, sqlite3
from pathlib import Path
import db, model_registry as MR

ROOT=Path(__file__).parent

def main():
    x=json.loads((ROOT/"site"/"cross_asset_v36.json").read_text(encoding="utf-8"))
    assert x["version"]=="3.6"
    assert len(x["data_meta"]["symbols"])==33
    assert x["data_meta"]["cross_market_features_lagged_one_day"] is True
    assert x["data_meta"]["macro_revision_aware"] is True
    assert x["data_meta"]["last_date"] < x["prospective_holdout_start"]
    assert x["decision"]["production_champion"]=="logreg-v3.2.0"
    assert x["decision"]["action"]=="retain"
    assert set(x["models"].values())=={"pooled-logreg-v3.6.1","pooled-lightgbm-v3.6.1"}

    nlive=0
    saw_extra_shrink=False
    for hrow in x["horizons"]:
        assert hrow["holdout_used_for_tuning"] is False
        for name,m in hrow["models"].items():
            assert m["prospective_holdout"]["used_for_tuning"] is False
            assert m["prospective_holdout"]["n_realized_rows"]==0
            assert m["prospective_holdout"]["status"]=="awaiting_new_data"
            boot=m["cluster_date_bootstrap"]
            assert boot["global_dates"] > 0
            assert boot["effective_date_cap"] <= boot["global_dates"]
            for r in m["live"]:
                nlive+=1
                raw=float(r["raw_p_up"]); cal=float(r["calibrated_p_up"]); shr=float(r["evidence_shrunk_p_up"])
                a=float(r["shrink_alpha"])
                assert 0 <= a <= 1
                assert abs(shr-.5) <= abs(cal-.5)+1e-9
                if a < .999: saw_extra_shrink=True
                assert r["date"] < x["prospective_holdout_start"]
    assert nlive==33*4*2
    assert saw_extra_shrink

    data=json.loads((ROOT/"site"/"data.json").read_text(encoding="utf-8"))
    assert data.get("cross_asset_version")=="3.6"
    assert all("cross_asset_v36" in a for a in data["assets"])

    con=db.connect()
    try:
        rows=con.execute("""SELECT model_version,COUNT(*) FROM prediction_ledger
                            WHERE model_version IN ('pooled-logreg-v3.6.1','pooled-lightgbm-v3.6.1')
                            GROUP BY model_version""").fetchall()
        counts=dict(rows)
        assert counts["pooled-logreg-v3.6.1"]==132
        assert counts["pooled-lightgbm-v3.6.1"]==132
        regs={r[0] for r in con.execute("SELECT model_version FROM model_registry")}
        assert "pooled-logreg-v3.6.1" in regs and "pooled-lightgbm-v3.6.1" in regs
        drow=con.execute("SELECT action,selected_version FROM model_decisions WHERE decision_id=?",
                         (x["decision"]["decision_id"],)).fetchone()
        assert drow==("retain","logreg-v3.2.0")
    finally:
        con.close()
    print("OK: v3.6 pooled global-time models + evidence shrinkage + fresh prospective holdout")

if __name__=="__main__":
    main()
