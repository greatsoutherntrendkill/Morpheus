import copy, sqlite3
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
import pytest
import forecast_journal_v4401015 as J
import evaluation_clock_v4401014 as CLOCK
NOW='2026-09-15T21:00Z'
def payload(h=1,symbol='^GSPC',date='2026-09-15',p=.6):
 return {'symbol':symbol,'source':'test fixture','history':[{'t':date,'c':100}], 'forecasts':{str(h):{'model_generation':'test-v15','calculation_identity':{'mode':'fast'},'data_integrity':{'as_of':date,'data_hash':'fixture'},'class_probabilities':{'up':p,'down':.2,'neutral':.8-p},'movement_guidance':{'material_move_threshold_pct':1},'distribution_forecast':{'quantiles':{'q10_return_pct':-1,'q90_return_pct':1}},'abstain':True}}}
def history(dates=('2026-09-15','2026-09-16'),prices=(100,101)):
 return pd.DataFrame({'date':dates,'open':prices,'high':prices,'low':prices,'close':prices})
@pytest.fixture
def journal(tmp_path):return J.Journal(tmp_path/'journal.sqlite3')
def test_idempotent_revisions_restart(journal):
 a=payload();assert journal.record(a,now=NOW)['inserted']==1
 assert journal.record(a,now=NOW)['existing']==1
 assert journal.record(payload(p=.5),now=NOW)['issues'][0]['revision']==2
 assert len(J.Journal(journal.path).rows())==2
 assert journal.dashboard()['groups'][0]['primary']==1
 assert journal.detail(1)['snapshot']['forecast']['class_probabilities']['up']==.6

def test_concurrent_record(journal):
 with ThreadPoolExecutor(max_workers=6) as pool:r=list(pool.map(lambda _:journal.record(payload(),now=NOW),range(12)))
 assert sum(x['inserted'] for x in r)==1

@pytest.mark.parametrize('table', ['issues','attempts','outcomes','failures','runs'])
@pytest.mark.parametrize('op',['UPDATE','DELETE'])
def test_sql_immutability(journal,table,op):
 journal.record(payload(),now=NOW);journal.record({'symbol':'X'},now=NOW)
 journal.settle(lambda _:history(),now='2026-09-16T21:00Z')
 with journal.connect() as c:
  with pytest.raises(sqlite3.IntegrityError,match='immutable'):
   c.execute(f'{op} {table} SET id=id' if op=='UPDATE' else f'DELETE FROM {table}')

def test_log_units_and_completed_bar(journal):
 journal.record(payload(),now=NOW);h=history(prices=(100,101.003))
 assert journal.settle(lambda _:h,now='2026-09-16T20:00Z')['settled']==0
 assert journal.settle(lambda _:h,now='2026-09-16T20:02Z')['settled']==1
 r=journal.rows()[0]['result'];assert r['outcome']=='neutral' and r['interval80_covered']
 assert r['simple_return_pct']>1 and r['log_return']<.01 and r['history_snapshot_saved']
 assert journal.settle(lambda _:history(prices=(100,110)),now='2026-09-17T21:00Z')['settled']==0
 assert journal.rows()[0]['result']==r

@pytest.mark.parametrize('symbol,date,target', [('^GSPC','2026-07-02','2026-07-06'),('^GSPC','2026-11-25','2026-11-27'),('BTC-USD','2026-07-03','2026-07-04')])
def test_calendars(journal,symbol,date,target):
 journal.record(payload(symbol=symbol,date=date),now=J.DATA.session_close(symbol,date)+pd.Timedelta(minutes=2))
 assert journal.rows()[0]['target_date']==target

@pytest.mark.parametrize('kind,expected',[('late','late_issue'),('future','future_origin'),('calendar','calendar_unverified'),('short','unsupported_horizon'),('invalid','invalid_contract')])
def test_ineligible(journal,kind,expected):
 a=payload();now=NOW
 if kind=='late':now='2026-09-16T21:00Z'
 if kind=='future':now='2026-09-15T19:00Z'
 if kind=='calendar':a['symbol']='PLZL.ME'
 if kind=='short':a['forecasts']['1h']=a['forecasts'].pop('1')
 if kind=='invalid':a['forecasts']['1']['class_probabilities']['up']=1.2
 journal.record(a,now=now);assert journal.rows()[0]['state']==expected
 assert journal.settle(lambda _:history(),now='2026-10-01')['checked']==0

@pytest.mark.parametrize('prices,dates,state', [((102,103),('2026-09-15','2026-09-16'),'origin_revised'),((100,),('2026-09-15',),'missing_target'),((101,),('2026-09-16',),'origin_missing')])
def test_unavailable(journal,prices,dates,state):
 journal.record(payload(),now=NOW);journal.settle(lambda _:history(dates,prices),now='2026-09-16T21:00Z')
 assert journal.rows()[0]['state']==state and not journal.rows()[0]['result']

def test_provider_retry_and_single_settlement(journal):
 journal.record(payload(),now=NOW)
 def fail(_):raise TimeoutError('offline')
 journal.settle(fail,now='2026-09-16T21:00Z');assert journal.rows()[0]['state']=='source_error'
 with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda _:journal.settle(lambda _:history(),now='2026-09-16T21:00Z'),range(2)))
 with journal.connect() as c:assert c.execute('SELECT COUNT(*) FROM outcomes').fetchone()[0]==1
 assert len(journal.detail(1)['attempts'])>=3

def test_modes_generations_separate(journal):
 a=payload();journal.record(a,now=NOW)
 a['forecasts']['1']['calculation_identity']['mode']='full';journal.record(a,now=NOW)
 a['forecasts']['1']['model_generation']='test-v16';journal.record(a,now=NOW)
 assert len(journal.dashboard()['groups'])==3

def test_no_replay_backfill(journal):
 with CLOCK.at(NOW):assert not journal.record(payload())['recorded']
 assert journal.dashboard()['total_issues']==0

def test_revision_excluded_from_metrics(journal):
 journal.record(payload(),now=NOW);journal.record(payload(p=.5),now=NOW)
 journal.settle(lambda _:history(),now='2026-09-16T21:00Z')
 g=journal.dashboard()['groups'][0]
 assert g['issues']==2 and g['settled']==1 and g['nonoverlap']==1 and not g['quality_confirmed']

def test_empty_and_failed(journal):
 assert journal.dashboard()['groups']==[]
 journal.record({'symbol':'X'},now=NOW)
 assert journal.dashboard()['unavailable_deliveries']==1 and journal.detail(100) is None

def test_frozen_threshold_and_revision(journal):
 a=payload();journal.record(a,now=NOW)
 a['forecasts']['1']['movement_guidance']['material_move_threshold_pct']=3
 journal.record(a,now=NOW)
 journal.settle(lambda _:history(prices=(100,102)),now='2026-09-16T21:00Z')
 rs=journal.rows();assert rs[0]['result']['outcome']=='neutral' and rs[1]['result']['outcome']=='up'

def test_missing_session_never_substituted(journal):
 journal.record(payload(h=2),now=NOW)
 journal.settle(lambda _:history(('2026-09-15','2026-09-17'),(100,102)),now='2026-09-17T21:00Z')
 assert journal.rows()[0]['state'] in ('origin_missing','history_gap')
 assert not journal.rows()[0]['result']

def test_conflicting_date(journal):
 journal.record(payload(),now=NOW)
 journal.settle(lambda _:history(('2026-09-15','2026-09-16','2026-09-16'),(100,101,102)),now='2026-09-16T21:00Z')
 assert journal.rows()[0]['state']=='data_conflict'

def test_nonoverlap_count(journal):
 for day in ['2026-09-15','2026-09-16']:
  journal.record(payload(h=2,date=day),now=day+'T21:00Z')
 journal.settle(lambda _:history(('2026-09-15','2026-09-16','2026-09-17','2026-09-18'),(100,100,100,100)),now='2026-09-18T21:00Z')
 g=journal.dashboard()['groups'][0];assert g['settled']==2 and g['nonoverlap']==1

def test_api_record_failure_visible(monkeypatch):
 import api
 def fail(*a,**k):raise OSError('disk full')
 monkeypatch.setattr(api.JOURNAL15,'journal',fail)
 monkeypatch.setattr(api,'_schedule_feedback_settlement_v436',lambda:False)
 a=payload();receipt=api._record_feedback_v436(a,'test')
 assert not receipt['recorded'] and not a['forecasts']['1']['journal_receipt']['recorded']

def test_api_record_receipt_and_no_legacy_write(monkeypatch,journal):
 import api
 monkeypatch.setattr(api.JOURNAL15,'journal',lambda:journal)
 monkeypatch.setattr(api,'_schedule_feedback_settlement_v436',lambda:True)
 def fail(*a,**k):raise AssertionError('legacy journal written')
 monkeypatch.setattr(api.FB436,'record_forecast_row',fail)
 a=payload();receipt=api._record_feedback_v436(a,'test')
 assert receipt['inserted']==1 and a['forecasts']['1']['journal_receipt']['recorded']

def test_api_dashboard_and_detail(monkeypatch,journal):
 import api,json
 monkeypatch.setattr(api.JOURNAL15,'journal',lambda:journal)
 journal.record(payload(),now=NOW)
 assert json.loads(api.forecast_journal_dashboard().body)['shown_issues']==1
 assert json.loads(api.forecast_journal_dashboard(symbol='NO_SUCH_SYMBOL').body)['shown_issues']==0
 assert json.loads(api.forecast_journal_detail(1).body)['revision']==1
 with pytest.raises(api.HTTPException) as exc:api.forecast_journal_detail(200)
 assert exc.value.status_code==404

def test_worker_failure_is_reported(monkeypatch):
 import api
 def fail(*a,**k):raise OSError('disk full')
 monkeypatch.setattr(api.JOURNAL15,'journal',fail)
 assert api._run_feedback_settlement_v436()['error']=='OSError'
 assert api._journal_last_error=='OSError' and api._feedback_refreshing is False
 monkeypatch.setattr(api,'_journal_last_error',None)

def test_schedule_failure_releases_lock(monkeypatch):
 import api
 class Broken:
  def submit(self,*a):raise RuntimeError('stopped')
 monkeypatch.setattr(api,'_feedback_executor',Broken());monkeypatch.setattr(api,'_feedback_refreshing',False)
 with pytest.raises(RuntimeError):api._schedule_feedback_settlement_v436()
 assert api._feedback_refreshing is False

def test_schedule_failure_does_not_erase_receipt(monkeypatch,journal):
 import api
 monkeypatch.setattr(api.JOURNAL15,'journal',lambda:journal)
 def fail():raise RuntimeError('stopped')
 monkeypatch.setattr(api,'_schedule_feedback_settlement_v436',fail)
 a=payload();r=api._record_feedback_v436(a,'test')
 assert r['recorded'] and a['forecasts']['1']['journal_receipt']['recorded']
 assert len(journal.rows())==1

def test_worker_restarts_unfinished_checks(monkeypatch):
 import api
 calls=[]
 class Stop:
  n=0
  def clear(self):self.n=0
  def set(self):self.n=2
  def is_set(self):return self.n>=2
  def wait(self,seconds):assert seconds==300;self.n+=1
 class ImmediateThread:
  def __init__(self,target,**kwargs):self.target=target
  def start(self):self.target()
 monkeypatch.setattr(api,'_journal_stop',Stop());monkeypatch.setattr(api,'Thread',ImmediateThread)
 monkeypatch.setattr(api,'_schedule_feedback_settlement_v436',lambda:calls.append('check'))
 api.start_forecast_journal_worker();api.start_forecast_journal_worker()
 assert len(calls)==4
 api.stop_forecast_journal_worker();assert api._journal_stop.is_set()

def test_overdue_pending_has_honest_status(journal):
 journal.record(payload(date='2026-01-05'),now='2026-01-05T22:00Z')
 r=journal.rows()[0]
 assert r['overdue'] and r['state']=='awaiting_result'
 assert 'Срок завершён' in r['state_label']
