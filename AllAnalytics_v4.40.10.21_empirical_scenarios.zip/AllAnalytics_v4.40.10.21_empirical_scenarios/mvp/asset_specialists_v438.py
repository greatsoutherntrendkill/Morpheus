"""AllAnalytics v4.38 — asset-class specialist models.

This layer adds separate research experts for equities, FX, commodities, crypto
and broad indices.  Specialists are routed by asset class / region / market
regime, but they do *not* receive live ensemble weight merely because they
exist.  Their forecast is always recorded as a prospective challenger and a
non-zero blend is allowed only after the v4.37 prospective guard has enough
paired observations and a human explicitly approves the candidate.

Design goals
------------
* different feature sets per asset class instead of one universal recipe;
* volatility-adjusted three-state target (up / neutral / down);
* equity cross-sectional and sector-relative features when enough cached peer
  histories exist; missing peers stay explicitly unavailable rather than being
  fabricated;
* time-ordered development split and probability calibration;
* conservative shrinkage when holdout skill / feature coverage is weak;
* no automatic champion promotion.
"""
from __future__ import annotations
import data_contract_v4401013 as DATA13

import json
import math
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

import config as C
import feature_event_v434 as FE434
import dynamic_ensemble_v437 as CORE437
import models as M
import prospective_selection_v438 as SEL438
import temporal_validation_v4401012 as TV
import freshness_contract_v4409 as FRESH4409

VERSION = "asset-class-specialists-v4.38.0"
VALIDATION_VERSION = "time-ordered-specialist-development-v4.38"
ROOT = Path(__file__).parent


def _finite(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _clip_p(x, lo=.04, hi=.96):
    return float(np.clip(float(x), lo, hi))


def _sigmoid(x):
    return float(1.0 / (1.0 + math.exp(-float(np.clip(x, -30, 30)))))


def _series(close) -> pd.Series:
    x = pd.Series(close, dtype=float).dropna().sort_index()
    try:
        x.index = pd.to_datetime(x.index).tz_localize(None)
    except Exception:
        try:
            x.index = pd.to_datetime(x.index)
        except Exception:
            pass
    return x[~x.index.duplicated(keep="last")]


@dataclass(frozen=True)
class SpecialistSpec:
    name: str
    min_history: int
    min_significant: int
    max_live_weight: float
    feature_names: tuple[str, ...]


SPECS = {
    "equity": SpecialistSpec(
        "Специалист по акциям", 320, 95, .16,
        (
            "ret_5", "ret_20", "ret_60", "vol_20", "vol_60", "ma20_gap", "ma60_gap",
            "benchmark_ret_20", "relative_20", "relative_60", "corr_benchmark_60",
            "market_breadth_20", "market_dispersion_20", "universe_rank_20",
            "sector_relative_20", "sector_rank_20", "sector_breadth_20",
        ),
    ),
    "index": SpecialistSpec(
        "Специалист по индексам", 300, 85, .14,
        (
            "ret_5", "ret_20", "ret_60", "vol_20", "ma20_gap", "ma60_gap",
            "benchmark_ret_20", "relative_20", "corr_benchmark_60",
            "market_breadth_20", "market_dispersion_20", "peer_rank_20",
        ),
    ),
    "fx": SpecialistSpec(
        "Специалист по валютам", 300, 85, .14,
        (
            "ret_5", "ret_20", "ret_60", "vol_20", "vol_60", "ma20_gap",
            "benchmark_ret_20", "relative_20", "corr_benchmark_60",
            "dxy_ret_20", "risk_ret_20", "gold_ret_20", "peer_rank_20", "market_breadth_20",
        ),
    ),
    "commodity": SpecialistSpec(
        "Специалист по сырью", 300, 85, .13,
        (
            "ret_5", "ret_20", "ret_60", "vol_20", "vol_60", "ma20_gap", "ma60_gap",
            "benchmark_ret_20", "relative_20", "corr_benchmark_60",
            "dxy_ret_20", "risk_ret_20", "commodity_breadth_20", "peer_rank_20",
        ),
    ),
    "crypto": SpecialistSpec(
        "Специалист по криптоактивам", 300, 85, .12,
        (
            "ret_3", "ret_7", "ret_20", "ret_60", "vol_10", "vol_20", "vol_60",
            "ma20_gap", "benchmark_ret_20", "relative_20", "corr_benchmark_60",
            "crypto_breadth_20", "peer_rank_20", "dxy_ret_20", "risk_ret_20",
        ),
    ),
    "other": SpecialistSpec(
        "Универсальный специалист", 340, 105, .10,
        ("ret_5", "ret_20", "ret_60", "vol_20", "ma20_gap", "benchmark_ret_20", "relative_20"),
    ),
}


# Static metadata only: no forecast value is encoded here.  It is used solely
# to group known equities when enough real cached peer histories are available.
EQUITY_SECTORS = {
    "AAPL": "technology", "MSFT": "technology", "NVDA": "technology", "AVGO": "technology",
    "GOOGL": "communication", "META": "communication", "NFLX": "communication",
    "AMZN": "consumer", "TSLA": "consumer", "WMT": "consumer", "COST": "consumer",
    "JPM": "financials", "V": "financials", "MA": "financials", "BRK-B": "financials",
    "XOM": "energy",
    "SBER.ME": "financials", "MOEX.ME": "financials",
    "GAZP.ME": "energy", "LKOH.ME": "energy", "ROSN.ME": "energy", "NVTK.ME": "energy", "TATN.ME": "energy",
    "GMKN.ME": "materials", "ALRS.ME": "materials", "CHMF.ME": "materials", "NLMK.ME": "materials", "PLZL.ME": "materials", "PHOR.ME": "materials",
    "YDEX.ME": "technology", "OZON.ME": "consumer", "MTSS.ME": "communication",
}


_MATRIX_CACHE = {"ts": 0.0, "matrix": pd.DataFrame()}
_PEER_CACHE = {"ts": 0.0, "matrix": pd.DataFrame()}
_SPECIALIST_CACHE = {}
SPECIALIST_CACHE_SECONDS = 180


def _db_matrix() -> pd.DataFrame:
    now = time.time()
    if now - float(_MATRIX_CACHE["ts"] or 0) < 90 and not _MATRIX_CACHE["matrix"].empty:
        return _MATRIX_CACHE["matrix"]
    try:
        import sqlite3
        con = sqlite3.connect(str(C.DB_PATH))
        try:
            d = pd.read_sql_query("SELECT symbol,date,close FROM prices ORDER BY date", con)
        finally:
            con.close()
        d["date"] = pd.to_datetime(d["date"], errors="coerce")
        d["close"] = pd.to_numeric(d["close"], errors="coerce")
        d = d.dropna(subset=["symbol", "date", "close"])
        m = d.pivot_table(index="date", columns="symbol", values="close", aggfunc="last").sort_index()
    except Exception:
        m = pd.DataFrame()
    _MATRIX_CACHE.update(ts=now, matrix=m)
    return m


def _cached_equity_matrix() -> pd.DataFrame:
    """Legacy cache reader retained for backward compatibility; v4.40.7 routing no longer depends on it.

    This deliberately does not trigger extra network calls.  Cross-sectional
    ranking becomes richer as the normal Markets workflow populates more cached
    equities.  Until at least several peers exist the corresponding feature is
    left missing and the UI can say that the sample is not ready.
    """
    now = time.time()
    if now - float(_PEER_CACHE["ts"] or 0) < 75:
        return _PEER_CACHE["matrix"]
    cols = {}
    patterns = [
        # Current and recent cache namespaces.  v4.40 keeps historical namespaces
        # readable so cross-sectional peer coverage does not reset on upgrades.
        ROOT / "runtime_cache" / "equity_forecast_v440_distribution",
        ROOT / "runtime_cache" / "equity_forecast_v440_distribution_fast",
        ROOT / "runtime_cache" / "equity_forecast_v439_events",
        ROOT / "runtime_cache" / "equity_forecast_v439_events_fast",
        ROOT / "runtime_cache" / "equity_forecast_v437_guard",
        ROOT / "runtime_cache" / "equity_forecast_v437_guard_fast",
        ROOT / "runtime_cache" / "equity_forecast_v435_dynamic",
        ROOT / "runtime_cache" / "equity_forecast_v435_dynamic_fast",
    ]
    for folder in patterns:
        if not folder.exists():
            continue
        for fp in folder.glob("*.json"):
            try:
                j = json.loads(fp.read_text(encoding="utf-8"))
                sym = str(j.get("symbol") or fp.stem.split("_")[0]).upper()
                rows = j.get("history") or []
                if len(rows) < 25:
                    continue
                s = pd.Series(
                    {pd.Timestamp(x.get("t") or x.get("date")): float(x.get("c", x.get("close"))) for x in rows if x.get("t") or x.get("date")},
                    dtype=float,
                ).sort_index()
                if len(s) >= 25:
                    old = cols.get(sym)
                    if old is None or len(s) > len(old):
                        cols[sym] = s
            except Exception:
                continue
    m = pd.DataFrame(cols).sort_index() if cols else pd.DataFrame()
    _PEER_CACHE.update(ts=now, matrix=m)
    return m


def _ret(s: pd.Series, n: int) -> pd.Series:
    return s / s.shift(int(n)) - 1.0


def _vol(s: pd.Series, n: int) -> pd.Series:
    return np.log(s).diff().rolling(int(n), min_periods=max(6, int(n)//2)).std() * math.sqrt(252)


def _align_factor(matrix: pd.DataFrame, symbol: str, idx: pd.Index) -> pd.Series:
    if matrix.empty or symbol not in matrix.columns:
        return pd.Series(np.nan, index=idx, dtype=float)
    return FRESH4409.bounded_reindex_series(matrix[symbol], idx, FRESH4409.MARKET_FILL_LIMIT).shift(1)


def _rank_and_breadth(matrix: pd.DataFrame, own_symbol: str, own: pd.Series, lookback: int = 20, min_peers: int = 3):
    if matrix.empty:
        nan = pd.Series(np.nan, index=own.index, dtype=float)
        return nan, nan, 0
    m = matrix.copy()
    m = FRESH4409.bounded_reindex_frame(m, own.index, FRESH4409.MARKET_FILL_LIMIT).shift(1)
    m[own_symbol] = own
    r = m / m.shift(lookback) - 1.0
    count = r.notna().sum(axis=1)
    breadth = (r.gt(0).sum(axis=1) / count.replace(0, np.nan)).where(count >= min_peers)
    ranks = r.rank(axis=1, pct=True)
    rank = ranks[own_symbol].where(count >= min_peers) if own_symbol in ranks.columns else pd.Series(np.nan, index=own.index)
    available = int(max(0, m.columns.size - 1))
    return rank.astype(float), breadth.astype(float), available


def _equity_peer_matrix(symbol: str, own: pd.Series):
    m = _db_matrix().copy()
    region_ru = str(symbol).upper().endswith(".ME")
    cols = [c for c in m.columns if str(c).upper().endswith(".ME") == region_ru and c != symbol]
    m = m[cols] if cols else pd.DataFrame(index=m.index)
    m[symbol] = FRESH4409.bounded_reindex_series(own, m.index, FRESH4409.MARKET_FILL_LIMIT) if not m.empty else own
    return m.sort_index()


def _sector_matrix(symbol: str, own: pd.Series):
    sector = EQUITY_SECTORS.get(str(symbol).upper())
    if not sector:
        return sector, pd.DataFrame()
    m = _db_matrix().copy()
    cols = [c for c in m.columns if EQUITY_SECTORS.get(str(c).upper()) == sector and c != symbol]
    out = m[cols] if cols else pd.DataFrame(index=m.index)
    if out.empty:
        out = pd.DataFrame({symbol: own})
    else:
        out[symbol] = FRESH4409.bounded_reindex_series(own, out.index, FRESH4409.MARKET_FILL_LIMIT)
    return sector, out.sort_index()


def _build_features(close: pd.Series, symbol: str, profile: FE434.AssetProfile) -> tuple[pd.DataFrame, dict]:
    own = _series(close)
    idx = own.index
    m = _db_matrix()
    x = pd.DataFrame(index=idx)
    as_of = idx[-1] if len(idx) else None
    freshness_sources = {}
    def record_source(name, series, critical=False):
        freshness_sources[str(name)] = FRESH4409.source_meta(
            str(name), series, as_of, warning_days=FRESH4409.MARKET_WARNING_DAYS,
            hard_days=FRESH4409.MARKET_HARD_DAYS, critical=critical)
    for n in (1, 3, 5, 7, 20, 60):
        x[f"ret_{n}"] = _ret(own, n)
    for n in (10, 20, 60):
        x[f"vol_{n}"] = _vol(own, n)
    x["ma20_gap"] = own / own.rolling(20, min_periods=12).mean() - 1.0
    x["ma60_gap"] = own / own.rolling(60, min_periods=30).mean() - 1.0

    bench = _align_factor(m, profile.benchmark, idx) if profile.benchmark else pd.Series(np.nan, index=idx)
    if profile.benchmark:
        record_source(f"benchmark:{profile.benchmark}", m[profile.benchmark] if profile.benchmark in m.columns else pd.Series(dtype=float), critical=True)
    x["benchmark_ret_20"] = _ret(bench, 20)
    x["relative_20"] = x["ret_20"] - x["benchmark_ret_20"]
    x["relative_60"] = x["ret_60"] - _ret(bench, 60)
    z = pd.concat([np.log(own).diff(), np.log(bench).diff()], axis=1)
    x["corr_benchmark_60"] = z.iloc[:, 0].rolling(60, min_periods=30).corr(z.iloc[:, 1])

    # Broad asset-class peers from the local point-in-time database.
    peer_cols = [c for c in profile.peers if c in m.columns and c != symbol]
    peer_m = m[peer_cols] if peer_cols else pd.DataFrame()
    for ps in peer_cols:
        record_source(f"peer:{ps}", m[ps], critical=False)
    # Hard-stale peers stay unavailable instead of being carried forward forever.
    fresh_peer_cols=[ps for ps in peer_cols if not freshness_sources[f"peer:{ps}"].get("hard_stale")]
    peer_m = m[fresh_peer_cols] if fresh_peer_cols else pd.DataFrame()
    peer_rank, peer_breadth, broad_peer_count = _rank_and_breadth(peer_m, symbol, own, 20, min_peers=3)
    x["peer_rank_20"] = peer_rank
    x["market_breadth_20"] = peer_breadth
    if not peer_m.empty:
        pr = FRESH4409.bounded_reindex_frame(peer_m, idx, FRESH4409.MARKET_FILL_LIMIT).shift(1) / FRESH4409.bounded_reindex_frame(peer_m, idx, FRESH4409.MARKET_FILL_LIMIT).shift(1).shift(20) - 1
        x["market_dispersion_20"] = pr.std(axis=1)

    for cs in ("DX-Y.NYB", "^GSPC", "GC=F"):
        record_source(f"context:{cs}", m[cs] if cs in m.columns else pd.Series(dtype=float), critical=False)
    x["dxy_ret_20"] = _ret(_align_factor(m, "DX-Y.NYB", idx), 20) if not freshness_sources["context:DX-Y.NYB"].get("hard_stale") else np.nan
    x["risk_ret_20"] = _ret(_align_factor(m, "^GSPC", idx), 20) if not freshness_sources["context:^GSPC"].get("hard_stale") else np.nan
    x["gold_ret_20"] = _ret(_align_factor(m, "GC=F", idx), 20) if not freshness_sources["context:GC=F"].get("hard_stale") else np.nan

    equity_peer_count = sector_peer_count = 0
    sector = None
    if profile.asset_class == "equity":
        em = _equity_peer_matrix(symbol, own)
        urank, ubreadth, equity_peer_count = _rank_and_breadth(em.drop(columns=[symbol], errors="ignore"), symbol, own, 20, min_peers=4)
        x["universe_rank_20"] = urank
        # If true equity peer breadth is ready, prefer it over index-proxy breadth.
        if equity_peer_count >= 3:
            x["market_breadth_20"] = ubreadth
        sector, sm = _sector_matrix(symbol, own)
        srank, sbreadth, sector_peer_count = _rank_and_breadth(sm.drop(columns=[symbol], errors="ignore"), symbol, own, 20, min_peers=3)
        x["sector_rank_20"] = srank
        x["sector_breadth_20"] = sbreadth
        other = sm.drop(columns=[symbol], errors="ignore")
        if not other.empty:
            sec_ret = (FRESH4409.bounded_reindex_frame(other, idx, FRESH4409.MARKET_FILL_LIMIT).shift(1) / FRESH4409.bounded_reindex_frame(other, idx, FRESH4409.MARKET_FILL_LIMIT).shift(1).shift(20) - 1).mean(axis=1)
            x["sector_relative_20"] = x["ret_20"] - sec_ret
        else:
            x["sector_relative_20"] = np.nan
    elif profile.asset_class == "crypto":
        crypto = [s for s in ("BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD") if s in m.columns and s != symbol]
        cm = m[crypto] if crypto else pd.DataFrame()
        _, cbreadth, _ = _rank_and_breadth(cm, symbol, own, 20, min_peers=3)
        x["crypto_breadth_20"] = cbreadth
    elif profile.asset_class == "commodity":
        comm = [s for s in ("GC=F", "SI=F", "CL=F", "NG=F", "HG=F") if s in m.columns and s != symbol]
        cm = m[comm] if comm else pd.DataFrame()
        _, cbreadth, _ = _rank_and_breadth(cm, symbol, own, 20, min_peers=3)
        x["commodity_breadth_20"] = cbreadth

    diag = {
        "asset_class": profile.asset_class,
        "region": profile.region,
        "benchmark": profile.benchmark,
        "broad_peer_count": broad_peer_count,
        "equity_peer_count": equity_peer_count,
        "sector": sector,
        "sector_peer_count": sector_peer_count,
        "freshness": FRESH4409.summarize_sources(freshness_sources),
    }
    return x.replace([np.inf, -np.inf], np.nan), diag


def _target(close: pd.Series, horizon: int):
    tgt = M.directional_target_frame(close, horizon)
    return tgt["y"].copy(), tgt["neutral"].copy(), tgt["ret_fwd"].copy(), tgt["threshold"].copy()


def _metrics(p, y):
    p = np.asarray(p, float); y = np.asarray(y, float)
    ok = np.isfinite(p) & np.isfinite(y); p, y = p[ok], y[ok]
    if len(p) < 8:
        return {"n": int(len(p)), "accuracy": None, "brier": None, "brier_skill": None}
    pred = (p >= .5).astype(float)
    acc = float(np.mean(pred == y))
    brier = float(np.mean((p-y)**2))
    base_p = float(np.mean(y)); base = float(np.mean((base_p-y)**2))
    skill = (1-brier/base)*100 if base > 1e-12 else 0.0
    return {"n": int(len(p)), "accuracy": round(acc, 4), "brier": round(brier, 6), "brier_skill": round(skill, 3)}


@dataclass
class _Platt:
    a: float
    b: float
    def apply(self, p):
        q = np.clip(np.asarray(p, float), 1e-5, 1-1e-5)
        z = np.log(q/(1-q))
        return 1/(1+np.exp(-np.clip(self.b+self.a*z, -30, 30)))


def _fit_platt(p, y):
    p = np.asarray(p, float); y = np.asarray(y, int)
    if len(p) < 25 or len(np.unique(y)) < 2:
        return None
    try:
        from sklearn.linear_model import LogisticRegression
        q = np.clip(p, 1e-5, 1-1e-5)
        z = np.log(q/(1-q)).reshape(-1, 1)
        mdl = LogisticRegression(C=.8, max_iter=260, solver="lbfgs", random_state=438).fit(z, y)
        return _Platt(float(mdl.coef_[0, 0]), float(mdl.intercept_[0]))
    except Exception:
        return None


def _fit_specialist(X: pd.DataFrame, y: pd.Series, min_significant: int, asset_class: str, clock=None):
    d = X.copy()
    d["__y"] = y
    d = d[d["__y"].isin([0.0, 1.0])]
    if len(d) < min_significant:
        return None
    feature_cols = list(X.columns)
    if len(feature_cols) < 4:
        return None
    d = d[feature_cols + ["__y"]].copy()
    n = len(d)
    a=max(50,int(n*.54)); b=max(a+20,int(n*.70)); c=max(b+18,int(n*.84)); c=min(c,n-14)
    if b<=a or c<=b or n-c<12:
        return None
    if clock is None: return None
    for key in TV.META: d[key]=clock[key].reindex(d.index)
    chunks=TV.split(d,(.54,.70,.84),(40,16,16,12))
    if chunks is None:return None
    train,select,cal,ev=chunks
    feature_cols=[c for c in feature_cols if train[c].notna().mean()>=.35]
    if len(feature_cols)<4:return None
    med=train[feature_cols].median().fillna(0.0)
    def mat(z):return z[feature_cols].fillna(med).clip(-8,8).to_numpy(float)
    if len(np.unique(train["__y"].to_numpy(int)))<2:return None
    try:
        from sklearn.preprocessing import StandardScaler
        from sklearn.linear_model import LogisticRegression
        from sklearn.ensemble import HistGradientBoostingClassifier, ExtraTreesClassifier
        scaler=StandardScaler().fit(mat(train))
        ytr=train["__y"].to_numpy(int)
        decay=np.exp(-np.arange(len(train)-1,-1,-1)/210.0)
        candidates={}
        lr=LogisticRegression(C=.28,max_iter=450,solver="lbfgs",random_state=438,class_weight="balanced")
        lr.fit(scaler.transform(mat(train)),ytr,sample_weight=decay);candidates["logistic"]=(lr,scaler)
        # Shallow nonlinear candidates capture threshold effects without allowing a
        # high-capacity tree ensemble to memorize a 2-3 year financial sample.
        hgb=HistGradientBoostingClassifier(max_depth=2,max_iter=90,learning_rate=.035,l2_regularization=2.5,min_samples_leaf=16,random_state=438)
        hgb.fit(mat(train),ytr,sample_weight=decay);candidates["hist_gradient_boosting"]=(hgb,None)
        et=ExtraTreesClassifier(n_estimators=180,max_depth=3,min_samples_leaf=12,max_features=.65,class_weight="balanced",random_state=438,n_jobs=1)
        et.fit(mat(train),ytr,sample_weight=decay);candidates["extra_trees"]=(et,None)

        def predict(pair,z):
            mdl,sc=pair;xx=mat(z);xx=sc.transform(xx) if sc is not None else xx
            return mdl.predict_proba(xx)[:,1]
        scored=[]
        ys=select["__y"].to_numpy(int)
        for name,pair in candidates.items():
            ps=predict(pair,select);brier=float(np.mean((ps-ys)**2));scored.append((brier,name,pair))
        scored.sort(key=lambda z:z[0]);selection_brier,selected_name,_=scored[0]

        # Refit the chosen algorithm on train+selection. Calibration and evaluation
        # remain chronologically later and therefore untouched by model selection.
        fitset=pd.concat([train,select]);med2=fitset[feature_cols].median().fillna(0.0)
        def mat2(z):return z[feature_cols].fillna(med2).clip(-8,8).to_numpy(float)
        yfit=fitset["__y"].to_numpy(int);wfit=np.exp(-np.arange(len(fitset)-1,-1,-1)/230.0)
        if selected_name=="logistic":
            sc2=StandardScaler().fit(mat2(fitset));mdl2=LogisticRegression(C=.28,max_iter=450,solver="lbfgs",random_state=438,class_weight="balanced")
            mdl2.fit(sc2.transform(mat2(fitset)),yfit,sample_weight=wfit)
        elif selected_name=="hist_gradient_boosting":
            sc2=None;mdl2=HistGradientBoostingClassifier(max_depth=2,max_iter=90,learning_rate=.035,l2_regularization=2.5,min_samples_leaf=16,random_state=438)
            mdl2.fit(mat2(fitset),yfit,sample_weight=wfit)
        else:
            sc2=None;mdl2=ExtraTreesClassifier(n_estimators=180,max_depth=3,min_samples_leaf=12,max_features=.65,class_weight="balanced",random_state=438,n_jobs=1)
            mdl2.fit(mat2(fitset),yfit,sample_weight=wfit)
        def pred2(z):
            xx=mat2(z);xx=sc2.transform(xx) if sc2 is not None else xx
            return mdl2.predict_proba(xx)[:,1]
        pcal=pred2(cal);calibrator=_fit_platt(pcal,cal["__y"].to_numpy(int))
        pev=pred2(ev)
        if calibrator is not None:pev=calibrator.apply(pev)
        metrics=_metrics(pev,ev["__y"].to_numpy(int))

        # Keep the estimator to which this calibrator actually belongs.
        live,sc_live,med_live=mdl2,sc2,med2
        return {"model":live,"scaler":sc_live,"median":med_live,"features":feature_cols,"calibrator":calibrator,
                "temporal_split":train.attrs.get("temporal_split"),"metrics":metrics,"selected_model":selected_name,"selection_brier":round(selection_brier,6),
                "candidate_selection":[{"model":name,"brier":round(float(bs),6)} for bs,name,_ in scored],
                "train_n":len(train),"selection_n":len(select),"cal_n":len(cal),"eval_n":len(ev),"significant_n":n}
    except Exception:
        return None


def _fit_move_specialist(X: pd.DataFrame, neutral: pd.Series, min_rows: int = 120, clock=None):
    """Fit P(material move | current specialist features) with a time-ordered audit.

    This replaces the old trailing neutral-share estimate.  The deployment model is
    refit only after the late evaluation slice has been scored.
    """
    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.preprocessing import StandardScaler
    except Exception:
        return None
    d=X.copy(); d["__move"]=(1.0-pd.to_numeric(neutral,errors="coerce"))
    d=d[d["__move"].isin([0.0,1.0])]
    if len(d)<max(80,int(min_rows)):
        return None
    cols=list(X.columns)
    if len(cols)<4:
        return None
    d=d[cols+["__move"]].copy(); n=len(d); cut=max(60,int(n*.78)); cut=min(cut,n-20)
    if cut<50 or n-cut<15:
        return None
    if clock is None:return None
    for key in TV.META:d[key]=clock[key].reindex(d.index)
    chunks=TV.split(d,(.78,),(50,15))
    if chunks is None:return None
    train,ev=chunks
    cols=[c for c in cols if train[c].notna().mean()>=.35]
    if len(cols)<4:return None
    if len(np.unique(train["__move"].to_numpy(int)))<2:
        return None
    med=train[cols].median().fillna(0.0)
    def mat(z,m=med): return z[cols].fillna(m).clip(-8,8).to_numpy(float)
    sc=StandardScaler().fit(mat(train)); mdl=LogisticRegression(C=.22,max_iter=420,solver="lbfgs",random_state=4406,class_weight="balanced")
    decay=np.exp(-np.arange(len(train)-1,-1,-1)/230.0)
    mdl.fit(sc.transform(mat(train)),train["__move"].to_numpy(int),sample_weight=decay)
    pev=mdl.predict_proba(sc.transform(mat(ev)))[:,1]
    metrics=_metrics(pev,ev["__move"].to_numpy(int))
    med_live,sc_live,live=med,sc,mdl
    return {"model":live,"scaler":sc_live,"median":med_live,"features":cols,"temporal_split":train.attrs.get("temporal_split"),"metrics":metrics,"train_n":len(train),"eval_n":len(ev)}


def _cache_specialist(key, payload):
    _SPECIALIST_CACHE[key]=(time.time(),dict(payload))
    if len(_SPECIALIST_CACHE)>256:
        for k,_ in sorted(_SPECIALIST_CACHE.items(),key=lambda kv:kv[1][0])[:64]:
            _SPECIALIST_CACHE.pop(k,None)
    return payload


def specialist_forecast(close: pd.Series, symbol: str, horizon: int, regime: str | None = None) -> dict:
    own = _series(close); h = int(horizon); profile = FE434.asset_profile(symbol)
    spec = SPECS.get(profile.asset_class, SPECS["other"])
    cache_key=(str(symbol).upper(),h,DATA13.series_hash(own),DATA13.dependency_fingerprint(),str(regime or ""))
    cached=_SPECIALIST_CACHE.get(cache_key)
    if cached and time.time()-cached[0] < SPECIALIST_CACHE_SECONDS:
        return dict(cached[1])
    if len(own) < spec.min_history:
        return _cache_specialist(cache_key,{
            "version": VERSION, "status": "insufficient_history", "symbol": str(symbol).upper(), "horizon": h,
            "asset_class": profile.asset_class, "specialist": spec.name, "route": f"{profile.asset_class}:{profile.region}:{regime or 'unknown'}",
            "p_up": None, "reason": f"для специалиста нужно минимум {spec.min_history} наблюдений",
        })
    revision=DATA13.dependency_fingerprint()
    for cache in (_MATRIX_CACHE,_PEER_CACHE):
        if cache.get('revision')!=revision:cache.update(ts=0.0,revision=revision)
    X, feature_diag = _build_features(own, str(symbol).upper(), profile)
    y, neutral, _, _ = _target(own, h)
    wanted = [c for c in spec.feature_names if c in X.columns]
    Xs = X[wanted].copy()
    fitted = _fit_specialist(Xs.iloc[:-h] if h < len(Xs) else Xs.iloc[:0], y.iloc[:-h] if h < len(y) else y.iloc[:0], spec.min_significant, profile.asset_class, clock=TV.timeline(own.index,h))
    live_row = Xs.iloc[[-1]] if len(Xs) else pd.DataFrame()
    coverage = float(live_row.notna().mean(axis=1).iloc[0]) if not live_row.empty and len(wanted) else 0.0
    move_fit = _fit_move_specialist(Xs.iloc[:-h] if h < len(Xs) else Xs.iloc[:0], neutral.iloc[:-h] if h < len(neutral) else neutral.iloc[:0], min_rows=max(100,spec.min_significant), clock=TV.timeline(own.index,h))
    p_neutral = None
    p_move = None
    move_metrics = (move_fit or {}).get("metrics") or {}
    move_quality_ok = bool((move_metrics.get("brier_skill") or -999) > 0)
    if move_fit is not None and not live_row.empty:
        mcols=move_fit["features"]
        mz=live_row.reindex(columns=mcols).fillna(move_fit["median"])[mcols].clip(-8,8).to_numpy(float)
        mz=move_fit["scaler"].transform(mz)
        p_move=float(np.clip(move_fit["model"].predict_proba(mz)[:,1][0],.03,.97))
        p_neutral=1.0-p_move
    if fitted is None or live_row.empty:
        return _cache_specialist(cache_key,{
            "version": VERSION, "status": "insufficient_specialist_sample", "symbol": str(symbol).upper(), "horizon": h,
            "asset_class": profile.asset_class, "specialist": spec.name, "route": f"{profile.asset_class}:{profile.region}:{regime or 'unknown'}",
            "p_up": None, "p_neutral": None if p_neutral is None else round(p_neutral, 4), "p_move": None if p_move is None else round(p_move,4), "feature_coverage": round(coverage, 4), "feature_diagnostics": feature_diag,
            "move_model":{"version":"specialist-move-logreg-v4.40.6","trained":move_fit is not None,"quality_ok":move_quality_ok,"metrics":move_metrics},
            "feature_set": wanted, "reason": "недостаточно значимых point-in-time наблюдений для отдельного specialist fit",
        })
    cols = fitted["features"]
    z = live_row.reindex(columns=cols).fillna(fitted["median"])[cols].clip(-8, 8).to_numpy(float)
    z_model = fitted["scaler"].transform(z) if fitted.get("scaler") is not None else z
    p_sig = float(fitted["model"].predict_proba(z_model)[:, 1][0])
    if fitted["calibrator"] is not None:
        p_sig = float(fitted["calibrator"].apply([p_sig])[0])
    # Convert P(up | significant move) into a neutral-aware score using the learned
    # Move/No-Move model. A conservative 20% neutral fallback is used only if the
    # separate move model cannot be fit; such a fallback is never eligible to alter
    # the production neutral mass.
    p_neutral_work = float(p_neutral if p_neutral is not None else .20)
    p_raw = (1-p_neutral_work)*p_sig + p_neutral_work*.5
    skill = _finite((fitted["metrics"] or {}).get("brier_skill"))
    accuracy = _finite((fitted["metrics"] or {}).get("accuracy"))
    # Specialist is a challenger; weak holdout evidence means shrink, not confidence.
    if skill is None or skill <= 0 or (accuracy is not None and accuracy < .50):
        skill_factor = .08
    else:
        skill_factor = float(np.clip(.48 + min(20, skill)/48, .48, .86))
    coverage_factor = float(np.clip(.45 + .55*coverage, .45, 1.0))
    shrink = skill_factor * coverage_factor
    p_live = float(.5 + shrink*(p_raw-.5))
    p_live = _clip_p(p_live, .10, .90)
    # Convert the published neutral-aware directional score back to the exact
    # conditional probability used by the specialist.  Downstream ensembles blend
    # like-with-like on this conditional scale, then re-apply the neutral mass.
    p_move_work = max(1e-6, 1.0-p_neutral_work)
    p_conditional = _clip_p(.5 + (p_live-.5)/p_move_work, .02, .98)
    feature_freshness = (feature_diag.get("freshness") or {})
    quality_ok = bool((skill or -999) > 0 and (accuracy or 0) >= .51 and coverage >= .50 and not feature_freshness.get("hard_stale"))
    return _cache_specialist(cache_key,{
        "version": VERSION, "validation_version": VALIDATION_VERSION, "status": "ok", "symbol": str(symbol).upper(), "horizon": h,
        "asset_class": profile.asset_class, "region": profile.region, "specialist": spec.name,
        "route": f"{profile.asset_class}:{profile.region}:{regime or 'unknown'}", "p_up": round(p_live, 6), "p_down": round(1-p_live, 6),
        "conditional_p_up": round(p_conditional, 6), "raw_significant_p_up": round(p_sig, 6),
        "p_neutral": None if p_neutral is None else round(p_neutral, 4), "p_move": None if p_move is None else round(p_move,4), "feature_coverage": round(coverage, 4),
        "move_model":{"version":"specialist-move-logreg-v4.40.6","trained":move_fit is not None,"quality_ok":move_quality_ok,"metrics":move_metrics,
                      "train_n":None if move_fit is None else move_fit.get("train_n"),"evaluation_n":None if move_fit is None else move_fit.get("eval_n")},
        "feature_set": cols, "feature_diagnostics": feature_diag, "feature_freshness": feature_freshness, "development_metrics": fitted["metrics"],
        "temporal_split":fitted.get("temporal_split"), "development_split": {"train_n": fitted["train_n"], "selection_n": fitted.get("selection_n",0), "calibration_n": fitted["cal_n"], "evaluation_n": fitted["eval_n"], "significant_n": fitted["significant_n"]},
        "selected_model": fitted.get("selected_model"), "candidate_selection": fitted.get("candidate_selection") or [],
        "calibrated": bool(fitted["calibrator"] is not None), "quality_ok": quality_ok,
        "max_live_weight": spec.max_live_weight, "automatic_promotion": False,
        "reason": "asset-class specialist with class-specific point-in-time features; prospective guard still controls any live weight",
    })


def forecast_horizon(close: pd.Series, symbol: str, horizon: int = 10, fast: bool = True, context: dict | None = None) -> dict:
    base = CORE437.forecast_horizon(close, symbol=symbol, horizon=int(horizon), fast=fast, context=context)
    if not base or base.get("p_up") is None:
        return base or {}
    h = int(horizon)
    spec = specialist_forecast(close, symbol, h, regime=base.get("regime"))
    sp = _finite(spec.get("p_up"))
    sp_cond = _finite(spec.get("conditional_p_up"))
    base_neutral = _finite(base.get("p_neutral"))
    base_neutral = float(np.clip(base_neutral if base_neutral is not None else .20, .02, .85))
    base_move = max(1e-6, 1.0-base_neutral)
    base_cond = _finite(base.get("conditional_p_up"))
    if base_cond is None and _finite(base.get("p_up")) is not None:
        base_cond = _clip_p(.5 + (float(base.get("p_up"))-.5)/base_move, .02, .98)
    if sp_cond is None and sp is not None:
        sp_neutral = _finite(spec.get("p_neutral"))
        sp_move = max(1e-6, 1.0-float(sp_neutral if sp_neutral is not None else base_neutral))
        sp_cond = _clip_p(.5 + (sp-.5)/sp_move, .02, .98)
    components = list(base.get("components") or [])
    components.append({
        "name": "asset_specialist", "p_up": None if sp is None else round(sp, 6),
        "conditional_p_up": None if sp_cond is None else round(sp_cond, 6),
        "p_move": spec.get("p_move"), "p_neutral": spec.get("p_neutral"), "weight": 0.0,
        "reliability": None, "validated": False, "asset_class": spec.get("asset_class"), "route": spec.get("route"),
        "development_metrics": spec.get("development_metrics") or {}, "feature_coverage": spec.get("feature_coverage"),
    })

    try:
        gate = SEL438.specialist_gate(str(symbol).upper(), h, max_live_weight=float(spec.get("max_live_weight") or .12))
    except Exception as exc:
        gate = {"version": SEL438.VERSION, "eligible": False, "human_approved": False, "active": False, "weight": 0.0,
                "reason": f"specialist guard unavailable: {type(exc).__name__}"}
    weight = float(gate.get("weight") or 0.0) if spec.get("quality_ok") and sp_cond is not None else 0.0
    p_base = float(base["p_up"]); p_cond_final = float(base_cond if base_cond is not None else p_base)
    p_neutral_final = base_neutral
    conditional_disagreement = abs(sp_cond-p_cond_final) if sp_cond is not None else 0.0
    threshold = float(base.get("signal_threshold") or .58)
    reliability = float(((base.get("reliability") or {}).get("probability") or .5))

    if weight > 0 and sp_cond is not None:
        p_cond_final = _clip_p((1-weight)*p_cond_final + weight*sp_cond, .02, .98)
        sp_neutral = _finite(spec.get("p_neutral"))
        if sp_neutral is not None and bool((spec.get("move_model") or {}).get("quality_ok")):
            p_neutral_final = float(np.clip((1-weight)*p_neutral_final + weight*sp_neutral, .02, .85))
        if conditional_disagreement >= .18:
            p_cond_final = .5 + .86*(p_cond_final-.5)
            threshold = min(.75, threshold+.01)
        p_move_final = 1.0-p_neutral_final
        p_final = float(np.clip(.5 + p_move_final*(p_cond_final-.5), .02, .98))
        dir_prob = max(p_final, 1-p_final)
        abstain = bool(dir_prob < threshold)
        if abstain:
            strength = "нет преимущества"
        elif dir_prob >= .72:
            strength = "выраженный"
        elif dir_prob >= max(.64, threshold):
            strength = "умеренный"
        else:
            strength = "слабый"
    else:
        # Absolute diagnostic-only invariant: no approved weight means every
        # production decision field is byte-for-byte inherited from the base.
        p_final = p_base
        p_cond_final = float(base_cond if base_cond is not None else p_base)
        p_neutral_final = base_neutral
        p_move_final = float(_finite(base.get("p_move")) if _finite(base.get("p_move")) is not None else 1.0-p_neutral_final)
        threshold = float(base.get("signal_threshold") or threshold)
        abstain = bool(base.get("abstain"))
        strength = str(base.get("signal_strength") or ("нет преимущества" if abstain else "слабый"))

    components[-1]["weight"] = round(weight, 4)
    components[-1]["validated"] = bool(gate.get("active"))


    out = dict(base)
    effective_version = VERSION if weight > 0 else (base.get("version") or VERSION)
    out.update({
        "version": effective_version, "model_version": effective_version, "specialist_version": VERSION,
        "p_up": round(p_final, 6), "p_down": round(1-p_final, 6), "conditional_p_up": round(p_cond_final, 6),
        "p_neutral": round(p_neutral_final, 6), "p_move": round(p_move_final, 6),
        "class_probabilities": (dict(base.get("class_probabilities") or {}) if weight<=0 else {"up": round(p_move_final*p_cond_final, 6), "neutral": round(p_neutral_final, 6), "down": round(p_move_final*(1-p_cond_final), 6)}),
        "components": components, "abstain": abstain, "signal_strength": strength, "signal_threshold": round(threshold, 3),
        "asset_specialist": spec, "specialist_gate": gate, "specialist_weight_status": "prospective_validated_human_approved" if gate.get("active") else "challenger_only_pending_guard",
        "validation": {**(base.get("validation") or {}), "asset_class_specialist": True, "specialist_uses_time_ordered_development_split": True,
                       "specialist_prospective_validated": bool(gate.get("eligible")), "specialist_human_approved": bool(gate.get("human_approved")),
                       "automatic_promotion": False, "specialist_validation_version": VALIDATION_VERSION},
    })
    score = dict(out.get("scorecard") or {})
    score.update({
        "specialist_asset_class": spec.get("asset_class"), "specialist_route": spec.get("route"),
        "specialist_development_brier_skill": (spec.get("development_metrics") or {}).get("brier_skill"),
        "specialist_feature_coverage": spec.get("feature_coverage"), "specialist_live_weight": round(weight, 4),
    })
    out["scorecard"] = score
    return out
