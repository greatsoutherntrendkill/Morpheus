# AllAnalytics v4.30 — Fault-Isolated Data Loading + Explainable Forecast + Fast Quotes

## Reliability
- Fixed a dashboard-wide failure mode where an exception inside the Overview current-price widget could stop the rest of `init()` before Pulse, events, news and map were rendered.
- Initial dashboard widgets now start through isolated steps: one broken optional widget cannot blank the whole page.
- Added pooled resilient HTTP transport v4.30 with direct/system/dedicated-egress routes, finite default timeouts and a self-healing route circuit breaker.
- News still uses stale-while-revalidate and embedded/last-good fallback; map geometry remains local-first.

## Prices
- The Overview selected asset now has its own fast quote loop every 7 seconds instead of waiting for the full market batch.
- Technical Lab refreshes the selected quote every 6 seconds while visible.
- Full market batch refresh is 15 seconds; backend quote cache defaults to 12 seconds.
- Added 5-second single-instrument server cache and persistent `terminal_quotes_last_good_v430.json` so a temporary provider/VPN failure does not erase a known price.
- MOEX live cache defaults to 8 seconds.

## Forecast explanation
- Technical Lab now shows a compact “На чём основан прогноз” block under the current forecast.
- Intraday forecasts expose actual RSI 14, EMA 9/21, MACD histogram, technical score, source and model timestamp.
- Daily equity forecasts preserve and display OOS edge, effective sample size, Brier skill and quality-gate state when those diagnostics are available.

## Notes
- `ALLANALYTICS_EGRESS_PROXY` remains optional. If an OS-level VPN blocks a provider at the network layer, only a genuinely separate egress route can make the live request geographically independent; AllAnalytics now keeps the UI operational through last-good/generated data even when that route is unavailable.
