"""AllAnalytics v4.29 resilient HTTP transport.

Goal: external providers should not depend on one proxy/VPN path.  Module-level
requests.get/post calls are routed through multiple independent Requests sessions:
1) direct session that ignores HTTP(S)_PROXY env variables;
2) normal system/env route;
3) optional dedicated egress proxy from ALLANALYTICS_EGRESS_PROXY.

Provider-specific code still owns semantic fallbacks and last-good caches.
"""
from __future__ import annotations

import os
import threading
from typing import Any

import requests

_ORIG_GET = requests.get
_ORIG_POST = requests.post
_PATCHED = False
_LOCK = threading.Lock()
_STATS = {"attempts": 0, "success": 0, "fallback_success": 0, "errors": 0, "last_route": None, "last_error": None}


def _session(trust_env: bool, proxy: str | None = None) -> requests.Session:
    s = requests.Session()
    s.trust_env = trust_env
    if proxy:
        s.proxies.update({"http": proxy, "https": proxy})
    return s


def _do(method: str, url: str, **kwargs: Any):
    # Respect explicit caller proxy configuration first: do not overwrite it.
    explicit_proxies = kwargs.get("proxies")
    egress = os.getenv("ALLANALYTICS_EGRESS_PROXY", "").strip() or None
    routes: list[tuple[str, bool, str | None]] = []
    if explicit_proxies:
        routes.append(("caller-proxy", True, None))
    else:
        # Normal OS/VPN route may be a tunnel outside Requests; direct still helps
        # when the issue is HTTP_PROXY/HTTPS_PROXY inherited by Python.
        routes.extend([("direct-no-env", False, None), ("system-env", True, None)])
        if egress:
            routes.append(("dedicated-egress", False, egress))

    last_exc = None
    last_resp = None
    for idx, (name, trust_env, proxy) in enumerate(routes):
        with _LOCK:
            _STATS["attempts"] += 1
        try:
            if name == "caller-proxy":
                resp = (_ORIG_GET if method == "GET" else _ORIG_POST)(url, **kwargs)
            else:
                s = _session(trust_env, proxy)
                try:
                    resp = s.request(method, url, **kwargs)
                finally:
                    s.close()
            last_resp = resp
            # Retry another route on gateway/provider blocks and rate/network-ish errors.
            if resp.status_code in {403, 407, 408, 425, 429, 451, 500, 502, 503, 504, 520, 521, 522, 523, 524} and idx < len(routes)-1:
                continue
            with _LOCK:
                _STATS["success"] += 1
                if idx:
                    _STATS["fallback_success"] += 1
                _STATS["last_route"] = name
                _STATS["last_error"] = None
            return resp
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
            with _LOCK:
                _STATS["last_error"] = f"{type(exc).__name__}: {str(exc)[:180]}"
            continue
    with _LOCK:
        _STATS["errors"] += 1
    if last_resp is not None:
        return last_resp
    if last_exc is not None:
        raise last_exc
    raise requests.RequestException(f"No HTTP route available for {url}")


def resilient_get(url: str, **kwargs: Any):
    return _do("GET", url, **kwargs)


def resilient_post(url: str, **kwargs: Any):
    return _do("POST", url, **kwargs)


def install_global_patch() -> None:
    global _PATCHED
    if _PATCHED:
        return
    requests.get = resilient_get  # type: ignore[assignment]
    requests.post = resilient_post  # type: ignore[assignment]
    _PATCHED = True


def status() -> dict:
    with _LOCK:
        return {"version": "4.29", "patched": _PATCHED, **dict(_STATS), "dedicated_egress_configured": bool(os.getenv("ALLANALYTICS_EGRESS_PROXY", "").strip())}
