"""One-command AllAnalytics v3.8 refresh."""
from __future__ import annotations
import subprocess,sys

def run(cmd):
    print('\n>>>',' '.join(cmd)); subprocess.run(cmd,check=True)

def main():
    args=sys.argv[1:]
    run([sys.executable,'update.py',*args])
    run([sys.executable,'update_altdata_v38.py'])
    run([sys.executable,'export_site.py'])
    run([sys.executable,'build_cross_asset_v36.py'])
    run([sys.executable,'build_regime_v37.py'])
    print('\nAllAnalytics v3.8 refresh complete.')

if __name__=='__main__': main()
