import pandas as pd
import numpy as np
import pytest
from intraday_movement_v440105 import build

@pytest.mark.parametrize('h',['30m','1h','2h','4h'])
def test_intraday_real_windows(h):
    d=pd.DataFrame({'date':pd.date_range('2026-01-01',periods=600,freq='5min'),'close':100*np.exp(np.sin(np.arange(600)/7)*.003)})
    r=build(d,h)
    assert r['material_move_threshold_pct']>0
    assert r['expected_abs_move_pct']>=r['material_move_threshold_pct']
    assert r['directional_scenario_range'] is None
    assert r['distribution_quality_ok'] is False

def test_overnight_is_not_one_hour():
    dates=pd.DatetimeIndex([pd.Timestamp('2026-01-01')+pd.Timedelta(days=i,minutes=j*5) for i in range(50) for j in range(6)])
    r=build(pd.DataFrame({'date':dates,'close':np.arange(300)+100}),'1h')
    assert r['observations']==0
    assert r['expected_abs_move_pct'] is None

def test_null_history_is_not_zero():
    r=build(pd.DataFrame({'date':pd.date_range('2026-01-01',periods=20,freq='5min'),'close':100}),'4h')
    assert r['material_move_threshold_pct'] is None
