
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).parent

def frame(v=100.0):
    return pd.DataFrame([
        {"date":"2026-09-03","open":v-1,"high":v+1,"low":v-2,"close":v-1},
        {"date":"2026-09-04","open":v-1,"high":v+2,"low":v-2,"close":v},
    ])

def main():
    import market_data_v41 as M
    import news_map_v40 as N

    # Cascade: Yahoo failure must not prevent Stooq success.
    oy,os=M.yahoo_chart,M.stooq_history
    try:
        M.yahoo_chart=lambda *a,**k:(M._empty(),"",["Yahoo test fail"])
        M.stooq_history=lambda *a,**k:(frame(6000),"Stooq test",[])
        r=M.fetch_history("^GSPC")
        assert r.source=="Stooq test" and not r.frame.empty
        assert "Yahoo test fail" in r.errors
    finally:
        M.yahoo_chart, M.stooq_history = oy, os

    # Crypto: Binance failure -> Bybit.
    ob,oby=M.binance_history,M.bybit_history
    try:
        M.binance_history=lambda *a,**k:(M._empty(),"",["Binance fail"])
        M.bybit_history=lambda *a,**k:(frame(100000),"Bybit test",[])
        r=M.fetch_history("BTC-USD")
        assert r.source=="Bybit test"
    finally:
        M.binance_history,M.bybit_history=ob,oby

    assert not M.plausible("^DJI",132)
    assert M.plausible("^DJI",50000)

    n=N.locate({"title":"Bundesbank и правительство Германии обсуждают экономику",
                "summary":"","affected":[],"impact_score":55})
    assert n["map_country"]=="Germany"
    assert "Germany" in n["map_highlight"]

    html=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    assert 'href="favicon.png?v=4.1"' in html
    assert 'id="news-slider"' in html
    assert "active-country" in html
    assert "x.c??x.close" in html
    assert "function directional(f)" in html
    assert "/api/quotes/live?force=" in html

    fav=ROOT/"site"/"favicon.png"
    assert fav.exists() and fav.stat().st_size>100

    print("OK: v4.1 quote cascade + graph history + compact news slider + country highlight + favicon")

if __name__=="__main__":
    main()
