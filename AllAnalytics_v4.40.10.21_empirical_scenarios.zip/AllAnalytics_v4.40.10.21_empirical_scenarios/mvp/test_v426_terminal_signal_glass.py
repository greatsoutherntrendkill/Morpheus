from pathlib import Path

ROOT=Path(__file__).parent
html=(ROOT/'site'/'technical_lab_v411.html').read_text(encoding='utf-8')
api=(ROOT/'api.py').read_text(encoding='utf-8')

assert 'AllAnalytics v4.26 — Technical Lab / Signal Glass workspace' in html
assert "--glass:linear-gradient" in html
assert 'body[data-theme=signal] .workspace' in html
assert 'body[data-theme=signal] .topbar' in html
assert 'body[data-theme=signal] :is(.left,.center,.right)' in html
assert 'body[data-theme=signal] .summary' in html
assert 'body[data-theme=signal] .aa-select__panel' in html
assert "css('--chart-bg')||css('--bg')" in html
# Functional anchors must remain present.
for token in ['/api/chart/history','/api/terminal/quote','/api/forecast/short','/api/markets/equity-forecast','data-draw="trendline"','data-strategy="smc"']:
    assert token in html, token
assert 'version="4.26"' in api
print('OK: v4.26 Technical Lab Signal Glass redesign; functional anchors preserved')
