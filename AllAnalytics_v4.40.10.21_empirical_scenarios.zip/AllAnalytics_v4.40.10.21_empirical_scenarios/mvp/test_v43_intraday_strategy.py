
from __future__ import annotations
from pathlib import Path
import hashlib
import pandas as pd

ROOT=Path(__file__).parent

def frame(start="2026-09-07 10:00",n=80,freq="min",base=100):
    t=pd.date_range(start,periods=n,freq=freq)
    return pd.DataFrame({
        "date":t,"open":[base+i*.01 for i in range(n)],
        "high":[base+i*.01+.2 for i in range(n)],
        "low":[base+i*.01-.2 for i in range(n)],
        "close":[base+i*.01+.05 for i in range(n)],
    })

def main():
    import market_data_v43 as M

    assert set(M.INTERVALS)=={"1m","5m","1h"}

    # Crypto cascade: Binance failure -> Bybit success.
    ob,oby=M.binance_intraday,M.bybit_intraday
    try:
        M.binance_intraday=lambda *a,**k:(M.D._empty(),"",["Binance fail"])
        M.bybit_intraday=lambda *a,**k:(frame(),"Bybit 1m",[])
        r=M.fetch_intraday("BTC-USD","1m")
        assert r.source=="Bybit 1m" and len(r.frame)==80
    finally:
        M.binance_intraday,M.bybit_intraday=ob,oby

    # Intraday must not be generated from daily snapshot.
    api=(ROOT/"api.py").read_text(encoding="utf-8")
    assert 'interval not in {"1m","5m","1h","1d"}' in api
    assert 'elif interval=="1d" and not cached' in api
    assert "MD43.fetch_intraday" in api

    lab=(ROOT/"site"/"technical_lab_v43.html").read_text(encoding="utf-8")
    for s in ["1 минута","5 минут","1 час","ICT / структура и ликвидность",
              "Ликвидность сосредоточена","Расположение цены относительно скользящих",
              "Цена находится ${zone} полос Боллинджера"]:
        assert s in lab, s
    assert "strategySummary(currentStrategy)" in lab
    assert "interval=${interval}" in lab

    index=(ROOT/"site"/"index.html").read_text(encoding="utf-8")
    assert 'id="overview-interval"' in index
    assert "loadOverviewChart(true)" in index
    assert "overviewLiveHistory" in index
    assert ("technical_lab_v43.html" in index) or ("technical_lab_v44.html" in index) or ("technical_lab_v45.html" in index) or ("technical_lab_v46.html" in index) or ("technical_lab_v47.html" in index) or ("technical_lab_v411.html" in index) or ("technical_lab_v411.html" in index) or ("technical_lab_v47.html" in index)

    fav=ROOT/"site"/"favicon.png"
    assert fav.exists() and fav.stat().st_size>100

    print("OK: v4.3 strategy-specific analysis + real intraday + overview live timeframe + favicon")

if __name__=="__main__":
    main()
