import json
import numpy as np
import pandas as pd
import macro_calendar_v440109 as C
import macro_event_model_v440109 as M
import event_response_v439 as E

def series(n=400):
 idx=pd.bdate_range('2023-01-01',periods=n)
 return pd.Series(100*np.exp(np.cumsum(np.random.default_rng(15).normal(0,.01,n))),index=idx)

def ev(date,kind='fed_rate',seen='2023-01-01T00:00:00Z'):
 return C.row(kind,date,'https://www.federalreserve.gov',seen,'14:00','America/New_York')

def test_complete_prices_after_cutoff_never_train():
 x=series();events=[ev(str(x.index[i].date())) for i in range(40,350,20)]
 a=M.study(x,'^GSPC','fed_rate',events,as_of=x.index[250]);y=x.copy();y.iloc[250:]*=10
 b=M.study(y,'^GSPC','fed_rate',events,as_of=x.index[250]);assert a==b
 assert all(r['response_session']<str(x.index[250].date()) for r in a['rows'])

def test_post_event_windows_must_be_complete():
 x=series();e=ev(str(x.index[-2].date()));a=M.study(x,'^GSPC','fed_rate',[e],as_of=x.index[-1])
 assert a['event_day']['n']==1 and a['after_5d']['n']==0 and a['after_1d']['n']==0

def test_us_event_maps_to_next_japan_session():
 idx=pd.bdate_range('2026-09-14',periods=6);e=ev('2026-09-16')
 assert idx[M.event_session(e,idx,'^GSPC')]==pd.Timestamp('2026-09-16')
 assert idx[M.event_session(e,idx,'^N225')]==pd.Timestamp('2026-09-17')

def test_intraday_respects_release_time_not_whole_day():
 e=ev('2026-09-16');cal={'retrieved_at':'2026-09-15T00:00:00Z','events':[e]}
 a=M.build(series(),'^GSPC','1h',as_of='2026-09-16T16:00:00Z',calendar=cal,news=[])
 b=M.build(series(),'^GSPC','1h',as_of='2026-09-16T17:30:00Z',calendar=cal,news=[])
 assert not a['upcoming'] and len(b['upcoming'])==1
 assert not b['intraday_study_available']

def test_calendar_not_known_before_snapshot():
 e=ev('2026-09-16',seen='2026-09-15T19:00:00Z')
 a=M.build(series(),'^GSPC',5,as_of='2026-09-15T18:00:00Z',calendar={'events':[e]},news=[])
 assert not a['upcoming']

def test_no_macro_results_or_probability_created(monkeypatch):
 e=ev('2026-09-16');monkeypatch.setattr(C,'load',lambda:{'events':[e],'retrieved_at':'2026-09-15T00:00:00Z'})
 monkeypatch.setattr(M.FE,'_read_seed_news',lambda:[])
 f={'p_up':.63,'conditional_p_up':.70,'confidence_score':.42,'abstain':False,'summary':'base','class_probabilities':{'up':.49,'neutral':.3,'down':.21}}
 out=M.apply(f,series(),'^GSPC',1,as_of='2026-09-16T12:00:00Z')
 for k in ('p_up','conditional_p_up','confidence_score','class_probabilities'):assert out[k]==f[k]
 assert out['abstain'] and not f['abstain'] and out['event_signal_guard']

def test_news_without_timestamp_or_future_are_excluded():
 a=[{'title':'US tariff sanctions','published_at':'2026-09-17T00:00:00Z'},{'title':'US tariff sanctions'}]
 assert not M.news_risks('^GSPC','2026-09-16T00:00:00Z',a)

def test_duplicate_publication_not_multiple_observations():
 x=series();e=ev(str(x.index[40].date()));a=M.study(x,'^GSPC','fed_rate',[e,e],as_of=x.index[-1]);assert a['event_day']['n']==1

def test_global_relevance():
 for s in ['^GSPC','SBER.ME','EURUSD=X','BTC-USD','CL=F','^N225']:assert M.relevant('employment_us',s)
 assert M.relevant('cbr_rate','SBER.ME') and not M.relevant('cbr_rate','AAPL')

def test_small_or_no_effect_samples_never_pass_scale_gate():
 assert not M.scale_audit([{'normalized_abs':1}]*60)['diagnostic_pass']
 assert not M.scale_audit([{'normalized_abs':4}]*15)['diagnostic_pass']

def test_new_calendar_has_real_dates_and_no_invented_consensus():
 d=json.loads(C.BUNDLED.read_text());assert len(d['events'])>300
 for r in d['events']:assert r['source_url'].startswith('https://') and 'actual' not in r and 'forecast' not in r
 assert any(r['date']=='2026-09-16' and r['type']=='fed_rate' for r in d['events'])
 assert not any(r['date']=='2025-10-03' and r['type']=='employment_us' for r in d['events']) # shutdown: actual release moved

def test_rate_cut_size_never_assumed_25bp():
 assert E.surprise_from_event({'date':'2024-01-01','title':'ФРС снизила ставку','expected_bp':0},calendar=[])['known'] is False

def test_old_sensitivity_cannot_read_future_targets():
 x=series();d=str(x.index[-3].date());e={'date':d,'type':'fed_rate','title':'ФРС решение по ставке','surprise_known':True,'surprise_score':1,'session_timing':'during_session'}
 assert E.historical_event_responses(x,'AAPL','fed_rate',5,as_of=x.index[-1],events=[e])['n']==0

def test_recent_release_keeps_risk_filter_after_announcement():
 e=ev('2026-09-16');a=M.build(series(),'^GSPC',1,as_of='2026-09-16T18:30:00Z',calendar={'events':[e]},news=[])
 assert a['recent_releases'] and a['signal_guard'] and not a['upcoming']

def test_dst_converts_fomc_time():
 assert ev('2026-01-28')['scheduled_at'].endswith('19:00:00+00:00')
 assert ev('2026-09-16')['scheduled_at'].endswith('18:00:00+00:00')

def test_refresh_failure_does_not_claim_fresh_snapshot(monkeypatch,tmp_path):
 old={'events':[ev('2026-09-16')],'retrieved_at':'2023-01-01T00:00:00Z','sources':{}}
 monkeypatch.setattr(C,'load',lambda:old)
 monkeypatch.setattr(C,'cache_path',lambda:tmp_path/'calendar.json')
 def fail(*a,**k):raise RuntimeError('offline')
 monkeypatch.setattr(C.requests,'get',fail)
 C.refresh();got=json.loads((tmp_path/'calendar.json').read_text())
 assert got['events'][0]['last_checked_at']=='2023-01-01T00:00:00Z'
 a=M.build(series(),'^GSPC',1,as_of='2026-09-15T20:00:00Z',calendar=got,news=[])
 assert a['calendar_stale']
