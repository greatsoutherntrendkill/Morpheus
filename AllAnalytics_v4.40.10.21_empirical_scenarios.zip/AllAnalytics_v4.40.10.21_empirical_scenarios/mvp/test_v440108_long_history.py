import pandas as pd
import equity_forecast_v416 as E

def rows(n):
 return pd.DataFrame({'date':pd.date_range('2023-01-01',periods=n),'close':[100+i*.01 for i in range(n)]})

def setup(monkeypatch,long_n):
 calls=[]
 monkeypatch.setattr(E,'_load_history_cache',lambda *a:rows(0))
 monkeypatch.setattr(E,'_save_history_cache',lambda *a:None)
 monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a:(rows(0),'',[]))
 monkeypatch.setattr(E.MOEX419,'history_recent',lambda *a,**k:(rows(101),{'source':'recent'}))
 def long(*a,**k):calls.append(k);return rows(long_n)
 monkeypatch.setattr(E.MOEX419,'candles_fast',long)
 monkeypatch.setattr(E,'_apimoex_forecast_history',lambda *a:(rows(0),'',[]))
 return calls

def test_recent_does_not_block_full_history(monkeypatch):
 calls=setup(monkeypatch,800);d,diag=E._resolve_ru_forecast_history('PLZL.ME')
 assert len(d)==800 and diag['model_ready'] and calls[0]['calendar_days']==1095

def test_incomplete_long_history_keeps_best_fallback(monkeypatch):
 setup(monkeypatch,200);d,diag=E._resolve_ru_forecast_history('PLZL.ME')
 assert len(d)==200 and not diag['model_ready']

def test_failed_long_source_uses_recent(monkeypatch):
 setup(monkeypatch,0)
 def fail(*a,**k):raise TimeoutError()
 monkeypatch.setattr(E.MOEX419,'candles_fast',fail)
 d,diag=E._resolve_ru_forecast_history('PLZL.ME')
 assert len(d)==101 and not diag['model_ready'] and any('TimeoutError' in x for x in diag['errors'])

def test_apimoex_long_history_is_preferred(monkeypatch):
 setup(monkeypatch,200)
 monkeypatch.setattr(E,'_apimoex_forecast_history',lambda *a:(rows(700),'apimoex',[]))
 d,diag=E._resolve_ru_forecast_history('PLZL.ME')
 assert len(d)==700 and diag['model_ready']


def test_short_history_cache_detection():
 assert E._short_ru_history({'symbol':'PLZL.ME','observations':101})
 assert not E._short_ru_history({'symbol':'PLZL.ME','observations':877})
 assert not E._short_ru_history({'symbol':'AVGO','observations':101})
