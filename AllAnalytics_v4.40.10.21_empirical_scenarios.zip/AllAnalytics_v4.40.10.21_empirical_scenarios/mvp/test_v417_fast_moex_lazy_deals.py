from pathlib import Path

ROOT=Path(__file__).parent
HTML=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
SRC=(ROOT/'sources.py').read_text(encoding='utf-8')
MD=(ROOT/'market_data_v41.py').read_text(encoding='utf-8')
API=(ROOT/'api.py').read_text(encoding='utf-8')


def test_batch_moex_live_layer_present():
    assert 'fetch_moex_market_snapshot_batch' in SRC
    assert 'boards/{board}/securities.json' in SRC
    assert "market='shares'" in MD
    assert "market='index'" in MD
    assert 'MOEX ISS · пакет TQBR' in MD


def test_ru_indices_can_use_dynamic_model():
    assert 'symbol in C.MOEX_INDICES' in API
    assert 'isRussianIndexAsset' in HTML
    assert 'isDynamicMarketModelAsset' in HTML


def test_deals_are_lazy_paged():
    assert "limit:'12'" in HTML
    assert 'limit=12&offset=${dealsState.offset}' in HTML
    assert 'Загрузить ещё ↓' in HTML
    assert 'loadSecDealRows(false,true)' in HTML
    assert 'enrich_n=min(lim,2) if k=="mna"' in API


def test_compact_deal_hero():
    assert 'deal-hero-compact' in HTML
    assert 'deal-hero-meta' in HTML
    assert '-webkit-line-clamp:2' in HTML
