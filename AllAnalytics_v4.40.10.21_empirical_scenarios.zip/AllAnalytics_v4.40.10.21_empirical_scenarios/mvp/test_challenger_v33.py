
"""v3.3 tests: split identity, frozen holdout, immutable challenger ledger."""
from __future__ import annotations
import sqlite3, tempfile
from pathlib import Path
import numpy as np, pandas as pd

import challenger_models as CM
import model_registry as MR


def synthetic_close(n=520):
    rng=np.random.default_rng(123)
    r=rng.normal(0.0002,0.012,n)
    idx=pd.bdate_range("2024-01-02",periods=n)
    return pd.Series(100*np.exp(np.cumsum(r)),index=idx)


def test_compare():
    close=synthetic_close()
    old = __import__("os").environ.get("FINAL_HOLDOUT_START")
    __import__("os").environ["FINAL_HOLDOUT_START"]="2025-10-01"
    try:
        out=CM.compare_asset(close,horizon=5,min_train=180,retrain_every=20)
    finally:
        if old is None: __import__("os").environ.pop("FINAL_HOLDOUT_START",None)
        else: __import__("os").environ["FINAL_HOLDOUT_START"]=old
    assert out and out["identical_splits"] is True
    assert out["holdout_used_for_tuning"] is False
    assert set(out["models"])=={"logistic_regression","lightgbm","catboost"}
    dates={m["frozen_train_max_date"] for m in out["models"].values()}
    assert len(dates)==1, dates
    assert list(dates)[0] < out["holdout_start"]
    assert "lightgbm" in out["paired_holdout"] and "catboost" in out["paired_holdout"]


def test_registry_and_ledger():
    with tempfile.TemporaryDirectory() as td:
        con=sqlite3.connect(Path(td)/"x.db")
        MR.ensure_schema(con)
        MR.register_champion(con)
        MR.register_challenger(con,"lightgbm-v3.3.0","lightgbm","features-pit-v3.1.0",
                               CM.LOCKED_CONFIGS["lightgbm"])
        pid=MR.append_prediction_for_model(con,"lightgbm-v3.3.0","features-pit-v3.1.0",
                                           "TEST",10,"2026-09-01",.57,
                                           {"research_challenger":True},{},
                                           "research_challenger")
        assert pid
        # identical rerun is idempotent
        pid2=MR.append_prediction_for_model(con,"lightgbm-v3.3.0","features-pit-v3.1.0",
                                            "TEST",10,"2026-09-01",.99,{},{},"research_challenger")
        assert pid==pid2
        stored=con.execute("select p_up from prediction_ledger where prediction_id=?",(pid,)).fetchone()[0]
        assert abs(stored-.57)<1e-12
        try:
            con.execute("update prediction_ledger set p_up=.99 where prediction_id=?",(pid,))
            raise AssertionError("ledger mutation was not blocked")
        except sqlite3.DatabaseError:
            pass


if __name__=="__main__":
    test_compare()
    test_registry_and_ledger()
    print("OK: v3.3 locked splits + frozen holdout + immutable challenger ledger")
