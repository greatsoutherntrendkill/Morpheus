from pathlib import Path

ROOT=Path(__file__).resolve().parent


def test_dashboard_init_isolated_and_price_safe():
    t=(ROOT/'site'/'index.html').read_text(encoding='utf-8')
    assert 'safeInitStepV430' in t
    assert 'safeAnimateForecastPriceV430' in t
    assert 'loadOverviewLiveQuoteV430' in t
    assert 'OVERVIEW_PRICE_REFRESH_MS=7000' in t


def test_terminal_quote_refresh_and_model_evidence():
    t=(ROOT/'site'/'technical_lab_v411.html').read_text(encoding='utf-8')
    assert 'TERMINAL_QUOTE_REFRESH_MS=6000' in t
    assert 'forecastEvidenceHtml' in t
    assert 'OOS преимущество' in t
    assert 'EMA 9 / EMA 21' in t
    assert 'MACD histogram' in t


def test_backend_quote_lastgood_and_faster_cache():
    t=(ROOT/'api.py').read_text(encoding='utf-8')
    assert 'terminal_quotes_last_good_v430.json' in t
    assert 'QUOTE_REFRESH_SECONDS","12"' in t
    assert 'TERMINAL_QUOTE_CACHE_SECONDS","5"' in t
    assert 'resilient_http_v430 as RH430' in t


def test_resilient_transport_has_pool_and_circuit_breaker():
    t=(ROOT/'resilient_http_v430.py').read_text(encoding='utf-8')
    assert '_thread_session("direct-no-env", False)' in t
    assert '_thread_session("system-env", True)' in t
    assert 'thread-safe' in t
    assert 'blocked_until' in t
    assert 'dedicated-egress' in t
    assert 'timeout' in t
