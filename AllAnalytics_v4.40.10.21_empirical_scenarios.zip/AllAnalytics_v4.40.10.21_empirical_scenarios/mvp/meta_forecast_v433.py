"""AllAnalytics v4.33 — conservative meta-forecast.

Combines the existing production/research walk-forward model with the v4.33
volatility-aware regime challenger. The challenger never replaces the champion
merely because its point estimate is more extreme. Disagreement shrinks the
published probability toward 50%, and a dynamic no-edge gate may abstain.
"""
from __future__ import annotations
import math
import models
import model_quality_v433 as MQ

VERSION="meta-quality-v4.33.0"


def _finite(x):
    try:
        x=float(x); return x if math.isfinite(x) else None
    except Exception:return None


def forecast_horizon(close, horizon=10, fast=True) -> dict:
    h=int(horizon)
    champion=models.walk_forward_direction(close,horizon=h,min_train=120 if fast else 220,
                                            retrain_every=40 if fast else 20,
                                            bootstrap_resamples=45 if fast else 220)
    challenger=MQ.walk_forward_regime(close,horizon=h,min_train=140 if fast else 220,
                                      retrain_every=40 if fast else 25)
    pc=_finite((champion or {}).get("live_p_up")); pq=_finite((challenger or {}).get("p_up"))
    if pc is None and pq is None:return {}
    cq=(champion or {}).get("quality") or {}; qq=(challenger or {}).get("quality") or {}
    c_trusted=bool(cq.get("trusted")); q_trusted=bool(qq.get("trusted"))

    comps=[]
    if pc is not None:
        wc=.62 if c_trusted else .42
        comps.append(("production",pc,wc,c_trusted))
    if pq is not None:
        wq=.55 if q_trusted else .28
        comps.append(("vol_regime",pq,wq,q_trusted))
    sw=sum(x[2] for x in comps) or 1.0
    raw=sum(x[1]*x[2] for x in comps)/sw
    # If models disagree on direction, do not let a weighted mean look more certain
    # than the evidence actually is.
    signs={x[1]>=.5 for x in comps}
    disagreement=len(signs)>1
    shrink=.58 if disagreement else (1.0 if any(x[3] for x in comps) else .72)
    p=.5+shrink*(raw-.5)
    p=float(min(.95,max(.05,p)))
    dir_prob=max(p,1-p)

    regime=(challenger or {}).get("regime") or "unknown"
    threshold=_finite((challenger or {}).get("signal_threshold")) or .58
    # Meta layer is deliberately stricter when neither component is validated.
    if not any(x[3] for x in comps):threshold=max(threshold,.60)
    # If neither component has passed its own OOS quality gate, only an unusually
    # strong and mutually consistent research signal may escape abstention.
    evidence_ok=any(x[3] for x in comps) or (not disagreement and dir_prob>=.72)
    abstain=bool(dir_prob<threshold or not evidence_ok)
    if dir_prob>=.70:strength="выраженный"
    elif dir_prob>=max(.63,threshold):strength="умеренный"
    elif dir_prob>=threshold:strength="слабый"
    else:strength="нет преимущества"
    if abstain: strength="нет преимущества"
    trusted=bool(not abstain and any(x[3] for x in comps) and not disagreement)

    champion_sc=(champion or {}).get("scorecard") or {}
    qsc=(challenger or {}).get("scorecard") or {}
    return {
        "version":VERSION,"horizon":h,"p_up":round(p,6),"p_down":round(1-p,6),
        "abstain":abstain,"signal_strength":strength,"signal_threshold":round(threshold,3),
        "regime":regime,"disagreement":disagreement,
        "quality":{"trusted":trusted,"confidence":"средняя" if trusted else "низкая",
                   "bias":"neutral" if abstain else ("bullish" if p>=.5 else "bearish"),
                   "reason":"нет достаточного преимущества" if abstain else ("модели расходятся" if disagreement else "сигнал поддержан ансамблем")},
        "components":[
            {"name":name,"p_up":round(prob,6),"weight":round(weight/sw,4),"trusted":valid}
            for name,prob,weight,valid in comps
        ],
        "champion":champion,
        "challenger":challenger,
        "scorecard":{
            "n_eff":champion_sc.get("Наблюдений (effective)"),
            "edge":champion_sc.get("Преимущество non-overlap, п.п."),
            "brier_skill":champion_sc.get("Brier skill non-overlap, %"),
            "ece":champion_sc.get("Calibration error non-overlap"),
            "challenger_n_eff":qsc.get("directional_effective_n"),
            "challenger_edge":qsc.get("directional_edge_pp"),
            "challenger_brier_skill":qsc.get("directional_brier_skill"),
            "challenger_ece":qsc.get("directional_ece"),
            "p_neutral":(challenger or {}).get("p_neutral"),
        },
        "validation":{"champion":(champion or {}).get("validation") or {},
                      "challenger":(challenger or {}).get("validation") or {},
                      "meta_disagreement_shrink":True,"automatic_promotion":False}
    }
