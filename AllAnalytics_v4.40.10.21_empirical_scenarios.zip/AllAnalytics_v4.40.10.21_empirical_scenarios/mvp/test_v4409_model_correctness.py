import numpy as np
import pandas as pd

import regime_models_v37 as RM
import robustness_v4407 as R
import asset_specialists_v438 as SP
import event_response_v439 as EV
import models
import forecast_contract_v4406 as FC
import model_correctness_v4409 as MC


class _Const:
    def __init__(self, p): self.p=float(p)
    def proba(self, X): return np.full(len(X), self.p, dtype=float)


def _series(n=520):
    idx=pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=n)
    rng=np.random.default_rng(409)
    return pd.Series(100*np.exp(np.cumsum(rng.normal(.0002,.011,n))), index=idx)


def test_soft_regime_router_really_uses_continuous_risk_score():
    m=RM.RegimeMoE(['x'])
    m.global_model=_Const(.50)
    m.class_models={}
    m.regime_models={'risk_off':_Const(.18),'mixed':_Const(.50),'risk_on':_Const(.82)}
    m.ood_prep=None; m.ood_ref=None
    X=np.array([[0.0],[0.0]])
    meta=pd.DataFrame({'expert_class':['equity','equity'],'risk_regime':['mixed','mixed'],'risk_score':[-.90,.90]})
    out=m.proba_components(X,meta)
    assert out[0]['risk_score'] < 0 and out[1]['risk_score'] > 0
    assert out[1]['regime_p'] > out[0]['regime_p']
    assert out[1]['p'] > out[0]['p']


def test_distribution_consistency_gate_is_diagnostic_when_quality_fails():
    out={'conditional_p_up':.80,'distribution_forecast':{
        'status':'ok','quality_ok':False,'horizon':10,
        'quantiles':{'q50_return_pct':-2.0},
        'evaluation':{'effective_n':50},
    }}
    g=R.consistency_gate(out)
    assert g['eligible'] is False
    assert g['action']=='none'
    assert g['severity']==0


def test_distribution_consistency_gate_requires_effective_sample():
    out={'conditional_p_up':.80,'distribution_forecast':{
        'status':'ok','quality_ok':True,'horizon':10,
        'quantiles':{'q50_return_pct':-2.0},
        'evaluation':{'effective_n':R.DIST_MIN_EFFECTIVE_N-1},
    }}
    g=R.consistency_gate(out)
    assert g['eligible'] is False and g['action']=='none'


def test_distribution_consistency_gate_can_act_only_when_qualified():
    out={'conditional_p_up':.80,'distribution_forecast':{
        'status':'ok','quality_ok':True,'horizon':10,
        'quantiles':{'q50_return_pct':-2.0},
        'evaluation':{'effective_n':R.DIST_MIN_EFFECTIVE_N+4},
    }}
    g=R.consistency_gate(out)
    assert g['eligible'] is True
    assert 'disagreement' in g['status']
    assert g['severity']>0


def test_unapproved_asset_specialist_has_literal_zero_influence(monkeypatch):
    base={'version':'core','model_version':'core','p_up':.61,'p_down':.39,'conditional_p_up':.68,
          'p_neutral':.34,'p_move':.66,'class_probabilities':{'up':.4488,'neutral':.34,'down':.2112},
          'signal_threshold':.58,'abstain':False,'signal_strength':'слабый','components':[],
          'validation':{},'scorecard':{},'reliability':{'probability':.6}}
    monkeypatch.setattr(SP.CORE437,'forecast_horizon',lambda *a,**k:dict(base))
    monkeypatch.setattr(SP,'specialist_forecast',lambda *a,**k:{
        'p_up':.30,'conditional_p_up':.18,'p_neutral':.20,'p_move':.80,'quality_ok':True,
        'move_model':{'quality_ok':True},'max_live_weight':.16,'asset_class':'equity','route':'test'})
    monkeypatch.setattr(SP.SEL438,'specialist_gate',lambda *a,**k:{'active':False,'eligible':False,'human_approved':False,'weight':0.0})
    out=SP.forecast_horizon(_series(),'AAPL',10,True)
    assert out['p_up']==base['p_up']
    assert out['conditional_p_up']==base['conditional_p_up']
    assert out['p_neutral']==base['p_neutral']
    assert out['signal_threshold']==base['signal_threshold']
    assert out['abstain']==base['abstain']


def test_unapproved_event_challenger_has_literal_zero_influence(monkeypatch):
    base={'version':'core','model_version':'core','p_up':.61,'p_down':.39,'conditional_p_up':.68,
          'p_neutral':.34,'p_move':.66,'class_probabilities':{'up':.4488,'neutral':.34,'down':.2112},
          'signal_threshold':.58,'abstain':False,'signal_strength':'слабый','components':[],
          'validation':{},'scorecard':{}}
    monkeypatch.setattr(EV.BASE438,'forecast_horizon',lambda *a,**k:dict(base))
    monkeypatch.setattr(EV,'event_response_forecast',lambda *a,**k:{'status':'awaiting_surprise','p_up':.20,'quality_ok':True,
        'max_live_weight':.10,'event':{'type':'fed_rate'},'event_sample_n':12})
    monkeypatch.setattr(EV.SEL439,'event_gate',lambda *a,**k:{'active':False,'eligible':False,'human_approved':False,'weight':0.0})
    EV._FORECAST_CACHE.clear()
    out=EV.forecast_horizon(_series(),'AAPL',10,True)
    assert out['p_up']==base['p_up']
    assert out['conditional_p_up']==base['conditional_p_up']
    assert out['signal_threshold']==base['signal_threshold']
    assert out['abstain']==base['abstain']


def test_feature_builder_stops_unbounded_market_forward_fill():
    idx=pd.bdate_range('2026-01-01',periods=120)
    close=pd.Series(np.linspace(100,120,len(idx)),index=idx)
    dxy=pd.Series(np.linspace(95,100,80),index=idx[:80])
    f=models.build_features(close,dxy=dxy)
    # A 40-row provider gap must not be silently converted into a current DXY feature.
    assert pd.isna(f['dxy_ret20'].iloc[-1])
    meta=f.attrs.get('freshness') or {}
    src=(meta.get('sources') or {}).get('dxy') or {}
    assert src.get('hard_stale') is True
    assert src.get('age_days',0) > src.get('hard_after_days',0)


def test_v4409_generation_and_wrapper_identity():
    assert FC.MODEL_GENERATION.endswith('v4.40.10.16')
    assert FC.CACHE_CONTRACT_VERSION.endswith('v4.40.10.16')
    assert MC.VERSION=='model-correctness-v4.40.9'
