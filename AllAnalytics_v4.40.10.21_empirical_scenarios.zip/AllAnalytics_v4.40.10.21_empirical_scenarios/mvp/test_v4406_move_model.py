from __future__ import annotations
import numpy as np
import pandas as pd
import models as M
import dynamic_ensemble_v437 as DE


def _heteroskedastic(n=720,seed=4406):
    rng=np.random.default_rng(seed)
    sig=np.where((np.arange(n)//70)%2==0,.004,.018)
    # include predictors the move classifier can learn through recent vol
    r=.0001+rng.normal(0,sig,n)
    return pd.Series(100*np.exp(np.cumsum(r)),index=pd.bdate_range('2023-01-02',periods=n))


def test_champion_has_learned_move_no_move_probability():
    out=M.walk_forward_direction(_heteroskedastic(),horizon=5,bootstrap_resamples=80)
    assert out
    assert 0 < out['p_move'] < 1
    assert abs(out['p_move']+out['p_neutral']-1)<1e-8
    mm=out['move_model']
    assert mm['version']=='move-sklearn-logreg-v4.40.10'
    assert mm['trained'] is True
    assert out['validation']['move_probability_modelled_from_current_features'] is True
    assert out['validation']['historical_neutral_share_not_used_as_primary_live_probability'] is True


def test_dynamic_ensemble_uses_learned_move_probability(monkeypatch):
    dates=pd.bdate_range('2025-01-02',periods=120)
    rec_c=[{'date':str(d.date()),'conditional_p_up':.60 if i%2==0 else .40,'p_up':.56 if i%2==0 else .44,'y':1 if i%2==0 else 0,'state':1 if i%2==0 else -1} for i,d in enumerate(dates)]
    rec_q=[{'date':str(d.date()),'conditional_p_up':.58 if i%2==0 else .42,'p_up':.55 if i%2==0 else .45,'y':1 if i%2==0 else 0,'state':1 if i%2==0 else -1,'regime':'trend_up|normal_vol'} for i,d in enumerate(dates)]
    champion={'live_p_up':.56,'conditional_p_up':.60,'p_move':.62,'oos_records':rec_c}
    challenger={'p_up':.55,'conditional_p_up':.58,'p_move':.68,'oos_records':rec_q,'regime':'trend_up|normal_vol'}
    base={'p_up':.56,'p_down':.44,'regime':'trend_up|normal_vol','base_meta':{'champion':champion,'challenger':challenger},
          'components':[],'scorecard':{},'validation':{},'feature_drift':{},'context_features':{},'event_context':{}}
    monkeypatch.setattr(DE.META434,'forecast_horizon',lambda *a,**k:dict(base))
    monkeypatch.setattr(DE.FE434,'build_context',lambda *a,**k:{'context_confidence':0,'drift_score':0,'event_risk':0})
    monkeypatch.setattr(DE.FE434,'apply_context_probability',lambda *a,**k:{})
    monkeypatch.setattr(DE.SEL437,'context_gate',lambda *a,**k:{'active':False,'eligible':False,'human_approved':False,'weight':0,'reason':'test'})
    s=_heteroskedastic(300)
    out=DE.forecast_horizon(s,'AAPL',5)
    assert out['move_probability_source']=='learned_move_no_move_ensemble'
    assert 0 < out['p_move'] < 1
    assert abs(sum(out['class_probabilities'].values())-1)<2e-6
