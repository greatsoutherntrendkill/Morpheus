"""AllAnalytics v4.40.10.2 — explainable movement ranges.

This module does not create a new price-target model.  It translates the existing
three-state target contract and calibrated distribution forecast into a small,
auditable user-facing description:

* the current volatility-adjusted threshold that defines a material move;
* the model's expected absolute move (only as a distributional scale estimate);
* a directional *scenario* range from calibrated tail quantiles, only when the
  distribution layer passed its own quality/effective-sample gate.

News/event context is intentionally not used to manufacture numerical precision.
It remains an explanatory, bounded context layer in the parent forecast.
"""
from __future__ import annotations

import math
import numpy as np
import pandas as pd

import target_contract_v4405 as TARGET

VERSION = "movement-guidance-v4.40.10.2"


def _finite(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _q(dist: dict, name: str):
    return _finite((dist.get("quantiles") or {}).get(name))


def _effective_n(dist: dict) -> int:
    ev = dist.get("evaluation") or {}
    direct = ev.get("effective_n")
    if direct is not None:
        try:
            return int(direct)
        except Exception:
            pass
    dep = ev.get("dependence_adjusted") or {}
    try:
        return int(dep.get("effective_n") or 0)
    except Exception:
        return 0


def build(close: pd.Series, horizon: int, forecast: dict | None) -> dict:
    f = forecast or {}
    h = max(1, int(horizon))
    c = TARGET._series(close)
    current_band = TARGET.band_pct_for_asof(c, h)
    recent = TARGET.threshold_series(c, h).dropna().tail(60) * 100.0 if len(c) else pd.Series(dtype=float)
    recent_range = None
    if len(recent) >= 15:
        lo, hi = np.quantile(recent.to_numpy(float), [.25, .75])
        if math.isfinite(float(lo)) and math.isfinite(float(hi)):
            recent_range = [round(float(lo), 3), round(float(hi), 3)]

    dist = f.get("distribution_forecast") or {}
    dist_status = str(dist.get("status") or "")
    effective_n = _effective_n(dist)
    quality_ok = bool(dist_status == "ok" and dist.get("quality_ok") is True and effective_n > 0)
    expected_abs = _finite(dist.get("expected_abs_move_pct")) if dist_status == "ok" else None
    q10, q25, q50, q75, q90 = (_q(dist, x) for x in (
        "q10_return_pct", "q25_return_pct", "q50_return_pct", "q75_return_pct", "q90_return_pct"
    ))

    central = None
    if q25 is not None and q75 is not None:
        central = [round(q25, 3), round(q75, 3)]

    cond_up = _finite(f.get("conditional_p_up"))
    if cond_up is None:
        cond_up = _finite(f.get("p_up"))
    side = "up" if cond_up is not None and cond_up >= .5 else "down"

    # Tail scenario, not a point target. q75→q90 for upside and q10→q25 for
    # downside describe the stronger same-direction part of the calibrated
    # predictive distribution.  We publish it only when the distribution audit
    # passed, and only when it actually clears the material-move threshold.
    scenario = None
    band = abs(float(current_band)) if current_band is not None else None
    if quality_ok and band is not None:
        if side == "up" and q75 is not None and q90 is not None and q90 > band:
            lo = max(band, q75)
            hi = q90
            if hi >= lo and lo > 0:
                scenario = {"direction": "up", "low_pct": round(lo, 3), "high_pct": round(hi, 3),
                            "basis": "q75-q90 calibrated predictive tail"}
        elif side == "down" and q10 is not None and q25 is not None and q25 < 0 and q10 < -band:
            lo = max(band, abs(q25))
            hi = abs(q10)
            if hi >= lo and lo > 0:
                scenario = {"direction": "down", "low_pct": round(lo, 3), "high_pct": round(hi, 3),
                            "basis": "q10-q25 calibrated predictive tail"}

    if dist_status != "ok":
        range_status = "distribution_unavailable"
        reason = "Распределение доходности пока не рассчитано на достаточной истории."
    elif not quality_ok:
        range_status = "research_only"
        reason = "Распределение рассчитано, но ещё не прошло проверку качества/эффективной выборки для публикации направленного диапазона."
    elif scenario is None:
        range_status = "no_one_sided_range"
        reason = "Калиброванное распределение пересекает нейтральную область, поэтому честный односторонний диапазон роста/снижения сейчас не выделяется."
    else:
        range_status = "validated_scenario_range"
        reason = "Сценарный диапазон построен из калиброванных квантилей и публикуется только после quality gate."

    return {
        "version": VERSION,
        "horizon": h,
        "return_unit": "log_return_percent",
        "material_move_threshold_pct": None if current_band is None else round(float(current_band), 3),
        "material_threshold_recent_iqr_pct": recent_range,
        "expected_abs_move_pct": None if expected_abs is None else round(float(expected_abs), 3),
        "central_50_return_interval_pct": central,
        "distribution_quality_ok": quality_ok,
        "distribution_effective_n": effective_n,
        "directional_scenario_range": scenario,
        "range_status": range_status,
        "reason": reason,
        "semantics": {
            "material_move": "absolute future log-return beyond the shared volatility-adjusted three-state threshold",
            "expected_abs_move": "distributional scale estimate, not a guaranteed target",
            "directional_scenario_range": "stronger same-direction calibrated tail scenario, not a point forecast",
        },
    }
