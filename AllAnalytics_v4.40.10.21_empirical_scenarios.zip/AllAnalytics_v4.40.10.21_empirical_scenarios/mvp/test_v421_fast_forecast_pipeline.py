import time
import numpy as np
import pandas as pd
import equity_forecast_v416 as E


def synthetic(n=500):
    rng=np.random.default_rng(7)
    dates=pd.bdate_range(end=pd.Timestamp.today().normalize(),periods=n)
    close=250*np.exp(np.cumsum(rng.normal(.00025,.012,n)))
    return pd.DataFrame({'date':dates,'open':close,'high':close*1.006,'low':close*.994,'close':close})


def test_fast_ru_forecast(monkeypatch):
    d=synthetic(500)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(pd.DataFrame(),'', ['mock yahoo disabled']))
    monkeypatch.setattr(E.MOEX419,'history_recent',lambda *a,**k:(d.copy(),{'source':'mock history','errors':[],'observations':len(d)}))
    monkeypatch.setattr(E,'_append_live_ru',lambda frame,symbol:frame)
    t=time.perf_counter()
    row=E.forecast_fast('SBER.ME',(10,),force=True)
    elapsed=time.perf_counter()-t
    assert row['status']=='ok'
    assert row['forecasts']['10']['p_up'] is not None
    assert row['profile'].startswith('fast-ui')
    assert elapsed < 2.0


def test_short_history_has_scenario_fallback(monkeypatch):
    d=synthetic(100)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(pd.DataFrame(),'', ['mock yahoo disabled']))
    monkeypatch.setattr(E.MOEX419,'history_recent',lambda *a,**k:(d.copy(),{'source':'mock history','errors':[],'observations':len(d)}))
    monkeypatch.setattr(E,'_append_live_ru',lambda frame,symbol:frame)
    row=E.forecast_fast('GAZP.ME',(10,),force=True)
    assert row['status']=='ok'
    assert row['forecasts']['10']['p_up'] is not None
    assert row['forecasts']['10']['status']=='сценарная оценка'
