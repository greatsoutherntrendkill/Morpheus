"""AllAnalytics v4.24 — устойчивые модельные прогнозы для раздела «Рынки».

Используется тот же production/research modelling module models.py, что и в
основном пайплайне: purged walk-forward, non-overlap evaluation и quality gate.
Модель не пересчитывается каждые 30 секунд — прогноз кэшируется, котировка живёт
отдельным быстрым контуром.
"""
from __future__ import annotations

import math
import copy
import data_contract_v4401013 as DATA13
import time
import json
import os
import urllib.parse
from pathlib import Path
from threading import Lock
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

try:
    import apimoex
except Exception:
    apimoex = None

import pandas as pd

import market_data_v41 as MD41
import market_universe_v416 as MU416
import config as C
import moex_fast_v419 as MOEX419
import models
import movement_guidance_v440102 as MOVEGUIDE440102
import macro_event_model_v440109 as MACRO109
import quality_contract_v4401011 as QUALITY

# Warm optional ML backends at server/module startup rather than on the first
# forecast request.  This keeps the first market-card calculation within the
# existing latency budget without changing model selection or predictions.
try:
    import lightgbm as _aa_lightgbm_warmup  # noqa: F401
except Exception:
    _aa_lightgbm_warmup = None
try:
    import catboost as _aa_catboost_warmup  # noqa: F401
except Exception:
    _aa_catboost_warmup = None
import meta_forecast_v434 as META434
import model_champion_validation_v44010 as META4406
import forecast_contract_v4406 as CONTRACT4406
# v4.40.6 is the single live source of truth. Older aliases remain only so
# API/tests that import EQF416.META435 do not break during the migration.
META440 = META4406
META435 = META4406
# legacy contract marker: import event_response_v439 as META435
# legacy contract marker: import dynamic_ensemble_v437 as META435

_LOCK = Lock()
_CACHE: dict[tuple[str, tuple[int, ...]], tuple[float, dict]] = {}
_FAST_CACHE: dict[tuple[str, tuple[int, ...]], tuple[float, dict]] = {}
TTL_SECONDS = 60 * 60 * 3
ROOT=Path(__file__).resolve().parent
# equity_forecast_v420 legacy cache namespace retained only as a regression marker
DISK_DIR=ROOT/"runtime_cache"/"equity_forecast_v4409_correctness"
DISK_DIR.mkdir(parents=True,exist_ok=True)
FAST_DISK_DIR=ROOT/"runtime_cache"/"equity_forecast_v4409_correctness_fast"
# legacy cache namespace markers: equity_forecast_v435_dynamic_fast / equity_forecast_v434_context_fast / equity_forecast_v433_meta_fast
FAST_DISK_DIR.mkdir(parents=True,exist_ok=True)
FAST_TTL_SECONDS=60*60*3
CACHE_CONTRACT_VERSION=QUALITY.VERSION
MAX_ASOF_STALENESS_DAYS=10
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 AllAnalytics/4.24"
RU_HISTORY_DIR=ROOT/"runtime_cache"/"equity_history_v424"
RU_HISTORY_DIR.mkdir(parents=True,exist_ok=True)
RU_HISTORY_TTL_SECONDS=24*60*60

def _make_forecast_session(trust_env: bool) -> requests.Session:
    s=requests.Session(); s.trust_env=trust_env
    s.headers.update({"User-Agent":UA,"Accept":"application/json,text/plain,*/*"})
    return s

_FORECAST_DIRECT=_make_forecast_session(False)
_FORECAST_ENV=_make_forecast_session(True)


def _disk_path(symbol: str, hs: tuple[int,...]) -> Path:
    safe="".join(c for c in str(symbol).upper() if c.isalnum() or c in "-_")
    return DISK_DIR/f"{safe}_{'-'.join(map(str,hs))}.json"


def _cache_payload_valid(j: dict, *, fast: bool=False) -> bool:
    if not isinstance(j,dict) or j.get("status")!="ok": return False
    cc=j.get("cache_contract") or {}
    if cc.get("version")!=CACHE_CONTRACT_VERSION: return False
    if cc.get("model_generation")!=META4406.MODEL_GENERATION: return False
    if cc.get("target_version")!=getattr(META4406,"TARGET4405").TARGET_VERSION: return False
    try:
        asof=pd.Timestamp(str(j.get("as_of") or "")[:10]).normalize()
        today=pd.Timestamp.utcnow().tz_localize(None).normalize()
        if pd.isna(asof) or (today-asof).days>MAX_ASOF_STALENESS_DAYS or asof>today+pd.Timedelta(days=1):
            return False
    except Exception:
        return False
    # A saved ML cache must contain at least one forecast from the current model
    # generation. Scenario fallbacks are intentionally not persisted across runs.
    fs=j.get("forecasts") or {}
    if not any(isinstance(v,dict) and v.get("model_generation")==META4406.MODEL_GENERATION for v in fs.values()):
        return False
    return True

def _stamp_cache_contract(row: dict) -> dict:
    out=dict(row)
    out["cache_contract"]={
        "version":CACHE_CONTRACT_VERSION,"saved_at":pd.Timestamp.utcnow().isoformat(),
        "model_generation":META4406.MODEL_GENERATION,"target_version":META4406.TARGET4405.TARGET_VERSION,
        "as_of":out.get("as_of"),
    }
    return out

def _load_disk(symbol: str, hs: tuple[int,...]) -> dict | None:
    p=_disk_path(symbol,hs)
    try:
        if not p.exists() or time.time()-p.stat().st_mtime>TTL_SECONDS*4:return None
        j=json.loads(p.read_text(encoding="utf-8"))
        if _cache_payload_valid(j): return j
        try:p.unlink()
        except Exception:pass
        return None
    except Exception:return None


def _save_disk(symbol: str, hs: tuple[int,...], row: dict):
    if os.getenv("PYTEST_CURRENT_TEST") or row.get("status")!="ok":return
    stamped=_stamp_cache_contract({**row,"history_route_version":"4.40.10.8"})
    if not _cache_payload_valid(stamped): return
    p=_disk_path(symbol,hs); tmp=p.with_suffix(".tmp")
    tmp.write_text(json.dumps(stamped,ensure_ascii=False,separators=(",",":")),encoding="utf-8");tmp.replace(p)


def _relaxed_yahoo_history(symbol: str, years: int=5) -> tuple[pd.DataFrame,str,list[str]]:
    """History fallback for VPN cases.

    Yahoo's Moscow quotes can be delayed/stale, so this source is never used as the
    live price. It is only a long-history backup for the model and is labelled as such.
    The current MOEX price is appended later when available.
    """
    enc=urllib.parse.quote(str(symbol),safe=""); errors=[]
    for host in ("query1.finance.yahoo.com","query2.finance.yahoo.com"):
        try:
            r=requests.get(f"https://{host}/v8/finance/chart/{enc}",params={"range":f"{max(2,years)}y","interval":"1d","events":"div,splits"},headers={"User-Agent":UA,"Accept":"application/json"},timeout=(3,7))
            if r.status_code!=200:errors.append(f"{host}: HTTP {r.status_code}");continue
            result=((r.json().get("chart") or {}).get("result") or [None])[0]
            if not result:errors.append(f"{host}: empty");continue
            ts=result.get("timestamp") or [];q=(((result.get("indicators") or {}).get("quote") or [{}])[0])
            n=min([len(ts)]+[len(q.get(k) or []) for k in ("open","high","low","close")])
            if n<220:errors.append(f"{host}: short history");continue
            d=pd.DataFrame({"date":pd.to_datetime(ts[:n],unit="s",utc=True).tz_convert(None),"open":(q.get("open") or [])[:n],"high":(q.get("high") or [])[:n],"low":(q.get("low") or [])[:n],"close":(q.get("close") or [])[:n]})
            for c in ("open","high","low","close"):d[c]=pd.to_numeric(d[c],errors="coerce")
            d=d.dropna(subset=["date","close"]).sort_values("date").drop_duplicates("date",keep="last")
            d["open"]=d["open"].fillna(d["close"]);d["high"]=d["high"].fillna(d[["open","close"]].max(axis=1));d["low"]=d["low"].fillna(d[["open","close"]].min(axis=1))
            if len(d)>=220:
                age=(pd.Timestamp.now().normalize()-pd.Timestamp(d.iloc[-1]["date"]).normalize()).days
                if age<=120:
                    return DATA13.yahoo_price_frame(d[["date","open","high","low","close"]],result),f"Yahoo historical backup ({host.split('.')[0]})",errors
                errors.append(f"{host}: history stale {age}d")
        except Exception as exc:errors.append(f"{host}: {type(exc).__name__}")
    return pd.DataFrame(columns=["date","open","high","low","close"]),"",errors



def _history_cache_path(symbol: str) -> Path:
    safe="".join(c for c in str(symbol).upper() if c.isalnum() or c in "-_")
    return RU_HISTORY_DIR/f"{safe}.json"


def _normalise_history(d: pd.DataFrame | None) -> pd.DataFrame:
    cols=["date","open","high","low","close"]
    if d is None or d.empty:return pd.DataFrame(columns=cols)
    x=d.copy()
    ren={"TRADEDATE":"date","OPEN":"open","HIGH":"high","LOW":"low","CLOSE":"close"}
    x=x.rename(columns={k:v for k,v in ren.items() if k in x.columns})
    if "date" not in x.columns or "close" not in x.columns:return pd.DataFrame(columns=cols)
    x["date"]=pd.to_datetime(x["date"],errors="coerce").dt.tz_localize(None)
    x["close"]=pd.to_numeric(x["close"],errors="coerce")
    x=x.dropna(subset=["date","close"]).sort_values("date").drop_duplicates("date",keep="last")
    for c in ("open","high","low"):
        if c not in x.columns:x[c]=x["close"]
        x[c]=pd.to_numeric(x[c],errors="coerce").fillna(x["close"])
    return x[cols]


def _load_history_cache(symbol: str, allow_stale: bool=False) -> pd.DataFrame:
    p=_history_cache_path(symbol)
    try:
        if not p.exists():return _normalise_history(None)
        if not allow_stale and time.time()-p.stat().st_mtime>RU_HISTORY_TTL_SECONDS:return _normalise_history(None)
        obj=json.loads(p.read_text(encoding="utf-8")); d=pd.DataFrame(obj.get("rows") or [])
        d.attrs.update(obj.get("metadata") or {})
        return _normalise_history(d)
    except Exception:return _normalise_history(None)


def _save_history_cache(symbol: str, d: pd.DataFrame, source: str):
    if os.getenv("PYTEST_CURRENT_TEST") or d is None or len(d)<61:return
    p=_history_cache_path(symbol);tmp=p.with_suffix(".tmp")
    rows=[{"date":str(pd.Timestamp(r.date).date()),"open":float(r.open),"high":float(r.high),"low":float(r.low),"close":float(r.close)} for r in d.tail(900).itertuples()]
    try:
        tmp.write_text(json.dumps({"saved_at":time.time(),"source":source,"metadata":dict(d.attrs),"rows":rows},ensure_ascii=False,separators=(",",":")),encoding="utf-8");tmp.replace(p)
    except Exception:pass


def _yahoo_forecast_history(symbol: str, years: int=3) -> tuple[pd.DataFrame,str,list[str]]:
    """Independent long-history channel for forecasts only.

    Query1/query2 and direct/environment sessions are raced in two small waves.
    This keeps the card request bounded instead of waiting through four sequential
    network timeouts.  MOEX remains the live-price authority.
    """
    enc=urllib.parse.quote(str(symbol),safe="");errors=[]
    def one(label,sess,host):
        try:
            r=sess.get(f"https://{host}/v8/finance/chart/{enc}",params={"range":f"{max(2,int(years))}y","interval":"1d","events":"div,splits"},timeout=(2.0,4.5))
            if r.status_code!=200:return None,"",f"Yahoo {label}/{host}: HTTP {r.status_code}"
            result=((r.json().get("chart") or {}).get("result") or [None])[0]
            if not result:return None,"",f"Yahoo {label}/{host}: empty"
            ts=result.get("timestamp") or [];q=(((result.get("indicators") or {}).get("quote") or [{}])[0])
            n=min([len(ts)]+[len(q.get(k) or []) for k in ("open","high","low","close")])
            if n<61:return None,"",f"Yahoo {label}/{host}: only {n} rows"
            d=_normalise_history(pd.DataFrame({"date":pd.to_datetime(ts[:n],unit="s",utc=True).tz_convert(None),"open":(q.get("open") or [])[:n],"high":(q.get("high") or [])[:n],"low":(q.get("low") or [])[:n],"close":(q.get("close") or [])[:n]}))
            if len(d)<61:return None,"",f"Yahoo {label}/{host}: <61 valid rows"
            age=(pd.Timestamp.now().normalize()-pd.Timestamp(d.iloc[-1]["date"]).normalize()).days
            if age>45:return None,"",f"Yahoo {label}/{host}: stale {age}d"
            return DATA13.yahoo_price_frame(d,result),f"Yahoo daily history · {host.split('.')[0]} · {label}",None
        except Exception as exc:return None,"",f"Yahoo {label}/{host}: {type(exc).__name__}"
    waves=[[("direct",_FORECAST_DIRECT,"query1.finance.yahoo.com"),("env",_FORECAST_ENV,"query1.finance.yahoo.com")],[("direct",_FORECAST_DIRECT,"query2.finance.yahoo.com"),("env",_FORECAST_ENV,"query2.finance.yahoo.com")]]
    for wave in waves:
        ex=ThreadPoolExecutor(max_workers=2)
        futs=[ex.submit(one,*args) for args in wave]
        try:
            for fut in as_completed(futs,timeout=6.0):
                d,src,err=fut.result()
                if err:errors.append(err)
                if d is not None and len(d)>=61:
                    ex.shutdown(wait=False,cancel_futures=True)
                    return d,src,errors
        except Exception as exc:errors.append(f"Yahoo wave: {type(exc).__name__}")
        finally:
            try:ex.shutdown(wait=False,cancel_futures=True)
            except Exception:pass
    return _normalise_history(None),"",errors


def _apimoex_forecast_history(symbol: str, market: str, board: str, years: int=3) -> tuple[pd.DataFrame,str,list[str]]:
    if apimoex is None:return _normalise_history(None),"",["apimoex not installed"]
    sec=str(symbol).upper().replace(".ME","");start=str((pd.Timestamp.now().normalize()-pd.Timedelta(days=365*years+45)).date());end=str(pd.Timestamp.now().normalize().date());errors=[]
    for label,sess in (("direct",_FORECAST_DIRECT),("env",_FORECAST_ENV)):
        try:
            rows=apimoex.get_board_history(sess,sec,start=start,end=end,columns=("TRADEDATE","CLOSE"),board=board,market=market,engine="stock")
            d=_normalise_history(pd.DataFrame(rows or []))
            if len(d)>=61:return d,f"MOEX ISS via apimoex · {board} · {label}",errors
            errors.append(f"apimoex {label}/{board}: only {len(d)} rows")
        except Exception as exc:errors.append(f"apimoex {label}/{board}: {type(exc).__name__}: {str(exc)[:90]}")
    return _normalise_history(None),"",errors


def _db_index_history(symbol: str) -> tuple[pd.DataFrame,str,list[str]]:
    try:
        import db
        con=db.connect()
        try:d=db.read_prices(con,symbol)
        finally:con.close()
        d=_normalise_history(d)
        if len(d)>=390:return d,f"local market.db · {symbol}",[]
        return d,"",[f"market.db: only {len(d)} rows"]
    except Exception as exc:return _normalise_history(None),"",[f"market.db: {type(exc).__name__}"]


def _resolve_ru_forecast_history(symbol: str, force: bool=False) -> tuple[pd.DataFrame,dict]:
    """Resolve history from independent layers, returning enough data for a real model when possible."""
    diag={"source":None,"errors":[],"candidates":[],"observations":0,"model_ready":False}
    if not force:
        cached=_load_history_cache(symbol,False)
        if len(cached)>=390:
            diag.update(source="forecast history disk cache",observations=len(cached),model_ready=True)
            return cached,diag
    is_index=symbol in C.MOEX_INDICES
    # Russian indices already have a 600-row verified local series in market.db.
    if is_index:
        d,src,errs=_db_index_history(symbol);diag["errors"]+=errs;diag["candidates"].append({"source":src or "market.db","rows":len(d)})
        if len(d)>=390:
            _save_history_cache(symbol,d,src);diag.update(source=src,observations=len(d),model_ready=True);return d,diag
    # A separate international history source first: one request, independent from MOEX routing.
    yahoo_symbol={"IMOEX":"IMOEX.ME","RTSI":"RTSI.ME","MOEXBC":"MOEXBC.ME","RGBI":"RGBI.ME"}.get(symbol,symbol)
    yd,ys,ye=_yahoo_forecast_history(yahoo_symbol,3);diag["errors"]+=ye[-4:];diag["candidates"].append({"source":ys or "Yahoo","rows":len(yd)})
    if len(yd)>=390:
        _save_history_cache(symbol,yd,ys);diag.update(source=ys,observations=len(yd),model_ready=True);return yd,diag
    market="index" if is_index else "shares";board="SNDX" if is_index else "TQBR"
    # Fast official MOEX recent window next.  If it has >=61 closes we can already
    # return a stable scenario probability instead of making the card wait for a
    # multi-page long-history download.
    rd,rdiag=MOEX419.history_recent(str(symbol).replace(".ME",""),market=market,board=board,calendar_days=145,force=force)
    rd=_normalise_history(rd);diag["errors"]+=list((rdiag or {}).get("errors") or [])[-3:];diag["candidates"].append({"source":(rdiag or {}).get("source") or "MOEX recent","rows":len(rd)})
    stale=_normalise_history(None) if force else _load_history_cache(symbol,True)
    quick=[(yd,ys or "Yahoo recent"),(rd,(rdiag or {}).get("source") or "MOEX recent"),(stale,"stale forecast history cache")]
    quick=[(x,s) for x,s in quick if x is not None and len(x)>=61]
    # A short response is a fallback, not evidence that the long model is ready.
    try:
        ld=_normalise_history(MOEX419.candles_fast(str(symbol).replace(".ME",""),market=market,board=board,calendar_days=1095,force=force))
        diag["candidates"].append({"source":"MOEX daily candles · long history","rows":len(ld)})
        if len(ld)>=390:
            src="MOEX daily candles · long history"
            _save_history_cache(symbol,ld,src);diag.update(source=src,observations=len(ld),model_ready=True)
            return ld,diag
        if len(ld)>=61:quick.append((ld,"MOEX daily candles · partial history"))
    except Exception as exc:
        diag["errors"].append("MOEX long history: "+type(exc).__name__)
    md,ms,me=_apimoex_forecast_history(symbol,market,board,3)
    diag["errors"]+=me[-4:];diag["candidates"].append({"source":ms or "apimoex","rows":len(md)})
    if len(md)>=61:quick.append((md,ms or "apimoex"))
    if quick:
        best,src=max(quick,key=lambda pair:len(pair[0]))
        _save_history_cache(symbol,best,src);diag.update(source=src,observations=len(best),model_ready=len(best)>=390)
        return best,diag
    diag["observations"]=max([len(x) for x in (yd,rd,md) if x is not None] or [0])
    return _normalise_history(None),diag

def _append_live_ru(d: pd.DataFrame, symbol: str) -> pd.DataFrame:
    # Quotes belong to the live-price UI, never to completed daily model inputs.
    return d


def _unified_shape(item: dict | None, horizon: int) -> dict:
    if not item or item.get("p_up") is None:
        return {
            "p_up": None, "p_down": None, "label": "Нет расчёта",
            "confidence": "нет данных", "agreement": 0.0,
            "status": "нет данных", "model_count": 0,
            "summary": "Недостаточно истории для корректного модельного расчёта.",
            "horizon": horizon,
        }
    p = float(item["p_up"])
    quality = item.get("quality") or {}
    score = item.get("scorecard") or {}
    trusted = bool(quality.get("trusted"))
    confidence = str(quality.get("confidence") or ("средняя" if trusted else "низкая"))
    label = "Вероятность роста" if p >= 0.5 else "Вероятность падения"
    edge = score.get("edge")
    n_eff = score.get("n_eff")
    parts = [f"Модель склоняется к {'росту' if p >= .5 else 'снижению'} на горизонте {horizon} дн."]
    if edge is not None:
        parts.append(f"OOS преимущество: {float(edge):+.1f} п.п.")
    if n_eff is not None:
        parts.append(f"Эффективная выборка: {int(n_eff)}.")
    if not trusted:
        parts.append("Сигнал исследовательский: quality gate пока не подтверждён.")
    return {
        "p_up": round(p, 4), "p_down": round(1-p, 4), "label": label,
        "confidence": confidence, "agreement": 1.0 if trusted else 0.55,
        "status": "подтверждён" if trusted else "исследовательский",
        "model_count": 1, "summary": " ".join(parts), "horizon": horizon,
        "quality": quality, "scorecard": score,
    }


def _market_stats(frame: pd.DataFrame) -> dict:
    if frame is None or frame.empty or len(frame) < 22:
        return {}
    d = frame.sort_values("date").copy()
    c = pd.to_numeric(d["close"], errors="coerce").dropna()
    if len(c) < 22:
        return {}
    last = float(c.iloc[-1])
    mom20 = (last / float(c.iloc[-21]) - 1) * 100 if float(c.iloc[-21]) else None
    ret = c.pct_change().dropna()
    vol20 = float(ret.tail(20).std() * math.sqrt(252) * 100) if len(ret) >= 20 else None
    hi52 = float(c.tail(252).max()) if len(c) else None
    lo52 = float(c.tail(252).min()) if len(c) else None
    return {
        "momentum_20d_pct": None if mom20 is None else round(mom20, 2),
        "volatility_20d_ann_pct": None if vol20 is None else round(vol20, 2),
        "high_52w": None if hi52 is None else round(hi52, 6),
        "low_52w": None if lo52 is None else round(lo52, 6),
    }



def _short_ru_history(row: dict) -> bool:
    symbol=str(row.get("symbol") or "")
    return (MU416.is_ru_equity(symbol) or symbol in C.MOEX_INDICES) and int(row.get("observations") or 0)<390


def _fast_disk_path(symbol: str, hs: tuple[int,...]) -> Path:
    safe="".join(c for c in str(symbol).upper() if c.isalnum() or c in "-_")
    return FAST_DISK_DIR/f"{safe}_{'-'.join(map(str,hs))}.json"


def _load_fast_disk(symbol: str, hs: tuple[int,...]) -> dict | None:
    p=_fast_disk_path(symbol,hs)
    try:
        if not p.exists() or time.time()-p.stat().st_mtime>FAST_TTL_SECONDS*4:return None
        j=json.loads(p.read_text(encoding="utf-8"))
        if _short_ru_history(j) and time.time()-p.stat().st_mtime>60:return None
        if j.get("history_route_version")=="4.40.10.8" and _cache_payload_valid(j,fast=True): return j
        try:p.unlink()
        except Exception:pass
        return None
    except Exception:return None


def _save_fast_disk(symbol: str, hs: tuple[int,...], row: dict):
    if os.getenv("PYTEST_CURRENT_TEST") or row.get("status")!="ok":return
    stamped=_stamp_cache_contract({**row,"history_route_version":"4.40.10.8"})
    if not _cache_payload_valid(stamped,fast=True): return
    p=_fast_disk_path(symbol,hs);tmp=p.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(stamped,ensure_ascii=False,separators=(",",":")),encoding="utf-8");tmp.replace(p)
    except Exception:pass


def _shape_walk_forward_result(r: dict | None, horizon: int) -> dict:
    if not r or r.get("live_p_up") is None:
        return _unified_shape(None,horizon)
    item={"p_up":float(r["live_p_up"]),"quality":r.get("quality") or {},"scorecard":{}}
    sc=r.get("scorecard") or {}
    item["scorecard"]={
        "n_eff":sc.get("Наблюдений (effective)"),
        "edge":sc.get("Преимущество non-overlap, п.п."),
        "brier_skill":sc.get("Brier skill non-overlap, %"),
        "ece":sc.get("Calibration error non-overlap"),
        "bootstrap_n":sc.get("Bootstrap resamples"),
    }
    return _unified_shape(item,horizon)


def _shape_meta_result(r: dict | None, horizon: int, close: pd.Series | None = None) -> dict:
    """Shape v4.40 guarded directional + calibrated distribution forecast."""
    if not r or r.get("p_up") is None:
        return _unified_shape(None,horizon)
    item={"p_up":float(r["p_up"]),"quality":r.get("quality") or {},"scorecard":r.get("scorecard") or {}}
    out=_unified_shape(item,horizon)
    out["model_version"]=r.get("version")
    out["base_model_version"]=r.get("base_model_version")
    out["integrity_version"]=r.get("integrity_version") or r.get("version")
    out["model_generation"]=r.get("model_generation")
    out["target_version"]=r.get("target_version")
    out["probability_semantics"]=r.get("probability_semantics")
    out["conditional_p_up"]=r.get("conditional_p_up")
    out["directional_score_up"]=r.get("directional_score_up", r.get("p_up"))
    out["directional_score_down"]=r.get("directional_score_down", r.get("p_down"))
    out["class_probabilities"]=r.get("class_probabilities") or {}
    if out["class_probabilities"]:
        out["label"]="Направленный перевес роста" if float(r["p_up"])>=.5 else "Направленный перевес снижения"
    out["abstain"]=bool(r.get("abstain"))
    out["signal_strength"]=r.get("signal_strength") or "нет преимущества"
    out["signal_threshold"]=r.get("signal_threshold")
    out["regime"]=r.get("regime")
    out["components"]=r.get("components") or []
    out["model_count"]=len(out["components"]) or 1
    if len(out["components"])>=2:
        vals=[float(x.get("p_up")) for x in out["components"] if x.get("p_up") is not None]
        if len(vals)>=2: out["agreement"]=round(max(0.0,min(1.0,1.0-(max(vals)-min(vals))/.30)),3)
    out["p_neutral"]=r.get("p_neutral") if r.get("p_neutral") is not None else (r.get("scorecard") or {}).get("p_neutral")
    out["validation"]=r.get("validation") or {}
    out["final_evaluation"]=r.get("final_evaluation") or {}
    out["temporal_validation"]=r.get("temporal_validation") or {}
    out["feature_version"]=r.get("feature_version")
    out["extension_policy"]=r.get("extension_policy")
    out["context_score"]=r.get("context_score")
    out["context_p_up"]=r.get("context_p_up")
    out["context_adjustment_pp"]=r.get("context_adjustment_pp")
    out["context_disagreement"]=bool(r.get("context_disagreement"))
    out["context_features"]=r.get("context_features") or {}
    out["event_context"]=r.get("event_context") or {}
    out["event_risk"]=r.get("event_risk")
    out["event_bias"]=r.get("event_bias")
    out["feature_drift"]=r.get("feature_drift") or {}
    out["dynamic_weights"]=r.get("dynamic_weights") or {}
    out["meta_learning"]=r.get("meta_learning") or {}
    out["reliability"]=r.get("reliability") or {}
    reliability_validated = (out["reliability"].get("trained") is True
                             and out["reliability"].get("validated_on_untouched_eval") is True)
    out["confidence_score"] = None
    out["confidence_status"] = "validated" if reliability_validated else "unconfirmed"
    if reliability_validated and out["reliability"].get("probability") is not None:
        out["confidence_score"]=round(float(out["reliability"]["probability"]),4)
    out["threshold_selection"]=r.get("threshold_selection") or {}
    out["context_weight_status"]=r.get("context_weight_status")
    out["prospective_selection_guard"]=r.get("prospective_selection_guard") or {}
    out["guard_version"]=r.get("guard_version")
    out["reliability_version"]=r.get("reliability_version")
    out["asset_specialist"]=r.get("asset_specialist") or {}
    out["specialist_gate"]=r.get("specialist_gate") or {}
    out["specialist_weight_status"]=r.get("specialist_weight_status")
    out["specialist_version"]=r.get("specialist_version")
    out["event_response"]=r.get("event_response") or {}
    out["event_gate"]=r.get("event_gate") or {}
    out["event_weight_status"]=r.get("event_weight_status")
    out["event_response_version"]=r.get("event_response_version")
    out["distribution_forecast"]=r.get("distribution_forecast") or {}
    out["distribution_version"]=r.get("distribution_version")
    out["ensemble_explanation"]=r.get("ensemble_explanation") or {}
    out["freshness_guard"]=r.get("freshness_guard") or {}
    out["soft_regime"]=r.get("soft_regime") or {}
    out["consistency_gate"]=r.get("consistency_gate") or {}
    out["robustness"]=r.get("robustness") or {}
    prob=max(float(r["p_up"]),1-float(r["p_up"]))
    side="роста" if float(r["p_up"])>=.5 else "снижения"
    classes=out.get("class_probabilities") or {}
    cup=classes.get("up"); cneutral=classes.get("neutral"); cdown=classes.get("down")
    class_text=(f"Классы: значимый рост {float(cup)*100:.0f}%, нейтрально {float(cneutral)*100:.0f}%, "
                f"значимое снижение {float(cdown)*100:.0f}%. ") if all(v is not None for v in (cup,cneutral,cdown)) else ""
    cond=r.get("conditional_p_up")
    cond_text=(f"При значимом движении условная вероятность роста {float(cond)*100:.0f}%. ") if cond is not None else ""
    if out["abstain"]:
        out["status"]="нет преимущества"
        out["confidence"]="низкая"
        if all(v is not None for v in (cup,cneutral,cdown)):
            out["summary"]=(f"На горизонте {horizon} дн. модель оценивает значимый рост в {float(cup)*100:.0f}%, "
                            f"нейтральное движение в {float(cneutral)*100:.0f}% и значимое снижение в {float(cdown)*100:.0f}%. "
                            "Перевес недостаточно устойчив, поэтому направленный сигнал не публикуется.")
        else:
            out["summary"]="Модель не видит достаточно устойчивого преимущества роста или снижения и воздерживается от направленного сигнала."
    else:
        direction_word="роста" if side=="роста" else "снижения"
        if all(v is not None for v in (cup,cneutral,cdown)) and cond is not None:
            out["summary"]=(f"На горизонте {horizon} дн.: значимый рост {float(cup)*100:.0f}%, "
                            f"нейтральное движение {float(cneutral)*100:.0f}%, значимое снижение {float(cdown)*100:.0f}%. "
                            f"Если движение окажется значимым, модель отдаёт {max(float(cond),1-float(cond))*100:.0f}% в пользу {direction_word}.")
        else:
            out["summary"]=(f"На горизонте {horizon} дн. модель видит преимущество {direction_word}, "
                            f"но вероятность пока рассматривается как исследовательская оценка.")
    if close is not None and len(close):
        try:
            out["movement_guidance"]=MOVEGUIDE440102.build(close,horizon,out)
        except Exception as exc:
            out["movement_guidance"]={"version":MOVEGUIDE440102.VERSION,"range_status":"unavailable","reason":f"movement guidance unavailable: {type(exc).__name__}"}
    return QUALITY.forecast(out)


def _scenario_shape(close: pd.Series, horizon: int) -> dict:
    _,s=models.scenario_paths(close,horizon=horizon,n_sims=900,seed=42+horizon,block_size=min(5,horizon))
    if not s or s.get("p_up") is None:return _unified_shape(None,horizon)
    p=float(s["p_up"])
    return {"p_up":round(p,4),"p_down":round(1-p,4),
            "label":"Вероятность роста" if p>=.5 else "Вероятность падения",
            "confidence":"низкая","agreement":0.45,"status":"сценарная оценка","model_count":1,
            "summary":f"Быстрая сценарная оценка на {horizon} дн. по последней доступной истории; оценка надёжности недоступна, поскольку основной модельный расчёт не получен.",
            "horizon":horizon,"quality":{"trusted":False,"confidence":"низкая","bias":"neutral","label":"сценарная оценка"},
            "scorecard":{"method":"historical_block_bootstrap_fast_fallback"}}


_INPUT_CACHE={}
_INPUT_LOCKS={}

def _model_history(symbol, force=False):
    # Cache the provider snapshot, not a forecast keyed only by ticker. Every
    # calculation still checks bar completion and hashes the actual input below.
    with _LOCK:
        lock=_INPUT_LOCKS.setdefault(str(symbol),Lock())
    with lock:
        saved=_INPUT_CACHE.get(str(symbol))
        if saved and not force and time.time()-saved[0]<180:
            return saved[1].copy(),copy.deepcopy(saved[2])
        if MU416.is_ru_equity(symbol) or symbol in C.MOEX_INDICES:
            d,diag=_resolve_ru_forecast_history(symbol,force=force)
        elif MU416.is_us_equity(symbol):
            d,source,errors=_yahoo_forecast_history(symbol,3);diag={'source':source,'errors':errors}
        else:
            rr=MD41.fetch_history(symbol,long_history=True);d=rr.frame;diag={'source':rr.source,'errors':list(rr.errors or [])}
        _INPUT_CACHE[str(symbol)]=(time.time(),d.copy(),copy.deepcopy(diag))
        return d,diag


def _forecast_fast_core(symbol: str, horizons=(10,), force: bool=False) -> dict:
    """Responsive forecast for market cards.

    v4.23 decouples live prices from forecast history completely. Russian market
    cards use the documented MOEX daily board-history endpoint (TRADEDATE/CLOSE)
    because the model only needs closes. One compact request normally yields enough
    observations for the fast block-bootstrap direction estimate; board-history
    automatically falls back to market-history if a security changed boards.
    """
    hs=tuple(sorted({int(h) for h in horizons if int(h) in (1,3,5,10,20,30,60)})) or (10,)
    d,diagnostics=_model_history(symbol,force)
    sources=[diagnostics.get('source','')];errors=list(diagnostics.get('errors') or [])
    d, data_audit=DATA13.prepare(d,symbol,' · '.join(x for x in sources if x))
    data_audit=DATA13.persist_input(d,data_audit,symbol)
    data_audit['dependency_hash']=DATA13.dependency_fingerprint()
    key=(str(symbol),hs,DATA13.calculation_key(data_audit,hs,'fast',CONTRACT4406.MODEL_GENERATION))
    now=time.time()
    # Prefer a completed full result only when its entire input contract matches.
    with _LOCK:
        for stamp,candidate in _CACHE.values():
            old=candidate.get('data_integrity') or {}
            if not force and now-stamp<180 and old.get('data_hash')==data_audit.get('data_hash') and old.get('dependency_hash')==data_audit.get('dependency_hash') and all(str(h) in candidate.get('forecasts',{}) for h in hs):
                return copy.deepcopy(candidate)
        cached=_FAST_CACHE.get(key)
        if cached and not force and now-cached[0]<180:return copy.deepcopy(cached[1])
    if d is None or d.empty:
        out={"symbol":symbol,"status":"unavailable","source":" · ".join(x for x in sources if x),"errors":errors[-6:]+["history unavailable"],"forecasts":{},"stats":None,
             "diagnostics":{"stage":"history","observations":0,**(diagnostics or {})}}
    else:
        d=d.sort_values("date").dropna(subset=["close"]).drop_duplicates("date",keep="last")
        close=pd.Series(d["close"].astype(float).values,index=pd.to_datetime(d["date"]))
        _MACRO_HISTORY[str(symbol)]=close.copy()
        _MODEL_HISTORY[data_audit["data_hash"]]=close.copy()
        shaped={}
        model_name="AllAnalytics v4.40.10.16 Quality Contract"
        # v4.34: the primary card signal is the real AllAnalytics walk-forward model.
        # The block-bootstrap probability is only a documented last-resort fallback
        # when every long-history provider is unavailable.
        if len(close)>=390:
            for h in hs:
                try:
                    r=META435.forecast_horizon(close,symbol=symbol,horizon=h,fast=True)
                    shaped[str(h)]=_shape_meta_result(r,h,close)
                except Exception as exc:
                    errors.append(f"fast model {h}d: {type(exc).__name__}: {str(exc)[:80]}")
                    shaped[str(h)]=_unified_shape(None,h)
            model_name="AllAnalytics Fast WF · v4.40.10.16 Quality Contract"
        if not any(v.get("p_up") is not None for v in shaped.values()) and len(close)>=61:
            shaped={str(h):_scenario_shape(close,h) for h in hs}
            for h in hs:
                try: shaped[str(h)]["movement_guidance"]=MOVEGUIDE440102.build(close,h,shaped[str(h)])
                except Exception: pass
            model_name="AllAnalytics scenario fallback · recent history"
        has_prob=any(v.get("p_up") is not None for v in shaped.values())
        hist=[{"t":str(pd.Timestamp(r.date).date()),"o":round(float(r.open),6),"h":round(float(r.high),6),"l":round(float(r.low),6),"c":round(float(r.close),6)} for r in d.tail(190).itertuples()]
        out={"symbol":symbol,"status":"ok" if has_prob else "unavailable","source":" · ".join(x for x in sources if x),
             "as_of":str(pd.Timestamp(d.iloc[-1]["date"]).date()),"observations":int(len(d)),"forecasts":shaped,
             "stats":_market_stats(d),"history":hist,"errors":errors[-8:],"model":model_name,"profile":"fast-ui-v435","specialist_profile":"v4.40.10",
             "diagnostics":{"stage":"model" if has_prob else "model-no-probability","observations":int(len(d)),**(diagnostics or {})}}
        if has_prob:_save_fast_disk(symbol,hs,out)
    out['data_integrity']=data_audit
    out['forecasts']={h:DATA13.decorate(v,data_audit,symbol,h,'fast') for h,v in out.get('forecasts',{}).items()}
    with _LOCK:_FAST_CACHE[key]=(now,out)
    return out


def _forecast_core(symbol: str, horizons=(1,3,5,10,20,30,60), force: bool=False) -> dict:
    hs=tuple(sorted({int(h) for h in horizons if int(h) in (1,3,5,10,20,30,60)})) or (10,)
    d,diagnostics=_model_history(symbol,force)
    sources=[diagnostics.get('source','')];errors=list(diagnostics.get('errors') or [])
    d, data_audit=DATA13.prepare(d,symbol,' · '.join(x for x in sources if x))
    data_audit=DATA13.persist_input(d,data_audit,symbol)
    data_audit['dependency_hash']=DATA13.dependency_fingerprint()
    key=(str(symbol),hs,DATA13.calculation_key(data_audit,hs,'full',CONTRACT4406.MODEL_GENERATION))
    now=time.time()
    with _LOCK:
        cached=_CACHE.get(key)
        if cached and not force and now-cached[0]<180:return copy.deepcopy(cached[1])
    if d is None or d.empty or len(d)<220:
        out={"symbol":symbol,"status":"unavailable","source":" · ".join(x for x in sources if x),"errors":errors[-8:]+(["insufficient history"] if d is None or len(d)<220 else []),"forecasts":{},"stats":{}}
    else:
        d=d.sort_values("date").dropna(subset=["close"]).drop_duplicates("date",keep="last")
        close=pd.Series(d["close"].astype(float).values,index=pd.to_datetime(d["date"]))
        _MACRO_HISTORY[str(symbol)]=close.copy()
        _MODEL_HISTORY[data_audit["data_hash"]]=close.copy()
        shaped={}
        for h in hs:
            try:
                shaped[str(h)]=_shape_meta_result(META435.forecast_horizon(close,symbol=symbol,horizon=h,fast=False),h,close)
            except Exception as exc:
                errors.append(f"meta model {h}d: {type(exc).__name__}: {str(exc)[:100]}")
                shaped[str(h)]=_unified_shape(None,h)
        # A valid history may still fail the stricter full model for one horizon.
        # Keep the result stable instead of causing the UI to requeue forever.
        if not any(v.get("p_up") is not None for v in shaped.values()):
            out={"symbol":symbol,"status":"unavailable","source":" · ".join(x for x in sources if x),"as_of":str(pd.Timestamp(d.iloc[-1]["date"]).date()),"errors":errors[-8:]+["model quality/history window produced no live probability"],"forecasts":shaped,"stats":_market_stats(d)}
        else:
            hist=[]
            for r in d.tail(190).itertuples():hist.append({"t":str(pd.Timestamp(r.date).date()),"o":round(float(r.open),6),"h":round(float(r.high),6),"l":round(float(r.low),6),"c":round(float(r.close),6)})
            out={"symbol":symbol,"status":"ok","source":" · ".join(x for x in sources if x),"as_of":str(pd.Timestamp(d.iloc[-1]["date"]).date()),"observations":int(len(d)),"forecasts":shaped,"stats":_market_stats(d),"history":hist,"errors":errors[-8:],"model":"AllAnalytics v4.40.6 Move/No-Move / evidence-consistent guard"}
            _save_disk(symbol,hs,out)
    out['data_integrity']=data_audit
    out['forecasts']={h:DATA13.decorate(v,data_audit,symbol,h,'full') for h,v in out.get('forecasts',{}).items()}
    with _LOCK:_CACHE[key]=(now,out)
    return out


def _with_macro_events(payload, symbol):
    out=copy.deepcopy(payload);hist=payload.get("history") or []
    # Prefer the same long daily series used by the forecast; it is retained only
    # in process, not sent in the API response.
    close=_MODEL_HISTORY.get((payload.get("data_integrity") or {}).get("data_hash"))
    if close is None:
        close=pd.Series([r["c"] for r in hist],index=pd.to_datetime([r["t"] for r in hist]),dtype=float)
    out["forecasts"]={str(h):QUALITY.forecast(MACRO109.apply(copy.deepcopy(f),close,symbol,h)) for h,f in (payload.get("forecasts") or {}).items()}
    for h,f in out['forecasts'].items():
        if f.get('calculation_identity'):
            f['calculation_identity']['key']=DATA13.calculation_key(f.get('data_integrity') or {},h,f['calculation_identity']['mode'],f.get('model_generation'),f.get('macro_events'))
    return out

_MACRO_HISTORY={}
_MODEL_HISTORY={}
def forecast_fast(symbol: str, horizons=(10,), force: bool=False):
    return _with_macro_events(_forecast_fast_core(symbol,horizons,force),symbol)

def forecast(symbol: str, horizons=(1,3,5,10,20,30,60), force: bool=False):
    return _with_macro_events(_forecast_core(symbol,horizons,force),symbol)
