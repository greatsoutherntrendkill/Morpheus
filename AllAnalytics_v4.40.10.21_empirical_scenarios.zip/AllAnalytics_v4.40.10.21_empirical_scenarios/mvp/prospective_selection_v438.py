"""AllAnalytics v4.38 — specialist prospective gate.

Extends the v4.37 governance contract to the new asset-class specialist.  The
specialist is visible and logged immediately, but its live blend weight remains
zero until paired prospective evidence passes the existing statistical guard
and a person explicitly approves that exact candidate/scope.
"""
from __future__ import annotations

import time

import prospective_selection_v437 as BASE437

VERSION = "asset-specialist-selection-guard-v4.40.8"
VALIDATION_VERSION = "paired-prospective-specialist-data-routing-v4.40.8"
_CACHE = {}


def specialist_report(*, window_days=180, symbol=None, horizon=None, ledger=None):
    report = BASE437.candidate_report(
        "asset_specialist", "core_meta", window_days=window_days,
        symbol=symbol, horizon=horizon, ledger=ledger, current_v437_only=False,
    )
    return {**report, "version": VERSION, "validation_version": VALIDATION_VERSION,
            "candidate": "asset_specialist", "baseline": "core_meta",
            "automatic_promotion": False,
            "policy_note": "specialist may influence production only after prospective eligibility and explicit human approval"}


def specialist_gate(symbol: str, horizon: int, *, window_days: int=180, max_live_weight: float=.15, ledger=None, cache_seconds: int=300):
    key=(str(symbol).upper(), int(horizon), int(window_days), round(float(max_live_weight),4))
    now=time.time(); cached=_CACHE.get(key)
    if ledger is None and cached and now-cached[0] < max(15,int(cache_seconds)):
        return cached[1]
    report=specialist_report(window_days=window_days,symbol=key[0],horizon=key[1],ledger=ledger)
    review=BASE437.REVIEW.latest("asset_specialist",symbol=key[0],horizon=key[1])
    approved=BASE437._review_approves_current_generation(review)
    active=bool(approved and report.get("eligible_for_human_review"))
    # v4.40.8: after approval the satellite weight is learned from paired
    # prospective evidence and must improve recent validation Brier.  The caller's
    # max_live_weight remains only a governance ceiling.
    route=BASE437.learned_blend_weight("asset_specialist","core_meta",cap=min(max(0.0,float(max_live_weight)),.24),window_days=window_days,symbol=key[0],horizon=key[1],ledger=ledger)
    weight=float(route.get("weight") or 0.0) if active else 0.0
    active=bool(active and weight>0)
    result={
        "version":VERSION,"validation_version":VALIDATION_VERSION,"symbol":key[0],"horizon":key[1],
        "eligible":bool(report.get("eligible_for_human_review")),"human_approved":approved,"active":active,
        "weight":round(weight,4),"max_live_weight":round(float(max_live_weight),4),"data_driven_weight":route,"report_hash":report.get("report_hash"),
        "reason":"prospective specialist edge confirmed + human approval" if active else ("awaiting explicit human approval" if report.get("eligible_for_human_review") else report.get("reason")),
        "review":review,"report":report,"automatic_promotion":False,
    }
    if ledger is None:_CACHE[key]=(now,result)
    return result


def selection_report(*,window_days=180,symbol=None,horizon=None,ledger=None):
    base=BASE437.selection_report(window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger)
    sp=specialist_report(window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger)
    sp["review"]=BASE437.REVIEW.latest("asset_specialist",symbol=symbol,horizon=horizon)
    return {**base,"version":VERSION,"validation_version":VALIDATION_VERSION,
            "candidates":list(base.get("candidates") or [])+[sp],
            "specialist_policy":"asset-class specialist is challenger-only until prospective guard + explicit approval",
            "automatic_champion_promotion":False,"review_required":True}


def review(candidate: str,decision: str,note: str="",*,window_days=180,symbol=None,horizon=None,ledger=None):
    if candidate != "asset_specialist":
        return BASE437.review(candidate,decision,note,window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger)
    report=specialist_report(window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger)
    out=BASE437.REVIEW.add("asset_specialist","core_meta",decision,note,report,symbol=symbol,horizon=horizon,window_days=window_days)
    return {"version":VERSION,"review":out,"report":report,"automatic_promotion":False}


def review_status(limit=50):
    base=BASE437.review_status(limit=limit)
    return {**base,"version":VERSION}
