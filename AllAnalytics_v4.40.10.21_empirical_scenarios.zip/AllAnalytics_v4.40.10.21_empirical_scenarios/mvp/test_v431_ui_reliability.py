from pathlib import Path
import re

ROOT=Path(__file__).parent
HTML=(ROOT/'site'/'index.html').read_text(encoding='utf-8')

def test_external_scripts_are_well_formed():
    assert '<script src="corpfin_data.js?v=4.14"></script>' in HTML
    assert '<script src="data.js?v=4.14"></script>' in HTML
    assert HTML.count('<script') == HTML.count('</script>')

def test_market_detail_history_is_live_loaded():
    assert 'function loadMarketDetailHistoryV431' in HTML
    assert '/api/chart/history?symbol=' in HTML
    assert 'window.__aaMarketHistoryV431' in HTML

def test_current_price_has_immediate_history_fallback():
    assert 'function aaV431LastPrice' in HTML
    assert "const hist=a.chart_history||a.history||[]" in HTML
    assert "valueEl.textContent='—'" in HTML
    assert 'renderOverviewLivePriceV431(a)' in HTML

def test_market_plain_language_has_asset_news():
    assert 'function marketAssetNewsV431' in HTML
    assert 'Новости по активу' in HTML
    assert 'marketNewsBlockV431(a)' in HTML

def test_altdata_has_last_good_and_transparent_proxy():
    assert 'aa-alt-last-good-v431' in HTML
    assert 'deriveAltFallbackV431' in HTML
    assert 'Open Interest, funding и ликвидации не выдумываются' in HTML

def test_pulse_thresholds_and_explorer():
    assert "prob>70?'strong':prob>=55?'moderate':'weak'" in HTML
    assert 'Выраженные прогнозы &gt;70%' in HTML
    assert 'pulse-drawer-v431' in HTML
    assert "onclick=\"selectMarket('" in HTML
