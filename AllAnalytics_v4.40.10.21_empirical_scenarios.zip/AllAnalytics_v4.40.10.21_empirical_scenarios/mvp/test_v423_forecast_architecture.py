import json
from pathlib import Path
import numpy as np
import pandas as pd

import equity_forecast_v416 as E
import moex_fast_v419 as M
import market_universe_v416 as U


def _frame(n=92):
    rng=np.random.default_rng(423)
    dates=pd.bdate_range(end=pd.Timestamp.today().normalize(),periods=n)
    close=100*np.exp(np.cumsum(rng.normal(.0003,.012,n)))
    return pd.DataFrame({'date':dates,'open':close,'high':close,'low':close,'close':close})


def test_history_recent_parses_documented_board_history(monkeypatch,tmp_path):
    dates=pd.bdate_range('2026-04-20', periods=82)
    block={'columns':['TRADEDATE','CLOSE'],'data':[[str(d.date()),100+i*.1] for i,d in enumerate(dates)]}
    def fake(path,params):
        assert '/iss/history/engines/stock/markets/shares/boards/TQBR/securities/SBER.json' in path
        assert params['history.columns']=='TRADEDATE,CLOSE'
        return {'history':block},'mock-direct'
    monkeypatch.setattr(M,'_request_json',fake)
    monkeypatch.setattr(M,'FAST_HISTORY_DIR',tmp_path)
    d,diag=M.history_recent('SBER',force=True)
    assert len(d)==82
    assert float(d.iloc[-1].close)>100
    assert diag['source']=='MOEX ISS board history'


def test_every_ru_equity_can_reach_probability_from_same_history_contract(monkeypatch):
    d=_frame(90)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(pd.DataFrame(),'', ['mock yahoo disabled']))
    monkeypatch.setattr(E.MOEX419,'history_recent',lambda *a,**k:(d.copy(),{'source':'mock board history','errors':[],'observations':len(d)}))
    monkeypatch.setattr(E,'_append_live_ru',lambda frame,symbol:frame)
    for sym,_ in U.RU_EQUITIES:
        row=E.forecast_fast(sym,(10,),force=True)
        assert row['status']=='ok', sym
        assert row['forecasts']['10']['p_up'] is not None, sym
        assert row['observations']>=61


def test_no_test_generated_forecast_cache_is_required(monkeypatch,tmp_path):
    d=_frame(88)
    monkeypatch.setattr(E,'FAST_DISK_DIR',tmp_path)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(pd.DataFrame(),'', ['mock yahoo disabled']))
    monkeypatch.setattr(E.MOEX419,'history_recent',lambda *a,**k:(d.copy(),{'source':'mock','errors':[],'observations':len(d)}))
    monkeypatch.setattr(E,'_append_live_ru',lambda frame,symbol:frame)
    row=E.forecast_fast('SBER.ME',(10,),force=True)
    assert row['status']=='ok'
    # pytest runs with PYTEST_CURRENT_TEST; production cache must not be polluted.
    assert not list(tmp_path.glob('*.json'))


def test_scenario_requires_61_closes_not_60():
    d=_frame(60)
    shaped=E._scenario_shape(pd.Series(d.close.values,index=d.date),10)
    assert shaped['p_up'] is None
    d2=_frame(61)
    shaped2=E._scenario_shape(pd.Series(d2.close.values,index=d2.date),10)
    assert shaped2['p_up'] is not None
