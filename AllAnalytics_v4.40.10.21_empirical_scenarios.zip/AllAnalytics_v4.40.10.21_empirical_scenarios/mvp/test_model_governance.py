import sqlite3, tempfile
from pathlib import Path
import model_registry as MR
p=Path(tempfile.mkstemp(suffix='.db')[1]); c=sqlite3.connect(p)
MR.register_champion(c)
pid=MR.append_prediction(c,'TEST',10,'2026-09-01',.61,{'trusted':True},{'mode':'pit'},{})
assert MR.append_prediction(c,'TEST',10,'2026-09-01',.61,{}, {}, {}) == pid
assert c.execute('select count(*) from prediction_ledger').fetchone()[0] == 1
try:
 c.execute('update prediction_ledger set p_up=.9 where prediction_id=?',(pid,)); c.commit(); raise AssertionError('mutable ledger')
except sqlite3.DatabaseError: c.rollback()
MR.register_challenger(c,'candidate-test','tree','features-pit-v3.1.0',{})
ok, _=MR.promotion_decision({'holdout_edge_ci_low':1,'holdout_brier_skill_ci_low':1,'net_sharpe':1,'effective_n':31},{'net_sharpe':.2})
assert ok
print('OK: immutable registry/ledger + challenger promotion gate')
c.close(); p.unlink(missing_ok=True)
