# AllAnalytics v4.40.5 — Evidence Consistency & Cache Integrity

## Shared target contract
- Added `target_contract_v4405.py` as the only production definition of a significant UP / NEUTRAL / DOWN move.
- Training and prospective settlement now use the same volatility window, sigma multiplier, floor/cap and forecast-date information set.

## Prospective evidence
- Forecast snapshots store model generation, target version, three class probabilities, conditional direction probability and move probability.
- Settlement stores multiclass Brier/log-loss, Move/No-Move Brier and conditional-direction Brier/log-loss.
- Neutral outcomes are never scored as DOWN and are excluded from conditional-direction accuracy.
- Promotion guard uses only evidence from the exact current model generation and target version.
- Historical generations remain in the immutable ledger for audit.

## Cache integrity
- Forecast cache payloads now include a cache contract, target version and model generation.
- Cache validity checks the forecast `as_of` date in addition to file mtime.
- Scenario/legacy payloads without the current generation are not persisted as reusable ML forecasts.
- Release packages no longer ship precomputed forecast-cache JSON files.

## Governance
- Legacy v3.2 binary model track record remains accessible for history but is explicitly labelled legacy rather than current-model evidence.
