# AllAnalytics v4.22 — Forecast-only reliability fix

Scope is intentionally limited to Russian market forecasts. Live quotes, M&A/IPO, news, layout, datasets and other market-data routes are unchanged.

- Russian stock/index card forecasts no longer wait for ~2 years of paginated MOEX history.
- Added a single-request recent MOEX candle window for the fast card probability.
- Fast RU forecast uses the existing AllAnalytics historical block-bootstrap direction engine.
- Full walk-forward/audit modelling remains available separately and no longer blocks the card result.
- If the local Python history request fails, the frontend automatically falls back to two parallel MOEX JSONP history chunks and sends them to the local AllAnalytics model endpoint.
- Browser fallback threshold lowered to 60 valid sessions, matching the existing scenario model requirement.
- Forecast requests are isolated from live quote state; no quote/source changes in this release.
