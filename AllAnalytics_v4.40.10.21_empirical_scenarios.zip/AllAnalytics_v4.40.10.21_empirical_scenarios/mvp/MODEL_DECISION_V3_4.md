# AllAnalytics v3.4 — Final Model Decision

## Decision: KEEP Logistic Regression as production champion

- Selected version: `logreg-v3.2.0`
- Full-universe assets tested: 33
- Asset/horizon benchmark rows: 132
- Horizons: 1, 5, 10, 20 trading days
- Final holdout used for tuning: **No**
- Multiple-testing correction: **Holm-Bonferroni**
- Promotion is never automatic: **Yes**

## Aggregate holdout diagnostics

| Model | Median Brier | Median ECE | Platt Brier | Platt ECE | Median 1D net Sharpe |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | 0.2797 | 0.2825 | 0.2579 | 0.1492 | 0.3851 |
| LightGBM | 0.2811 | 0.2859 | 0.2594 | 0.1440 | 0.1535 |
| CatBoost | 0.2576 | 0.2141 | 0.2583 | 0.1415 | 0.6155 |

## Why

- No challenger passed the predeclared full-universe promotion-review gate.
- lightgbm: 0 Holm-significant Brier wins, 0 significant losses, median Brier improvement=0.004335, median 1D net-Sharpe delta=0.10809999999999986.
- catboost: 0 Holm-significant Brier wins, 0 significant losses, median Brier improvement=0.020141, median 1D net-Sharpe delta=-0.021199999999999886.

## Governance consequence

The nonlinear models remain **shadow challengers**. Their live predictions continue to be
logged immutably, but public/production model output remains on the Logistic Regression champion.
A future promotion requires a new locked model version and new evidence; this v3.4 holdout is not
to be recycled as a tuning set.
