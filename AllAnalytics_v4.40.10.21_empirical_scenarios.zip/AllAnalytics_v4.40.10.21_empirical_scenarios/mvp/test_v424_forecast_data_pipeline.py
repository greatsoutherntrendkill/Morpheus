import numpy as np
import pandas as pd
import equity_forecast_v416 as E


def frame(n=760):
    rng=np.random.default_rng(424)
    dates=pd.bdate_range(end=pd.Timestamp('2026-09-09'),periods=n)
    close=100*np.exp(np.cumsum(rng.normal(.00025,.011,n)))
    return pd.DataFrame({'date':dates,'open':close,'high':close*1.004,'low':close*.996,'close':close})


def test_ru_fast_forecast_uses_independent_long_history(monkeypatch,tmp_path):
    d=frame(760)
    monkeypatch.setattr(E,'RU_HISTORY_DIR',tmp_path)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(d.copy(),'Yahoo mock',[]))
    monkeypatch.setattr(E.MOEX419,'history_recent',lambda *a,**k:(pd.DataFrame(),{'errors':['should not be needed']}))
    monkeypatch.setattr(E,'_append_live_ru',lambda x,s:x)
    row=E.forecast_fast('SBER.ME',(10,),force=True)
    assert row['status']=='ok'
    assert row['forecasts']['10']['p_up'] is not None
    assert row['model'].startswith('AllAnalytics Fast WF')
    assert row['observations']>=390


def test_ru_recent_history_still_returns_probability(monkeypatch,tmp_path):
    d=frame(95)
    monkeypatch.setattr(E,'RU_HISTORY_DIR',tmp_path)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(pd.DataFrame(),'', ['yahoo down']))
    monkeypatch.setattr(E.MOEX419,'history_recent',lambda *a,**k:(d.copy(),{'source':'MOEX recent mock','errors':[]}))
    monkeypatch.setattr(E,'_append_live_ru',lambda x,s:x)
    row=E.forecast_fast('GAZP.ME',(10,),force=True)
    assert row['status']=='ok'
    assert row['forecasts']['10']['p_up'] is not None
    assert 'scenario fallback' in row['model']


def test_index_can_use_local_history(monkeypatch,tmp_path):
    d=frame(600)
    monkeypatch.setattr(E,'RU_HISTORY_DIR',tmp_path)
    monkeypatch.setattr(E,'_db_index_history',lambda s:(d.copy(),'market.db mock',[]))
    monkeypatch.setattr(E,'_append_live_ru',lambda x,s:x)
    row=E.forecast_fast('IMOEX',(10,),force=True)
    assert row['status']=='ok'
    assert row['forecasts']['10']['p_up'] is not None
    assert row['model'].startswith('AllAnalytics Fast WF')
