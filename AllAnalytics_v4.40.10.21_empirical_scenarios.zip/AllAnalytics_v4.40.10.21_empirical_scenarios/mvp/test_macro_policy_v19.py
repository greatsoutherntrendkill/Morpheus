import numpy as np
import pandas as pd
import pytest
import macro_policy_data_v19 as D
import macro_policy_model_v19 as M
import macro_policy_service_v19 as S

def raw():
 return [dict(series='UNRATE',period='2020-01-01',available='2020-02-08T00:00:00+00:00',value=4.,source='test'),dict(series='UNRATE',period='2020-01-01',available='2020-03-08T00:00:00+00:00',value=9.,source='test')]

def test_release_time_and_revision():
 d=M.frame(raw());assert M.transformed(d,'UNRATE','2020-02-08T00:00Z').empty
 assert M.transformed(d,'UNRATE','2020-02-09T00:00Z').iloc[-1]==4
 assert M.transformed(d,'UNRATE','2020-04-01T00:00Z').iloc[-1]==9
 assert M.first_targets(d,'UNRATE')['2020-01'][0]==4

def test_append_only_import(tmp_path):
 c=D.connect(tmp_path/'test.db');D.ingest(c,'UNRATE',[dict(date='2020-01-01',realtime_start='2020-02-07',value='4')])
 with pytest.raises(ValueError):D.ingest(c,'UNRATE',[dict(date='2020-01-01',realtime_start='2020-02-07',value='9')])
 assert c.execute('SELECT value FROM observations').fetchone()[0]==4
 assert c.execute('SELECT available FROM observations').fetchone()[0].startswith('2020-02-08')

def test_missing_month_not_compressed():
 r=[dict(series='CPIAUCSL',period=str(p.date()),available=str((p+pd.Timedelta(days=40)).date())+'T00:00:00+00:00',value=100+i,source='test') for i,p in enumerate(pd.date_range('2020-01-01',periods=14,freq='MS')) if i!=1]
 z=M.transformed(M.frame(r),'CPIAUCSL','2022-01-01T00:00Z');assert pd.isna(z.loc['2021-02'])

def test_rate_end_not_average():
 r=[dict(series='DFEDTARU',period=p,available=a,value=v,source='test') for p,a,v in [('2020-01-02','2020-01-03T00:00:00Z',2),('2020-01-31','2020-02-01T00:00:00Z',1)]]
 assert M.first_targets(M.frame(r),'DFEDTARU')['2020-01'][0]==1

def test_missing_history_no_prediction():
 d=M.frame(raw());e=M.evaluate(d,'UNRATE',1,'2021-01-01T00:00Z');assert e['status']=='insufficient_history';assert M.forecast(d,'UNRATE',1,'2021-01-01T00:00Z',e)['status']=='unavailable'

def test_forecast_ledger_no_overwrite(tmp_path):
 c=D.connect(tmp_path/'test.db');f=dict(status='ok',series='UNRATE',period='2026-10',horizon=1,model='ridge',snapshot='a',version='test',issued='2026-09-21T10:00:00Z',value=4,lower=3,upper=5,baseline=4)
 i=S.record(c,f);f['value']=9;assert S.record(c,f)==i;assert c.execute('SELECT value FROM forecasts').fetchone()[0]==4

def test_model_learns_without_manual_direction():
 train=[dict(x=np.array([float(i)]),y=float(i)*2,baseline=0) for i in range(80)]
 assert abs(M.predict('ridge',train,dict(x=np.array([30.]),baseline=0))-60)<5

def test_quantile_small_sample():
 assert M.quantile([1,2]) is None;assert M.quantile([1]*20)==1

def test_future_values_do_not_change_past_features():
 x,b,n=M.features(M.frame(raw()),'UNRATE','2020-02-09T00:00Z');future=raw()+[dict(series='UNRATE',period='2030-01-01',available='2030-02-01T00:00Z',value=1000,source='test')];xx,bb,nn=M.features(M.frame(future),'UNRATE','2020-02-09T00:00Z');np.testing.assert_equal(x,xx);assert b==bb

def test_quantile_exact_order_statistic():
 assert M.quantile(list(range(1,21)))==17

def test_incomplete_rate_month_is_not_a_fact():
 d=M.frame([dict(series='DFEDTARL',period='2020-01-28',available='2020-01-29T00:00Z',value=2,source='test')]);assert not M.first_targets(d,'DFEDTARL')

def test_old_history_is_not_current():
 assert not M.freshness(M.frame(raw()),'UNRATE','2026-01-01T00:00Z')['ok']

def test_withdrawal_not_forward_filled():
 r=raw()+[dict(series='UNRATE',period='2020-01-01',available='2020-04-01T00:00Z',value=None,source='test')]
 assert pd.isna(M.transformed(M.frame(r),'UNRATE','2020-04-02T00:00Z').iloc[-1])

def test_purge_and_validation_selection(monkeypatch):
 samples=[]
 for i,p in enumerate(pd.period_range('2000-01',periods=150,freq='M')):
  issue=p.start_time.tz_localize('UTC');samples.append(dict(issued=issue,period=str(p),available=issue+pd.Timedelta(days=62),y=float(i%7),x=np.array([float(i)]),baseline=0,seasonal=0))
 monkeypatch.setattr(M,'dataset',lambda *a:samples)
 seen=[]
 def prediction(name,train,row):
  assert all(s['available']<row['issued'] and s['issued']<row['issued'] for s in train)
  seen.append((name,row['issued']));return 0.
 monkeypatch.setattr(M,'predict',prediction)
 e=M.evaluate(M.frame(raw()),'UNRATE',3,'2030-01-01T00:00Z')
 assert e['status']=='evaluated' and e['selected']=='persistence'
 assert all(n=='persistence' for n,t in seen if t>=pd.Timestamp(e['test_start']))
 assert e['nonoverlap_n']==8
 assert pd.Timestamp(e['selection_cutoff'])<pd.Timestamp(e['calibration_start'])<pd.Timestamp(e['test_start'])

def test_first_fact_kept_after_revision(tmp_path,monkeypatch):
 c=D.connect(tmp_path/'test.db');f=dict(status='ok',series='UNRATE',period='2020-01',horizon=1,model='ridge',snapshot='a',version='test',issued='2020-01-21T10:00:00Z',value=4.2,lower=3,upper=5,baseline=4)
 ident=S.record(c,f);d=M.frame(raw());S.settle(c,d,'2020-02-10T00:00Z');S.settle(c,d,'2020-04-01T00:00Z')
 assert c.execute('SELECT value FROM outcomes').fetchone()[0]==4
 assert c.execute('SELECT value FROM revisions').fetchone()[0]==9
 assert c.execute('SELECT available FROM revisions').fetchone()[0].startswith('2020-03-08')

def test_ingest_conflict_rolls_back_entire_batch(tmp_path):
 c=D.connect(tmp_path/'test.db');D.ingest(c,'UNRATE',[dict(date='2020-01-01',realtime_start='2020-02-07',value='4')])
 with pytest.raises(ValueError):D.ingest(c,'UNRATE',[dict(date='2020-02-01',realtime_start='2020-03-07',value='5'),dict(date='2020-01-01',realtime_start='2020-02-07',value='9')])
 assert c.execute('SELECT count(*) FROM observations').fetchone()[0]==1

def test_wide_vintage_decoder():
 class Response:
  status_code=200
  def json(self):return {'observations':[{'date':'2020-01-01','UNRATE_20200207':'4','UNRATE_20200306':'5'}],'count':1}
 class Client:
  def get(self,url,**kw):assert url.startswith('https://api.stlouisfed.org/');return Response()
 rows=D.fetch_series('UNRATE','test-key',session=Client());assert [r['value'] for r in rows]==['4','5'];assert rows[1]['realtime_start']=='2020-03-06'

def test_journal_summary_counts_one_first_issue(tmp_path,monkeypatch):
 monkeypatch.setenv('ALLANALYTICS_DATA_DIR',str(tmp_path))
 with D.connect() as c:
  for day,value in [('21',4),('22',5)]:
   f=dict(status='ok',series='UNRATE',period='2026-10',horizon=1,model='ridge',snapshot='a',version='test',issued=f'2026-09-{day}T10:00:00Z',value=value,lower=3,upper=6,baseline=4)
   i=S.record(c,f)
   with c:c.execute('INSERT INTO outcomes VALUES(?,?,?,?,?)',(i,'2026-11-10','2026-11-07',4.5,'test'))
 j=S.journal();assert j['total']==2;assert j['summary'][0]['issues']==1;assert j['summary'][0]['resolved']==1;assert j['summary'][0]['mae']==.5

def test_no_change_does_not_retrain(monkeypatch,tmp_path):
 monkeypatch.setenv('ALLANALYTICS_DATA_DIR',str(tmp_path));monkeypatch.setattr(S,'seed_history',lambda:None)
 monkeypatch.setattr(S,'read_bundle',lambda:dict(version=M.VERSION,input_fingerprint=S.fingerprint()))
 monkeypatch.setattr(S,'train',lambda:pytest.fail('same inputs must not retrain'))
 monkeypatch.setattr(S,'settle',lambda *a:None)
 S.job(False);assert S.STATE['stage']=='Новых публикаций нет'

def test_failed_candidate_publishes_baseline_with_separate_evidence(monkeypatch):
 d=M.frame(raw());e=dict(status='evaluated',selected='ridge',test_mae=2,baseline_mae=1,calibration_errors=[1.]*12,baseline_calibration_errors=[.2]*12)
 monkeypatch.setattr(M,'dataset',lambda *a:[]);monkeypatch.setattr(M,'predict',lambda *a:99.)
 f=M.forecast(d,'UNRATE',1,'2020-02-10T12:00Z',e)
 assert f['model']=='persistence' and f['value']==4
 assert f['candidate']['value']==99
 assert f['publication_reason']=='candidate_failed_holdout'
 assert f['lower']==pytest.approx(3.8) and f['upper']==pytest.approx(4.2)
 assert f['evaluation']['test_mae']==2
