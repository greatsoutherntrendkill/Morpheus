"""AllAnalytics v4.40.4 — Model Integrity wrapper.

This release changes validation/target semantics, not by adding another expert,
but by making the existing forecast stack internally consistent:

* shared volatility-adjusted UP / NEUTRAL / DOWN target;
* normalized UP / NEUTRAL / DOWN class probabilities plus a legacy directional score;
* separated meta fit / probability calibration / signal-threshold / final eval;
* deployment-matched calibration after refit;
* distribution production refit after untouched audit;
* dependence-aware validation and event timing anchors.

The wrapper provides one generation identifier for every live forecast while
preserving the lower-layer version for backward-compatible diagnostics.
"""
from __future__ import annotations

import distributional_forecast_v440 as BASE440
import models as M

VERSION = "model-integrity-v4.40.4"
MODEL_GENERATION = "directional-3state-integrity-v4.40.4"
VALIDATION_VERSION = "integrity-contract-v4.40.4"


def _ensemble_explanation(out: dict) -> dict:
    components=[]
    for row in out.get("components") or []:
        if not isinstance(row,dict):
            continue
        components.append({
            "name":row.get("name"),
            "p_up":row.get("p_up"),
            "conditional_p_up":row.get("conditional_p_up"),
            "weight":row.get("weight"),
            "validated":row.get("validated"),
        })
    return {
        "scope":"final_ensemble_component_decomposition",
        "directional_score_up":out.get("directional_score_up", out.get("p_up")),
        "conditional_p_up":out.get("conditional_p_up"),
        "class_probabilities":out.get("class_probabilities") or {},
        "p_neutral":out.get("p_neutral"),
        "abstain":bool(out.get("abstain")),
        "components":components,
        "feature_driver_scope":"base directional model only; component decomposition explains the final ensemble",
    }


def forecast_horizon(close, symbol: str, horizon: int = 10, fast: bool = True, context: dict | None = None) -> dict:
    out=BASE440.forecast_horizon(close,symbol=symbol,horizon=int(horizon),fast=fast,context=context)
    if not out:
        return {}
    out=dict(out)
    lower=out.get("version")
    out["base_model_version"]=lower
    out["version"]=VERSION
    out["integrity_version"]=VERSION
    out["model_generation"]=MODEL_GENERATION
    out["target_version"]=out.get("target_version") or M.TARGET_VERSION
    p_neutral=out.get("p_neutral")
    p_cond=out.get("conditional_p_up")
    try:
        p_neutral=float(p_neutral); p_cond=float(p_cond)
        p_neutral=max(0.0,min(.95,p_neutral)); p_cond=max(.0,min(1.0,p_cond))
        p_move=1.0-p_neutral
        classes={"up":p_move*p_cond,"neutral":p_neutral,"down":p_move*(1.0-p_cond)}
        total=sum(classes.values()) or 1.0
        classes={k:round(float(v/total),6) for k,v in classes.items()}
        out["class_probabilities"]=classes
        out["p_move"]=round(p_move,6)
    except Exception:
        classes=out.get("class_probabilities") or {}
    # Keep p_up/p_down as a legacy directional score because older API/UI code and
    # confidence gates are centered on 50%. New consumers must use the normalized
    # class_probabilities object when they need P(UP/NEUTRAL/DOWN).
    out["directional_score_up"]=out.get("p_up")
    out["directional_score_down"]=out.get("p_down")
    out["probability_semantics"]=(
        "class_probabilities are normalized P(significant up / neutral / significant down); "
        "p_up/p_down are backward-compatible neutral-aware directional scores, not class probability mass"
    )
    out["calibrated_probability_scope"]="conditional P(up | material move); neutral mass is modelled separately"
    out["ensemble_explanation"]=_ensemble_explanation(out)
    validation=dict(out.get("validation") or {})
    validation.update({
        "integrity_version":VALIDATION_VERSION,
        "shared_three_state_target":True,
        "normalized_three_state_probabilities":True,
        "legacy_directional_score_explicit":True,
        "neutral_never_coerced_to_down":True,
        "meta_calibration_threshold_eval_separated":True,
        "deployment_calibration_matches_refit":True,
        "distribution_refit_after_untouched_audit":True,
        "dependence_aware_oos":True,
        "event_response_timestamp_aware":True,
        "single_live_source_of_truth":True,
    })
    out["validation"]=validation
    return out
