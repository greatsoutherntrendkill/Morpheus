# AllAnalytics v4.40.10 — Champion & Validation Upgrade

## 1. Champion solver upgrade

The production directional champion and Move/No-Move classifier now use deterministic sklearn Logistic Regression (`lbfgs`, L2). `C` is selected from `0.03 / 0.10 / 0.30 / 1.0 / 3.0` on a recent chronological validation tail drawn strictly from the legal training sample. Any training labels whose `label_end` overlaps the inner validation start are purged. If the nested sample is too small, the model falls back to the locked `C=0.30` rather than tuning on noise.

The old NumPy `LogReg` class is retained only for legacy/challenger modules that still depend on its historical contract.

## 2. Data-driven internal RegimeMoE routing

The historical 45% global / 35% asset-class / 20% regime weights remain a safety fallback. RegimeMoE now tests a coarse simplex of alternative weights on an internal chronological OOS tail. Learned weights are adopted only when they reduce Brier versus the locked blend. Experts are then refit on the full legal training sample.

## 3. Persistent event and governance state

Release-local state is no longer the production source of truth:

- events: `~/AllAnalytics_Data/events/event_archive.sqlite3`
- review decisions: `~/AllAnalytics_Data/governance/model_promotion.sqlite3`

Legacy `runtime_cache/event_archive_v439.json` and `runtime_cache/model_promotion_v437.sqlite3` are migration sources only.

## 4. Sealed shadow benchmark

From 2026-09-15 onward, a deterministic 20% hash slice of prospective forecasts is reserved for independent audit. Shadow rows are excluded from:

- prospective publish routing;
- challenger/promotion selection;
- learned prospective blend weights;
- calibration and threshold fitting.

The audit remains `collecting` until at least 40 settled forecasts across 20 forecast dates are available. It is monitoring-only and never changes production.

## Identity

- Model version: `champion-validation-v4.40.10`
- Model generation: `directional-3state-move-champion-validation-v4.40.10`
- Forecast contract: `forecast-contract-v4.40.10`
- Cache contract: `forecast-cache-v4.40.10`
