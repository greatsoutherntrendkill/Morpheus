"""Real HTTP regression under a 128-descriptor limit; background downloads excluded."""
import gc,json,os,resource,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path(__file__).resolve().parents[1]
server_code='''import gc,os,resource,uvicorn
from api import app
@app.middleware("http")
async def count_fds(request,call_next):
 response=await call_next(request)
 response.headers['X-Test-Fds']=str(len(os.listdir('/dev/fd')))
 return response
gc.collect();gc.disable()
soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)
resource.setrlimit(resource.RLIMIT_NOFILE,(min(128,hard),hard))
uvicorn.run(app,host='127.0.0.1',port=8020,log_level='error',lifespan='off')
'''
with tempfile.TemporaryDirectory() as data:
 env=dict(os.environ,ALLANALYTICS_DATA_DIR=data,MACRO_POLICY_AUTO_UPDATE='0')
 with (root/'checks/resource_http_server.log').open('w') as log:
  p=subprocess.Popen([sys.executable,'-c',server_code],cwd=root/'mvp',env=env,stdout=log,stderr=log)
  try:
   def get(path):
    with urllib.request.urlopen('http://127.0.0.1:8020'+path,timeout=30) as r:
     r.read();return int(r.headers['X-Test-Fds'])
   for _ in range(100):
    if p.poll() is not None:raise RuntimeError('server stopped')
    try:get('/');break
    except OSError:time.sleep(.1)
   paths=['/api/models/forecast-journal','/api/models/forecast-journal?symbol=MA','/technical_lab_v411.html','/']
   baseline=get(paths[0]);counts=[]
   with ThreadPoolExecutor(max_workers=8) as pool:
    counts=list(pool.map(lambda i:get(paths[i%len(paths)]),range(1000)))
   final=get(paths[0])
   report=dict(requests=1000,workers=8,fd_limit=128,gc_disabled=True,background_downloads=False,baseline=baseline,peak=max(counts),final=final)
   assert final<=baseline+12,report
   print(json.dumps(report));(root/'checks/resource_http_result.json').write_text(json.dumps(report,indent=2))
  finally:
   p.terminate()
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait()
