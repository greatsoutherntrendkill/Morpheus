"""Freeze/run matched feature experiments. No external history downloads or promotion."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,math,time,argparse,concurrent.futures,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'mvp'))
import numpy as np,pandas as pd
import independent_evaluation_v4401014 as E
import temporal_validation_v4401012 as TV
import data_contract_v4401013 as D
import forecast_contract_v4406 as C
import verified_extensions_v4401016 as X
CHECKS=ROOT/'checks';PROTOCOL=CHECKS/'stage6_protocol.json';ROWS=CHECKS/'stage6_predictions.jsonl'
VARIANTS=['baseline','without_momentum','without_volatility','without_trend','plus_market']

def freeze():
 if PROTOCOL.exists():raise RuntimeError('Protocol already frozen')
 inputs={}
 for p in sorted((CHECKS/'input_snapshots').glob('*.json')):
  obj=json.loads(p.read_text());s=obj['symbol']
  if s in ('^GSPC','BTC-USD','EURUSD=X','PLZL.ME','CL=F') and s not in inputs:inputs[s]={'file':str(p.relative_to(ROOT)),'hash':E.digest(obj),'rows':len(obj['rows'])}
 jobs=[]
 for s,o in inputs.items():
  d=json.loads((ROOT/o['file']).read_text());dates=pd.to_datetime([x['date'] for x in d['rows']]);n=int(sum(dates<TV.SEALED_START))
  for h in (1,10,60):
   origins=np.unique(np.linspace(max(550,n-400),n-h-2,12,dtype=int)).tolist()
   for v in VARIANTS:jobs.append({'symbol':s,'horizon':h,'variant':v,'origins':origins,'factor_symbol':'BTC-USD' if s=='^GSPC' else '^GSPC'})
 p={'version':X.VERSION,'generation':C.MODEL_GENERATION,'created_at':pd.Timestamp.now(tz='UTC').isoformat(),'code_hash':E.code_hash(),'runtime':D.runtime_versions(),'inputs':inputs,'jobs':jobs,'variants':VARIANTS,'scope':'historical_development_replay_of_final_fast_pipeline','sealed_start':str(TV.SEALED_START.date()),'point_in_time_archive_verified':False,'untouched_prospective':False,'criteria':{'minimum_pairs':120,'minimum_nonoverlap':60,'minimum_nonoverlap_per_period':15,'periods':3,'relative_brier_gain':.02,'holm_alpha':.05,'no_log_loss_deterioration':True,'requires_vintage_archive':True,'requires_prospective_evidence':True,'automatic_promotion':False},'ablation_scope':'Core directional predictors and associated regime labels; target definition and separate quantile model unchanged. Removing MA200 keeps common 200-row warm-up.','market_factor':'One market at a time; trailing 20-close log return; scheduled source close +1 minute before target close +2 minutes; stale after 7 calendar days. Actual first-seen history is missing, so research only.'}
 PROTOCOL.write_text(json.dumps(p,ensure_ascii=False,indent=2));print('FROZEN',len(jobs),'jobs',sum(len(j['origins']) for j in jobs),'forecasts',E.digest(p),flush=True)

def one(job):
 os.environ['ALLANALYTICS_DATA_DIR']=tempfile.mkdtemp(prefix='aa-stage6-run-')
 import evaluation_clock_v4401014 as CLOCK
 import model_champion_validation_v44010 as M
 import equity_forecast_v416 as EQ
 import macro_event_model_v440109 as MACRO
 import quality_contract_v4401011 as Q
 import target_contract_v4405 as TARGET
 p=json.loads(PROTOCOL.read_text());s=job['symbol'];h=job['horizon'];variant=job['variant']
 def series(sym):
  o=json.loads((ROOT/p['inputs'][sym]['file']).read_text());d=pd.DataFrame(o['rows']);return pd.Series(d.close.to_numpy(float),index=pd.to_datetime(d.date))
 c=series(s);factor,audit=X.historical_market_factor(series(job['factor_symbol']),job['factor_symbol'],c.index,s)
 out=[]
 for pos,i in enumerate(job['origins']):
  start=time.time();prefix=c.iloc[:i+1];origin=c.index[i];end=c.index[i+h]
  row={'symbol':s,'horizon':h,'variant':variant,'origin':str(origin.date()),'target_date':str(end.date()),'origin_index':i,'target_index':i+h,'period':min(2,pos*3//len(job['origins'])),'status':'error'}
  try:
   if end>=TV.SEALED_START:raise ValueError('sealed label')
   if variant=='plus_market' and not np.isfinite(factor.iloc[i]):raise ValueError('source unavailable at decision')
   at=D.session_close(s,origin)+pd.Timedelta(minutes=2)
   with CLOCK.at(at),X.experiment(variant,factor):
    raw=M.forecast_horizon(prefix,s,h,fast=True)
    final=Q.forecast(MACRO.apply(EQ._shape_meta_result(raw,h,prefix),prefix,s,h,as_of=at))
   prob=final.get('class_probabilities');vec=E.vector(prob)
   if vec is None:raise ValueError('no valid final probabilities')
   band=TARGET.band_for_asof(prefix,h);ret=float(np.log(c.iloc[i+h]/c.iloc[i]));state=1 if ret>band else -1 if ret<-band else 0
   b,ll=E.losses([vec],[state]);row.update(status='ok',prob=prob,brier=float(b[0]),log_loss=float(ll[0]),state=state,threshold_log=band,realized_log_return=ret,abstain=bool(final.get('abstain')),regime=E.regime(prefix),input_hash=D.series_hash(prefix),as_of_utc=at.isoformat(),factor_source=job['factor_symbol'] if variant=='plus_market' else None,factor_value=float(factor.iloc[i]) if variant=='plus_market' else None,source_archive_verified=False)
  except Exception as exc:row['error']=type(exc).__name__+': '+str(exc)[:250]
  row['seconds']=round(time.time()-start,3);out.append(row)
 print(s,h,variant,sum(r['status']=='ok' for r in out),'/',len(out),round(sum(r['seconds'] for r in out),1),'s',flush=True)
 return out

def run(workers):
 p=json.loads(PROTOCOL.read_text())
 if p['code_hash']!=E.code_hash():raise RuntimeError('Code changed after freeze')
 for d in p['inputs'].values():
  if E.digest(json.loads((ROOT/d['file']).read_text()))!=d['hash']:raise RuntimeError('Input changed')
 if ROWS.exists():raise RuntimeError('Do not overwrite outcomes')
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool,ROWS.open('w') as f:
  futures=[pool.submit(one,j) for j in p['jobs']]
  for future in concurrent.futures.as_completed(futures):
   for row in future.result():f.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n')
   f.flush()
 summarize()

def summarize():
 p=json.loads(PROTOCOL.read_text());rows=[json.loads(x) for x in ROWS.read_text().splitlines()];index={(r['symbol'],r['horizon'],r['variant'],r['origin']):r for r in rows};groups=[]
 for job in p['jobs']:
  if job['variant']=='baseline':continue
  s,h,v=job['symbol'],job['horizon'],job['variant'];pairs=[];missing=0
  for i in job['origins']:
   cand=next((r for r in rows if r['symbol']==s and r['horizon']==h and r['variant']==v and r['origin_index']==i),None)
   base=index.get((s,h,'baseline',cand['origin'])) if cand else None
   if not cand or not base or cand['status']!='ok' or base['status']!='ok':missing+=1;continue
   assert cand['input_hash']==base['input_hash'] and cand['state']==base['state'] and cand['threshold_log']==base['threshold_log']
   pairs.append((base,cand))
  diff=[a['brier']-b['brier'] for a,b in pairs];step=float(np.median(np.diff(job['origins']))) if len(job['origins'])>1 else h
  block=max(1,math.ceil(h/max(1,step)));boot=E.bootstrap_difference(diff,block,n_boot=1999,seed=4401016)
  non=E.nonoverlap([b for a,b in pairs]);periods=[]
  for k in range(3):
   ps=[(a,b) for a,b in pairs if b['period']==k];periods.append({'period':k+1,'n':len(ps),'nonoverlap':len(E.nonoverlap([b for a,b in ps])),'brier_gain':float(np.mean([a['brier']-b['brier'] for a,b in ps])) if ps else None})
  bg=float(np.mean([a['brier'] for a,b in pairs])) if pairs else None;cg=float(np.mean([b['brier'] for a,b in pairs])) if pairs else None
  groups.append({'symbol':s,'horizon':h,'variant':v,'factor_source':job['factor_symbol'] if v=='plus_market' else None,'pairs':len(pairs),'missing':missing,'nonoverlap':len(non),'baseline_brier':bg,'candidate_brier':cg,'relative_gain':(bg-cg)/bg if bg else None,'baseline_log_loss':float(np.mean([a['log_loss'] for a,b in pairs])) if pairs else None,'candidate_log_loss':float(np.mean([b['log_loss'] for a,b in pairs])) if pairs else None,'uncertainty':boot,'periods':periods,'admitted':False,'reason':'Историческая диагностика: мало независимых исходов; нет нетронутой будущей выборки и полного архива доступности.'})
 adjusted=E.holm([g['uncertainty']['p_one_sided'] if g['uncertainty']['p_one_sided'] is not None else 1. for g in groups])
 for g,q in zip(groups,adjusted):g['holm_p']=q
 result={'version':X.VERSION,'protocol_hash':E.digest(p),'source_hash':p['code_hash'],'scope':p['scope'],'attempted':len(rows),'valid':sum(r['status']=='ok' for r in rows),'planned':sum(len(j['origins']) for j in p['jobs']),'complete':len(rows)==sum(len(j['origins']) for j in p['jobs']),'groups':groups,'admitted_count':0,'criteria':p['criteria'],'point_in_time_archive_verified':False,'untouched_prospective':False,'limitations':['Проверяется быстрый окончательный расчёт; полный режим требует отдельного эксперимента.','Данные уже были доступны при разработке.','Один выбранный рынок не представляет все возможные межрыночные источники.','Удаление группы относится к направленным признакам и режимам, а не к определению целевого движения и отдельному расчёту диапазонов.','Макросюрпризы и стакан не тестировались на выдуманных исторических данных.']}
 (CHECKS/'stage6_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(ROOT/'mvp/site/extensions_results_v4401016.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('COMPLETE',result['valid'],'/',result['planned'],'admitted 0',flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('action',choices=['freeze','run','summarize']);a.add_argument('--workers',type=int,default=3);args=a.parse_args()
 if args.action=='freeze':freeze()
 elif args.action=='run':run(args.workers)
 else:summarize()
