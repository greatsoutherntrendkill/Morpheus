const assert=require('assert'),fs=require('fs'),S=require('../mvp/site/candle_scenarios_v440107.js');
const fixture=JSON.parse(fs.readFileSync(__dirname+'/stage6_api_GSPC.json'));
const candles=fixture.history,f={...fixture.forecasts['10'],status:'ok'};
const opts={forecast:f,candles,tf:'1d',horizon:'10'};
const base=S.build(opts);assert(base.available);assert.deepStrictEqual(base,S.build(opts));
function moves(s){return s.paths.map(p=>({up:p.bars.filter(b=>b.c>b.o).length,down:p.bars.filter(b=>b.c<b.o).length,wiggle:p.bars.reduce((v,b)=>v+Math.abs(Math.log(b.c/b.o)),0)}));}
for(const p of moves(base)){assert(p.up>2&&p.down>2);}
// Same endpoint, very different recent observed volatility. No synthetic probability boost.
function history(scale){let price=100;return Array.from({length:240},(_,i)=>{let o=price;price*=Math.exp(Math.sin(i*1.7)*.001*(i>200?scale:1));return {t:new Date(Date.UTC(2026,0,1,0,i*60)).toISOString(),o,c:price,h:Math.max(o,price)*1.0008,l:Math.min(o,price)/1.0008};});}
const forecast={status:'ok',p_up:.6,movement_guidance:{material_move_threshold_pct:.3,expected_abs_move_pct:1}};
const quiet=S.build({forecast,candles:history(1),tf:'1h',horizon:'10'}),loud=S.build({forecast,candles:history(5),tf:'1h',horizon:'10'});
assert(loud.diagnostics.currentVol>quiet.diagnostics.currentVol*2);
assert(moves(loud)[0].wiggle>moves(quiet)[0].wiggle);
assert.deepStrictEqual(quiet.paths.map(p=>p.end),loud.paths.map(p=>p.end));
assert(quiet.diagnostics.sessionVol>0);
const risk=S.build({...opts,forecast:{...f,macro_events:{signal_guard:true}}});assert(risk.riskNote);assert.deepStrictEqual(risk.paths,base.paths);
assert(!S.build({...opts,candles:candles.slice(-4)}).available);
for(const tf of ['1min','5min','15min','30min','1h','4h','1d','1w','1mo','3mo','6mo','1y','3y'])for(const horizon of ['30m','1h','2h','4h','1','3','5','10','20','30','60']){
 const sc=S.build({...opts,tf,horizon});assert(sc.available);
 for(const path of sc.paths)for(const b of path.bars){assert(b.h>=Math.max(b.c,b.o)&&b.l<=Math.min(b.c,b.o)&&b.l>0);assert([b.o,b.c,b.h,b.l].every(Number.isFinite));}
}
const report={fixture:'stored GSPC historical snapshot',moves:moves(base),diagnostics:base.diagnostics,quietVol:quiet.diagnostics.currentVol,loudVol:loud.diagnostics.currentVol,quietMoves:moves(quiet),loudMoves:moves(loud),matrixCases:143};
fs.writeFileSync(__dirname+'/empirical_metrics.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
