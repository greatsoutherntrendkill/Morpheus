"""Offline repeatability check: same accepted OHLC, code, libraries and local databases.
Run from mvp with an isolated ALLANALYTICS_DATA_DIR. No network calls.
"""
import sys,json,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'mvp'))
import pandas as pd
import model_champion_validation_v44010 as M
import distributional_forecast_v440 as DIST
import asset_specialists_v438 as SPEC
import event_response_v439 as EVENT
import data_contract_v4401013 as D
checks=Path(__file__).resolve().parent

def relevant(out):
 return {k:out.get(k) for k in ['p_up','p_down','conditional_p_up','class_probabilities','abstain','signal_threshold']}|{'quantiles':(out.get('distribution_forecast') or {}).get('quantiles'),'price_quantiles':(out.get('distribution_forecast') or {}).get('price_quantiles')}
rows=[]
for p in sorted((checks/'input_snapshots').glob('*.json')):
 obj=json.loads(p.read_text());s=obj['symbol']
 if s not in {'^GSPC','BTC-USD','EURUSD=X','PLZL.ME'}:continue
 d=pd.DataFrame(obj['rows']);c=pd.Series(d.close.to_numpy(),index=pd.to_datetime(d.date))
 for fast in [True,False]:
  t=time.time();a=M.forecast_horizon(c,s,10,fast=fast)
  DIST._CACHE.clear();SPEC._SPECIALIST_CACHE.clear();EVENT._FORECAST_CACHE.clear()
  b=M.forecast_horizon(c,s,10,fast=fast)
  assert relevant(a)==relevant(b),(s,fast)
  assert a.get('p_up') is not None,(s,fast,a)
  assert a.get('confidence_score') is None
  rows.append({'symbol':s,'mode':'fast' if fast else 'full','horizon':10,'identical':True,'input_hash':obj['audit']['data_hash'],'result':relevant(b),'seconds':round(time.time()-t,2)})
  print(s,fast,'identical',rows[-1]['seconds'],flush=True)
report={'version':'4.40.10.13','scope':'numerical_repeatability_not_accuracy','runtime':D.runtime_versions(),'dependency_hash':D.dependency_fingerprint(),'results':rows}
(checks/'data_replay_4.40.10.13.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('PASS',len(rows))
