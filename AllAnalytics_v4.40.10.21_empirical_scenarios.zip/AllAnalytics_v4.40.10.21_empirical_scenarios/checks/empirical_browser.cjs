const {chromium}=require('/Users/semyonromanov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path'),assert=require('assert');
const site=path.resolve(__dirname,'../mvp/site'),fixture=JSON.parse(fs.readFileSync(__dirname+'/stage6_api_GSPC.json'));
(async()=>{const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--no-sandbox']});
try{const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.route('**/*',async route=>{let u=new URL(route.request().url());if(u.hostname!=='127.0.0.1')return route.abort();
 if(u.pathname.startsWith('/api/')){
  let j={};if(u.pathname.includes('/chart/history'))j={candles:fixture.history,source:'Проверочная история для теста интерфейса',as_of:fixture.as_of,points:fixture.history.length};
  else if(u.pathname.includes('/markets/forecast')){const h=u.searchParams.get('horizon');j={...fixture,forecasts:{[h]:fixture.forecasts['10']}};}
  else if(u.pathname.includes('/forecast/short'))j={...fixture.forecasts['10'],status:'ok'};
  return route.fulfill({json:j});
 }
 let file=path.join(site,decodeURIComponent(u.pathname==='/'?'/index.html':u.pathname));
 if(!file.startsWith(site)||!fs.existsSync(file))return route.fulfill({status:404,body:''});
 let ext=path.extname(file),types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.woff2':'font/woff2'};
 return route.fulfill({body:fs.readFileSync(file),contentType:types[ext]||'application/octet-stream'});
});
await page.goto('http://127.0.0.1:8021/technical_lab_v411.html?symbol=%5EGSPC&timeframe=6mo&interval=1d&period=6mo&forecast=10');
await page.waitForFunction(()=>typeof CHART!=='undefined'&&CHART.scenario?.available);await page.waitForTimeout(800);
const report={source:'Controlled stored historical API response, not live-provider verification',cases:[],errors};
for(const [width,height] of [[1440,1000],[430,932]]){await page.setViewportSize({width,height});await page.waitForTimeout(200);await page.screenshot({path:__dirname+`/empirical_${width}.png`,fullPage:true});
 const state=await page.evaluate(()=>({available:CHART.scenario.available,bars:CHART.scenario.n,method:CHART.scenario.method,overflow:document.documentElement.scrollWidth>innerWidth+1,status:document.querySelector('#scenario-status').textContent}));assert(state.available);assert(!state.overflow);report.cases.push({width,...state});}
await page.setViewportSize({width:1440,height:1000});
report.switches=[];
for(const tf of ['1min','1h','1d','6mo']){
 await page.selectOption('#timeframe',tf,{force:true});
 await page.waitForFunction(tf=>CHART.scenario?.available&&selectedTimeframe===tf&&CHART.scenarioReady,tf);
 for(const h of ['1h','10','60']){
  await page.selectOption('#short-forecast-horizon',h,{force:true});
  await page.waitForFunction(h=>CHART.scenario?.available&&CHART.scenario.horizon===h,h);
  report.switches.push({tf,h,available:await page.evaluate(()=>CHART.scenario.available)});
 }
}
assert.deepEqual(errors,[]);fs.writeFileSync(__dirname+'/empirical_browser.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});
