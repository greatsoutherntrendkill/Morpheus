"""Reproduce development diagnostics on the bundled immutable price snapshot.
No claim of final accuracy; run from mvp with isolated ALLANALYTICS_DATA_DIR.
"""
from pathlib import Path
import sys,json,sqlite3,time
import pandas as pd
sys.path.insert(0,str(Path.cwd()))
import model_champion_validation_v44010 as M
import temporal_validation_v4401012 as TV
con=sqlite3.connect('file:market.db?mode=ro',uri=True)
report={'version':TV.VERSION,'scope':'development_only','accuracy_improvement_claimed':False,'results':[]}
for symbol in ['^GSPC','BTC-USD','EURUSD=X','PLZL.ME']:
 rows=con.execute('select date,close from prices where symbol=? order by date',(symbol,)).fetchall()
 if not rows:
  cached=Path('runtime_cache/equity_history_v424/PLZLME.json') if symbol=='PLZL.ME' else Path('/nonexistent')
  bundled=Path('../checks/history_PLZL_stage2.json')
  if cached.exists():bundled.write_text(cached.read_text())
  if symbol=='PLZL.ME' and bundled.exists():
   history=json.loads(bundled.read_text())['rows'];rows=[(r['date'],r['close']) for r in history]
  else:continue
 close=pd.Series([r[1] for r in rows],index=pd.to_datetime([r[0] for r in rows])).dropna()
 for h in [1,10,60]:
  t=time.time();out=M.forecast_horizon(close,symbol,h,fast=True)
  splits=(out.get('temporal_validation') or {}).get('splits',[])
  for split in splits:
   for a,b in zip(split['boundaries'],split['boundaries'][1:]):assert pd.Timestamp(a['target_end_max'])<pd.Timestamp(b['origin_start'])
  assert out.get('confidence_score') is None
  assert out.get('quality_contract_version','').endswith('4.40.10.12')
  d=out.get('distribution_forecast') or {}
  report['results'].append({'symbol':symbol,'horizon':h,'p_up':out.get('p_up'),'class_probabilities':out.get('class_probabilities'),
    'input_rows':len(close),'input_first':str(close.index[0]),'input_last':str(close.index[-1]),'seconds':round(time.time()-t,2),
    'temporal_splits':splits,'distribution_status':d.get('status'),'distribution_development_evaluation':d.get('development_evaluation'),
    'scorecard':out.get('scorecard'),'confidence_status':out.get('confidence_status')})
  print(symbol,h,len(splits),d.get('status'),round(time.time()-t,1),flush=True)
Path('../checks/temporal_replay_4.40.10.12.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str))
print('PASS',len(report['results']))
