import json,time,urllib.request,urllib.parse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
base='http://127.0.0.1:8013'
folder=Path(__file__).resolve().parent

def one(symbol,h):
 start=time.time()
 u=base+'/api/markets/forecast?'+urllib.parse.urlencode({'symbol':symbol,'horizon':h})
 obj=json.load(urllib.request.urlopen(u,timeout=180));f=obj.get('forecasts',{}).get(str(h),{});a=obj.get('data_integrity') or {}
 assert a.get('version')=='data-contract-v4.40.10.13',(symbol,h,obj)
 assert f.get('data_integrity',{}).get('data_hash')==a.get('data_hash'),(symbol,h,obj)
 assert f.get('calculation_identity',{}).get('mode') in {'fast','full'}
 assert f.get('confidence_score') is None
 assert f.get('target_period',{}).get('observations')==h
 row={'symbol':symbol,'horizon':h,'status':obj.get('status'),'p_up':f.get('p_up'),'data':a,'target_period':f.get('target_period'),'calculation':f.get('calculation_identity'),'errors':obj.get('errors'),'seconds':round(time.time()-start,2)}
 print(symbol,h,row['status'],a.get('accepted_rows'),row['seconds'],flush=True)
 return row
rows=[]
with ThreadPoolExecutor(max_workers=3) as ex:
 jobs=[ex.submit(one,s,h) for s in ['^GSPC','BTC-USD','EURUSD=X','PLZL.ME','CL=F'] for h in [1,10,60]]
 for job in as_completed(jobs):rows.append(job.result())
(folder/'data_api_4.40.10.13.json').write_text(json.dumps({'results':rows,'verified':len(rows)},ensure_ascii=False,indent=2))
print('PASS',len(rows))
