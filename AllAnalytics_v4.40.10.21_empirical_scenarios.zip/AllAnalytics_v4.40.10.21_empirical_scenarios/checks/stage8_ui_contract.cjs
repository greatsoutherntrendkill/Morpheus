const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const u=require('../mvp/site/release_ui_v4401018.js');let n=0;const eq=(a,b)=>{assert.deepEqual(a,b);n++};
for(const v of [null,undefined,'',' ',true,false,[],{},NaN,Infinity,-.1,1.1])eq(u.probability(v),null);
for(const v of [0,.5,1,'0','0.7'])eq(u.probability(v),Number(v));
eq(u.direction({p_up:null}),null);eq(u.direction({p_up:.7,calibrated_probability:false}),null);
eq(u.direction({p_up:.2,conditional_p_up:.6}).p,.6);eq(u.direction({p_up:0}).prob,100);
eq(u.direction({p_up:.7}).band,'moderate');eq(u.direction({p_up:.71}).band,'strong');
const now=new Date('2026-09-20T12:00:00Z');
eq(u.nextEvent([{date:'2026-09-19'},{date:'2026-99-99'},{date:'2026-09-31'}],now),null);
eq(u.nextEvent([{date:'2026-10-02'},{date:'2026-09-21'},{date:'2026-09-20'}],now).date,'2026-09-20');
eq(u.rates({hike:0,cut:30,hold:70}),[0,30,70]);
for(const r of [{},{hike:null,cut:30,hold:70},{hike:true,cut:29,hold:70},{hike:20,cut:30,hold:70}])eq(u.rates(r),null);
for(const file of ['index.html','technical_lab_v411.html']){
const html=fs.readFileSync('../mvp/site/'+file,'utf8');
for(const match of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)){if(match[1].trim())new vm.Script(match[1]);}n++;
assert(html.includes('release_ui_v4401018.css'));assert(html.includes('release_ui_v4401018.js'));
}
console.log(`PASS ${n} input/semantic/syntax cases; both pages load release fixes`);
const html=fs.readFileSync('../mvp/site/index.html','utf8');
const context=vm.createContext({ReleaseUI:u,F:{assets:[{f:{p_up:null}},{f:{p_up:.1,conditional_p_up:.6}},{f:{p_up:.8,calibrated_probability:false}}],rates:[]},unified:a=>a.f,esc:String,num:String});
vm.runInContext(html.slice(html.indexOf('function pulseForecastRowsV431()'),html.indexOf('function togglePulseStrongV431()')),context);
assert.equal(context.pulseForecastRowsV431().length,1);assert.equal(context.pulseForecastRowsV431()[0].prob,60);
const eStart=html.lastIndexOf('function eventCard(e){');vm.runInContext(html.slice(eStart,html.indexOf('\nfunction renderPulse()',eStart)),context);
const missing=context.eventCard({date:'2026-10-01'});assert(missing.includes('Оценки вероятностей пока нет'));assert(!missing.includes('70%'));
const valid=context.eventCard({rate_probabilities:{hike:0,cut:30,hold:70}});assert(valid.includes('0%'));assert(valid.includes('70%'));
console.log('PASS integrated Pulse ignores unavailable and technical scores; calendar never supplies invented probabilities');
