const assert=require('assert'),S=require('../mvp/site/candle_scenarios_v440107.js');
const tfs=['1min','5min','15min','30min','1h','4h','1d','1w','1mo','3mo','6mo','1y','3y'],hs=['30m','1h','2h','4h','1','3','5','10','20','30','60'];
const candles=Array.from({length:60},(_,i)=>({t:i,o:100+Math.sin(i),c:100+Math.cos(i),h:102,l:98}));
let count=0;
for(const tf of tfs)for(const horizon of hs)for(const p of [.3,.5,.7]){
 const forecast={status:'ok',p_up:p,movement_guidance:{material_move_threshold_pct:1,expected_abs_move_pct:3}};
 const opts={forecast,candles,tf,horizon};const s=S.build(opts);assert(s.available,tf+horizon);assert(s.n>=28&&s.n<=52);assert.deepEqual(s,S.build(opts));
 assert(s.paths[0].bars[0].c>s.price);assert(s.paths[1].bars[0].c<s.price);
 for(const path of s.paths){let prior=s.price;for(const z of path.bars){assert.equal(z.o,prior);assert(z.l>0&&z.l<=Math.min(z.o,z.c)&&z.h>=Math.max(z.o,z.c));assert([z.o,z.c,z.l,z.h].every(Number.isFinite));prior=z.c}assert.equal(Math.sign(path.bars.at(-1).c-s.price),Math.sign(p-.5))}
 count++;
}
const base={status:'ok',p_up:.7,movement_guidance:{material_move_threshold_pct:1,expected_abs_move_pct:3,distribution_quality_ok:true,directional_scenario_range:{direction:'up',low_pct:4,high_pct:5}}};
const good=S.build({forecast:base,candles,tf:'1d',horizon:'20'});assert(good.range);for(const p of good.paths)assert(p.end>=4&&p.end<=5);
base.movement_guidance.distribution_quality_ok=false;assert.equal(S.build({forecast:base,candles,tf:'1d',horizon:'20'}).range,null);
base.movement_guidance.expected_abs_move_pct=null;assert.equal(S.build({forecast:base,candles,tf:'1d',horizon:'20'}).available,false);
assert.equal(S.build({forecast:{status:'unavailable'},candles,tf:'1d',horizon:'10'}).available,false);
console.log(`PASS ${count} combinations (13 chart scales × 11 horizons × 3 directions), OHLC bounds, continuity, determinism, quality gate and missing data.`);
// Renderer geometry: every coordinate finite; no mutation of historical bars; exports retain both labels.
const sc=S.build({forecast:{status:'ok',p_up:.6,movement_guidance:{material_move_threshold_pct:.4,expected_abs_move_pct:2}},candles,tf:'1d',horizon:'30'});
for(const W of [280,420,760,1400])for(const priceH of [260,480,800]){
 const ctx=new Proxy({},{get:(_,name)=>(...args)=>{for(const a of args)if(typeof a==='number')assert(Number.isFinite(a),name)}});
 const chart={scenario:sc,scenarioProgress:1,offset:0,ctx},d={W,priceH,pL:56,pR:66,pT:20,pB:48},vis={start:0,end:60};
 const sy=p=>20+(106-p)/12*(priceH-68);const palette={up:'#aabbcc',down:'#ccaaaa',first:'#aaccbb',second:'#bbaacc',muted:'#999999',bg:'#000000',tint:'#111111',band:'#222222'};
 S.draw(chart,vis,d,{y:sy},palette);const out=S.svg(chart,vis,d,sy,palette);assert(out.includes('Сценарий I'));assert(out.includes('Сценарий II'));assert(!out.includes('NaN'));
 chart.offset=1;assert.equal(S.active(chart),false);assert.equal(S.historyRight(chart,d),d.pR);
}
console.log('PASS renderer/export across 12 viewport combinations; historical pan hides future overlay.');
for(const side of [.3,.7]){
 const f={status:'ok',p_up:side,movement_guidance:{material_move_threshold_pct:1,expected_abs_move_pct:3}};
 const s=S.build({forecast:f,candles,tf:'1h',horizon:'5'});
 for(const p of s.paths){assert(p.bars.filter(z=>z.c>z.o).length>=3);assert(p.bars.filter(z=>z.c<z.o).length>=3)}
}
const source=require('fs').readFileSync(require.resolve('../mvp/site/candle_scenarios_v440107.js'),'utf8');assert(!source.includes('scenario-hatch'));assert(!source.includes('url(#scenario-hatch)'));
console.log('PASS corrections in both directions and hollow export without hatching.');
