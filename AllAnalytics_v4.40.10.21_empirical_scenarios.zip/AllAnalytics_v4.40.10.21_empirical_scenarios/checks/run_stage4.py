"""Freeze protocol BEFORE computation; replay final output on strict price prefixes.
Run from mvp in a dedicated data directory. No source-history/network downloads.
"""
import os
# Avoid oversubscribing native maths inside independent audit worker processes.
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import sys,json,argparse,traceback,concurrent.futures,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'mvp'))
import numpy as np,pandas as pd
import independent_evaluation_v4401014 as E
import data_contract_v4401013 as D
import forecast_contract_v4406 as C
import temporal_validation_v4401012 as TV
CHECKS=ROOT/'checks';PROTOCOL=CHECKS/'stage4_protocol.json';ROWS=CHECKS/'stage4_predictions.jsonl'

def freeze():
 if PROTOCOL.exists():raise RuntimeError('Protocol already frozen; do not overwrite after seeing outcomes')
 inputs={}
 for p in sorted((CHECKS/'input_snapshots').glob('*.json')):
  o=json.loads(p.read_text());s=o['symbol']
  if s in {'^GSPC','BTC-USD','EURUSD=X','PLZL.ME','CL=F'} and s not in inputs:inputs[s]=(p,o)
 jobs=[];manifest=[]
 for symbol,(p,obj) in inputs.items():
  dates=pd.to_datetime([r['date'] for r in obj['rows']]);legal=np.flatnonzero(dates<TV.SEALED_START);last=int(legal[-1]);n=last+1
  manifest.append({'symbol':symbol,'file':str(p.relative_to(ROOT)),'file_hash':E.digest(obj),'source':obj.get('audit',{}),'rows':n})
  for h in [1,10,60]:
   # Fixed price-independent 12-point schedule, spanning 3 contiguous audit periods.
   start=max(550,n-400);stop=n-h-2
   if stop<=start:continue
   origins=np.unique(np.linspace(start,stop,12,dtype=int)).tolist()
   for mode in ['fast','full']:
    jobs.append({'symbol':symbol,'horizon':h,'mode':mode,'input':str(p.relative_to(ROOT)),'origins':origins})
 obj={'version':E.VERSION,'created_at':pd.Timestamp.now(tz='UTC').isoformat(),'generation':C.MODEL_GENERATION,
      'code_hash':E.code_hash(),'criteria':E.CRITERIA,'evidence_scope':'historical_development_replay',
      'point_in_time_archive_verified':False,'sealed_start':str(TV.SEALED_START.date()),'runtime':D.runtime_versions(),
      'baselines':['uniform three-state 1/3','resolved 504-observation frequencies + Laplace(1)','same past 20-observation trend frequencies + Laplace(1)'],
      'cost_bps':[5,15,30],'execution':'next observed open -> origin+h close; no overlapping positions; hypothetical unlevered proxy',
      'availability':'strict prefix; only news/calendar first_seen<=origin; retrospective price revisions and missing archives prevent untouched claim',
      'inputs':manifest,'jobs':jobs}
 PROTOCOL.write_text(json.dumps(obj,ensure_ascii=False,indent=2));print('FROZEN',E.digest(obj),len(jobs),'jobs',sum(len(j['origins']) for j in jobs),'origins',flush=True)

def one_job(job):
 # Separate process AND stores per asset/horizon/mode; no personal evidence import.
 import tempfile
 state=tempfile.mkdtemp(prefix='aa-stage4-')
 os.environ['ALLANALYTICS_DATA_DIR']=state
 import evaluation_clock_v4401014 as clock
 import equity_forecast_v416 as EQ
 import model_champion_validation_v44010 as M
 import macro_event_model_v440109 as MACRO
 import quality_contract_v4401011 as Q
 obj=json.loads((ROOT/job['input']).read_text());d=pd.DataFrame(obj['rows']);d['date']=pd.to_datetime(d.date)
 c=pd.Series(d.close.to_numpy(float),index=d.date);h=job['horizon'];s=job['symbol'];rows=[]
 for pos,i in enumerate(job['origins']):
  started=time.time();prefix=c.iloc[:i+1].copy();origin=c.index[i];end=c.index[i+h]
  row={'symbol':s,'mode':job['mode'],'horizon':h,'origin':str(origin.date()),'target_date':str(end.date()),'origin_index':i,'target_index':i+h,'period':min(2,pos*3//len(job['origins'])),'regime':E.regime(prefix),'status':'error'}
  try:
   if end>=TV.SEALED_START:raise ValueError('sealed future label accessed')
   stamp=D.session_close(s,origin)+pd.Timedelta(minutes=2)
   with clock.at(stamp):
    raw=M.forecast_horizon(prefix,s,h,fast=job['mode']=='fast')
    final=EQ._shape_meta_result(raw,h,prefix)
    final=Q.forecast(MACRO.apply(final,prefix,s,h,as_of=stamp))
   model_prob=final.get('class_probabilities')
   if E.vector(model_prob) is None:raise ValueError('Final three-state probability unavailable')
   baseline=E.baselines(prefix,h);training=baseline.pop('training')
   q=(final.get('distribution_forecast') or {}).get('quantiles') or {};interval=None
   if q.get('q10_return_pct') is not None and q.get('q90_return_pct') is not None:interval=[q['q10_return_pct']/100,q['q90_return_pct']/100]
   forecasts={'model':{'prob':model_prob,'abstain':bool(final.get('abstain')),'interval80':interval,'interval_published':bool((final.get('distribution_forecast') or {}).get('quality_ok'))}}
   for name,f in baseline.items():
    p=E.vector(f['prob']);score=.5+(p[2]-p[0])/2
    f['abstain']=bool(f.get('abstain',max(score,1-score)<.60));forecasts[name]=f
   band=TARGET.band_for_asof(prefix,h);y=float(np.log(c.iloc[i+h]/c.iloc[i]));state_y=1 if y>band else -1 if y<-band else 0
   # MOEX snapshots are close-only board history: no claim of next-open execution.
   trustworthy_open=s!='PLZL.ME' and 'open' in d
   entry=float(d.iloc[i+1]['open']) if trustworthy_open else None
   row.update(status='ok',forecasts=forecasts,realized_log_return=y,state=state_y,threshold_log=band,
    next_open_to_target_return=float(c.iloc[i+h]/entry-1) if entry and entry>0 else None,
    baseline_training=training,input_prefix_hash=D.series_hash(prefix),as_of_utc=stamp.isoformat(),
    future_access=False,confidence_status=final.get('confidence_status'),freshness=raw.get('freshness_guard',{}).get('status'),
    event_calendar_status=final.get('macro_events',{}).get('status'),signal_threshold=final.get('signal_threshold'))
  except Exception as exc:row['error']=type(exc).__name__+': '+str(exc)[:250]
  row['seconds']=round(time.time()-started,3);rows.append(row)
  print(s,h,job['mode'],pos+1,row['status'],row['seconds'],flush=True)
 return rows

# Target contract is imported independently of the forecasting pipeline.
import target_contract_v4405 as TARGET

def run(workers):
 protocol=json.loads(PROTOCOL.read_text())
 if protocol['code_hash']!=E.code_hash():raise RuntimeError('Source changed after protocol freeze; evaluation refused')
 for item in protocol['inputs']:
  if E.digest(json.loads((ROOT/item['file']).read_text()))!=item['file_hash']:raise RuntimeError('Input changed')
 if ROWS.exists():raise RuntimeError('Existing outcomes cannot silently be overwritten')
 rows=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
  futures=[pool.submit(one_job,j) for j in protocol['jobs']]
  with ROWS.open('w') as stream:
   for future in concurrent.futures.as_completed(futures):
    for row in future.result():stream.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n');rows.append(row)
    stream.flush()
 result=E.report(rows,protocol)
 (CHECKS/'stage4_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
 (ROOT/'mvp/site/evaluation_v4401014.json').write_text(json.dumps(result,ensure_ascii=False,allow_nan=False))
 print('COMPLETE',result['summary'],flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['freeze','run','report']);p.add_argument('--workers',type=int,default=3);a=p.parse_args()
 if a.action=='freeze':freeze()
 elif a.action=='run':run(a.workers)
 else:
  protocol=json.loads(PROTOCOL.read_text());rows=[json.loads(x) for x in ROWS.read_text().splitlines()]
  result=E.report(rows,protocol);(CHECKS/'stage4_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False));(ROOT/'mvp/site/evaluation_v4401014.json').write_text(json.dumps(result,ensure_ascii=False,allow_nan=False));print(result['summary'])
