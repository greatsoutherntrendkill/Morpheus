const assert=require('assert'),S=require('../mvp/site/candle_scenarios_v440107.js'),UI=require('../mvp/site/short_horizons_v4401017.js');
const candles=Array.from({length:60},(_,i)=>({t:i,o:100,c:100,h:102,l:98}));
const f={status:'ok',p_up:.6,movement_guidance:{material_move_threshold_pct:1,expected_abs_move_pct:3}};
let ends;
for(const tf of ['1min','5min','15min','30min','1h','4h','1d','1w','1mo','3mo','6mo','1y','3y']){
 const s=S.build({forecast:f,candles,tf,horizon:'10',levels:{res:[{p:103}],sup:[{p:97}]}});
 const next=s.paths.map(x=>x.end);if(ends)assert.deepEqual(next,ends);ends=next;
 assert.equal(s.pathSemantics,'conditional_illustration_not_hit_probability');
}
const h=UI.render({probability_semantics:'uncalibrated_technical_direction_score'});assert(h.includes('не вероятность'));assert(!h.includes('undefined'));assert.equal(UI.render(f),'');
assert.equal(S.build({forecast:{...f,p_up:null},candles,tf:'1h',horizon:'10'}).available,false);
console.log('PASS endpoint invariance across 13 scales, missing direction guard and intraday UI semantics');
