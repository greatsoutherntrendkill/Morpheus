const fs=require('fs'),vm=require('vm'),assert=require('assert');
const s=fs.readFileSync(process.argv[2],'utf8');
const slice=(a,b)=>s.slice(s.indexOf(a),s.indexOf(b,s.indexOf(a)));
let calls=[],pending=[];const controls={'#short-forecast-horizon':{value:'60'},'#timeframe':{value:'1h'}};
const ctx=vm.createContext({URL,DAILY_FORECAST_LABELS:{60:'60 дней'},location:{href:'http://localhost/?forecast=60'},history:{replaceState(){}},symbol:'EURUSD=X',shortForecastH:'60',shortForecastState:null,$:k=>controls[k],renderCompactForecast(){},loadProspectiveStatsV436(){},loadEvidenceReadinessV4401(){},loadSelectionStatsV437(){},isIntradayForecast:h=>h.endsWith('h'),loadDailyForecastState(sym,h){calls.push([sym,h]);return new Promise(r=>pending.push(r))},fetch:async()=>({ok:true,json:async()=>({status:'ok',p_up:.61})})});
vm.runInContext(slice('let forecastRequestId=0;','function timeframeLabel'),ctx);
(async()=>{
 const a=vm.runInContext('loadShortForecast(false)',ctx);controls['#short-forecast-horizon'].value='1';const b=vm.runInContext('loadShortForecast(false)',ctx);
 pending[1]({status:'ok',horizon:'1'});await b;pending[0]({status:'ok',horizon:'60'});await a;assert.equal(ctx.shortForecastState.horizon,'1');
 let chart=0,forecast=0;Object.assign(ctx,{refreshEnhancedSelect(){},applySelectedTimeframe(){},loadData(){chart++},loadShortForecast(){forecast++}});
 vm.runInContext(s.match(/\$\('#timeframe'\)\.onchange=.*?;\n/)[0],ctx);controls['#timeframe'].onchange();assert.equal(chart,1);assert.equal(forecast,0);assert.equal(ctx.shortForecastH,'1');
 vm.runInContext(slice('function round4','function interpolateDailyForecast'),ctx);const f=ctx.normalizeDailyForecast({p_up:.46,conditional_p_up:.46,summary:'Полный текст',class_probabilities:{up:.29,neutral:.37,down:.34}},'60');assert.equal(f.reason,'Полный текст');assert.equal(f.target,null);assert.equal(ctx.round4(null),null);assert.equal(f.class_probabilities.neutral,.37);
 console.log('PASS: late responses ignored; chart leaves horizon and forecast unchanged; full summary and probabilities preserved; missing target remains missing');
})();
