"""Descriptive event windows, not a forecast admission test or causal estimate."""
import sys,json,math,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'mvp'))
import pandas as pd
import macro_calendar_v440109 as CAL
import macro_event_model_v440109 as M
import independent_evaluation_v4401014 as E
calendar=CAL.load();events=calendar.get('events',[]);groups=[]
for p in sorted((ROOT/'checks/input_snapshots').glob('*.json')):
 o=json.loads(p.read_text());s=o['symbol']
 if s not in ('^GSPC','BTC-USD'):continue
 d=pd.DataFrame(o['rows']);c=pd.Series(d.close.to_numpy(float),index=pd.to_datetime(d.date))
 for kind in sorted({e['type'] for e in events}):
  if not M.relevant(kind,s):continue
  r=M.study(c,s,kind,events,'2026-09-18T00:00:00Z')
  groups.append({'symbol':s,**r})
for g in groups:
 g['simple_windows']={}
 for key,field in [('before','pre_day_pct'),('day','day_pct'),('after1','post_1d_pct'),('after5','post_5d_pct')]:
  values=[100*math.expm1(float(row[field])/100) for row in g['rows'] if row.get(field) is not None and math.isfinite(float(row[field]))]
  g['simple_windows'][key]={'n':len(values),'median_change_pct':statistics.median(values) if values else None,'median_abs_pct':statistics.median([abs(v) for v in values]) if values else None}
out={'scope':'descriptive_retrospective_event_windows','calendar_hash':E.digest(calendar),'events_in_archive':len(events),'as_of':'2026-09-18T00:00:00Z','groups':groups,'causal_effect':False,'admission':False,'point_in_time_consensus_available':False,'limitations':['Только S&P 500 и Bitcoin: остальные календари требуют отдельной проверки.','Возвраты: до события, за сессию события, после одной и пяти сессий. Масштаб — медиана абсолютного изменения.','Соседние события могут перекрываться; их нельзя считать независимыми экспериментами.','Архив ожиданий отсутствует; это не оценка реакции на неожиданный компонент публикации.','Время публикации в календаре может быть неполным; дневное сопоставление приблизительно.']}
(ROOT/'checks/stage6_event_study.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('Descriptive groups',len(groups),'events',len(events), 'nonempty',sum(g['event_day'].get('n',0)>0 for g in groups))

(ROOT/'mvp/site/extensions_events_v4401016.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
