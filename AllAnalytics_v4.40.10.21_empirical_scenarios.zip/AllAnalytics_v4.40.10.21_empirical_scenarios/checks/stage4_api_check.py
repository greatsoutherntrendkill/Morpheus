import json,urllib.request,urllib.parse
from pathlib import Path
base='http://127.0.0.1:8014'
report=json.load(urllib.request.urlopen(base+'/evaluation_v4401014.json',timeout=20))
assert report['summary']['attempted']==360 and report['summary']['qualified_groups']==0
rows=[]
for s,h in [('^GSPC',10),('BTC-USD',1),('PLZL.ME',60)]:
 obj=json.load(urllib.request.urlopen(base+'/api/markets/forecast?'+urllib.parse.urlencode({'symbol':s,'horizon':h}),timeout=180))
 f=obj['forecasts'][str(h)]
 assert f['model_generation'].endswith('4.40.10.14')
 assert f['confidence_score'] is None
 assert f['quality_contract_version'].endswith('4.40.10.14')
 assert abs(sum(f['class_probabilities'].values())-1)<.0001
 assert f['data_integrity']['accepted_rows']>390
 rows.append({'symbol':s,'horizon':h,'generation':f['model_generation'],'confidence_status':f['confidence_status'],'target_period':f['target_period'],'class_probabilities':f['class_probabilities']})
 print(s,h,'PASS',flush=True)
Path(__file__).with_name('stage4_api_verified.json').write_text(json.dumps({'report_served':True,'forecasts':rows},ensure_ascii=False,indent=2))
