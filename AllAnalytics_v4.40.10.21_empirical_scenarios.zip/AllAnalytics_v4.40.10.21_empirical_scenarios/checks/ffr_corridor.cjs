const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'../mvp/site'),F=require(path.join(root,'ffr_corridor_v4401010.js'));
const data=JSON.parse(fs.readFileSync(path.join(root,'data.json'))),series=data.research_monthly_v4403.rates.find(r=>r.region==='US').path;
let arcs=[],raf=[],time=0,reduced=true;
global.document={body:{}};global.getComputedStyle=()=>({getPropertyValue:k=>({'--accent':'#b7f45c','--ffr-lower':'#87bcdb','--grid':'#324236'}[k]||'')});global.devicePixelRatio=2;
global.matchMedia=()=>({matches:reduced});global.requestAnimationFrame=f=>{raf.push(f);return raf.length};global.cancelAnimationFrame=()=>{};global.performance={now:()=>time};
let selected;
function canvas(w,h,id){const ctx=new Proxy({arc:(x,y,r)=>{assert(Number.isFinite(x)&&Number.isFinite(y));assert(x-r>=0&&x+r<=w);assert(y-r>=0&&y+r<=h);arcs.push({x,y,r});}},{get:(o,k)=>o[k]||(()=>{})});return{width:0,height:0,isConnected:true,dataset:{rateChart:id},style:{},setAttribute(){},getContext:()=>ctx,getBoundingClientRect:()=>({width:w,height:h,left:0})};}
let cases=0;
for(const w of [180,320,520,1100])for(const h of [72,130,240])for(let i=0;i<series.length;i++){
 const c=canvas(w,h,`${w}-${h}`);arcs=[];assert(F.draw(c,series,series[i].month,k=>selected=k));const points=arcs.filter(x=>x.r===4.5);assert.equal(points.length,2);assert.equal(points[0].x,points[1].x);assert(points[0].y<points[1].y);
 const g=F.geometry(series,w,h);c.onclick({clientX:g.x(i)});assert.equal(selected,series[i].month);cases++;
}
// One interpolation parameter keeps both markers aligned throughout a month change.
const c=canvas(520,130,'animation');F.draw(c,series,series[0].month,()=>{});reduced=false;arcs=[];F.draw(c,series,series.at(-1).month,()=>{});
for(time=50;time<=250;time+=50){const tasks=raf;raf=[];arcs=[];tasks.forEach(f=>f(time));const pts=arcs.filter(x=>x.r===4.5);if(pts.length){assert.equal(pts[0].x,pts[1].x);assert(pts[0].y<pts[1].y);}}
const svg=F.svg(series,series[1].month,x=>x);assert.equal((svg.match(/<polyline /g)||[]).length,2);assert.equal((svg.match(/<circle /g)||[]).length,2);assert(svg.includes('Нижняя граница')&&svg.includes('Верхняя граница'));
assert(!F.valid([{value:3.75}]));assert(!F.draw(c,[{value:3.75}],'',()=>{}));
// Parse every inline application script, without running the application or browser.
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');let scripts=0;for(const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)){if(!m[1].includes('src=')&&!m[1].includes('application/')){new vm.Script(m[2]);scripts++;}}
console.log(`${cases} viewport/month combinations, synchronized animation, SVG export and ${scripts} inline scripts passed.`);
