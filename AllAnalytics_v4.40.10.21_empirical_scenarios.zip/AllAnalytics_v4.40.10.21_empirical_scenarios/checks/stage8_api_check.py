import json,urllib.request,urllib.parse,time,concurrent.futures
from pathlib import Path
out=Path(__file__).with_name('stage8_api.json')
cases=[('BTC-USD',h) for h in ['30m','1h','2h','4h','1','3','5','10','20','30','60']]+[(s,'10') for s in ['^GSPC','EURUSD=X','GC=F','CL=F','ES=F','AAPL','PLZL.ME']]
def run(case):
 s,h=case;t=time.time();path='/api/forecast/short' if h.endswith(('m','h')) else '/api/markets/forecast'
 try:
  with urllib.request.urlopen('http://127.0.0.1:8018'+path+'?'+urllib.parse.urlencode({'symbol':s,'horizon':h,'force':0}),timeout=150) as r:j=json.load(r)
  f=j if path.endswith('short') else j.get('forecasts',{}).get(h,{})
  return dict(symbol=s,horizon=h,seconds=round(time.time()-t,2),status=f.get('status',j.get('status')),p_up=f.get('p_up'),movement_guidance=f.get('movement_guidance'),probability_semantics=f.get('probability_semantics'),reason=f.get('reason',f.get('summary')),received=bool(f))
 except Exception as e:return dict(symbol=s,horizon=h,error=str(e),seconds=round(time.time()-t,2))
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for r in ex.map(run,cases):
  rows.append(r);out.write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(r['symbol'],r['horizon'],r.get('status'),r.get('error',''),flush=True)
