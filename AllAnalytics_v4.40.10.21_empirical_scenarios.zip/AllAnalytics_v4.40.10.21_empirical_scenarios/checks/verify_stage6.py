import json,sys,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'mvp'))
import independent_evaluation_v4401014 as E
p=json.loads((ROOT/'checks/stage6_protocol.json').read_text());r=json.loads((ROOT/'checks/stage6_results.json').read_text());rows=[json.loads(x) for x in (ROOT/'checks/stage6_predictions.jsonl').read_text().splitlines()]
assert p['code_hash']==E.code_hash() and r['source_hash']==p['code_hash']
assert r['protocol_hash']==E.digest(p)
for v in p['inputs'].values():assert E.digest(json.loads((ROOT/v['file']).read_text()))==v['hash']
planned={(j['symbol'],j['horizon'],j['variant'],i) for j in p['jobs'] for i in j['origins']}
actual={(x['symbol'],x['horizon'],x['variant'],x['origin_index']) for x in rows}
assert actual==planned and len(rows)==len(planned)==900 and r['complete']
for x in rows:
 assert x['target_date']<p['sealed_start'] and x['target_index']-x['origin_index']==x['horizon']
 if x['status']!='ok':continue
 b,l=E.losses([E.vector(x['prob'])],[x['state']]);assert abs(b[0]-x['brier'])<1e-12 and abs(l[0]-x['log_loss'])<1e-12
 expected=1 if x['realized_log_return']>x['threshold_log'] else -1 if x['realized_log_return']<-x['threshold_log'] else 0
 assert x['state']==expected and not x['source_archive_verified']
assert len(r['groups'])==60 and all(not x['admitted'] for x in r['groups'])
assert json.loads((ROOT/'mvp/site/extensions_results_v4401016.json').read_text())==r
print('PASS 900 scheduled results; all probability losses, outcomes, input hashes, code hash, protocol hash, untouched boundary and all 60 non-admission decisions')
