"""Audit actual released evaluation files, including failed calculation coverage."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'mvp'))
import independent_evaluation_v4401014 as E
p=json.loads((root/'checks/stage4_protocol.json').read_text())
r=json.loads((root/'checks/stage4_results.json').read_text())
rows=[json.loads(line) for line in (root/'checks/stage4_predictions.jsonl').read_text().splitlines()]
assert p['code_hash']==E.code_hash(root/'mvp')
assert r['protocol_hash']==E.digest(p)
assert r['criteria']==p['criteria']==E.CRITERIA
expected={(j['symbol'],j['horizon'],j['mode'],i) for j in p['jobs'] for i in j['origins']}
actual={(j['symbol'],j['horizon'],j['mode'],j['origin_index']) for j in rows}
assert len(rows)==len(actual) and expected==actual
for item in p['inputs']:assert E.digest(json.loads((root/item['file']).read_text()))==item['file_hash']
for row in rows:
 assert pd.Timestamp(row['target_date'])<pd.Timestamp(p['sealed_start'])
 if row['status']!='ok':assert row.get('error');continue
 assert pd.Timestamp(row['baseline_training']['label_end_max'])<pd.Timestamp(row['origin'])
 assert row['freshness']=='fresh'
 for name in ('model',*E.BASELINES):assert E.vector(row['forecasts'][name]['prob']) is not None
for g in r['groups']:
 subset=[x for x in rows if (x['symbol'],x['horizon'],x['mode'])==(g['symbol'],g['horizon'],g['mode'])]
 good=[x for x in subset if x['status']=='ok']
 assert g['attempted']==len(subset) and g['paired']==len(good)
 # Independent Brier re-calculation from stored forecasts/outcomes.
 loss=[]
 for x in good:
  pp=[x['forecasts']['model']['prob'][n] for n in E.CLASSES];pp=np.asarray(pp)/sum(pp)
  yy=np.eye(3)[x['state']+1];loss.append(float(np.sum((pp-yy)**2)))
 assert abs(np.mean(loss)-g['metrics']['model']['brier'])<1e-12
 assert g['nonoverlap']<=g['paired']
 assert not g['passed'] and not g['automatic_promotion']
 assert 'historical_development_only' in g['reasons']
 for strategy in g['execution'].values():
  for variant in strategy:
   trades=variant['trades']
   for t in trades:assert abs(t['gross']-t['net']-variant['roundtrip_cost_bps']/10000)<1e-12
   for a,b in zip(trades,trades[1:]):assert a['exit']<b['origin']
assert r['summary']['attempted']==len(rows)
assert r['summary']['qualified_groups']==0
assert json.loads((root/'mvp/site/evaluation_v4401014.json').read_text())==r
print('PASS: protocol, source/input hashes, all planned origins, strict label times, independent Brier recalculation, execution costs/non-overlap, no false promotion, published JSON match')
print(r['summary'])
