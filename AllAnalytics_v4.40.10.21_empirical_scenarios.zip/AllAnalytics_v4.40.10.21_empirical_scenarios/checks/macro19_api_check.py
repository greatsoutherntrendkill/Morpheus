import urllib.request,json,math
from pathlib import Path
results=[]
for path in ['/api/macro-policy/v19','/api/research/monthly-v4403','/api/research/monthly-v4404','/api/research/outlook']:
 with urllib.request.urlopen('http://127.0.0.1:8019'+path,timeout=30) as r:b=json.load(r)
 assert b['version']=='macro-policy-trained-19.5'
 assert len(b['forecasts'])==21
 for f in b['forecasts']:
  assert f['status']=='ok'
  assert all(math.isfinite(f[k]) for k in ('value','lower','upper'))
  assert f['lower']<=f['value']<=f['upper']
  if f['publication_reason']=='candidate_failed_holdout':assert f['value']==f['baseline'] and f['model']=='persistence'
 for h in (1,2,3):
  lo=next(f for f in b['forecasts'] if f['series']=='DFEDTARL' and f['horizon']==h)
  hi=next(f for f in b['forecasts'] if f['series']=='DFEDTARU' and f['horizon']==h)
  assert lo['value']<hi['value'] and lo['period']==hi['period']
 assert all(s['resolved']==0 for s in b['journal']['summary'])
 results.append(dict(endpoint=path,forecasts=21,valid=True,gated=sum(f['publication_reason']=='candidate_failed_holdout' for f in b['forecasts'])))
with urllib.request.urlopen('http://127.0.0.1:8019/data.json',timeout=30) as r:b=json.load(r)
assert not b['research_monthly_v4403']['rates'] and not b['research_outlook_v46']['rates']
Path(__file__).with_name('macro19_api.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results))
