# AllAnalytics v4.40.9 — Model Correctness

v4.40.9 is a correctness release. It deliberately keeps the v4.40.8 three-state target and data-driven routing design unchanged, while fixing four concrete production inconsistencies.

## 1. Real soft-regime routing

`regime_models_v37.RegimeMoE` already contained continuous routing logic, but train/OOS/live prediction calls did not pass `risk_score`, so the router silently defaulted to `0.0` and behaved close to the `mixed` regime. v4.40.9 passes point-in-time `risk_score` through development OOS, frozen live fit, live forecasts and frozen holdout evaluation.

## 2. Quality-aware Directional ↔ Distribution gate

A distribution forecast may now affect directional confidence only when all conditions are met:

- `status == ok`;
- `quality_ok == true`;
- dependence-aware / conservative effective sample is at least the minimum required by the robustness gate.

An unqualified distribution remains visible for diagnostics but its consistency result is `action=none`. Fast empirical distribution forecasts now report a conservative non-overlap `effective_n` and cannot pass quality with an insufficient effective sample.

## 3. Absolute zero influence for unapproved challengers

`weight == 0` now means literal diagnostic-only behavior for both asset specialists and Event Response. Without prospective validation + explicit approval, a challenger cannot change:

- `p_up` / conditional direction;
- `P(move)` / `P(neutral)`;
- class probabilities;
- signal threshold;
- abstention / `NO EDGE`;
- signal strength.

The base production decision fields are passed through unchanged.

## 4. Feature freshness/staleness contract

A new `freshness_contract_v4409.py` provides source-class-specific age metadata and bounded forward fill.

- market/DXY/peer factors: maximum 5 target-index rows of carry-forward;
- slower macro factors: bounded 45-row carry-forward;
- each source carries `age_days`, last observation, warning/hard thresholds and missing/stale flags;
- hard-stale benchmark/context factors are excluded from cross-sectional calculations;
- specialist market matrices use bounded fill rather than unlimited `.ffill()`;
- the robustness guard consumes freshness metadata emitted by the actual feature/context layer, not only optional caller metadata.

## Identity / evidence isolation

- Model version: `model-correctness-v4.40.9`
- Model generation: `directional-3state-move-correctness-v4.40.9`
- Forecast contract: `forecast-contract-v4.40.9`
- Cache contract: `forecast-cache-v4.40.9`

The target definition itself is unchanged, but generation isolation prevents v4.40.8 prospective decisions from being silently treated as identical to the corrected v4.40.9 production stack.
