import pandas as pd
import pytest
import equity_forecast_v416 as E

@pytest.mark.parametrize('symbol',['^GSPC','GC=F','BTC-USD','EURUSD=X'])
@pytest.mark.parametrize('horizon',[1,5,10,20,30,60])
def test_daily_requests_model_history(monkeypatch,symbol,horizon):
    frame=pd.DataFrame({'date':pd.date_range('2020-01-01',periods=800),'open':100.,'high':101.,'low':99.,'close':100.})
    calls=[]
    def history(sym,long_history=False):
        calls.append(long_history)
        return E.MD41.MarketResult(sym,frame,'test',[])
    monkeypatch.setattr(E.MD41,'fetch_history',history)
    monkeypatch.setattr(E.META435,'forecast_horizon',lambda *a,**k:{'p_up':.6,'reliability':{'probability':.57}})
    monkeypatch.setattr(E.MOVEGUIDE440102,'build',lambda *a,**k:{})
    row=E.forecast_fast(symbol,(horizon,),force=True)
    assert calls==[True]
    assert row['forecasts'][str(horizon)]['confidence_score']==.57
    assert 'scenario fallback' not in row['model']

def test_short_history_does_not_invent_confidence(monkeypatch):
    frame=pd.DataFrame({'date':pd.date_range('2020-01-01',periods=100),'open':100.,'high':101.,'low':99.,'close':100.})
    monkeypatch.setattr(E.MD41,'fetch_history',lambda *a,**k:E.MD41.MarketResult('^GSPC',frame,'test',[]))
    monkeypatch.setattr(E.META435,'forecast_horizon',lambda *a,**k:pytest.fail('short history must not reach model'))
    row=E.forecast_fast('^GSPC',(1,),force=True)
    f=row['forecasts']['1']
    assert f.get('confidence_score') is None
    assert 'в фоне' not in f['summary']
