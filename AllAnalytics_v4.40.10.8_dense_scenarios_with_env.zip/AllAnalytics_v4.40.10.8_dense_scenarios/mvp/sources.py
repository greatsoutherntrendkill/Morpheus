"""
Загрузчики данных из бесплатных источников. Каждый возвращает DataFrame
и умеет падать мягко (вернуть пустой df + напечатать причину), чтобы один
сбойный источник не ронял весь апдейт.
"""
import os
import io
import numpy as np
import pandas as pd
import requests
import time
import moex_fast_v418 as MOEX418

TIMEOUT = 30


# ---------------------------------------------------------------------------
# yfinance — цены (без ключа)
# ---------------------------------------------------------------------------
def fetch_yf(symbol: str, period="5y") -> pd.DataFrame:
    import yfinance as yf
    try:
        raw = yf.download(symbol, period=period, interval="1d",
                          progress=False, auto_adjust=True)
        if raw is None or raw.empty:
            print(f"  [yf] {symbol}: пусто")
            return pd.DataFrame(columns=["date", "open", "high", "low", "close"])
        cols = {}
        for src, dst in (("Open", "open"), ("High", "high"),
                         ("Low", "low"), ("Close", "close")):
            s = raw[src]
            if isinstance(s, pd.DataFrame):
                s = s.iloc[:, 0]
            cols[dst] = s.values
        out = pd.DataFrame(cols, index=raw.index).reset_index()
        out = out.rename(columns={out.columns[0]: "date"})
        out = out.dropna(subset=["close"]).sort_values("date").drop_duplicates("date", keep="last")
        for c in ("open", "high", "low", "close"): out[c] = pd.to_numeric(out[c], errors="coerce")
        out = out.dropna(subset=["open", "high", "low", "close"])
        out["high"] = out[["high", "open", "close"]].max(axis=1)
        out["low"] = out[["low", "open", "close"]].min(axis=1)
        if not validate_price_frame(out):
            print(f"  [yf] {symbol}: данные не прошли проверку качества/свежести")
            return pd.DataFrame(columns=["date", "open", "high", "low", "close"])
        return out
    except Exception as e:
        print(f"  [yf] {symbol}: ошибка {e}")
        return pd.DataFrame(columns=["date", "open", "high", "low", "close"])



def validate_price_frame(df: pd.DataFrame, min_rows: int = 120, max_stale_days: int = 12) -> bool:
    if df is None or df.empty or len(df) < min_rows:
        return False
    try:
        d = df.copy(); d["date"] = pd.to_datetime(d["date"], errors="coerce")
        for c in ("open", "high", "low", "close"): d[c] = pd.to_numeric(d[c], errors="coerce")
        d = d.dropna(subset=["date", "open", "high", "low", "close"]).sort_values("date")
        if len(d) < min_rows or (d[["open", "high", "low", "close"]] <= 0).any().any(): return False
        if (d["high"] < d[["open", "close"]].max(axis=1)).any(): return False
        if (d["low"] > d[["open", "close"]].min(axis=1)).any(): return False
        age = (pd.Timestamp.today().normalize() - d["date"].iloc[-1].normalize()).days
        return age <= max_stale_days
    except Exception:
        return False


def compute_cross(num: pd.DataFrame, den: pd.DataFrame) -> pd.DataFrame:
    """Кросс = num/den по совпадающим датам.

    Для дневного OHLC используем корректные границы отношения:
    high ~= numerator_high / denominator_low,
    low  ~= numerator_low / denominator_high.
    Это всё ещё дневное приближение: точный high/low кросса требует синхронных intraday данных.
    """
    if num.empty or den.empty:
        return pd.DataFrame(columns=["date", "open", "high", "low", "close"])
    a = num.set_index("date")
    b = den.set_index("date")
    idx = a.index.intersection(b.index)
    if len(idx) == 0:
        return pd.DataFrame(columns=["date", "open", "high", "low", "close"])
    out = pd.DataFrame(index=idx)
    out["close"] = a.loc[idx, "close"] / b.loc[idx, "close"]
    if {"open"} <= set(a.columns) and {"open"} <= set(b.columns):
        out["open"] = a.loc[idx, "open"] / b.loc[idx, "open"]
    else:
        out["open"] = out["close"]
    if {"high", "low"} <= set(a.columns) and {"high", "low"} <= set(b.columns):
        out["high"] = a.loc[idx, "high"] / b.loc[idx, "low"]
        out["low"] = a.loc[idx, "low"] / b.loc[idx, "high"]
    else:
        out["high"] = out[["open", "close"]].max(axis=1)
        out["low"] = out[["open", "close"]].min(axis=1)
    return out[["open", "high", "low", "close"]].dropna(subset=["close"]).reset_index().rename(columns={"index": "date"})


# ---------------------------------------------------------------------------
# MOEX ISS — российские индексы (без ключа)
# ---------------------------------------------------------------------------
def fetch_moex_index(secid: str, start="2018-01-01") -> pd.DataFrame:
    """История индекса: SNDX candles primary, legacy history fallback."""
    fast=MOEX418.candles(secid,market="index",board="SNDX",years=5)
    if fast is not None and not fast.empty:
        return fast
    url = (f"https://iss.moex.com/iss/history/engines/stock/markets/index/"
           f"securities/{secid}.json")
    rows, pos = [], 0
    try:
        while True:
            r = requests.get(url, params={"from": start, "start": pos}, timeout=TIMEOUT)
            r.raise_for_status()
            block = r.json()["history"]
            cols, data = block["columns"], block["data"]
            if not data:
                break
            ci = {name: cols.index(name) for name in ("TRADEDATE", "OPEN", "HIGH", "LOW", "CLOSE") if name in cols}
            if "TRADEDATE" not in ci or "CLOSE" not in ci:
                break
            for row in data:
                c = row[ci["CLOSE"]]
                if c is None:
                    continue
                o = row[ci["OPEN"]] if "OPEN" in ci and row[ci["OPEN"]] is not None else c
                h = row[ci["HIGH"]] if "HIGH" in ci and row[ci["HIGH"]] is not None else max(o, c)
                lo = row[ci["LOW"]] if "LOW" in ci and row[ci["LOW"]] is not None else min(o, c)
                rows.append((row[ci["TRADEDATE"]], o, h, lo, c))
            pos += len(data)
            if len(data) < 100:
                break
        return pd.DataFrame(rows, columns=["date", "open", "high", "low", "close"]).dropna(subset=["close"])
    except Exception as e:
        print(f"  [moex] {secid}: ошибка {e}")
        return pd.DataFrame(columns=["date", "open", "high", "low", "close"])




# ---------------------------------------------------------------------------
# MOEX ISS — акции Московской биржи (без ключа)
# ---------------------------------------------------------------------------
def fetch_moex_security(secid: str, start="2018-01-01", board="TQBR") -> pd.DataFrame:
    """Дневная история акции MOEX ISS; fast candles primary, history fallback."""
    secid=str(secid or "").upper().replace(".ME","")
    fast=MOEX418.candles(secid,market="shares",board=board,years=5)
    if fast is not None and not fast.empty:
        return fast
    urls=[
        f"https://iss.moex.com/iss/history/engines/stock/markets/shares/boards/{board}/securities/{secid}.json",
        f"https://iss.moex.com/iss/history/engines/stock/markets/shares/securities/{secid}.json",
    ]
    for url in urls:
        rows=[]; pos=0
        try:
            while True:
                r=requests.get(url,params={"from":start,"start":pos,"iss.meta":"off"},timeout=TIMEOUT)
                r.raise_for_status(); block=(r.json() or {}).get("history") or {}
                cols,data=block.get("columns") or [],block.get("data") or []
                if not data: break
                ci={name:cols.index(name) for name in ("TRADEDATE","OPEN","HIGH","LOW","CLOSE","LEGALCLOSEPRICE") if name in cols}
                if "TRADEDATE" not in ci: break
                for row in data:
                    c=None
                    for key in ("CLOSE","LEGALCLOSEPRICE"):
                        if key in ci and row[ci[key]] is not None:
                            c=row[ci[key]]; break
                    if c is None: continue
                    o=row[ci["OPEN"]] if "OPEN" in ci and row[ci["OPEN"]] is not None else c
                    h=row[ci["HIGH"]] if "HIGH" in ci and row[ci["HIGH"]] is not None else max(o,c)
                    lo=row[ci["LOW"]] if "LOW" in ci and row[ci["LOW"]] is not None else min(o,c)
                    rows.append((row[ci["TRADEDATE"]],o,h,lo,c))
                pos+=len(data)
                if len(data)<100: break
            if rows:
                return pd.DataFrame(rows,columns=["date","open","high","low","close"]).dropna(subset=["close"])
        except Exception as e:
            print(f"  [moex-share] {secid}: ошибка {e}")
    return pd.DataFrame(columns=["date","open","high","low","close"])


def fetch_moex_security_snapshot(secid: str, board="TQBR") -> dict:
    """Текущий snapshot одной акции через общий v4.18 board cache."""
    secid=str(secid or "").upper().replace(".ME","")
    row=MOEX418.get_snapshot([secid], market="shares").get(secid) or {}
    if not row:
        return {}
    return {"last":row.get("last"),"chg1d":row.get("chg1d"),"time":row.get("time"),
            "name":row.get("name"),"prev":row.get("prev"),"source":row.get("source"),
            "stale":row.get("stale",False)}


# ---------------------------------------------------------------------------
# MOEX ISS — пакетный live snapshot для российских акций и индексов
# ---------------------------------------------------------------------------
_MOEX_BATCH_CACHE = {}

def _moex_block_rows(block):
    cols=(block or {}).get("columns") or []
    data=(block or {}).get("data") or []
    return [{cols[i]: row[i] for i in range(min(len(cols),len(row)))} for row in data]

# Endpoint shape retained in v4.18 adapter: /iss/engines/stock/markets/{market}/boards/{board}/securities.json
def fetch_moex_market_snapshot_batch(secids, market="shares", board="TQBR", ttl=10) -> dict:
    """v4.18: компактный пакетный ISS-контур с persistent last-good cache."""
    kind = "shares" if str(market).lower() == "shares" else "index"
    return MOEX418.get_snapshot(secids, market=kind, force=False)


# ---------------------------------------------------------------------------
# FRED — макро США/РФ (нужен бесплатный ключ FRED_API_KEY)
# ---------------------------------------------------------------------------
def fetch_fred(series_id: str, api_key: str, start="2015-01-01") -> pd.DataFrame:
    if not api_key:
        return pd.DataFrame(columns=["date", "value"])
    url = "https://api.stlouisfed.org/fred/series/observations"
    try:
        r = requests.get(url, timeout=TIMEOUT, params={
            "series_id": series_id, "api_key": api_key,
            "file_type": "json", "observation_start": start})
        r.raise_for_status()
        obs = r.json().get("observations", [])
        df = pd.DataFrame(obs)[["date", "value"]]
        df["value"] = pd.to_numeric(df["value"], errors="coerce")
        return df.dropna()
    except Exception as e:
        print(f"  [fred] {series_id}: ошибка {e}")
        return pd.DataFrame(columns=["date", "value"])


# ---------------------------------------------------------------------------
# CBR — ключевая ставка ЦБ РФ (без ключа), для автообновления строки "Россия"
# ---------------------------------------------------------------------------
def fetch_cbr_key_rate_series(start="2015-01-01") -> pd.DataFrame:
    """Историю ключевой ставки ЦБ РФ с cbr.ru (SOAP KeyRateXML). df[date,value]."""
    url = "https://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx"
    body = ('<?xml version="1.0" encoding="utf-8"?>'
            '<soap12:Envelope xmlns:soap12='
            '"http://www.w3.org/2003/05/soap-envelope">'
            '<soap12:Body><KeyRateXML xmlns="http://web.cbr.ru/">'
            f'<fromDate>{start}</fromDate>'
            '<ToDate>2035-01-01</ToDate></KeyRateXML>'
            '</soap12:Body></soap12:Envelope>')
    try:
        r = requests.post(url, data=body.encode(), timeout=TIMEOUT,
                          headers={"Content-Type":
                                   "application/soap+xml; charset=utf-8"})
        r.raise_for_status()
        df = pd.read_xml(io.StringIO(r.text), xpath=".//KR")
        out = pd.DataFrame({"date": pd.to_datetime(df["DT"]),
                            "value": pd.to_numeric(df["Rate"], errors="coerce")})
        return out.dropna().sort_values("date")
    except Exception as e:
        print(f"  [cbr] история ключевой ставки: ошибка {e}")
        return pd.DataFrame(columns=["date", "value"])


def fetch_cbr_key_rate() -> float | None:
    """Последнее значение ключевой ставки ЦБ РФ. None при сбое."""
    s = fetch_cbr_key_rate_series()
    return None if s.empty else float(s.iloc[-1]["value"])


# ---------------------------------------------------------------------------
# DEMO — синтетика, чтобы дашборд заработал офлайн без единого запроса в сеть
# ---------------------------------------------------------------------------
def demo_price(symbol: str, n=600, seed=0) -> pd.DataFrame:
    rng = np.random.default_rng(abs(hash(symbol)) % (2**32) + seed)
    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=n)
    m = len(dates)                    # анкерный диапазон может вернуть на 1 меньше
    base = {"BTC-USD": 80000, "ETH-USD": 2500, "GC=F": 4400, "^GSPC": 7700,
            "^NDX": 29000, "^GDAXI": 26000, "DX-Y.NYB": 99, "ES=F": 7750,
            "NQ=F": 29600, "EURUSD=X": 1.16, "GBPUSD=X": 1.35,
            "RUB=X": 86, "CNY=X": 7.1}.get(symbol, 100.0)
    mu, sigma = 0.0002, 0.012
    steps = rng.normal(mu, sigma, m)
    close = base * np.exp(np.cumsum(steps))
    open_ = np.r_[close[0], close[:-1]]                       # открытие = вчерашнее закрытие
    span = np.abs(rng.normal(0, sigma, m)) * close            # внутридневной размах
    high = np.maximum(open_, close) + span
    low = np.minimum(open_, close) - span
    return pd.DataFrame({"date": dates, "open": open_, "high": high,
                         "low": low, "close": close})


def demo_macro(series: str, n=120) -> pd.DataFrame:
    rng = np.random.default_rng(abs(hash(series)) % (2**32))
    dates = pd.date_range(end=pd.Timestamp.today().normalize(),
                          periods=n, freq="MS")
    m = len(dates)  # анкерная частота может вернуть на 1 меньше — берём фактическую длину
    level = {"FEDFUNDS": 3.6, "UNRATE": 4.2, "DGS10": 4.1,
             "IR3TIB01EZM156N": 2.4, "IR3TIB01GBM156N": 4.0,
             "IR3TIB01JPM156N": 0.8, "CBR_KEYRATE": 15.0,
             "VIXCLS": 18.0, "T10Y2Y": 0.4, "UMCSENT": 65.0,
             "PAYEMS": 158000.0, "INDPRO": 103.0}.get(series, 100.0)
    walk = level + np.cumsum(rng.normal(0, 0.05, m))
    return pd.DataFrame({"date": dates, "value": walk})
