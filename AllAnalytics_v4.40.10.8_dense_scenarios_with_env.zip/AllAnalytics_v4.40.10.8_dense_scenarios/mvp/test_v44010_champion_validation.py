import json
import sqlite3
from pathlib import Path
import numpy as np
import pandas as pd

import champion_validation_v44010 as CV
import sealed_shadow_v44010 as SH
import persistent_state_v44010 as PS
import event_response_v439 as EV
import prospective_selection_v437 as SEL
import forecast_contract_v4406 as FC


def test_champion_solver_selects_only_from_chronological_tail():
    rng=np.random.default_rng(10); n=260
    x=rng.normal(size=(n,5)); z=.8*x[:,0]-.5*x[:,1]+rng.normal(scale=.8,size=n)
    y=(z>0).astype(int)
    dates=pd.date_range('2023-01-01',periods=n,freq='D')
    label=dates+pd.Timedelta(days=5)
    m,d=CV.fit_chronological_selected(x,y,dates=dates,label_ends=label,min_fit=80,min_validation=30)
    assert d['solver']==CV.SOLVER_VERSION
    assert d['selected_c'] in CV.C_GRID
    assert d['purged_inner_split'] is True
    assert 0 < m.proba(x[-3:]).min() < 1


def test_shadow_slice_is_reserved_from_training(monkeypatch):
    monkeypatch.setenv('ALLANALYTICS_SHADOW_START','2026-09-15')
    rows=[]
    for i in range(60):
        rows.append({'forecast_key':f'k{i}','data_as_of':'2026-10-01','symbol':'AAPL','horizon':10})
    sh=SH.shadow_rows(rows); tr=SH.training_rows(rows)
    assert sh and tr
    assert len(sh)+len(tr)==len(rows)
    assert all(x not in tr for x in sh)


def test_persistent_governance_path_can_migrate_legacy(tmp_path,monkeypatch):
    legacy=tmp_path/'legacy.sqlite3'; dst=tmp_path/'persistent.sqlite3'
    con=sqlite3.connect(legacy); con.execute('create table t(x int)');con.execute('insert into t values(7)');con.commit();con.close()
    assert PS.migrate_sqlite_once(legacy,dst) is True
    assert PS.migrate_sqlite_once(legacy,dst) is False
    con=sqlite3.connect(dst); assert con.execute('select x from t').fetchone()[0]==7;con.close()


def test_event_archive_persists_to_sqlite(tmp_path,monkeypatch):
    monkeypatch.setattr(EV,'EVENT_DB_PATH',tmp_path/'events.sqlite3')
    monkeypatch.setattr(EV,'ARCHIVE_PATH',tmp_path/'missing.json')
    monkeypatch.delenv('PYTEST_CURRENT_TEST',raising=False)
    rows=[{'date':'2026-09-16','event':'FOMC rate decision','actual_bp':0,'expected_bp':0,'source':'test'}]
    out=EV.sync_event_archive(rows,persist=True)
    assert any(x.get('type')=='fed_rate' for x in out)
    loaded=EV._load_archive()
    assert any(x.get('type')=='fed_rate' for x in loaded)


def test_generation_is_v44010():
    assert FC.MODEL_GENERATION.endswith('v4.40.10')
    assert FC.CACHE_CONTRACT_VERSION.endswith('v4.40.10')

def test_regime_moe_can_learn_internal_weights(monkeypatch):
    import regime_models_v37 as R
    class Dummy:
        def __init__(self,seed): self.seed=seed
        def fit(self,X,y): return self
        def proba(self,X):
            X=np.asarray(X,float)
            col=0 if self.seed==370 else (1 if 371<=self.seed<390 else 2)
            z=np.clip(X[:,col],-6,6)
            return 1/(1+np.exp(-z))
        def coef_abs(self): return np.array([1/3,1/3,1/3])
    monkeypatch.setattr(R,'FastExpert',Dummy)
    monkeypatch.setitem(R.LOCKED_CONFIG,'min_class_rows',80)
    monkeypatch.setitem(R.LOCKED_CONFIG,'min_regime_rows',80)
    rng=np.random.default_rng(77); n=1600
    X=rng.normal(size=(n,3)); y=(X[:,2]+rng.normal(scale=.25,size=n)>0).astype(float)
    dates=pd.date_range('2020-01-01',periods=n,freq='D'); label=dates+pd.Timedelta(days=5)
    meta=pd.DataFrame({'expert_class':['equities']*n,'risk_regime':['risk_on']*n,'risk_score':[.75]*n})
    m=R.RegimeMoE(['a','b','c']).fit(X,y,meta,dates=dates,label_ends=label)
    assert abs(sum(m.weights.values())-1)<1e-9
    assert m.weight_selection['version']=='regime-moe-weights-v4.40.10'
    assert m.weight_selection['validation_n']>0
    assert m.weights['regime'] >= .20
