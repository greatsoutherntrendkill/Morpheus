import numpy as np
import pandas as pd

import routing_policy_v4408 as R
import forecast_contract_v4406 as FC


def test_oos_blend_weight_is_learned_and_recently_validated():
    n=90
    y=np.asarray(([0,1]*45),float)
    # Component A is strong, B points the wrong way.
    a=np.where(y==1,.78,.22); b=np.where(y==1,.42,.58)
    df=pd.DataFrame({'a':a,'b':b,'y':y})
    out=R.fit_oos_blend(df,'a','b','y')
    assert out['learned'] is True
    assert out['weight_a'] > .8
    assert out['validation_brier'] < out['equal_weight_brier']


def test_oos_blend_falls_back_to_equal_weight_without_enough_evidence():
    df=pd.DataFrame({'a':[.7]*10,'b':[.3]*10,'y':[1,0]*5})
    out=R.fit_oos_blend(df,'a','b','y')
    assert out['learned'] is False
    assert out['weight_a']==.5 and out['weight_b']==.5


class _Ledger:
    def __init__(self,rows): self._rows=rows
    def rows(self,**kwargs): return list(self._rows)


def _row(i,good):
    # Same headline confidence; event_risk is what determines whether the live
    # directional call historically deserved publication.
    date=pd.Timestamp('2025-01-02')+pd.Timedelta(days=i)
    return {
        'target_as_of':str(date.date()),'data_as_of':str(date.date()),'target_version':'volatility-adjusted-3state-v4.40.5',
        'model_generation':'directional-3state-move-robust-v4.40.7','conditional_p_up':.75,'p_move':.82,'reliability':.62,
        'outcome':'up' if good else 'down',
        'components':[{'name':'production','conditional_p_up':.74},{'name':'vol_regime','conditional_p_up':.76}],
        'context':{'event_risk':0.0 if good else 1.0,'context_disagreement':False,'feature_drift':{'score':.1}},
    }


def test_prospective_router_waits_for_sample():
    rows=[_row(i,i%2==0) for i in range(20)]
    out=R.prospective_publish_router(symbol='AAPL',horizon=10,live={
        'conditional_p_up':.75,'p_move':.82,'disagreement':.02,'drift':.1,'event_risk':0,'context_disagreement':False,'reliability':.62,
    },ledger=_Ledger(rows),window_days=3650)
    assert out['active'] is False
    assert out['reason']=='collecting_prospective_evidence'


def test_prospective_router_can_learn_event_sensitive_publish_policy():
    rows=[_row(i,(i%4)!=0) for i in range(120)]
    out=R.prospective_publish_router(symbol='AAPL',horizon=10,live={
        'conditional_p_up':.75,'p_move':.82,'disagreement':.02,'drift':.1,'event_risk':0,'context_disagreement':False,'reliability':.62,
    },ledger=_Ledger(rows),window_days=3650)
    assert out['validated'] is True
    assert out['active'] is True
    assert out['router_brier'] <= out['baseline_brier']
    assert out['publish_threshold'] >= .5


def test_v4408_contract_changes_generation_and_cache_identity():
    assert FC.MODEL_GENERATION.endswith('v4.40.10')
    assert FC.CACHE_CONTRACT_VERSION.endswith('v4.40.10')
    assert 'routing' in FC.PROBABILITY_SEMANTICS_VERSION


def test_old_generation_approval_does_not_carry_forward():
    import prospective_selection_v437 as sel
    import target_contract_v4405 as target
    old = {"decision": "approve", "report": {"model_generation": "old-generation", "target_version": target.TARGET_VERSION}}
    current = {"decision": "approve", "report": {"model_generation": sel.CURRENT_MODEL_GENERATION, "target_version": sel.CURRENT_TARGET_VERSION}}
    assert sel._review_approves_current_generation(old) is False
    assert sel._review_approves_current_generation(current) is True
