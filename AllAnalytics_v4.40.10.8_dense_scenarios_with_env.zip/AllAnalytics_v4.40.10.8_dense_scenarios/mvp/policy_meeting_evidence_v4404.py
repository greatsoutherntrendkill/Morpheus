"""Persistent point-in-time evidence for future Fed/CBR meeting models.

v4.40.4 intentionally does not backfill historical meeting features from today's
revised macro data.  Instead it starts an append-only pre-meeting snapshot ledger
that survives code releases.  Outcomes can be settled shortly after a meeting
from the observed current policy rate; only then may these rows later enter a
trained meeting-level classifier.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json
import os
import sqlite3

import pandas as pd

VERSION="policy-meeting-evidence-v4.40.4"
DEFAULT_DB=Path(os.getenv("ALLANALYTICS_POLICY_EVIDENCE_DB") or (Path.home()/"AllAnalytics_Data"/"evidence"/"policy_meeting_evidence.sqlite3"))


def _now():
    return datetime.now(timezone.utc).isoformat()


def _connect(path=None):
    p=Path(path or DEFAULT_DB);p.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(p,timeout=5);con.row_factory=sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL");con.execute("PRAGMA busy_timeout=5000")
    con.executescript("""
    CREATE TABLE IF NOT EXISTS meeting_snapshots(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at TEXT NOT NULL,
      model_generation TEXT NOT NULL,
      region TEXT NOT NULL,
      meeting_date TEXT NOT NULL,
      snapshot_date TEXT NOT NULL,
      current_rate REAL NOT NULL,
      inflation REAL,
      labor REAL,
      growth REAL,
      news_hawk REAL,
      geo_risk REAL,
      scenario_hike REAL,
      scenario_hold REAL,
      scenario_cut REAL,
      context_json TEXT,
      settled INTEGER NOT NULL DEFAULT 0,
      realized_rate REAL,
      realized_action TEXT,
      settled_at TEXT,
      settlement_source TEXT,
      UNIQUE(model_generation,region,meeting_date,snapshot_date)
    );
    CREATE INDEX IF NOT EXISTS idx_policy_meeting_scope ON meeting_snapshots(region,meeting_date,settled);
    """);con.commit();return con


def _macro_for(outlook,region,month):
    vals={}
    for row in outlook.get("macro") or []:
        if row.get("region")!=region: continue
        point=next((z for z in row.get("path") or [] if z.get("month")==month),None)
        if point is not None: vals[str(row.get("kind"))]=point.get("value")
    return vals


def record_outlook(outlook: dict, path=None) -> dict:
    """Append one pre-meeting snapshot per region/meeting/snapshot date."""
    as_of=str(outlook.get("as_of") or "")[:10]
    if not as_of:return {"inserted":0}
    try: as_date=pd.Timestamp(as_of).date()
    except Exception:return {"inserted":0}
    generation=str(outlook.get("integrity_version") or outlook.get("version") or VERSION)
    signals=outlook.get("signals") or {}; inserted=0
    with _connect(path) as con:
        for rate in outlook.get("rates") or []:
            region=str(rate.get("region") or "")
            if region not in {"US","RU"}:continue
            current=float(rate.get("current"))
            sig=signals.get(region) or {}
            for point in rate.get("path") or []:
                meeting=str(point.get("meeting") or "")[:10]
                if not meeting:continue
                try: md=pd.Timestamp(meeting).date()
                except Exception:continue
                # Only information recorded before the decision may train later.
                if md < as_date:continue
                month=str(point.get("month") or meeting[:7])
                macro=_macro_for(outlook,region,month);probs=point.get("probabilities") or {}
                ctx={"factors":point.get("factors") or [],"source":rate.get("source"),
                     "probability_semantics":outlook.get("probability_semantics")}
                cur=con.execute("""INSERT OR IGNORE INTO meeting_snapshots(
                    created_at,model_generation,region,meeting_date,snapshot_date,current_rate,
                    inflation,labor,growth,news_hawk,geo_risk,scenario_hike,scenario_hold,scenario_cut,context_json
                  ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                  (_now(),generation,region,meeting,as_of,current,
                   macro.get("inflation"),macro.get("labor"),macro.get("growth"),
                   sig.get("hawk"),sig.get("geo"),probs.get("hike"),probs.get("hold"),probs.get("cut"),
                   json.dumps(ctx,ensure_ascii=False,separators=(",",":"))))
                inserted+=max(0,int(cur.rowcount or 0))
        con.commit()
    return {"inserted":inserted,"path":str(Path(path or DEFAULT_DB))}


def settle_recent(outlook: dict, path=None, max_days_after: int=10) -> dict:
    """Settle recent meetings from the observed current policy rate.

    We deliberately settle only shortly after the meeting, before another policy
    meeting can contaminate the outcome.  Stale pending rows remain pending rather
    than being guessed retroactively.
    """
    as_of=str(outlook.get("as_of") or "")[:10]
    try: as_date=pd.Timestamp(as_of).date()
    except Exception:return {"settled":0}
    current={str(r.get("region")):r.get("current") for r in outlook.get("rates") or []}
    settled=0
    with _connect(path) as con:
        rows=con.execute("SELECT DISTINCT region,meeting_date FROM meeting_snapshots WHERE settled=0 ORDER BY meeting_date").fetchall()
        for row in rows:
            region=row["region"]; meeting=row["meeting_date"]
            try: md=pd.Timestamp(meeting).date();delta=(as_date-md).days
            except Exception:continue
            if delta < 1 or delta > int(max_days_after):continue
            new=current.get(region)
            if new is None:continue
            snaps=con.execute("SELECT id,current_rate FROM meeting_snapshots WHERE region=? AND meeting_date=? AND settled=0",(region,meeting)).fetchall()
            for snap in snaps:
                old=float(snap["current_rate"]);newf=float(new);diff=newf-old
                action="hike" if diff>1e-8 else "cut" if diff<-1e-8 else "hold"
                con.execute("UPDATE meeting_snapshots SET settled=1,realized_rate=?,realized_action=?,settled_at=?,settlement_source=? WHERE id=?",
                            (newf,action,_now(),"observed_policy_rate_within_10d",int(snap["id"])))
                settled+=1
        con.commit()
    return {"settled":settled}


def status(path=None) -> dict:
    try:
        with _connect(path) as con:
            total=int(con.execute("SELECT COUNT(*) FROM meeting_snapshots").fetchone()[0])
            settled=int(con.execute("SELECT COUNT(*) FROM meeting_snapshots WHERE settled=1").fetchone()[0])
            rows=con.execute("""SELECT region,COUNT(DISTINCT meeting_date) meetings,
                COUNT(DISTINCT CASE WHEN settled=1 THEN meeting_date END) settled_meetings
                FROM meeting_snapshots GROUP BY region""").fetchall()
        by={r["region"]:{"meetings":int(r["meetings"]),"settled_meetings":int(r["settled_meetings"])} for r in rows}
        return {"version":VERSION,"path":str(Path(path or DEFAULT_DB)),"snapshots":total,"settled":settled,"pending":total-settled,"by_region":by}
    except Exception as exc:
        return {"version":VERSION,"snapshots":0,"settled":0,"pending":0,"error":type(exc).__name__}


def update_from_outlook(outlook: dict, path=None) -> dict:
    a=settle_recent(outlook,path=path);b=record_outlook(outlook,path=path);return {**status(path),**a,**b}
