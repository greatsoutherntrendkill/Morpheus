/* Conditional illustrations, never synthetic observations or a fitted OHLC forecast. */
(function(root){
'use strict';
const finite=x=>x!=null&&Number.isFinite(Number(x));
const mean=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:0;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function build({forecast:f,candles,tf,horizon,category='',levels={}}){
 const g=f?.movement_guidance||{},last=candles?.at(-1),price=Number(last?.c);
 if(f?.status!=='ok'||!finite(price)||price<=0)return {available:false,reason:'Сценарии появятся после загрузки прогноза и графика.'};
 const threshold=finite(g.material_move_threshold_pct)?Math.abs(Number(g.material_move_threshold_pct)):null;
 const typical=finite(g.expected_abs_move_pct)?Math.abs(Number(g.expected_abs_move_pct)):null;
 if(!(threshold>0)||!(typical>0))return {available:false,reason:'Недостаточно данных о масштабе движения: сценарные свечи пока не строятся.'};
 const p=finite(f.conditional_p_up)?Number(f.conditional_p_up):Number(f.p_up);
 if(!finite(p)||p<0||p>1)return {available:false,reason:'Нет пригодной оценки направления.'};
 const direction=p===.5?0:p>.5?1:-1;
 const range=g.distribution_quality_ok===true?g.directional_scenario_range:null;
 const validRange=range&&finite(range.low_pct)&&finite(range.high_pct)&&Number(range.low_pct)>0&&Number(range.high_pct)>=Number(range.low_pct)&&((range.direction==='up'?1:-1)===direction);
 let magnitude=validRange?(Number(range.low_pct)+Number(range.high_pct))/2:Math.max(threshold,typical);
 if(!Number.isFinite(magnitude)||magnitude>=95||threshold>=95)return {available:false,reason:'Масштаб слишком велик для надёжного отображения короткими сценариями.'};
 const session=/акци|индекс|фьючер|сырь/i.test(category)?390:1440;
 const horizonMinutes=({'30m':30,'1h':60,'2h':120,'4h':240})[String(horizon)]||Number(horizon)*session;
 const stepMinutes=({'1min':1,'5min':5,'15min':15,'30min':30,'1h':60,'4h':240,'1d':session,'1w':session*5,'1mo':session*21,'3mo':session,'6mo':session,'1y':session,'3y':session})[tf];
 if(!(horizonMinutes>0)||!(stepMinutes>0))return {available:false,reason:'Этот временной масштаб пока не поддерживается.'};
 const nativeBars=horizonMinutes/stepMinutes,n=clamp(Math.ceil(nativeBars),28,52),group=nativeBars/n;
 const rows=(candles||[]).slice(-60).filter(z=>[z.o,z.h,z.l,z.c].every(x=>finite(x)&&Number(x)>0));
 if(rows.length<5)return {available:false,reason:'Нужно не менее 5 свечей для оценки тел и теней.'};
 const wickPct=mean(rows.map(z=>(Math.max(0,z.h-Math.max(z.o,z.c))+Math.max(0,Math.min(z.o,z.c)-z.l))/z.c*50));
 const bodyPct=mean(rows.map(z=>Math.abs(z.c-z.o)/z.c*100));
 // Square-root rescaling is a drawing heuristic, not a fitted intrahorizon variance model.
 const wick=clamp(wickPct*Math.sqrt(group),magnitude/n*.04,magnitude/n*1.8);
 const body=clamp(bodyPct*Math.sqrt(group),0,magnitude/n*1.1);
 const priceAt=r=>price*Math.exp(r/100),pivot=Math.max(1,Math.floor(n*.33));
 const nearby=(direction>0?levels?.res:levels?.sup)||[];
 const loMag=validRange?Number(range.low_pct):Math.max(threshold,magnitude*.85),hiMag=validRange?Number(range.high_pct):magnitude*1.15;
 const level=nearby.map(z=>Number(z.p)).find(v=>Number.isFinite(v)&&direction*Math.log(v/price)*100>=loMag&&direction*Math.log(v/price)*100<=hiMag);
 if(level)magnitude=Math.abs(Math.log(level/price)*100);
 const paths=[1,-1].map((initial,pathIndex)=>{
  const end=direction*(level?clamp(magnitude+(pathIndex===0?-.05:.05)*(hiMag-loMag),loMag,hiMag):validRange?Number(range.low_pct)+(Number(range.high_pct)-Number(range.low_pct))*(pathIndex===0?.4:.6):magnitude*(pathIndex===0?.95:1.05));
  const impulse=initial*threshold,delta=end-impulse;
  const knots=[[0,0],[.12,impulse*.58],[.20,impulse*.38],[.32,impulse],[.41,impulse*.73],[.59,impulse+delta*.48],[.69,impulse+delta*.31],[.85,impulse+delta*.84],[.92,impulse+delta*.72],[1,end]];
  const samples=rows.map(z=>Math.log(z.c/z.o)),avg=mean(samples),sd=Math.sqrt(mean(samples.map(v=>(v-avg)**2)))||1;
  const liquidityLevels=[...(initial>0?levels?.res||[]:levels?.sup||[]),...(initial>0?levels?.p?.hi||[]:levels?.p?.lo||[])].map(z=>Number(z.p)).filter(v=>Number.isFinite(v)&&v>0&&initial*(v/price-1)>0&&Math.abs(Math.log(v/price)*100)<threshold*1.4);
  const sweepLevel=liquidityLevels.sort((a,b)=>Math.abs(a-priceAt(impulse))-Math.abs(b-priceAt(impulse)))[0];
  let prior=0;const bars=[];
  for(let i=1;i<=n;i++){
   const t=i/n,k=knots.findIndex(z=>z[0]>=t),a=knots[Math.max(0,k-1)],b=knots[Math.max(1,k)],u=(t-a[0])/(b[0]-a[0]);
   const trend=a[1]+(b[1]-a[1])*u;
   const residual=clamp((samples[(i+pathIndex*17)%samples.length]-avg)/sd,-2,2);
   const r=i===n?end:trend+residual*body*.32*Math.sin(Math.PI*t);
   const o=priceAt(prior),c=priceAt(r),w=price*wick/100*(.65+.35*Math.abs(residual));
   let h=Math.max(o,c)+w,l=Math.max(price*.001,Math.min(o,c)-w),event=null;
   // Illustrate rejection at an observed historical level, never claim observed order-book liquidity.
   if(sweepLevel&&i===Math.round(n*.32)&&Math.abs(sweepLevel-c)<price*threshold*.5/100){
    if(initial>0&&sweepLevel>=Math.max(o,c))h=Math.max(h,sweepLevel+w*.35);
    if(initial<0&&sweepLevel<=Math.min(o,c))l=Math.min(l,sweepLevel-w*.35);
    event='условный прокол исторического уровня';
   }
   bars.push({o,c,h,l:Math.max(price*.001,l),fraction:t,event});prior=r;
  }
  return {label:pathIndex===0?'Сценарий I':'Сценарий II',initial,end,bars};
 });
 return {available:true,level:level||null,price,threshold,typical,magnitude,direction,paths,n,nativeBars,group,horizon:String(horizon),range:validRange?range:null,abstain:!!f.abstain,
  timeNote:group>1.1?`Укрупнённые шаги: ≈ ${Number(group.toPrecision(2))} свечей в одном` :group<.9?'Условные шаги внутри выбранной свечи':'Шаг сценария примерно равен шагу свечей',
  qualityNote:validRange?`Подтверждённый диапазон: ${direction>0?'рост':'снижение'} ${Number(range.low_pct).toFixed(2)}–${Number(range.high_pct).toFixed(2)}%. Конечные ориентиры расположены внутри него.`:'Масштаб по истории; направленный диапазон не подтверждён.'};
}
function active(chart){return chart.scenario?.available&&chart.offset===0;}
function historyRight(chart,d){return active(chart)?d.pR+(d.W-d.pL-d.pR)*.38:d.pR;}
function values(chart){return active(chart)?chart.scenario.paths.flatMap(p=>p.bars.flatMap(z=>[z.h,z.l])):[];}
function draw(chart,vis,d,ys,palette){
 if(!active(chart))return;
 const s=chart.scenario,ctx=chart.ctx,right=d.W-d.pR,left=d.W-historyRight(chart,d),width=right-left;
 if(width<32)return;
 const x0=left+9,x1=right-10,step=(x1-x0)/s.n,progress=chart.scenarioProgress??1;
 const histStep=(left-d.pL)/(vis.end-vis.start),bw=clamp(step*.74,.65,7);
 ctx.save();ctx.beginPath();ctx.rect(left,d.pT,width,d.priceH-d.pT-d.pB);ctx.clip();
 ctx.fillStyle=palette.tint;ctx.fillRect(left,d.pT,width,d.priceH-d.pT-d.pB);
 ctx.strokeStyle=palette.muted;ctx.globalAlpha=.45;ctx.setLineDash([3,5]);ctx.beginPath();ctx.moveTo(left,d.pT);ctx.lineTo(left,d.priceH-d.pB);ctx.stroke();ctx.globalAlpha=1;ctx.setLineDash([]);
 // The band is the material-move threshold, not a confidence interval.
 ctx.fillStyle=palette.band;const y1=ys.y(s.price*Math.exp(s.threshold/100)),y2=ys.y(s.price*Math.exp(-s.threshold/100));ctx.fillRect(left,y1,width,y2-y1);
 for(const [pi,path] of s.paths.entries()){
  ctx.strokeStyle=pi===0?palette.first:palette.second;ctx.globalAlpha=.16;ctx.setLineDash([2,4]);ctx.beginPath();ctx.moveTo(left,ys.y(s.price));
  path.bars.slice(0,Math.ceil(s.n*progress)).forEach((z,i)=>ctx.lineTo(x0+(i+.5)*step,ys.y(z.c)));ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
  path.bars.forEach((z,i)=>{
   if(i>=Math.ceil(s.n*progress))return;
   const x=x0+(i+.5)*step+(pi===0?-bw*.12:bw*.12),top=Math.min(ys.y(z.o),ys.y(z.c)),height=Math.max(2,Math.abs(ys.y(z.o)-ys.y(z.c))),col=z.c>=z.o?palette.up:palette.down;
   ctx.strokeStyle=col;ctx.lineWidth=1;ctx.setLineDash([]);ctx.beginPath();ctx.moveTo(x,ys.y(z.h));ctx.lineTo(x,ys.y(z.l));ctx.stroke();ctx.setLineDash([]);
   ctx.fillStyle=palette.bg;ctx.fillRect(x-bw/2,top,bw,height);ctx.strokeRect(x-bw/2,top,bw,height);

  });
 }
 ctx.restore();
 // Labels stay in reserved rows, independent of price extremes and panel height.
 ctx.save();ctx.font='10px Arial';ctx.textAlign='left';ctx.textBaseline='top';
 for(let i=0;i<2;i++){ctx.fillStyle=i===0?palette.first:palette.second;ctx.fillText(s.paths[i].label,left+7,d.pT+5+i*15,Math.max(25,width-14))}
 ctx.fillStyle=palette.muted;ctx.font='9px Arial';ctx.textAlign='right';ctx.fillText('+'+({'30m':'30 мин','1h':'1 ч','2h':'2 ч','4h':'4 ч'}[s.horizon]||s.horizon+' дн.'),right-3,d.priceH-d.pB+7,width-6);ctx.restore();
}
function svg(chart,vis,d,sy,palette){
 if(!active(chart))return '';
 const s=chart.scenario,left=d.W-historyRight(chart,d),right=d.W-d.pR,width=right-left,step=(width-19)/s.n,histStep=(left-d.pL)/(vis.end-vis.start),bw=clamp(step*.74,.65,7);
 let out=`<line x1="${left}" y1="${d.pT}" x2="${left}" y2="${d.priceH-d.pB}" stroke="${palette.muted}" stroke-dasharray="3 5"/><rect x="${left}" y="${sy(s.price*Math.exp(s.threshold/100))}" width="${width}" height="${sy(s.price*Math.exp(-s.threshold/100))-sy(s.price*Math.exp(s.threshold/100))}" fill="${palette.muted}" opacity=".07"/>`;
 for(const [pi,path] of s.paths.entries()){
  out+=`<text x="${left+7}" y="${d.pT+12+pi*15}" font-family="Arial" font-size="10" fill="${pi?palette.second:palette.first}">${path.label}</text>`;
  for(const [i,z] of path.bars.entries()){
   const x=left+9+(i+.5)*step+(pi===0?-bw*.12:bw*.12),top=Math.min(sy(z.o),sy(z.c)),height=Math.max(2,Math.abs(sy(z.o)-sy(z.c))),col=z.c>=z.o?palette.up:palette.down;
   out+=`<line x1="${x}" x2="${x}" y1="${sy(z.h)}" y2="${sy(z.l)}" stroke="${col}" /><rect x="${x-bw/2}" y="${top}" width="${bw}" height="${height}" fill="none" stroke="${col}"/>`;
  }
 }
 const label=({'30m':'30 мин','1h':'1 ч','2h':'2 ч','4h':'4 ч'})[s.horizon]||s.horizon+' дн.';
 out+=`<text x="${right-4}" y="${d.priceH-18}" text-anchor="end" font-family="Arial" font-size="9" fill="${palette.muted}">Условные пути · +${label}</text><text x="${right-4}" y="${d.priceH-5}" text-anchor="end" font-family="Arial" font-size="8" fill="${palette.muted}">Время справа показано отдельно</text>`;return out;
}

const api={build,active,historyRight,values,draw,svg};if(typeof module!=='undefined')module.exports=api;else root.CandleScenarios=api;
})(typeof window!=='undefined'?window:this);
