"""AllAnalytics v4.33 — volatility-aware regime challenger.

Purpose
-------
This module is a *challenger*, not an automatic replacement for the production
champion. It addresses four weaknesses of a plain binary up/down model:

1. tiny movements are treated as neutral rather than as a full directional win;
2. probabilities are calibrated only from prior OOS predictions;
3. a regime-specific expert is blended with a global expert when enough evidence exists;
4. the model may explicitly abstain when the edge is too small for the current regime.

All target construction is point-in-time. A forward label for date T can enter
training only after its horizon has fully elapsed.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np
import pandas as pd

import models as M

VERSION = "vol-regime-challenger-v4.33.0"
NEUTRAL_SIGMA = M.TARGET_NEUTRAL_SIGMA
MIN_ABS_MOVE = M.TARGET_MIN_ABS_MOVE
MIN_DIRECTIONAL_TRAIN = 120
MIN_REGIME_TRAIN = 70
CALIBRATION_MIN_OOS = 70
CALIBRATION_REFIT_EVERY = 35


@dataclass
class _Platt:
    coef: float
    intercept: float

    def apply(self, p):
        arr=np.clip(np.asarray(p,float),1e-5,1-1e-5)
        z=np.log(arr/(1-arr))
        out=1/(1+np.exp(-np.clip(self.intercept+self.coef*z,-30,30)))
        return out


def _fit_platt(p, y) -> _Platt | None:
    p=np.asarray(p,float); y=np.asarray(y,float)
    ok=np.isfinite(p)&np.isfinite(y)
    p,y=p[ok],y[ok]
    if len(p)<CALIBRATION_MIN_OOS or len(np.unique(y))<2:
        return None
    try:
        from sklearn.linear_model import LogisticRegression
        z=np.log(np.clip(p,1e-5,1-1e-5)/(1-np.clip(p,1e-5,1-1e-5))).reshape(-1,1)
        mdl=LogisticRegression(C=1.5,max_iter=250,solver="lbfgs",random_state=433).fit(z,y)
        return _Platt(float(mdl.coef_[0,0]),float(mdl.intercept_[0]))
    except Exception:
        return None


def _regime_labels(feats: pd.DataFrame) -> pd.Series:
    """Point-in-time coarse market regimes from features known at that date."""
    d50=pd.to_numeric(feats.get("dist_ma50"),errors="coerce")
    d200=pd.to_numeric(feats.get("dist_ma200"),errors="coerce")
    vr=pd.to_numeric(feats.get("vol_ratio"),errors="coerce")
    trend=np.where((d50>0)&(d200>0),"trend_up",
          np.where((d50<0)&(d200<0),"trend_down","transition"))
    vol=np.where(vr>1.18,"high_vol",np.where(vr<0.82,"low_vol","normal_vol"))
    return pd.Series([f"{a}|{b}" for a,b in zip(trend,vol)],index=feats.index,dtype="object")


def _target_frame(close: pd.Series, horizon: int, neutral_sigma: float=NEUTRAL_SIGMA) -> pd.DataFrame:
    # v4.40.4: every directional component shares the exact same target contract.
    return M.directional_target_frame(close, horizon, neutral_sigma=neutral_sigma)[
        ["ret_fwd","threshold","state","label_end"]
    ].copy()


def _direction_metrics(p_dir, y_dir, base_prob) -> dict:
    p=np.asarray(p_dir,float); y=np.asarray(y_dir,float); b=np.asarray(base_prob,float)
    ok=np.isfinite(p)&np.isfinite(y)&np.isfinite(b)
    p,y,b=p[ok],y[ok],b[ok]
    if len(p)<5:
        return {"n":len(p),"accuracy":None,"base_accuracy":None,"edge_pp":None,"brier":None,"brier_skill":None,"ece":None}
    m=M._metric_bundle(p,y,b)
    return {
        "n":int(len(p)),"accuracy":float(m["acc"]),"base_accuracy":float(m["base"]),
        "edge_pp":float(m["edge"]),"brier":float(m["brier"]),
        "brier_skill":float(m["brier_skill"]),"ece":float(m["ece"]),
    }


def _movement_probability(states: np.ndarray, regimes: np.ndarray, current_regime: str) -> float:
    """Legacy fallback only; v4.40.6 live P(move) comes from a classifier."""
    st=np.asarray(states,float); regs=np.asarray(regimes,object)
    global_n=len(st); global_moves=int(np.sum(st!=0))
    global_p=(global_moves+8)/(global_n+16) if global_n else 0.5
    mask=(regs==current_regime); n=int(mask.sum()); moves=int(np.sum(st[mask]!=0)) if n else 0
    p=(moves+30*global_p)/(n+30) if n else global_p
    return float(np.clip(p,0.18,0.92))


def _fit_move_model(X, state, idx, *, lr=.18, n_iter=280, l2=3e-2):
    idx=np.asarray(idx,dtype=int)
    if len(idx)<MIN_DIRECTIONAL_TRAIN:
        return None,idx
    y=(np.asarray(state[idx])!=0).astype(float)
    if len(np.unique(y))<2:
        return None,idx
    return M.LogReg(lr=lr,n_iter=n_iter,l2=l2).fit(X[idx],y),idx


def _fit_direction_model(X, state, idx):
    idx=np.asarray(idx,dtype=int)
    idx=idx[np.asarray(state[idx])!=0]
    if len(idx)<MIN_DIRECTIONAL_TRAIN:
        return None,idx
    y=(np.asarray(state[idx])>0).astype(float)
    if len(np.unique(y))<2:
        return None,idx
    return M.LogReg(lr=.20,n_iter=260,l2=3e-2).fit(X[idx],y),idx


def _dynamic_signal_threshold(regime: str, quality_trusted: bool) -> float:
    if "high_vol" in str(regime): th=0.60
    elif "low_vol" in str(regime): th=0.55
    else: th=0.57
    if not quality_trusted:
        th+=0.02
    return float(min(0.66,th))


def _strength(prob_direction: float, threshold: float) -> str:
    if prob_direction>=0.70: return "выраженный"
    if prob_direction>=max(0.63,threshold): return "умеренный"
    if prob_direction>=threshold: return "слабый"
    return "нет преимущества"


def walk_forward_regime(close: pd.Series, horizon: int=10, min_train: int=220,
                        retrain_every: int=30, expert_weight: float=.62) -> dict:
    """Purged expanding walk-forward challenger with neutral labels and regime experts."""
    h=int(horizon)
    c=pd.Series(close,dtype=float).dropna().sort_index()
    feats=M.build_features(c)
    regs=_regime_labels(feats)
    target=_target_frame(c,h)
    df=feats.copy(); df["regime"]=regs; df=df.join(target)
    df["date"]=df.index
    df=df.dropna(subset=list(feats.columns)+["ret_fwd","threshold","state","label_end"])
    if len(df)<min_train+70:
        return {}

    Xcols=list(feats.columns); X=df[Xcols].to_numpy(float)
    state=df["state"].to_numpy(float); regimes=df["regime"].astype(str).to_numpy(object)
    dates=pd.to_datetime(df["date"]).to_numpy(); label_ends=pd.to_datetime(df["label_end"]).to_numpy()
    n=len(df)
    holdout_start=M._resolve_final_holdout_start(dates,min_train)
    holdout_pos=n if holdout_start is None else int(np.searchsorted(np.asarray(dates,dtype="datetime64[ns]"),np.datetime64(holdout_start,"ns"),side="left"))

    p_total=np.full(n,np.nan); p_dir_raw=np.full(n,np.nan); p_dir_cal=np.full(n,np.nan); p_move_arr=np.full(n,np.nan)
    base_dir=np.full(n,np.nan); base_move=np.full(n,np.nan); used_expert=np.zeros(n,dtype=bool)
    global_model=None; expert_model=None; move_global=None; move_expert=None; expert_regime=None; last_fit=-999
    cal=None; move_cal=None; last_calib_n=0; last_move_calib_n=0
    hist_raw=[]; hist_y=[]; hist_move_raw=[]; hist_move_y=[]

    for t in range(n):
        if t>=holdout_pos and holdout_start is not None:
            train_idx=M._frozen_holdout_train_indices(label_ends,dates,holdout_start,t)
        else:
            train_idx=M._purged_train_indices(label_ends,dates[t],t)
        if len(train_idx)<min_train:
            continue
        directional=train_idx[state[train_idx]!=0]
        if len(directional)<MIN_DIRECTIONAL_TRAIN:
            continue
        ydir=(state[directional]>0).astype(float)
        if len(np.unique(ydir))<2:
            continue
        reg_now=str(regimes[t])
        if global_model is None or (t-last_fit)>=int(retrain_every) or expert_regime!=reg_now:
            global_model=M.LogReg(lr=.20,n_iter=260,l2=3e-2).fit(X[directional],ydir)
            move_global,_=_fit_move_model(X,state,train_idx,lr=.18,n_iter=280,l2=3e-2)
            reg_dir=directional[regimes[directional]==reg_now]
            reg_all=train_idx[regimes[train_idx]==reg_now]
            expert_model=None; move_expert=None
            if len(reg_dir)>=MIN_REGIME_TRAIN:
                yy=(state[reg_dir]>0).astype(float)
                if len(np.unique(yy))>=2:
                    expert_model=M.LogReg(lr=.18,n_iter=240,l2=4e-2).fit(X[reg_dir],yy)
            if len(reg_all)>=MIN_REGIME_TRAIN:
                move_expert,_=_fit_move_model(X,state,reg_all,lr=.16,n_iter=250,l2=4e-2)
            expert_regime=reg_now; last_fit=t
        pg=float(global_model.proba(X[t:t+1])[0])
        pr=None if expert_model is None else float(expert_model.proba(X[t:t+1])[0])
        praw=pg if pr is None else float((1-expert_weight)*pg+expert_weight*pr)
        # Fit calibrators only from *previous* OOS observations.
        if len(hist_raw)>=CALIBRATION_MIN_OOS and (cal is None or len(hist_raw)-last_calib_n>=CALIBRATION_REFIT_EVERY):
            cal=_fit_platt(hist_raw,hist_y); last_calib_n=len(hist_raw)
        pcal=float(cal.apply([praw])[0]) if cal is not None else praw
        mg=float(move_global.proba(X[t:t+1])[0]) if move_global is not None else _movement_probability(state[train_idx],regimes[train_idx],reg_now)
        me=None if move_expert is None else float(move_expert.proba(X[t:t+1])[0])
        mraw=mg if me is None else float((1-expert_weight)*mg+expert_weight*me)
        if len(hist_move_raw)>=CALIBRATION_MIN_OOS and (move_cal is None or len(hist_move_raw)-last_move_calib_n>=CALIBRATION_REFIT_EVERY):
            move_cal=_fit_platt(hist_move_raw,hist_move_y); last_move_calib_n=len(hist_move_raw)
        pmove=float(move_cal.apply([mraw])[0]) if move_cal is not None else mraw
        pmove=float(np.clip(pmove,.03,.97))
        p=0.5+pmove*(pcal-0.5)
        p_total[t]=float(np.clip(p,0.02,0.98)); p_dir_raw[t]=praw; p_dir_cal[t]=pcal; p_move_arr[t]=pmove
        base_dir[t]=float(np.mean(ydir)); base_move[t]=float(np.mean(state[train_idx]!=0)); used_expert[t]=pr is not None
        if holdout_start is None or t<holdout_pos:
            hist_move_raw.append(mraw); hist_move_y.append(1.0 if state[t]!=0 else 0.0)
            if state[t]!=0:
                hist_raw.append(praw); hist_y.append(1.0 if state[t]>0 else 0.0)

    dev=np.isfinite(p_total)
    if holdout_start is not None:
        dev &= pd.DatetimeIndex(pd.to_datetime(dates))<holdout_start
    if int(dev.sum())<35:
        return {}
    dir_dev=dev&(state!=0)&np.isfinite(p_dir_cal)&np.isfinite(base_dir)
    metrics=_direction_metrics(p_dir_cal[dir_dev],(state[dir_dev]>0).astype(float),base_dir[dir_dev])
    move_dev=dev&np.isfinite(p_move_arr)&np.isfinite(base_move)
    move_metrics=_direction_metrics(p_move_arr[move_dev],(state[move_dev]!=0).astype(float),base_move[move_dev])
    n_eff=max(1,int(metrics["n"]//max(1,h)))
    trusted=bool(n_eff>=25 and (metrics["edge_pp"] or -999)>0 and (metrics["brier_skill"] or -999)>0 and (metrics["ece"] or 1)<=0.16)

    # Live refit: all labels that are already known today are legal.
    live_feats=M.build_features(c).dropna()
    if live_feats.empty:
        return {}
    live_regs=_regime_labels(M.build_features(c)).dropna()
    live_regime=str(live_regs.reindex(live_feats.index).iloc[-1])
    legal=np.arange(len(df),dtype=int)
    directional=legal[state!=0]
    if len(directional)<MIN_DIRECTIONAL_TRAIN:
        return {}
    ydir=(state[directional]>0).astype(float)
    gm=M.LogReg(lr=.20,n_iter=280,l2=3e-2).fit(X[directional],ydir)
    mm,_=_fit_move_model(X,state,legal,lr=.18,n_iter=300,l2=3e-2)
    reg_dir=directional[regimes[directional]==live_regime]
    reg_all=legal[regimes[legal]==live_regime]
    em=None; mem=None
    if len(reg_dir)>=MIN_REGIME_TRAIN and len(np.unique((state[reg_dir]>0).astype(float)))>=2:
        em=M.LogReg(lr=.18,n_iter=250,l2=4e-2).fit(X[reg_dir],(state[reg_dir]>0).astype(float))
    if len(reg_all)>=MIN_REGIME_TRAIN:
        mem,_=_fit_move_model(X,state,reg_all,lr=.16,n_iter=260,l2=4e-2)
    xlive=live_feats[Xcols].to_numpy(float)[-1:]
    pg=float(gm.proba(xlive)[0]); pe=None if em is None else float(em.proba(xlive)[0])
    raw_live=pg if pe is None else float((1-expert_weight)*pg+expert_weight*pe)
    final_cal=_fit_platt(hist_raw,hist_y)
    cal_live=float(final_cal.apply([raw_live])[0]) if final_cal is not None else raw_live
    mg=float(mm.proba(xlive)[0]) if mm is not None else _movement_probability(state,regimes,live_regime)
    me=None if mem is None else float(mem.proba(xlive)[0])
    move_raw_live=mg if me is None else float((1-expert_weight)*mg+expert_weight*me)
    final_move_cal=_fit_platt(hist_move_raw,hist_move_y)
    p_move=float(final_move_cal.apply([move_raw_live])[0]) if final_move_cal is not None else move_raw_live
    p_move=float(np.clip(p_move,.03,.97))
    p_up=float(np.clip(0.5+p_move*(cal_live-0.5),0.02,0.98))
    dir_prob=max(p_up,1-p_up); threshold=_dynamic_signal_threshold(live_regime,trusted)
    abstain=bool(dir_prob<threshold)
    strength=_strength(dir_prob,threshold)

    # Soft-neutral diagnostic: 1 up, 0 down, 0.5 neutral.
    soft=np.where(state[dev]>0,1.0,np.where(state[dev]<0,0.0,0.5))
    soft_brier=float(np.mean((p_total[dev]-soft)**2)) if len(soft) else None
    soft_base=float(np.mean((0.5-soft)**2)) if len(soft) else None
    soft_skill=(1-soft_brier/soft_base)*100 if soft_base and soft_base>1e-12 else 0.0

    oos_records=[]
    dev_positions=np.where(dev & np.isfinite(p_total))[0]
    for j in dev_positions[-480:]:
        actual_up=1 if state[j]>0 else (0 if state[j]<0 else None)
        oos_records.append({
            "date":str(pd.Timestamp(dates[j]).date()),
            "p_up":round(float(p_total[j]),8),
            "conditional_p_up":round(float(p_dir_cal[j]),8) if np.isfinite(p_dir_cal[j]) else None,
            "p_move":round(float(p_move_arr[j]),8) if np.isfinite(p_move_arr[j]) else None,
            "p_neutral":round(float(1-p_move_arr[j]),8) if np.isfinite(p_move_arr[j]) else None,
            "y":actual_up,
            "state":int(state[j]),
            "regime":str(regimes[j]),
        })

    return {
        "version":VERSION,"horizon":h,"p_up":round(p_up,6),"p_down":round(1-p_up,6),
        "oos_records":oos_records,
        "p_neutral":round(1-p_move,6),"p_move":round(p_move,6),"p_move_raw":round(move_raw_live,6),
        "conditional_p_up":round(cal_live,6),"raw_conditional_p_up":round(raw_live,6),
        "move_model":{"version":"regime-move-logreg-v4.40.6","trained":mm is not None,"regime_expert":mem is not None,"calibrated":bool(final_move_cal is not None)},
        "regime":live_regime,"expert_used":bool(em is not None),"calibrated":bool(final_cal is not None),
        "abstain":abstain,"signal_strength":strength,"signal_threshold":round(threshold,3),
        "quality":{"trusted":trusted,"confidence":"средняя" if trusted else "низкая","bias":"neutral" if abstain else ("bullish" if p_up>=.5 else "bearish")},
        "scorecard":{
            "directional_oos_n":metrics["n"],"directional_effective_n":n_eff,
            "directional_accuracy":None if metrics["accuracy"] is None else round(metrics["accuracy"]*100,2),
            "directional_base_accuracy":None if metrics["base_accuracy"] is None else round(metrics["base_accuracy"]*100,2),
            "directional_edge_pp":None if metrics["edge_pp"] is None else round(metrics["edge_pp"],2),
            "directional_brier":None if metrics["brier"] is None else round(metrics["brier"],5),
            "directional_brier_skill":None if metrics["brier_skill"] is None else round(metrics["brier_skill"],2),
            "directional_ece":None if metrics["ece"] is None else round(metrics["ece"],5),
            "soft_brier":None if soft_brier is None else round(soft_brier,5),
            "soft_brier_skill":round(float(soft_skill),2),
            "move_oos_n":move_metrics.get("n"),
            "move_accuracy":None if move_metrics.get("accuracy") is None else round(move_metrics["accuracy"]*100,2),
            "move_brier":move_metrics.get("brier"),
            "move_brier_skill":move_metrics.get("brier_skill"),
            "move_ece":move_metrics.get("ece"),
            "expert_share_oos":round(float(np.mean(used_expert[dev])) if dev.any() else 0.0,3),
            "neutral_share_oos":round(float(np.mean(state[dev]==0)) if dev.any() else 0.0,3),
        },
        "validation":{
            "purged":True,"point_in_time_regimes":True,"neutral_target":"volatility_adjusted",
            "neutral_sigma":NEUTRAL_SIGMA,"min_abs_move":MIN_ABS_MOVE,
            "calibration":"rolling_oos_platt","calibration_uses_future":False,
            "move_probability_modelled_from_current_features":True,"move_model_version":"regime-move-logreg-v4.40.6",
            "holdout_start":None if holdout_start is None else str(holdout_start.date()),
        }
    }
