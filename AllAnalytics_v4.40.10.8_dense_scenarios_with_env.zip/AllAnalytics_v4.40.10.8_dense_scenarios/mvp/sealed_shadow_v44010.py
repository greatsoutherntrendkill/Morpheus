"""AllAnalytics v4.40.10 — sealed prospective shadow benchmark.

A deterministic 20% slice of prospective forecasts after the release boundary is
reserved for audit and MUST NOT be used by routing, promotion, calibration or
threshold selection. It becomes informative only after enough outcomes settle.
"""
from __future__ import annotations
import hashlib
import os
import numpy as np
import pandas as pd
import target_contract_v4405 as TARGET4405
import forecast_contract_v4406 as CONTRACT

VERSION="sealed-shadow-v4.40.10"
DEFAULT_START="2026-09-15"
SHARE_BUCKETS=5
SHADOW_BUCKET=0
MIN_SETTLED=40
MIN_DATES=20


def start_date():
    try:return pd.Timestamp(os.getenv("ALLANALYTICS_SHADOW_START",DEFAULT_START)).normalize()
    except Exception:return pd.Timestamp(DEFAULT_START)


def is_shadow_row(row: dict) -> bool:
    try:
        d=pd.Timestamp(str(row.get("data_as_of") or row.get("target_as_of") or "")[:10]).normalize()
        if pd.isna(d) or d<start_date():return False
    except Exception:return False
    key=str(row.get("forecast_key") or "")
    if not key:
        key="|".join([str(row.get("symbol") or ""),str(row.get("horizon") or ""),str(row.get("data_as_of") or ""),str(row.get("model_generation") or "")])
    h=int(hashlib.sha256(key.encode("utf-8")).hexdigest()[:8],16)
    return (h % SHARE_BUCKETS)==SHADOW_BUCKET


def training_rows(rows):
    return [r for r in (rows or []) if not is_shadow_row(r)]


def shadow_rows(rows):
    return [r for r in (rows or []) if is_shadow_row(r)]


def audit(ledger=None, limit=500):
    if ledger is None:
        import prospective_feedback_v436 as FB
        ledger=FB.LEDGER
    try:
        rows=ledger.rows(limit=limit,settled_only=True,model_generation=CONTRACT.MODEL_GENERATION,target_version=TARGET4405.TARGET_VERSION)
    except Exception as exc:
        return {"version":VERSION,"status":"unavailable","error":type(exc).__name__,"used_for_training":False}
    rows=shadow_rows(rows)
    dates={str(r.get("data_as_of") or "")[:10] for r in rows}
    out={"version":VERSION,"start":str(start_date().date()),"allocation":"deterministic 20% hash slice",
         "used_for_training":False,"used_for_routing":False,"used_for_calibration":False,"settled_n":len(rows),"unique_dates":len(dates),
         "minimum_settled":MIN_SETTLED,"minimum_dates":MIN_DATES}
    if len(rows)<MIN_SETTLED or len(dates)<MIN_DATES:
        out.update(status="collecting",ready=False);return out
    mcb=[]; mll=[]; move=[]; direction=[]
    for r in rows:
        for arr,key in ((mcb,"multiclass_brier"),(mll,"multiclass_log_loss"),(move,"move_brier")):
            try:
                v=float(r.get(key));
                if np.isfinite(v):arr.append(v)
            except Exception:pass
        try:
            v=float(r.get("direction_brier"));
            if np.isfinite(v):direction.append(v)
        except Exception:pass
    out.update(status="ready",ready=True,
               multiclass_brier=None if not mcb else round(float(np.mean(mcb)),7),
               multiclass_log_loss=None if not mll else round(float(np.mean(mll)),7),
               move_brier=None if not move else round(float(np.mean(move)),7),
               direction_brier=None if not direction else round(float(np.mean(direction)),7),
               direction_n=len(direction))
    return out
