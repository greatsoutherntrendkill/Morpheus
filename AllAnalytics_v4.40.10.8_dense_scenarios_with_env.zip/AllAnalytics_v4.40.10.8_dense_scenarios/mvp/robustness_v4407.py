"""AllAnalytics v4.40.7 — Model Robustness wrapper.

Adds four deployment-safety layers without changing the learned v4.40.6 target:
1) freshness/staleness guard;
2) soft regime probabilities and uncertainty-aware confidence;
3) directional/distribution consistency gate;
4) explicit robustness diagnostics for API/UI.

Cross-sectional independence is implemented in asset_specialists_v438.py by using
one synchronized DB universe rather than user-populated forecast caches.
"""
from __future__ import annotations
import math
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import model_integrity_v4406 as BASE
import freshness_contract_v4409 as FRESH4409

VERSION="model-correctness-robustness-v4.40.9"
import forecast_contract_v4406 as CONTRACT
TARGET4405=BASE.TARGET4405
MODEL_GENERATION=CONTRACT.MODEL_GENERATION


def _clip(x, lo=0.0, hi=1.0):
    try:return float(np.clip(float(x),lo,hi))
    except Exception:return None


def freshness_guard(close: pd.Series, context: dict|None=None, now=None)->dict:
    """Source-aware freshness gate.

    v4.40.9 consumes the per-source contract emitted by the actual feature
    builders instead of looking only at the optional caller ``context``. Legacy
    ``*_age_days`` dictionaries are still understood as a conservative fallback.
    """
    s=pd.Series(close).dropna()
    if s.empty:
        return {"status":"stale","market_age_days":None,"max_context_age_days":None,"penalty":1.0,"hard_stale":True,
                "version":FRESH4409.VERSION,"warning_sources":[],"hard_stale_sources":["own_market_price"],"missing_sources":["own_market_price"]}
    last=pd.Timestamp(s.index[-1])
    if last.tzinfo is not None:last=last.tz_convert(None)
    now_ts=pd.Timestamp(now if now is not None else datetime.now(timezone.utc)).tz_localize(None).normalize()
    age=max(0.0,float((now_ts-last.normalize()).days))
    ages=[]; warning_sources=[]; hard_sources=[]; missing_sources=[]; legacy_ages=[]

    def walk(o,path="context"):
        if isinstance(o,dict):
            # Contract source record: thresholds/status were determined by the
            # source-class policy (market vs macro), so do not overwrite them
            # with one generic context threshold.
            if "age_days" in o and any(k in o for k in ("source","warning_after_days","hard_after_days","hard_stale","missing")):
                name=str(o.get("source") or path)
                try:
                    z=float(o.get("age_days"))
                    if math.isfinite(z):ages.append(max(0.0,z))
                except Exception:pass
                if o.get("missing"):missing_sources.append(name)
                if o.get("warning"):warning_sources.append(name)
                if o.get("hard_stale") and o.get("critical",True):hard_sources.append(name)
                return
            for k,v in o.items():
                lk=str(k).lower()
                if lk.endswith(("age_days","staleness_days")):
                    try:
                        z=float(v)
                        if math.isfinite(z):
                            z=max(0.0,z);ages.append(z);legacy_ages.append(z)
                    except Exception:pass
                else:walk(v,f"{path}.{k}")
        elif isinstance(o,(list,tuple)):
            for i,v in enumerate(o):walk(v,f"{path}[{i}]")
    walk(context or {})
    cmax=max(ages) if ages else None
    legacy_max=max(legacy_ages) if legacy_ages else None
    # Daily market data can legitimately be 2–3 calendar days old over weekends.
    hard=bool(age>FRESH4409.MARKET_HARD_DAYS or hard_sources or (legacy_max is not None and legacy_max>45))
    warn=bool(age>FRESH4409.MARKET_WARNING_DAYS or warning_sources or missing_sources or (legacy_max is not None and legacy_max>14))
    penalty=1.0 if hard else (.55 if warn else 0.0)
    return {"status":"stale" if hard else ("warning" if warn else "fresh"),"market_age_days":age,
            "max_context_age_days":cmax,"penalty":penalty,"hard_stale":hard,"version":FRESH4409.VERSION,
            "warning_sources":sorted(set(warning_sources)),"hard_stale_sources":sorted(set(hard_sources)),
            "missing_sources":sorted(set(missing_sources)),
            "policy":{"market_warning_days":FRESH4409.MARKET_WARNING_DAYS,"market_hard_days":FRESH4409.MARKET_HARD_DAYS,
                      "source_specific_thresholds":True,"bounded_forward_fill":True}}


def soft_regime(close: pd.Series)->dict:
    s=pd.Series(close).dropna().astype(float)
    if len(s)<80:return {"trend":.34,"range":.33,"high_vol":.33,"entropy":1.0,"dominant":"unknown"}
    r=np.log(s).diff(); mom=float(np.log(s.iloc[-1]/s.iloc[-21])) if len(s)>21 else 0.0
    vol=float(r.iloc[-20:].std()*math.sqrt(252)) if len(r)>=20 else 0.0
    hist_vol=r.rolling(20).std()*math.sqrt(252)
    med=float(hist_vol.iloc[:-1].median()) if hist_vol.iloc[:-1].notna().any() else max(vol,1e-6)
    trend_score=abs(mom)/(max(vol/math.sqrt(12),.015))
    hv_score=max(0.0,(vol/(med+1e-9)-1.0)*1.7)
    range_score=max(0.0,1.25-trend_score)
    raw=np.array([trend_score,range_score,hv_score],float)
    raw=np.exp(np.clip(raw-raw.max(),-20,20)); p=raw/raw.sum()
    names=["trend","range","high_vol"]; probs={n:round(float(v),4) for n,v in zip(names,p)}
    ent=float(-(p*np.log(p+1e-12)).sum()/math.log(3))
    return {**probs,"entropy":round(ent,4),"dominant":names[int(np.argmax(p))],"momentum20":round(mom,5),"ann_vol20":round(vol,5)}


DIST_MIN_EFFECTIVE_N=8

def consistency_gate(out:dict)->dict:
    dist=out.get("distribution_forecast") or {}
    ev=dist.get("evaluation") or {}; dep=ev.get("dependence_adjusted") or {}
    try:eff=int(dep.get("effective_n") if dep.get("effective_n") is not None else ev.get("effective_n"))
    except Exception:eff=0
    qualified=bool(dist.get("status")=="ok" and dist.get("quality_ok") is True and eff>=DIST_MIN_EFFECTIVE_N)
    if not qualified:
        return {"status":"distribution_unqualified","severity":0.0,"action":"none","eligible":False,
                "distribution_status":dist.get("status"),"distribution_quality_ok":bool(dist.get("quality_ok")),
                "distribution_effective_n":eff,"min_effective_n":DIST_MIN_EFFECTIVE_N}
    cond=_clip(out.get("conditional_p_up")); q50=dist.get("q50_return_pct")
    if q50 is None:
        q=(dist.get("quantiles") or {});q50=(q.get("q50_return_pct") if isinstance(q,dict) else None)
    try:q50=float(q50)
    except Exception:q50=None
    if cond is None or q50 is None:
        return {"status":"unavailable","severity":0.0,"action":"none","eligible":False,
                "distribution_quality_ok":True,"distribution_effective_n":eff}
    dir_sign=1 if cond>=.5 else -1
    med_sign=1 if q50>0 else (-1 if q50<0 else 0)
    disagreement=med_sign!=0 and dir_sign!=med_sign
    conviction=abs(cond-.5)*2
    mag=abs(q50); mag_pct=mag*100 if mag<.5 else mag
    severity=float(np.clip((conviction-.10)/.50,0,1)) if disagreement else 0.0
    if disagreement and mag_pct>=1.0: severity=min(1.0,severity+.20)
    status="strong_disagreement" if severity>=.7 else ("mild_disagreement" if disagreement else "agree")
    return {"status":status,"severity":round(severity,4),"directional_conditional_p_up":round(cond,4),
            "distribution_q50_return_pct":q50,"action":"abstain" if severity>=.85 else ("shrink" if severity>0 else "none"),
            "eligible":True,"distribution_quality_ok":True,"distribution_effective_n":eff,"min_effective_n":DIST_MIN_EFFECTIVE_N}


def forecast_horizon(close, symbol:str, horizon:int=10, fast:bool=True, context:dict|None=None)->dict:
    out=BASE.forecast_horizon(close,symbol=symbol,horizon=int(horizon),fast=fast,context=context)
    if not out:return {}
    out=dict(out);out["base_model_version"]=out.get("version");out["version"]=VERSION;out["model_generation"]=MODEL_GENERATION
    # Use freshness metadata from the feature layer that actually produced the
    # context factors. Caller metadata is merged only as additional evidence.
    fresh_context={"model_context":out.get("context_freshness") or {}}
    if context is not None:fresh_context["caller_context"]=context
    fresh=freshness_guard(pd.Series(close),context=fresh_context);reg=soft_regime(pd.Series(close));cons=consistency_gate(out)
    cond=_clip(out.get("conditional_p_up"));pmove=_clip(out.get("p_move"))
    reasons=[]
    if cond is not None and pmove is not None:
        # Uncertain regime boundaries should not flip experts abruptly; they only
        # shrink confidence smoothly. High entropy => modest shrink, not a hard switch.
        shrink=1.0-0.12*float(reg.get("entropy") or 0)
        if fresh["status"]=="warning":shrink*=.82;reasons.append("stale_features_warning")
        if fresh["hard_stale"]:shrink*=.55;reasons.append("stale_features_hard")
        sev=float(cons.get("severity") or 0)
        if sev>0:shrink*=max(.35,1-.55*sev);reasons.append("direction_distribution_disagreement")
        cond2=.5+shrink*(cond-.5)
        classes={"up":pmove*cond2,"neutral":1-pmove,"down":pmove*(1-cond2)}
        out["conditional_p_up"]=round(cond2,6);out["class_probabilities"]={k:round(float(v),6) for k,v in classes.items()}
        # legacy neutral-aware directional score
        out["p_up"]=round(float(.5+pmove*(cond2-.5)),6);out["p_down"]=round(float(1-out["p_up"]),6)
        out["directional_score_up"]=out["p_up"];out["directional_score_down"]=out["p_down"]
        if fresh["hard_stale"] or cons.get("action")=="abstain":
            out["abstain"]=True;out["signal_strength"]="нет преимущества"
            q=dict(out.get("quality") or {});q.update(trusted=False,confidence="низкая",reason="robustness gate: "+", ".join(reasons));out["quality"]=q
    out["freshness_guard"]=fresh;out["soft_regime"]=reg;out["consistency_gate"]=cons
    out["robustness"]={"version":VERSION,"reasons":reasons,"cross_sectional_universe":"synchronized_database_matrix",
                       "soft_regime_routing":True,"freshness_guard":True,"direction_distribution_gate":True,"distribution_gate_quality_aware":True,"feature_freshness_contract":FRESH4409.VERSION}
    val=dict(out.get("validation") or {});val.update({"robustness_version":VERSION,"freshness_guard":True,
        "soft_regime_gating":True,"direction_distribution_consistency_gate":True,"distribution_consistency_requires_quality":True,"feature_freshness_contract":FRESH4409.VERSION,"cross_sectional_user_action_independent":True});out["validation"]=val
    return out
