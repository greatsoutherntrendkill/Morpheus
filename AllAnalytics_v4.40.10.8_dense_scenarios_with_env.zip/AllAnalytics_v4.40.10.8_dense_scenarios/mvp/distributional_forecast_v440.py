"""AllAnalytics v4.40 — distributional forecast and expected move.

This layer deliberately does not alter the guarded directional probability from
v4.39.  It estimates the *distribution* of future log returns so the product can
show a calibrated range, expected absolute move and asymmetric tails instead of
pretending that a single up/down probability describes all forecast risk.

Leakage / governance rules
--------------------------
* features are point-in-time and targets are future h-session log returns;
* train -> purge -> calibration -> purge -> untouched evaluation is chronological;
* quantile interval calibration is learned on the calibration slice only;
* evaluation metrics are never used to refit or tune the live models;
* v4.40 has no production blend weight and cannot change ``p_up``;
* options IV is an external benchmark only and is never used as a hidden target.
"""
from __future__ import annotations

import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd

import event_response_v439 as BASE439
import asset_specialists_v438 as SP438
import feature_event_v434 as FE434

try:
    from sklearn.ensemble import HistGradientBoostingRegressor, GradientBoostingRegressor
except Exception:  # requirements include sklearn; kept defensive for static mode
    HistGradientBoostingRegressor = None
    GradientBoostingRegressor = None

VERSION = "distributional-forecast-v4.40.4-integrity"
VALIDATION_VERSION = "purged-eval+deployment-refit+dependence-adjusted-v4.40.4"
ROOT = Path(__file__).resolve().parent
ALT_SNAPSHOT = ROOT / "site" / "altdata_v40.json"
CACHE_SECONDS = 300
_QUANTILES = (0.10, 0.25, 0.50, 0.75, 0.90)
_CACHE: dict[tuple, tuple[float, dict]] = {}


def _finite(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _series(close) -> pd.Series:
    x = pd.Series(close, dtype=float).dropna().sort_index()
    try:
        x.index = pd.to_datetime(x.index).tz_localize(None)
    except Exception:
        x.index = pd.to_datetime(x.index)
    return x[~x.index.duplicated(keep="last")]


def _pinball(y, pred, q: float) -> float | None:
    y = np.asarray(y, float); pred = np.asarray(pred, float)
    ok = np.isfinite(y) & np.isfinite(pred)
    if not ok.any():
        return None
    e = y[ok] - pred[ok]
    loss = np.maximum(q * e, (q - 1.0) * e)
    return float(np.mean(loss))


def _distribution_eval(y, pred, baseline_quantiles, horizon: int, n_boot: int = 300) -> dict:
    """Raw + dependence-adjusted distribution metrics for overlapping H-day labels."""
    y=np.asarray(y,float); pred=np.asarray(pred,float); bq=np.asarray(baseline_quantiles,float)
    ok=np.isfinite(y)&np.all(np.isfinite(pred),axis=1)
    y=y[ok];pred=pred[ok]
    if not len(y):return {}
    def one(ii):
        yy=y[ii];pp=pred[ii]
        pins=[_pinball(yy,pp[:,j],q) for j,q in enumerate(_QUANTILES)]
        bases=[_pinball(yy,np.full(len(yy),bq[j]),q) for j,q in enumerate(_QUANTILES)]
        mp=float(np.mean([x for x in pins if x is not None]));bp=float(np.mean([x for x in bases if x is not None]))
        return {
            "coverage_80":float(np.mean((yy>=pp[:,0])&(yy<=pp[:,4]))),
            "coverage_50":float(np.mean((yy>=pp[:,1])&(yy<=pp[:,3]))),
            "mean_pinball":mp,"baseline_pinball":bp,
            "pinball_skill_pct":float((1-mp/bp)*100) if bp>1e-12 else 0.0,
            "median_mae_pct":float(np.mean(np.abs(yy-pp[:,2]))),
        }
    raw=one(np.arange(len(y),dtype=int))
    h=max(1,int(horizon));phase=[];sizes=[]
    for k in range(min(h,len(y))):
        ii=np.arange(k,len(y),h,dtype=int)
        if len(ii)<3:continue
        phase.append(one(ii));sizes.append(len(ii))
    if phase:
        dep={k:float(np.nanmedian([z[k] for z in phase])) for k in phase[0]}
        dep.update({"n_nonoverlap":int(np.median(sizes)),"phases":len(phase),"effective_n":max(1,int(len(y)//h))})
    else:
        dep={**raw,"n_nonoverlap":len(y),"phases":1,"effective_n":len(y)}
    # Moving-block bootstrap for the metrics that drive quality decisions.
    ci={};n=len(y);block=max(1,min(n,max(h,5)))
    if n>=20:
        rng=np.random.default_rng(4404+n+17*h);max_start=max(1,n-block+1);vals={k:[] for k in ("coverage_80","coverage_50","pinball_skill_pct")}
        for _ in range(max(120,int(n_boot))):
            idx=[]
            while len(idx)<n:
                st=int(rng.integers(0,max_start));idx.extend(range(st,min(st+block,n)))
            z=one(np.asarray(idx[:n],int))
            for k in vals:vals[k].append(z[k])
        for k,a in vals.items():
            arr=np.asarray(a,float);ci[k+"_ci95"]=[float(np.nanpercentile(arr,2.5)),float(np.nanpercentile(arr,97.5))]
    return {"raw":raw,"dependence_adjusted":dep,"bootstrap":{**ci,"block_size":block,"resamples":max(120,int(n_boot)) if n>=20 else 0}}


def _conformal_q(scores, coverage: float) -> float:
    s = np.asarray(scores, float)
    s = s[np.isfinite(s)]
    if not len(s):
        return 0.0
    # finite-sample split-conformal quantile; "higher" prevents optimistic
    # interpolation between calibration residuals.
    level = min(1.0, math.ceil((len(s) + 1) * float(coverage)) / len(s))
    try:
        return float(np.quantile(s, level, method="higher"))
    except TypeError:  # numpy < 1.22 compatibility
        return float(np.quantile(s, level, interpolation="higher"))


def _enforce_quantile_order(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, float)
    if a.ndim == 1:
        return np.sort(a)
    return np.sort(a, axis=1)


def _build_features(close: pd.Series, symbol: str) -> tuple[pd.DataFrame, dict]:
    own = _series(close)
    profile = FE434.asset_profile(symbol)
    # Re-use the v4.38 point-in-time class-aware feature layer, then add purely
    # historical distribution/risk descriptors needed by the quantile models.
    x, diag = SP438._build_features(own, str(symbol).upper(), profile)
    lr = np.log(own).diff()
    neg = lr.where(lr < 0, 0.0)
    pos = lr.where(lr > 0, 0.0)
    x["downside_vol_20"] = np.sqrt((neg.pow(2)).rolling(20, min_periods=10).mean()) * math.sqrt(252)
    x["upside_vol_20"] = np.sqrt((pos.pow(2)).rolling(20, min_periods=10).mean()) * math.sqrt(252)
    x["vol_ratio_20_60"] = x.get("vol_20") / x.get("vol_60").replace(0, np.nan)
    x["realized_skew_60"] = lr.rolling(60, min_periods=30).skew()
    x["abs_ret_5"] = x.get("ret_5").abs()
    x["abs_ret_20"] = x.get("ret_20").abs()
    roll_max = own.rolling(60, min_periods=20).max()
    x["drawdown_60"] = own / roll_max - 1.0
    return x.replace([np.inf, -np.inf], np.nan), {**diag, "feature_count": int(x.shape[1])}


def _future_return(close: pd.Series, horizon: int) -> pd.Series:
    own = _series(close)
    return (np.log(own.shift(-int(horizon)) / own) * 100.0).replace([np.inf, -np.inf], np.nan)


def _fit_quantile_model(X, y, q: float, fast: bool = False):
    try:
        if HistGradientBoostingRegressor is None:
            raise RuntimeError("HistGradientBoostingRegressor unavailable")
        mdl = HistGradientBoostingRegressor(
            loss="quantile", quantile=float(q), learning_rate=.08 if fast else .055, max_iter=24 if fast else 100,
            max_leaf_nodes=8 if fast else 15, min_samples_leaf=18, l2_regularization=.35,
            random_state=440,
        )
        mdl.fit(X, y)
        return mdl, "HistGradientBoostingRegressor"
    except Exception:
        if GradientBoostingRegressor is None:
            raise
        mdl = GradientBoostingRegressor(
            loss="quantile", alpha=float(q), n_estimators=36 if fast else 110, learning_rate=.07 if fast else .04,
            max_depth=2, min_samples_leaf=14, random_state=440,
        )
        mdl.fit(X, y)
        return mdl, "GradientBoostingRegressor"


def _fit_abs_move_model(X, y_abs, fast: bool = False):
    try:
        if HistGradientBoostingRegressor is None:
            raise RuntimeError("HistGradientBoostingRegressor unavailable")
        mdl = HistGradientBoostingRegressor(
            loss="absolute_error", learning_rate=.08 if fast else .055, max_iter=22 if fast else 90,
            max_leaf_nodes=8 if fast else 15, min_samples_leaf=18, l2_regularization=.35,
            random_state=441,
        )
        mdl.fit(X, y_abs)
        return mdl
    except Exception:
        return None


def _prepare(close: pd.Series, symbol: str, horizon: int):
    x, feature_diag = _build_features(close, symbol)
    y = _future_return(close, horizon)
    data = x.copy(); data["__y__"] = y
    # Keep rows with a real target and at least 35% feature availability.  The
    # actual imputation statistics are learned on train only below.
    feat_cols = [c for c in data.columns if c != "__y__"]
    coverage = data[feat_cols].notna().mean(axis=1)
    data = data[data["__y__"].notna() & (coverage >= .35)].sort_index()
    n = len(data); h = int(horizon)
    if n < 250:
        return None, {**feature_diag, "usable_rows": n, "reason": "need >=250 labelled rows"}

    train_end = max(145, int(n * .60))
    cal_end = max(train_end + h + 42, int(n * .80))
    if cal_end + h + 24 > n:
        cal_end = n - h - 24
    cal_start = train_end + h
    eval_start = cal_end + h
    if cal_start >= cal_end or eval_start >= n:
        return None, {**feature_diag, "usable_rows": n, "reason": "not enough rows after purge gaps"}

    train = data.iloc[:train_end].copy()
    cal = data.iloc[cal_start:cal_end].copy()
    ev = data.iloc[eval_start:].copy()
    if len(train) < 120 or len(cal) < 30 or len(ev) < 20:
        return None, {**feature_diag, "usable_rows": n, "reason": "chronological slices too small"}

    # Drop features that are mostly unavailable in train; no future slice can
    # rescue a feature that was not known reliably during training.
    available = train[feat_cols].notna().mean()
    cols = [c for c in feat_cols if float(available.get(c, 0)) >= .45]
    if len(cols) < 7:
        return None, {**feature_diag, "usable_rows": n, "reason": "insufficient point-in-time feature coverage"}

    med = train[cols].median(numeric_only=True).reindex(cols).fillna(0.0)
    lo = train[cols].quantile(.01).reindex(cols)
    hi = train[cols].quantile(.99).reindex(cols)

    def tx(frame):
        z = frame[cols].copy().fillna(med)
        for c in cols:
            a, b = _finite(lo.get(c)), _finite(hi.get(c))
            if a is not None and b is not None and a < b:
                z[c] = z[c].clip(a, b)
        return z.to_numpy(float)

    live_raw = x.iloc[[-1]].reindex(columns=cols)
    live_coverage = float(live_raw.notna().mean(axis=1).iloc[0]) if len(cols) else 0.0
    live = live_raw.fillna(med)
    for c in cols:
        a, b = _finite(lo.get(c)), _finite(hi.get(c))
        if a is not None and b is not None and a < b:
            live[c] = live[c].clip(a, b)

    return {
        "cols": cols, "X_train": tx(train), "y_train": train["__y__"].to_numpy(float),
        "X_cal": tx(cal), "y_cal": cal["__y__"].to_numpy(float),
        "X_eval": tx(ev), "y_eval": ev["__y__"].to_numpy(float),
        "X_live": live.to_numpy(float), "live_coverage": live_coverage,
        "split": {"train_n": len(train), "purge_train_cal": h, "calibration_n": len(cal),
                  "purge_cal_eval": h, "evaluation_n": len(ev)},
        "feature_diag": {**feature_diag, "usable_rows": n},
    }, None


def _options_benchmark(symbol: str, horizon: int) -> dict:
    try:
        snap = json.loads(ALT_SNAPSHOT.read_text(encoding="utf-8"))
    except Exception:
        return {"available": False, "reason": "options snapshot unavailable"}
    sym = str(symbol).upper()
    rows = []
    try:
        under = ((snap.get("options") or {}).get("underlyings") or {})
        for r in under.values():
            if not isinstance(r, dict):
                continue
            linked = [str(x).upper() for x in (r.get("linked_assets") or [])]
            if sym == str(r.get("underlying") or "").upper() or sym in linked:
                rows.append(r)
    except Exception:
        rows = []
    candidates = []
    for r in rows:
        iv = _finite(r.get("median_iv"))
        if iv is None or iv <= 0 or iv > 5:
            continue
        move = iv * math.sqrt(max(1, int(horizon)) / 252.0) * 100.0
        candidates.append({
            "underlying": r.get("underlying"), "median_iv": round(iv, 6),
            "implied_move_pct_1sigma": round(move, 4),
            "expiration": r.get("nearest_30d_expiration"), "source": r.get("source"),
            "fallback_used": bool(r.get("fallback_used")),
        })
    if not candidates:
        return {"available": False, "reason": "no fresh mapped options IV in local snapshot"}
    # One benchmark is easier to audit than silently averaging unrelated proxies.
    best = candidates[0]
    return {"available": True, **best}



def _fast_distribution_forecast(close: pd.Series, symbol: str, horizon: int) -> dict:
    """Low-latency empirical distribution for market cards.

    It conditions historical h-session returns on a broad current volatility and
    trend state.  No sklearn fit occurs on the request path.  Calibration and an
    untouched evaluation slice are still chronological, so the fast range remains
    auditable rather than being a cosmetic ATR band.
    """
    own=_series(close);h=int(horizon)
    if len(own)<180:
        return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"insufficient_history",
                "symbol":str(symbol).upper(),"horizon":h,"reason":"fast distribution needs >=180 closes"}
    lr=np.log(own).diff()
    vol20=lr.rolling(20,min_periods=12).std()*math.sqrt(h)*100.0
    ret20=np.log(own/own.shift(20))*100.0
    target=_future_return(own,h)
    hist=pd.DataFrame({"y":target,"vol":vol20,"trend":ret20},index=own.index).iloc[:-h].dropna(subset=["y"])
    if len(hist)<140:
        return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"insufficient_distribution_sample",
                "symbol":str(symbol).upper(),"horizon":h,"reason":"not enough labelled fast-distribution rows"}
    cur_vol=_finite(vol20.iloc[-1]);cur_trend=_finite(ret20.iloc[-1])
    selected=hist
    if cur_vol is not None and cur_vol>0:
        selected=selected[(selected["vol"].isna())|((selected["vol"]>=cur_vol*.62)&(selected["vol"]<=cur_vol*1.62))]
    if cur_trend is not None and abs(cur_trend)>=.15:
        same=selected[np.sign(selected["trend"].fillna(0))==np.sign(cur_trend)]
        if len(same)>=80:selected=same
    if len(selected)<90:selected=hist
    selected=selected.sort_index()
    n=len(selected);a=max(70,int(n*.60));b=max(a+25,int(n*.80));b=min(b,n-22)
    if b<=a or n-b<18:
        a=max(60,int(n*.65));b=max(a+20,n-20)
    train=selected.iloc[:a]["y"].to_numpy(float);cal=selected.iloc[a:b]["y"].to_numpy(float);ev=selected.iloc[b:]["y"].to_numpy(float)
    if len(train)<55 or len(cal)<15 or len(ev)<15:
        return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"insufficient_distribution_sample",
                "symbol":str(symbol).upper(),"horizon":h,"reason":"fast chronological slices too small"}
    raw=np.quantile(train,_QUANTILES)
    median_bias=float(np.median(cal-raw[2]))
    shifted=raw+median_bias
    score80=np.maximum.reduce([np.full(len(cal),shifted[0])-cal,cal-np.full(len(cal),shifted[4]),np.zeros(len(cal))])
    score50=np.maximum.reduce([np.full(len(cal),shifted[1])-cal,cal-np.full(len(cal),shifted[3]),np.zeros(len(cal))])
    corr80=max(0.0,_conformal_q(score80,.80));corr50=max(0.0,_conformal_q(score50,.50))
    live=np.array([shifted[0]-corr80,shifted[1]-corr50,shifted[2],shifted[3]+corr50,shifted[4]+corr80],float)
    live=_enforce_quantile_order(live)
    peval=np.tile(live,(len(ev),1))
    pinballs={str(q):_pinball(ev,peval[:,i],q) for i,q in enumerate(_QUANTILES)}
    mean_pinball=float(np.mean([v for v in pinballs.values() if v is not None]))
    base_q=np.quantile(hist.iloc[:max(70,int(len(hist)*.60))]["y"].to_numpy(float),_QUANTILES)
    base_losses=[_pinball(ev,np.full(len(ev),base_q[i]),q) for i,q in enumerate(_QUANTILES)]
    base_pinball=float(np.mean([v for v in base_losses if v is not None]));skill=(1-mean_pinball/base_pinball)*100 if base_pinball>1e-12 else 0.0
    cov80=float(np.mean((ev>=live[0])&(ev<=live[4])));cov50=float(np.mean((ev>=live[1])&(ev<=live[3])))
    sigma20=float(lr.tail(20).std(ddof=1)*math.sqrt(h)*100.0) if len(lr.dropna())>=12 else 0.0
    sigma60=float(lr.tail(60).std(ddof=1)*math.sqrt(h)*100.0) if len(lr.dropna())>=30 else sigma20
    vol_expected=max(0.0,.65*sigma20+.35*sigma60)
    min80=1.28155*max(vol_expected,.05);min50=.67449*max(vol_expected,.05)
    live[0]=min(live[0],live[2]-min80);live[4]=max(live[4],live[2]+min80);live[1]=min(live[1],live[2]-min50);live[3]=max(live[3],live[2]+min50);live=_enforce_quantile_order(live)
    expected_hist=float(np.mean(np.abs(selected["y"].tail(min(180,len(selected))).to_numpy(float))))
    expected_move=max(.01,.65*expected_hist+.35*vol_expected)
    px=float(own.iloc[-1]);qmap={f"q{int(q*100):02d}_return_pct":round(float(live[i]),4) for i,q in enumerate(_QUANTILES)};pmap={f"q{int(q*100):02d}_price":round(px*math.exp(float(live[i])/100.0),6) for i,q in enumerate(_QUANTILES)}
    up=float(live[4]-live[2]);down=float(live[2]-live[0]);options=_options_benchmark(symbol,h)
    if options.get("available"):options["model_to_iv_move_ratio"]=round(expected_move/max(float(options["implied_move_pct_1sigma"]),1e-9),4)
    # Conservative non-overlap effective sample for the fast profile.  Daily
    # overlapping H-day outcomes are not independent; the consistency gate may
    # only use this layer when the effective sample is large enough.
    effective_n=max(1,int(len(ev)//max(1,h)))
    quality_ok=bool(skill>0 and .66<=cov80<=.95 and .35<=cov50<=.72 and effective_n>=8)
    return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"ok","symbol":str(symbol).upper(),"horizon":h,
            "return_definition":"future log return, percent","quantiles":qmap,"price_quantiles":pmap,
            "interval_50":{"low_return_pct":qmap["q25_return_pct"],"high_return_pct":qmap["q75_return_pct"],"low_price":pmap["q25_price"],"high_price":pmap["q75_price"],"nominal_coverage":.50},
            "interval_80":{"low_return_pct":qmap["q10_return_pct"],"high_return_pct":qmap["q90_return_pct"],"low_price":pmap["q10_price"],"high_price":pmap["q90_price"],"nominal_coverage":.80},
            "expected_abs_move_pct":round(expected_move,4),"volatility_expected_move_pct_1sigma":round(vol_expected,4),
            "upside_tail_pct":round(up,4),"downside_tail_pct":round(down,4),"tail_asymmetry_pct":round(up-down,4),"options_benchmark":options,
            "calibration":{"median_bias_pct":round(median_bias,5),"interval80_addon_pct":round(corr80,5),"interval50_addon_pct":round(corr50,5),"method":"chronological split-conformal empirical fast profile"},
            "evaluation":{"n":int(len(ev)),"effective_n":int(effective_n),"effective_n_method":"non-overlap floor(n/horizon)","coverage_80":round(cov80,4),"coverage_50":round(cov50,4),"mean_pinball":round(mean_pinball,6),"baseline_pinball":round(base_pinball,6),"pinball_skill_pct":round(skill,3),"crps_like":round(2*mean_pinball,6),"median_mae_pct":round(float(np.mean(np.abs(ev-live[2]))),4),"quantile_pinball":{k:None if v is None else round(v,6) for k,v in pinballs.items()}},
            "development_split":{"train_n":len(train),"calibration_n":len(cal),"evaluation_n":len(ev),"conditioning_n":int(n)},
            "feature_count":3,"feature_coverage":1.0,"feature_diagnostics":{"conditioning":"current volatility band + trend sign","selected_rows":int(n),"all_rows":int(len(hist))},
            "selected_model_family":"EmpiricalRegimeQuantiles","compute_profile":"fast_empirical","quality_ok":quality_ok,
            "automatic_promotion":False,"changes_directional_probability":False,
            "reason":"low-latency regime-conditioned empirical quantiles; p_up remains controlled by v4.39"}

def distribution_forecast(close: pd.Series, symbol: str, horizon: int, fast: bool = False) -> dict:
    own = _series(close); h = int(horizon)
    if fast:
        key_fast=(str(symbol).upper(),h,True,str(own.index[-1])[:10] if len(own) else "",round(float(own.iloc[-1]),6) if len(own) else None)
        cached=_CACHE.get(key_fast)
        if cached and time.time()-cached[0]<CACHE_SECONDS:return dict(cached[1])
        out=_fast_distribution_forecast(own,symbol,h)
        if out.get("status")=="ok":
            out["version"]=VERSION;out["validation_version"]=VALIDATION_VERSION
            out["production_refit"]={"method":"fast empirical conditioning","calibration_matches_live_profile":True}
        _CACHE[key_fast]=(time.time(),dict(out));return out
    key = (str(symbol).upper(), h, bool(fast), str(own.index[-1])[:10] if len(own) else "", round(float(own.iloc[-1]), 6) if len(own) else None)
    cached = _CACHE.get(key)
    if cached and time.time() - cached[0] < CACHE_SECONDS:return dict(cached[1])
    if len(own) < 280:
        out = {"version": VERSION, "validation_version": VALIDATION_VERSION, "status": "insufficient_history",
               "symbol": str(symbol).upper(), "horizon": h, "reason": "distribution model needs longer history"}
        _CACHE[key] = (time.time(), out); return out

    prepared, error = _prepare(own, str(symbol).upper(), h)
    if prepared is None:
        out = {"version": VERSION, "validation_version": VALIDATION_VERSION, "status": "insufficient_distribution_sample",
               "symbol": str(symbol).upper(), "horizon": h, **(error or {})}
        _CACHE[key] = (time.time(), out); return out

    # -------- untouched development evaluation --------
    dev_models = {}; family = None
    for q in _QUANTILES:
        mdl, fam = _fit_quantile_model(prepared["X_train"], prepared["y_train"], q, fast=False)
        dev_models[q] = mdl; family = family or fam
    def predict_with(models, X):
        return _enforce_quantile_order(np.column_stack([models[q].predict(X) for q in _QUANTILES]))
    pcal = predict_with(dev_models, prepared["X_cal"])
    median_bias = float(np.median(prepared["y_cal"] - pcal[:, 2])); pcal = pcal + median_bias
    score80=np.maximum.reduce([pcal[:,0]-prepared["y_cal"],prepared["y_cal"]-pcal[:,4],np.zeros(len(pcal))])
    score50=np.maximum.reduce([pcal[:,1]-prepared["y_cal"],prepared["y_cal"]-pcal[:,3],np.zeros(len(pcal))])
    corr80=max(0.0,_conformal_q(score80,.80));corr50=max(0.0,_conformal_q(score50,.50))
    def apply_cal(z,bias,c80,c50):
        z=_enforce_quantile_order(np.asarray(z,float))+bias;one=z.ndim==1
        if one:z=z.reshape(1,-1)
        z[:,0]-=c80;z[:,4]+=c80;z[:,1]-=c50;z[:,3]+=c50;z=_enforce_quantile_order(z)
        return z[0] if one else z
    peval=apply_cal(predict_with(dev_models,prepared["X_eval"]),median_bias,corr80,corr50)
    yev=prepared["y_eval"]
    train_q=np.quantile(prepared["y_train"],_QUANTILES)
    audit=_distribution_eval(yev,peval,train_q,horizon=h,n_boot=260)
    raw=audit.get("raw") or {};dep=audit.get("dependence_adjusted") or raw
    pinballs={str(q):_pinball(yev,peval[:,i],q) for i,q in enumerate(_QUANTILES)}

    # -------- deployment refit + deployment-matched calibration --------
    # After the untouched evaluation is computed, the live model may use old eval
    # outcomes.  A recent tail remains reserved for calibration so the calibrator
    # is fitted to predictions from the exact same deployment model.
    Xhist=np.vstack([prepared["X_train"],prepared["X_cal"],prepared["X_eval"]])
    yhist=np.concatenate([prepared["y_train"],prepared["y_cal"],prepared["y_eval"]])
    dep_cal_n=max(30,min(80,int(len(yhist)*.18)))
    dep_train_X,dep_train_y=Xhist[:-dep_cal_n],yhist[:-dep_cal_n]
    dep_cal_X,dep_cal_y=Xhist[-dep_cal_n:],yhist[-dep_cal_n:]
    prod_models={}
    for q in _QUANTILES:
        prod_models[q],_=_fit_quantile_model(dep_train_X,dep_train_y,q,fast=False)
    prod_cal_raw=predict_with(prod_models,dep_cal_X)
    prod_bias=float(np.median(dep_cal_y-prod_cal_raw[:,2]));prod_cal_shift=prod_cal_raw+prod_bias
    prod_s80=np.maximum.reduce([prod_cal_shift[:,0]-dep_cal_y,dep_cal_y-prod_cal_shift[:,4],np.zeros(len(dep_cal_y))])
    prod_s50=np.maximum.reduce([prod_cal_shift[:,1]-dep_cal_y,dep_cal_y-prod_cal_shift[:,3],np.zeros(len(dep_cal_y))])
    prod_corr80=max(0.0,_conformal_q(prod_s80,.80));prod_corr50=max(0.0,_conformal_q(prod_s50,.50))
    live=apply_cal(predict_with(prod_models,prepared["X_live"])[0],prod_bias,prod_corr80,prod_corr50)
    abs_model=_fit_abs_move_model(dep_train_X,np.abs(dep_train_y),fast=False)
    abs_move=_finite(abs_model.predict(prepared["X_live"])[0]) if abs_model is not None else None

    daily=np.log(own).diff().dropna();sigma20=float(daily.tail(20).std(ddof=1)*math.sqrt(h)*100.0) if len(daily)>=12 else 0.0
    sigma60=float(daily.tail(60).std(ddof=1)*math.sqrt(h)*100.0) if len(daily)>=30 else sigma20
    vol_expected=max(0.0,.65*sigma20+.35*sigma60)
    dep_skill=float(dep.get("pinball_skill_pct") or 0);dep_cov80=float(dep.get("coverage_80") or 0);dep_cov50=float(dep.get("coverage_50") or 0);dep_n=int(dep.get("effective_n") or 0)
    quality_ok=bool(dep_skill>0 and .66<=dep_cov80<=.95 and .36<=dep_cov50<=.70 and dep_n>=15 and prepared["live_coverage"]>=.45)
    if not quality_ok:live[2]*=.35
    min80=1.28155*max(vol_expected,.05);min50=.67449*max(vol_expected,.05)
    live[0]=min(live[0],live[2]-min80);live[4]=max(live[4],live[2]+min80);live[1]=min(live[1],live[2]-min50);live[3]=max(live[3],live[2]+min50);live=_enforce_quantile_order(live)
    if abs_move is None or not math.isfinite(abs_move):abs_move=(abs(live[1])+abs(live[3]))/2.0
    expected_move=max(.01,.65*max(0.0,abs_move)+.35*vol_expected)

    px=float(own.iloc[-1]);qmap={f"q{int(q*100):02d}_return_pct":round(float(live[i]),4) for i,q in enumerate(_QUANTILES)}
    pmap={f"q{int(q*100):02d}_price":round(px*math.exp(float(live[i])/100.0),6) for i,q in enumerate(_QUANTILES)}
    upside_tail=float(live[4]-live[2]);downside_tail=float(live[2]-live[0]);options=_options_benchmark(symbol,h)
    if options.get("available"):options["model_to_iv_move_ratio"]=round(expected_move/max(float(options["implied_move_pct_1sigma"]),1e-9),4)
    out={
        "version":VERSION,"validation_version":VALIDATION_VERSION,"status":"ok","symbol":str(symbol).upper(),"horizon":h,
        "return_definition":"future log return, percent","quantiles":qmap,"price_quantiles":pmap,
        "interval_50":{"low_return_pct":qmap["q25_return_pct"],"high_return_pct":qmap["q75_return_pct"],"low_price":pmap["q25_price"],"high_price":pmap["q75_price"],"nominal_coverage":.50},
        "interval_80":{"low_return_pct":qmap["q10_return_pct"],"high_return_pct":qmap["q90_return_pct"],"low_price":pmap["q10_price"],"high_price":pmap["q90_price"],"nominal_coverage":.80},
        "expected_abs_move_pct":round(expected_move,4),"volatility_expected_move_pct_1sigma":round(vol_expected,4),
        "upside_tail_pct":round(upside_tail,4),"downside_tail_pct":round(downside_tail,4),"tail_asymmetry_pct":round(upside_tail-downside_tail,4),
        "options_benchmark":options,
        "calibration":{"median_bias_pct":round(prod_bias,5),"interval80_addon_pct":round(prod_corr80,5),"interval50_addon_pct":round(prod_corr50,5),
                       "method":"deployment-matched chronological split conformal tail"},
        "development_calibration":{"median_bias_pct":round(median_bias,5),"interval80_addon_pct":round(corr80,5),"interval50_addon_pct":round(corr50,5)},
        "evaluation":{"n":int(len(yev)),"coverage_80":round(float(raw.get("coverage_80",0)),4),"coverage_50":round(float(raw.get("coverage_50",0)),4),
                      "mean_pinball":round(float(raw.get("mean_pinball",0)),6),"baseline_pinball":round(float(raw.get("baseline_pinball",0)),6),
                      "pinball_skill_pct":round(float(raw.get("pinball_skill_pct",0)),3),"crps_like":round(2*float(raw.get("mean_pinball",0)),6),
                      "median_mae_pct":round(float(raw.get("median_mae_pct",0)),4),"quantile_pinball":{k:None if v is None else round(v,6) for k,v in pinballs.items()},
                      "dependence_adjusted":{k:(round(v,6) if isinstance(v,float) else v) for k,v in dep.items()},"block_bootstrap":audit.get("bootstrap") or {}},
        "development_split":prepared["split"],"production_refit":{"fit_n":int(len(dep_train_y)),"calibration_n":int(len(dep_cal_y)),
            "uses_completed_evaluation_after_audit":True,"calibration_matches_deployment_fit":True,"evaluation_metrics_not_recomputed_after_refit":True},
        "feature_count":len(prepared["cols"]),"feature_coverage":round(prepared["live_coverage"],4),"feature_diagnostics":prepared["feature_diag"],
        "selected_model_family":family,"compute_profile":"full","quality_ok":quality_ok,"automatic_promotion":False,"changes_directional_probability":False,
        "reason":"distributional risk layer with untouched evaluation, dependence-aware audit and deployment-matched refit/calibration; directional p_up is unchanged",
    }
    _CACHE[key]=(time.time(),out);return dict(out)


def forecast_horizon(close: pd.Series, symbol: str, horizon: int = 10, fast: bool = True, context: dict | None = None) -> dict:
    base = BASE439.forecast_horizon(close, symbol=symbol, horizon=int(horizon), fast=fast, context=context)
    if not base or base.get("p_up") is None:
        return base or {}
    dist = distribution_forecast(close, symbol, int(horizon), fast=bool(fast))
    out = dict(base)
    # Critical governance invariant: v4.40 does not alter p_up, threshold, abstain
    # or component weights.  It only adds a second, auditable distribution output.
    out["distribution_version"] = VERSION
    out["distribution_forecast"] = dist
    validation = dict(out.get("validation") or {})
    validation.update({
        "distributional_forecast": dist.get("status") == "ok",
        "distributional_quality_ok": bool(dist.get("quality_ok")),
        "distributional_purged_time_ordered_split": True,
        "distributional_interval_calibration": "deployment_matched_split_conformal",
        "distributional_dependence_adjusted_evaluation": True,
        "distributional_production_refit_after_audit": True,
        "distributional_changes_directional_probability": False,
        "distributional_validation_version": VALIDATION_VERSION,
        "automatic_promotion": False,
    })
    out["validation"] = validation
    score = dict(out.get("scorecard") or {})
    if dist.get("status") == "ok":
        q = dist.get("quantiles") or {}; ev = dist.get("evaluation") or {}
        score.update({
            "distribution_q10_return_pct": q.get("q10_return_pct"),
            "distribution_q50_return_pct": q.get("q50_return_pct"),
            "distribution_q90_return_pct": q.get("q90_return_pct"),
            "distribution_expected_abs_move_pct": dist.get("expected_abs_move_pct"),
            "distribution_coverage_80": ev.get("coverage_80"),
            "distribution_pinball_skill_pct": ev.get("pinball_skill_pct"),
        })
    out["scorecard"] = score
    return out
