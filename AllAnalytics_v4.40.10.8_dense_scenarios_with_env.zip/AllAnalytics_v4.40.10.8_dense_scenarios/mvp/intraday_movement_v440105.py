"""Descriptive intraday movement statistics; no change to direction prediction."""
import numpy as np
import pandas as pd

MINUTES={'30m':30,'1h':60,'2h':120,'4h':240}

def build(frame,horizon,interval_minutes=5):
    minutes=MINUTES[horizon]
    bars=minutes//interval_minutes
    out={'version':'intraday-movement-v4.40.10.5','horizon':horizon,'basis':'intraday_empirical',
         'material_move_threshold_pct':None,'expected_abs_move_pct':None,
         'material_threshold_recent_iqr_pct':None,'distribution_quality_ok':False,
         'directional_scenario_range':None,'range_status':'research_only',
         'reason':'Направленный внутридневной диапазон не калиброван. Порог — нижний квартиль, типичный масштаб — медиана абсолютных исторических движений за выбранный горизонт; это описательная статистика, не ценовая цель.'}
    if bars<1:return out
    d=frame[['date','close']].copy()
    d['date']=pd.to_datetime(d['date'],utc=True,errors='coerce')
    d['close']=pd.to_numeric(d['close'],errors='coerce')
    d=d.dropna().sort_values('date').drop_duplicates('date')
    d=d[d.close>0]
    # Only complete fixed-duration windows: do not call overnight/weekend gaps one hour.
    gaps=d.date.diff().dt.total_seconds().div(60)
    contiguous=gaps.eq(interval_minutes).rolling(bars).sum().eq(bars)
    ret=np.log(d.close/d.close.shift(bars))*100
    values=ret[contiguous].replace([np.inf,-np.inf],np.nan).dropna().abs()
    out['observations']=int(len(values))
    if len(values)<30:
        out['range_status']='insufficient_history'
        out['reason']='Недостаточно полных внутридневных окон для выбранного горизонта; числовые параметры не публикуются.'
        return out
    out['material_move_threshold_pct']=round(float(values.quantile(.25)),4)
    out['expected_abs_move_pct']=round(float(values.median()),4)
    return out
