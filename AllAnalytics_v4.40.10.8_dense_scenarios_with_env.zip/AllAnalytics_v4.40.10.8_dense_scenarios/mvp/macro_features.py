"""macro_features.py — revision-aware point-in-time macro feature layer.

v3.1 reconstructs the macro information set from ALFRED new/revised observation
events. Initial releases and later revisions become visible only from their own
available_date; revised current FRED history is never back-filled into past ML.

The reconstructed state also computes observation-date YoY and ~3-month changes,
so revisions to historical observations affect derived features only after the
revision becomes public.

Legacy fixed publication lags remain opt-in via MACRO_ALLOW_LEGACY_LAG=1.
"""
import os
import numpy as np
import pandas as pd

import db
import config as C


def load_calendar() -> pd.DataFrame:
    """Календарь заседаний ЦБ из seed_cb_calendar.csv (date, cb, event, expected, actual)."""
    try:
        c = pd.read_csv(C.CB_CALENDAR_SEED, parse_dates=["date"])
        return c.sort_values("date").reset_index(drop=True)
    except Exception:
        return pd.DataFrame(columns=["date", "cb", "event"])



# Legacy fallback lags. v3.0 live models prefer macro_pit/ALFRED.
LAG_DAYS = {
    "FEDFUNDS": 1, "DGS10": 1, "CBR_KEYRATE": 1,
    "IR3TIB01EZM156N": 20, "IR3TIB01GBM156N": 20, "IR3TIB01JPM156N": 20,
    "CPIAUCSL": 45, "CPILFESL": 45, "PCEPI": 30,
    "UNRATE": 7, "PAYEMS": 7, "INDPRO": 17, "GDPC1": 90,
    "RUSCPIALLMINMEI": 45, "LRHUTTTTRUM156S": 60,
}
DEFAULT_LAG = 30
BD_YEAR, BD_QTR, BD_MONTH = 252, 63, 21



def _bool_env(name: str, default=False) -> bool:
    v = os.getenv(name)
    if v is None:
        return bool(default)
    return str(v).strip().lower() in {"1", "true", "yes", "on"}


def _state_value_at_or_before(keys, state, target_date):
    """Latest observation value with observation_date <= target_date."""
    import bisect
    if not keys:
        return np.nan
    target = pd.Timestamp(target_date)
    pos = bisect.bisect_right(keys, target) - 1
    if pos < 0:
        return np.nan
    return float(state[keys[pos]])


def _series_revision_metrics(g: pd.DataFrame, price_index: pd.DatetimeIndex) -> pd.DataFrame:
    """Reconstruct the information set through every ALFRED revision event.

    For each available_date we apply every new/revised observation known that day,
    then compute:
      - latest level;
      - YoY change from observation-date history;
      - ~3 month level change from observation-date history.

    This means a revision can change a derived macro feature only from the date that
    revision became public; it is never back-filled into earlier model dates.
    """
    import bisect
    cols = ["level", "yoy", "chg3m"]
    if g is None or g.empty:
        return pd.DataFrame(index=price_index, columns=cols, dtype=float)

    gg = g.dropna(subset=["available_date", "observation_date", "value"]).copy()
    if gg.empty:
        return pd.DataFrame(index=price_index, columns=cols, dtype=float)
    gg["available_date"] = pd.to_datetime(gg["available_date"])
    gg["observation_date"] = pd.to_datetime(gg["observation_date"])
    gg = gg.sort_values(["available_date", "observation_date"])

    state = {}
    keys = []
    rec = []
    for avail, batch in gg.groupby("available_date", sort=True):
        for _, row in batch.iterrows():
            od = pd.Timestamp(row["observation_date"])
            if od not in state:
                bisect.insort(keys, od)
            state[od] = float(row["value"])

        if not keys:
            continue
        latest_date = keys[-1]
        latest = float(state[latest_date])
        prev_year = _state_value_at_or_before(
            keys, state, latest_date - pd.DateOffset(years=1)
        )
        prev_3m = _state_value_at_or_before(
            keys, state, latest_date - pd.DateOffset(months=3)
        )
        yoy = np.nan
        if np.isfinite(prev_year) and abs(prev_year) > 1e-12:
            yoy = (latest / prev_year - 1.0) * 100.0
        chg3m = latest - prev_3m if np.isfinite(prev_3m) else np.nan
        rec.append({
            "available_date": pd.Timestamp(avail),
            "level": latest,
            "yoy": yoy,
            "chg3m": chg3m,
        })

    if not rec:
        return pd.DataFrame(index=price_index, columns=cols, dtype=float)
    ev = pd.DataFrame(rec).drop_duplicates("available_date", keep="last").set_index("available_date")
    full = ev.reindex(price_index.union(ev.index)).sort_index().ffill()
    return full.reindex(price_index)[cols]


def _raw_daily_pit(con, price_index: pd.DatetimeIndex) -> pd.DataFrame:
    pit = db.read_macro_pit(con)
    if pit.empty:
        return pd.DataFrame(index=price_index)
    cols = {}
    for sid, g in pit.groupby("series"):
        metrics = _series_revision_metrics(g, price_index)
        if metrics.empty or metrics["level"].isna().all():
            continue
        cols[sid] = metrics["level"]
        cols[sid + "__yoy"] = metrics["yoy"]
        cols[sid + "__chg3m"] = metrics["chg3m"]
    return pd.DataFrame(cols, index=price_index)


def _raw_daily_legacy(con, price_index: pd.DatetimeIndex) -> pd.DataFrame:
    """Old revised-FRED + fixed-lag approximation. Opt-in only in v3.0."""
    m = db.read_macro(con)
    if m.empty:
        return pd.DataFrame(index=price_index)
    cols = {}
    for sid, g in m.groupby("series"):
        s = g.set_index("date")["value"].sort_index()
        lag = LAG_DAYS.get(sid, DEFAULT_LAG)
        s.index = s.index + pd.Timedelta(days=lag)
        s = s[~s.index.duplicated(keep="last")]
        joined = s.reindex(price_index.union(s.index)).sort_index().ffill()
        cols[sid] = joined.reindex(price_index)
    return pd.DataFrame(cols, index=price_index)


def _raw_daily(con, price_index: pd.DatetimeIndex) -> pd.DataFrame:
    """Point-in-time macro on the trading calendar.

    Strict default: PIT first-release data only.  Legacy fixed-lag data is used
    only when MACRO_ALLOW_LEGACY_LAG=1 is explicitly set.
    """
    pit = _raw_daily_pit(con, price_index)
    if not pit.empty and len(pit.columns):
        return pit
    if _bool_env("MACRO_ALLOW_LEGACY_LAG", False):
        return _raw_daily_legacy(con, price_index)
    return pd.DataFrame(index=price_index)


def macro_data_audit(con) -> dict:
    """Provenance report for the macro information set used by ML."""
    pit = db.read_macro_pit(con)
    releases = db.read_macro_releases(con)
    target = set(C.FRED_US) | set(C.FRED_RU) | set(C.FRED_RATES) | {C.CBR_KEYRATE_SERIES}
    if pit.empty:
        legacy = _bool_env("MACRO_ALLOW_LEGACY_LAG", False)
        return {
            "mode": "legacy_fixed_lag" if legacy else "price_only_no_pit",
            "label": "Legacy fixed lag" if legacy else "PIT unavailable · macro omitted",
            "pit_series": 0, "target_series": len(target),
            "coverage_pct": 0.0, "rows": 0,
            "revision_rows": 0, "timed_release_rows": 0,
        }

    have = set(pit["series"].dropna().astype(str))
    coverage = 100.0 * len(have & target) / max(1, len(target))
    sources = sorted(set(pit.get("source", pd.Series(dtype=str)).dropna().astype(str)))
    revision_rows = int((pd.to_numeric(pit.get("is_initial", 1), errors="coerce").fillna(1) == 0).sum())
    timed = 0
    total_rel = 0
    if releases is not None and not releases.empty:
        total_rel = int(len(releases))
        timed = int((releases["precision"] == "scheduled_time").sum())

    mode = "point_in_time_revision_aware" if revision_rows > 0 else "point_in_time_initial_release"
    label = ("ALFRED PIT · revision-aware"
             if revision_rows > 0 else "ALFRED PIT · initial releases")
    return {
        "mode": mode,
        "label": label,
        "pit_series": len(have & target),
        "target_series": len(target),
        "coverage_pct": round(coverage, 1),
        "rows": int(len(pit)),
        "revision_rows": revision_rows,
        "timed_release_rows": timed,
        "release_rows": total_rel,
        "available_from": None if pit["available_date"].isna().all()
            else str(pit["available_date"].min().date()),
        "available_to": None if pit["available_date"].isna().all()
            else str(pit["available_date"].max().date()),
        "sources": sources,
    }


def _aux(raw: pd.DataFrame, sid: str, kind: str, fallback=None):
    c = f"{sid}__{kind}"
    if c in raw.columns:
        return raw[c]
    return fallback


def _derive(raw: pd.DataFrame) -> pd.DataFrame:
    """Economic features from the reconstructed vintage-aware information set."""
    f = pd.DataFrame(index=raw.index)
    have = set(raw.columns)

    if "FEDFUNDS" in have:
        f["us_ff"] = raw["FEDFUNDS"]
        f["us_ff_chg3m"] = _aux(raw, "FEDFUNDS", "chg3m",
                                 raw["FEDFUNDS"].diff(BD_QTR))
    if "DGS2" in have:
        f["ust_2y"] = raw["DGS2"]
    if "DGS5" in have:
        f["ust_5y"] = raw["DGS5"]
    if "DGS10" in have:
        f["ust_10y"] = raw["DGS10"]
    if "DGS30" in have:
        f["ust_30y"] = raw["DGS30"]
    if {"DGS10", "DGS2"} <= have:
        f["curve_2s10s_market"] = raw["DGS10"] - raw["DGS2"]
    if {"DGS30", "DGS5"} <= have:
        f["curve_5s30s"] = raw["DGS30"] - raw["DGS5"]
    if "T10Y3M" in have:
        f["curve_3m10y"] = raw["T10Y3M"]
    if "BAMLH0A0HYM2" in have:
        f["hy_oas"] = raw["BAMLH0A0HYM2"]
    if "BAMLC0A4CBBB" in have:
        f["bbb_oas"] = raw["BAMLC0A4CBBB"]
    if {"BAMLH0A0HYM2", "BAMLC0A4CBBB"} <= have:
        f["credit_risk_premium"] = raw["BAMLH0A0HYM2"] - raw["BAMLC0A4CBBB"]
    if "NFCI" in have:
        f["nfci"] = raw["NFCI"]
    if {"DGS10", "FEDFUNDS"} <= have:
        f["slope_10y_ff"] = raw["DGS10"] - raw["FEDFUNDS"]
    if {"DGS10", "CPIAUCSL"} <= have:
        cpi_yoy = _aux(raw, "CPIAUCSL", "yoy",
                       raw["CPIAUCSL"].pct_change(BD_YEAR) * 100)
        f["us_real10y"] = raw["DGS10"] - cpi_yoy
        f["us_cpi_yoy"] = cpi_yoy
        # Because cpi_yoy is release-aware and ffilled, this changes only after
        # a newly known release/revision.
        f["us_cpi_accel"] = cpi_yoy.diff(BD_MONTH)
    if "INDPRO" in have:
        f["us_indpro_yoy"] = _aux(raw, "INDPRO", "yoy",
                                   raw["INDPRO"].pct_change(BD_YEAR) * 100)
    if "UNRATE" in have:
        f["us_unrate_chg3m"] = _aux(raw, "UNRATE", "chg3m",
                                     raw["UNRATE"].diff(BD_QTR))
    if "PAYEMS" in have:
        f["us_payems_yoy"] = _aux(raw, "PAYEMS", "yoy",
                                   raw["PAYEMS"].pct_change(BD_YEAR) * 100)
    if "VIXCLS" in have:
        f["us_vix"] = raw["VIXCLS"]
    if "T10Y2Y" in have:
        f["curve_2s10s"] = raw["T10Y2Y"]
    if "UMCSENT" in have:
        f["us_sentiment"] = raw["UMCSENT"]
    if "CBR_KEYRATE" in have:
        f["ru_key"] = raw["CBR_KEYRATE"]
        f["ru_key_chg3m"] = _aux(raw, "CBR_KEYRATE", "chg3m",
                                  raw["CBR_KEYRATE"].diff(BD_QTR))
    return f, raw


def _carry(symbol: str, raw: pd.DataFrame) -> pd.DataFrame | None:
    """Дифференциал ставок по валютной паре из CARRY_MAP."""
    spec = C.CARRY_MAP.get(symbol)
    if spec is None:
        return None
    a, b = spec
    if a not in raw.columns:
        return None
    out = pd.DataFrame(index=raw.index)
    if b and b in raw.columns:
        out["carry_diff"] = raw[a] - raw[b]
    else:
        out["carry_diff"] = raw[a]                           # односторонний драйвер
    out["carry_chg3m"] = out["carry_diff"].diff(BD_QTR)
    return out


def _category(symbol: str) -> str:
    for sym, (_, cat) in {**C.YF_PRICES}.items():
        if sym == symbol:
            return cat
    if symbol in C.YF_CROSSES:
        return C.YF_CROSSES[symbol][3]
    if symbol in C.MOEX_INDICES:
        return C.MOEX_INDICES[symbol][1]
    return ""


def _rate_change_bp(macro_long: pd.DataFrame, sid: str, date) -> float | None:
    """Изменение ставки вокруг заседания в базисных пунктах (факт), из ряда ставки."""
    g = macro_long[macro_long["series"] == sid]
    if g.empty:
        return None
    s = g.set_index("date")["value"].sort_index()
    d = pd.Timestamp(date)
    before = s[s.index < d]
    after = s[(s.index >= d) & (s.index <= d + pd.Timedelta(days=25))]
    if before.empty or after.empty:
        return None
    return round((after.iloc[0] - before.iloc[-1]) * 100, 0)


def _reaction_pct(price_df: pd.DataFrame, date) -> float | None:
    """Движение инструмента вокруг заседания, % (реакция рынка)."""
    if price_df.empty:
        return None
    s = price_df.set_index("date")["close"].sort_index()
    d = pd.Timestamp(date)
    pre = s[s.index < d]
    post = s[(s.index >= d) & (s.index <= d + pd.Timedelta(days=5))]
    if pre.empty or post.empty:
        return None
    return round((post.iloc[-1] / pre.iloc[-1] - 1) * 100, 2)


def surprise_label(expected_bp, actual_bp) -> str:
    """Классифицирует сюрприз решения относительно ожиданий."""
    if pd.isna(expected_bp) or actual_bp is None or pd.isna(actual_bp):
        return "—"
    d = actual_bp - expected_bp
    if d > 0:
        return "ястребиный сюрприз"       # ставка выше ожиданий
    if d < 0:
        return "голубиный сюрприз"        # ставка ниже ожиданий
    return "как ожидалось"


def meeting_outcomes(con) -> pd.DataFrame:
    """Календарь + ожидание/факт/сюрприз/реакция по каждому заседанию."""
    cal = load_calendar()
    if cal.empty:
        return cal
    macro = db.read_macro(con)
    rows = []
    for _, e in cal.iterrows():
        cb, d = e["cb"], e["date"]
        exp = e.get("expected_bp", np.nan)
        exp = float(exp) if pd.notna(exp) else np.nan
        sid = C.CB_RATE_SERIES.get(cb)
        sym = C.CB_REACTION_SYMBOL.get(cb)
        act = _rate_change_bp(macro, sid, d) if sid else None
        rea = _reaction_pct(db.read_prices(con, sym), d) if sym else None
        surprise = (act - exp) if (act is not None and pd.notna(exp)) else None
        rows.append({"date": d, "cb": cb, "event": e["event"],
                     "expected_bp": exp, "actual_bp": act,
                     "surprise_bp": surprise, "reaction_pct": rea})
    return pd.DataFrame(rows).sort_values("date", ascending=False).reset_index(drop=True)


def macro_features_for(con, symbol: str, price_index: pd.DatetimeIndex) -> pd.DataFrame:
    """
    Готовый набор макропризнаков для инструмента, выровненный по датам цен.
    Пусто -> модель просто работает на ценовых признаках (graceful).
    """
    raw = _raw_daily(con, price_index)
    if raw.empty:
        return pd.DataFrame(index=price_index)
    derived, raw = _derive(raw)
    cat = _category(symbol)

    picks = pd.DataFrame(index=price_index)

    carry = _carry(symbol, raw)
    if carry is not None:                                    # валютные пары
        picks = picks.join(carry)

    us_ctx = [c for c in ["us_real10y", "slope_10y_ff", "us_cpi_accel",
                          "us_ff_chg3m"] if c in derived.columns]
    biz_ctx = [c for c in ["us_payems_yoy", "us_unrate_chg3m", "us_indpro_yoy",
                           "us_vix", "curve_2s10s", "us_sentiment"]
               if c in derived.columns]
    ru_ctx = [c for c in ["ru_key", "ru_key_chg3m"] if c in derived.columns]

    is_equity = cat.startswith("Индексы") and cat != "Индексы РФ"
    if is_equity or cat in ("Сырьё", "Крипто", "Фьючерсы"):
        picks = picks.join(derived[us_ctx + biz_ctx])
    elif cat == "Индексы РФ":
        picks = picks.join(derived[ru_ctx + [c for c in ["us_real10y", "us_vix"]
                                             if c in derived.columns]])
    elif cat == "Валюты" and carry is None:
        picks = picks.join(derived[[c for c in ["us_ff_chg3m", "slope_10y_ff"]
                                    if c in derived.columns]])

    # чистим полностью пустые колонки
    picks = picks.dropna(axis=1, how="all")
    return picks
