"""AllAnalytics v4.37 — prospective model selection & promotion guard.

The selector uses only *settled prospective forecasts* recorded by v4.36.  It
never changes the champion automatically.  A candidate can become eligible for
human review only after passing sample-size, paired-bootstrap and stability
checks.  The context/event layer may receive a non-zero live weight only when:

1. the prospective evidence gate currently passes; and
2. a human explicitly approved that candidate/scope through the review store.

This keeps model governance separate from model fitting and prevents a temporary
run of good luck from silently changing production behaviour.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

import prospective_feedback_v436 as FB436
import target_contract_v4405 as TARGET4405
import forecast_contract_v4406 as CONTRACT4406
import persistent_state_v44010 as PSTATE44010
import sealed_shadow_v44010 as SHADOW44010

VERSION = "prospective-selection-guard-v4.40.10"
VALIDATION_VERSION = "generation-isolated-data-driven-routing-persistent-governance-v4.40.10"
CURRENT_MODEL_GENERATION = CONTRACT4406.MODEL_GENERATION
CURRENT_TARGET_VERSION = TARGET4405.TARGET_VERSION
LEGACY_REVIEW_DB = Path(__file__).parent / "runtime_cache" / "model_promotion_v437.sqlite3"
DEFAULT_REVIEW_DB = PSTATE44010.governance_db_path()
BOOTSTRAP_SEED = 437


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _finite(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _clip_p(v):
    x = _finite(v)
    return None if x is None else float(np.clip(x, .001, .999))


def _safe_json(v) -> str:
    return json.dumps(v if v is not None else {}, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _as_date(v):
    try:
        x = pd.Timestamp(str(v)[:10])
        return x.normalize() if pd.notna(x) else None
    except Exception:
        return None


def _component_p(row: dict, name: str):
    """Conditional P(up | material move) for prospective model selection.

    v4.40.5 deliberately does not compare direction experts on neutral outcomes.
    """
    if name in {"dynamic_ensemble_v435", "dynamic_ensemble_v437", "dynamic_ensemble", "ensemble"}:
        return _clip_p(row.get("conditional_p_up"))
    for c in row.get("components") or []:
        if isinstance(c, dict) and str(c.get("name")) == str(name):
            return _clip_p(c.get("conditional_p_up"))
    return None


def _context_blend_p(row: dict, weight: float):
    # Prospective direction comparison must stay on the conditional scale.
    base = _clip_p(row.get("conditional_p_up"))
    ctx = _component_p(row, "context_advisory")
    if base is None or ctx is None:
        return None
    return _clip_p((1-float(weight))*base + float(weight)*ctx)


def _paired_rows(rows: Iterable[dict], candidate: str, baseline: str, context_weight: float | None = None):
    out = []
    for row in rows or []:
        outcome=str(row.get("outcome") or "")
        if outcome not in {"up","down"}:
            continue
        y=1.0 if outcome=="up" else 0.0
        pb = _component_p(row, baseline)
        if candidate == "context_blend":
            pc = _context_blend_p(row, float(context_weight or 0))
        else:
            pc = _component_p(row, candidate)
        if pc is None or pb is None:
            continue
        out.append({
            "date": str(row.get("target_as_of") or row.get("data_as_of") or "")[:10],
            "outcome": outcome, "y": y, "p_candidate": pc, "p_baseline": pb,
            "symbol": row.get("symbol"), "horizon": row.get("horizon"),
            "model_generation":row.get("model_generation"),"target_version":row.get("target_version"),
        })
    return sorted(out, key=lambda x: x["date"])


def _metrics(rows: list[dict], p_key: str) -> dict:
    if not rows:
        return {"n": 0, "significant_n": 0, "accuracy": None, "brier": None, "calibration_error": None}
    brier=[]; cal=[]; hits=[]
    for r in rows:
        p=_finite(r.get(p_key)); y=_finite(r.get("y"))
        if p is None or y is None:
            continue
        brier.append((p-y)**2); cal.append(abs(p-y))
        if r.get("outcome") in {"up","down"}:
            hits.append(int((p>=.5 and r.get("outcome")=="up") or (p<.5 and r.get("outcome")=="down")))
    return {
        "n": len(rows), "significant_n": sum(1 for r in rows if r.get("outcome") in {"up","down"}),
        "accuracy": round(float(np.mean(hits)), 4) if hits else None,
        "brier": round(float(np.mean(brier)), 6) if brier else None,
        "calibration_error": round(float(np.mean(cal)), 6) if cal else None,
    }


def _paired_deltas(rows: list[dict]):
    brier=[]; accuracy=[]
    for r in rows:
        pc=float(r["p_candidate"]); pb=float(r["p_baseline"]); y=float(r["y"])
        # Positive value means the candidate is better.
        brier.append((pb-y)**2 - (pc-y)**2)
        if r.get("outcome") in {"up","down"}:
            hc=int((pc>=.5 and r["outcome"]=="up") or (pc<.5 and r["outcome"]=="down"))
            hb=int((pb>=.5 and r["outcome"]=="up") or (pb<.5 and r["outcome"]=="down"))
            accuracy.append(hc-hb)
    return np.asarray(brier,float), np.asarray(accuracy,float)


def _bootstrap_ci(values, n_boot=1600, seed=BOOTSTRAP_SEED, horizon: int=1):
    """Moving-block bootstrap; H-day prospective outcomes are not IID."""
    a=np.asarray(values,float);a=a[np.isfinite(a)]
    if len(a)<2:
        return {"n":len(a),"mean":float(np.mean(a)) if len(a) else None,"ci95":[None,None],"prob_gt_zero":None,
                "block_size":max(1,int(horizon)),"effective_n":len(a)}
    n=len(a);block=max(1,min(n,max(5,int(horizon))))
    rng=np.random.default_rng(int(seed));max_start=max(1,n-block+1);means=[]
    for _ in range(max(200,int(n_boot))):
        idx=[]
        while len(idx)<n:
            st=int(rng.integers(0,max_start));idx.extend(range(st,min(st+block,n)))
        means.append(float(np.mean(a[np.asarray(idx[:n],int)])))
    means=np.asarray(means,float);lo,hi=np.quantile(means,[.025,.975])
    return {"n":int(n),"mean":round(float(a.mean()),7),"ci95":[round(float(lo),7),round(float(hi),7)],
            "prob_gt_zero":round(float(np.mean(means>0)),4),"block_size":int(block),
            "effective_n":max(1,int(n/max(1,int(horizon))))}


def _stability(rows: list[dict]):
    if len(rows)<30:
        return {"segments":[],"positive_segments":0,"stable":False}
    parts=np.array_split(np.arange(len(rows)),3);segs=[]
    for i,idx in enumerate(parts,1):
        chunk=[rows[int(j)] for j in idx]
        db,_=_paired_deltas(chunk)
        segs.append({"segment":i,"n":len(chunk),"brier_improvement":round(float(db.mean()),7) if len(db) else None,
                     "from":chunk[0]["date"] if chunk else None,"to":chunk[-1]["date"] if chunk else None})
    pos=sum(1 for s in segs if (s.get("brier_improvement") or 0)>0)
    # Stability deliberately tolerates one nearly-flat segment, but not a material
    # collapse.  This is a guard against one lucky recent regime driving promotion.
    worst=min((s.get("brier_improvement") for s in segs if s.get("brier_improvement") is not None),default=-1)
    return {"segments":segs,"positive_segments":pos,"worst_segment":round(float(worst),7),
            "stable":bool(pos>=2 and worst>=-.01)}


def _report_hash(payload: dict) -> str:
    keep={k:v for k,v in payload.items() if k not in {"review","generated_at"}}
    return hashlib.sha256(_safe_json(keep).encode("utf-8")).hexdigest()[:20]


class ReviewStore:
    def __init__(self,path: str|Path|None=None):
        explicit=path or os.getenv("ALLANALYTICS_PROMOTION_DB")
        self.path=Path(explicit or DEFAULT_REVIEW_DB).expanduser()
        if explicit is None:
            PSTATE44010.migrate_sqlite_once(LEGACY_REVIEW_DB,self.path)
        self.path.parent.mkdir(parents=True,exist_ok=True);self._init()

    def _connect(self):
        con=sqlite3.connect(self.path,timeout=5);con.row_factory=sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL");con.execute("PRAGMA busy_timeout=5000")
        return con

    def _init(self):
        with self._connect() as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS review_decisions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              created_at TEXT NOT NULL,
              candidate TEXT NOT NULL,
              baseline TEXT NOT NULL,
              symbol TEXT,
              horizon INTEGER,
              window_days INTEGER NOT NULL,
              decision TEXT NOT NULL,
              note TEXT,
              report_hash TEXT NOT NULL,
              report_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_v437_review_scope ON review_decisions(candidate,symbol,horizon,id);
            """);con.commit()

    def latest(self,candidate: str,symbol: str|None=None,horizon: int|None=None):
        with self._connect() as con:
            # Exact scope first, then global candidate decision.
            row=con.execute("""SELECT * FROM review_decisions WHERE candidate=? AND symbol IS ? AND horizon IS ? ORDER BY id DESC LIMIT 1""",
                            (str(candidate),str(symbol).upper() if symbol else None,int(horizon) if horizon is not None else None)).fetchone()
            if not row and (symbol is not None or horizon is not None):
                row=con.execute("SELECT * FROM review_decisions WHERE candidate=? AND symbol IS NULL AND horizon IS NULL ORDER BY id DESC LIMIT 1",(str(candidate),)).fetchone()
        if not row:return None
        x=dict(row);x["report"]=json.loads(x.pop("report_json") or "{}")
        return x

    def add(self,candidate: str,baseline: str,decision: str,note: str,report: dict,symbol=None,horizon=None,window_days=180):
        decision=str(decision or "").lower()
        if decision not in {"approve","reject","hold"}:
            raise ValueError("decision must be approve, reject or hold")
        if decision=="approve" and not bool(report.get("eligible_for_human_review")):
            raise ValueError("candidate is not eligible for approval under the current prospective guard")
        rh=str(report.get("report_hash") or _report_hash(report))
        with self._connect() as con:
            cur=con.execute("""INSERT INTO review_decisions(created_at,candidate,baseline,symbol,horizon,window_days,decision,note,report_hash,report_json)
                               VALUES(?,?,?,?,?,?,?,?,?,?)""",
                            (_utc_now(),candidate,baseline,str(symbol).upper() if symbol else None,int(horizon) if horizon is not None else None,
                             int(window_days),decision,str(note or "")[:1000],rh,_safe_json(report)))
            con.commit();rid=int(cur.lastrowid)
        return {"id":rid,"decision":decision,"candidate":candidate,"report_hash":rh,"created_at":_utc_now()}

    def rows(self,limit=50):
        with self._connect() as con:
            return [dict(x) for x in con.execute("SELECT id,created_at,candidate,baseline,symbol,horizon,window_days,decision,note,report_hash FROM review_decisions ORDER BY id DESC LIMIT ?",(max(1,min(int(limit),200)),)).fetchall()]


REVIEW = ReviewStore()
_CACHE={}

def _review_approves_current_generation(review: dict|None) -> bool:
    if not review or str(review.get("decision") or "")!="approve": return False
    rep=review.get("report") or {}
    return str(rep.get("model_generation") or "")==CURRENT_MODEL_GENERATION and str(rep.get("target_version") or "")==CURRENT_TARGET_VERSION


def candidate_report(candidate: str, baseline: str="production", *, window_days: int=180, symbol: str|None=None, horizon: int|None=None, context_weight: float|None=None, ledger=None, current_v437_only: bool=False, rows_override=None) -> dict:
    led=ledger or FB436.LEDGER
    try:
        rows=list(rows_override) if rows_override is not None else led.rows(limit=500,symbol=symbol,horizon=horizon,settled_only=True)
        rows=SHADOW44010.training_rows(rows)
    except Exception as exc:
        result={"version":VERSION,"validation_version":VALIDATION_VERSION,"generated_at":_utc_now(),"candidate":candidate,"baseline":baseline,
                "model_generation":CURRENT_MODEL_GENERATION,"target_version":CURRENT_TARGET_VERSION,"symbol":symbol,"horizon":horizon,
                "window_days":int(window_days),"context_weight":context_weight,"paired_n":0,"significant_n":0,
                "candidate_metrics":{"n":0},"baseline_metrics":{"n":0},"eligible_for_human_review":False,"automatic_promotion":False,
                "reason":f"prospective ledger unavailable: {type(exc).__name__}"}
        result["report_hash"]=_report_hash(result); return result
    # Never mix evidence across target semantics/model generations. Old observations
    # remain in the immutable ledger for audit, but cannot promote the current stack.
    rows=[x for x in rows if str(x.get("model_generation") or "")==CURRENT_MODEL_GENERATION
          and str(x.get("target_version") or "")==CURRENT_TARGET_VERSION]
    if current_v437_only:
        rows=[x for x in rows if str(((x.get("context") or {}).get("prospective_selection_guard") or {}).get("version") or (x.get("context") or {}).get("guard_version") or "").startswith("prospective-selection-guard-")]
    cutoff=pd.Timestamp.utcnow().tz_localize(None).normalize()-pd.Timedelta(days=max(14,min(int(window_days),3650)))
    rows=[x for x in rows if (_as_date(x.get("target_as_of")) or pd.Timestamp.min)>=cutoff]
    paired=_paired_rows(rows,candidate,baseline,context_weight=context_weight)
    cm=_metrics(paired,"p_candidate");bm=_metrics(paired,"p_baseline")
    db,da=_paired_deltas(paired)
    h_eff=int(horizon or (np.median([int(x.get("horizon") or 1) for x in paired]) if paired else 1))
    bci=_bootstrap_ci(db,seed=BOOTSTRAP_SEED,horizon=h_eff);aci=_bootstrap_ci(da,seed=BOOTSTRAP_SEED+1,horizon=h_eff)
    stab=_stability(paired)
    n=int(cm.get("n") or 0);sig=int(cm.get("significant_n") or 0)
    cal_delta=None
    if cm.get("calibration_error") is not None and bm.get("calibration_error") is not None:
        cal_delta=round(float(bm["calibration_error"]-cm["calibration_error"]),6) # positive better
    # Strong enough to be discussed by a person, not auto promoted.
    sample_ok=n>=60 and sig>=30
    statistical_ok=bool((bci.get("ci95") or [None])[0] is not None and bci["ci95"][0]>0)
    accuracy_safe=bool(aci.get("ci95",[None,None])[0] is None or aci["ci95"][0]>=-.05)
    calibration_safe=bool(cal_delta is None or cal_delta>=-.02)
    eligible=bool(sample_ok and statistical_ok and accuracy_safe and calibration_safe and stab.get("stable"))
    reasons=[]
    if not sample_ok:reasons.append("недостаточно prospective наблюдений: нужно ≥60 общих и ≥30 значимых")
    if sample_ok and not statistical_ok:reasons.append("95% bootstrap-интервал улучшения Brier пока пересекает ноль")
    if not accuracy_safe:reasons.append("направленная точность нестабильна относительно базовой модели")
    if not calibration_safe:reasons.append("калибровка ухудшилась сильнее допустимого")
    if not stab.get("stable"):reasons.append("улучшение неустойчиво по временным сегментам")
    result={
        "version":VERSION,"validation_version":VALIDATION_VERSION,"generated_at":_utc_now(),"candidate":candidate,"baseline":baseline,
        "model_generation":CURRENT_MODEL_GENERATION,"target_version":CURRENT_TARGET_VERSION,"scoring_scope":"conditional direction on material moves only",
        "symbol":symbol,"horizon":horizon,"window_days":int(window_days),"context_weight":context_weight,"current_v437_only":bool(current_v437_only),
        "candidate_metrics":cm,"baseline_metrics":bm,"paired_n":n,"significant_n":sig,
        "paired_bootstrap":{"brier_improvement":bci,"accuracy_improvement":aci,"method":"moving_block","horizon_block":h_eff},"calibration_improvement":cal_delta,"stability":stab,
        "gates":{"sample_size":sample_ok,"paired_brier_ci":statistical_ok,"accuracy_safety":accuracy_safe,"calibration_safety":calibration_safe,"time_stability":bool(stab.get("stable"))},
        "eligible_for_human_review":eligible,"automatic_promotion":False,"reason":"готов к ручной проверке" if eligible else "; ".join(reasons),
    }
    result["report_hash"]=_report_hash(result)
    return result



def learned_blend_weight(candidate: str, baseline: str="core_meta", *, cap: float=.20, window_days: int=365, symbol=None, horizon=None, ledger=None, rows_override=None) -> dict:
    """Learn a candidate satellite weight from paired prospective probabilities.

    The weight is fitted on an older chronological slice and must improve Brier on
    a recent validation tail.  ``cap`` is a governance safety ceiling, not a model
    preference.  No evidence -> zero candidate weight.
    """
    led=ledger or FB436.LEDGER
    try:
        rows=list(rows_override) if rows_override is not None else led.rows(limit=500,symbol=symbol,horizon=horizon,settled_only=True)
        rows=SHADOW44010.training_rows(rows)
    except Exception as exc:
        return {"version":VERSION,"learned":False,"weight":0.0,"n":0,"cap":float(np.clip(float(cap),0.0,.50)),"reason":f"prospective_ledger_unavailable:{type(exc).__name__}"}
    rows=[x for x in rows if str(x.get("model_generation") or "")==CURRENT_MODEL_GENERATION
          and str(x.get("target_version") or "")==CURRENT_TARGET_VERSION]
    cutoff=pd.Timestamp.utcnow().tz_localize(None).normalize()-pd.Timedelta(days=max(30,min(int(window_days),3650)))
    rows=[x for x in rows if (_as_date(x.get("target_as_of")) or pd.Timestamp.min)>=cutoff]
    paired=_paired_rows(rows,candidate,baseline)
    n=len(paired); cap=float(np.clip(float(cap),0.0,.50))
    if n<36:
        return {"version":VERSION,"learned":False,"weight":0.0,"n":n,"cap":cap,"reason":"insufficient_prospective_evidence"}
    cut=max(22,min(n-10,int(n*.70))); train=paired[:cut]; val=paired[cut:]
    if len(val)<8:
        return {"version":VERSION,"learned":False,"weight":0.0,"n":n,"cap":cap,"reason":"insufficient_validation_tail"}
    pc=np.asarray([r["p_candidate"] for r in train],float); pb=np.asarray([r["p_baseline"] for r in train],float); y=np.asarray([r["y"] for r in train],float)
    d=pc-pb; den=float(np.dot(d,d)); w=0.0 if den<=1e-12 else float(np.clip(np.dot(d,y-pb)/den,0.0,cap))
    pvc=np.asarray([r["p_candidate"] for r in val],float); pvb=np.asarray([r["p_baseline"] for r in val],float); yv=np.asarray([r["y"] for r in val],float)
    blend=(1-w)*pvb+w*pvc; b_blend=float(np.mean((blend-yv)**2)); b_base=float(np.mean((pvb-yv)**2))
    ok=bool(w>0 and b_blend<=b_base+1e-12)
    return {"version":VERSION,"learned":ok,"weight":round(w if ok else 0.0,6),"fitted_weight":round(w,6),"n":n,"fit_n":len(train),"validation_n":len(val),
            "validation_brier":round(b_blend,7),"baseline_brier":round(b_base,7),"brier_improvement":round(b_base-b_blend,7),"cap":cap,
            "reason":"validated_recent_prospective" if ok else "learned_weight_failed_recent_validation"}

def context_report(*,window_days=180,symbol=None,horizon=None,ledger=None,rows_override=None):
    # v4.40.8: candidate context contribution is learned continuously from paired
    # prospective evidence instead of choosing among hand-written 4/8/12/16% weights.
    route=learned_blend_weight("context_advisory","core_meta",cap=.20,window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger,rows_override=rows_override)
    w=float(route.get("weight") or 0.0)
    report=candidate_report("context_blend","core_meta",window_days=window_days,symbol=symbol,horizon=horizon,context_weight=w,ledger=ledger,current_v437_only=True,rows_override=rows_override)
    return {**report,"candidate":"context_blend","context_weight":w,"data_driven_weight":route,"tested_weights":None}

def selection_report(*,window_days=180,symbol=None,horizon=None,ledger=None):
    led=ledger or FB436.LEDGER
    shared=SHADOW44010.training_rows(led.rows(limit=500,symbol=symbol,horizon=horizon,settled_only=True))
    candidates=[
        candidate_report("dynamic_ensemble_v437","production",window_days=window_days,symbol=symbol,horizon=horizon,ledger=led,current_v437_only=True,rows_override=shared),
        candidate_report("vol_regime","production",window_days=window_days,symbol=symbol,horizon=horizon,ledger=led,rows_override=shared),
        context_report(window_days=window_days,symbol=symbol,horizon=horizon,ledger=led,rows_override=shared),
    ]
    for r in candidates:
        r["review"]=REVIEW.latest(r["candidate"],symbol=symbol,horizon=horizon)
    return {"version":VERSION,"validation_version":VALIDATION_VERSION,"window_days":int(window_days),"symbol":symbol,"horizon":horizon,
            "candidates":candidates,"automatic_champion_promotion":False,"review_required":True,
            "policy":"only current model_generation + target_version are eligible; direction candidates are scored only on material moves with conditional probabilities; approval is always explicit"}


def review(candidate: str,decision: str,note: str="",*,window_days=180,symbol=None,horizon=None,ledger=None):
    if candidate=="context_blend":report=context_report(window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger)
    else:
        baseline="production"
        report=candidate_report(candidate,baseline,window_days=window_days,symbol=symbol,horizon=horizon,ledger=ledger,current_v437_only=(candidate=="dynamic_ensemble_v437"))
    out=REVIEW.add(candidate,report.get("baseline") or "production",decision,note,report,symbol=symbol,horizon=horizon,window_days=window_days)
    return {"version":VERSION,"review":out,"report":report,"automatic_promotion":False}


def context_gate(symbol: str,horizon: int,window_days: int=180,ledger=None,cache_seconds: int=300):
    key=(str(symbol).upper(),int(horizon),int(window_days))
    now=time.time();cached=_CACHE.get(key)
    if ledger is None and cached and now-cached[0]<max(15,int(cache_seconds)):
        return cached[1]
    report=context_report(window_days=window_days,symbol=key[0],horizon=key[1],ledger=ledger)
    review=REVIEW.latest("context_blend",symbol=key[0],horizon=key[1])
    approved=_review_approves_current_generation(review)
    active=bool(approved and report.get("eligible_for_human_review"))
    weight=float(report.get("context_weight") or 0) if active else 0.0
    result={"version":VERSION,"symbol":key[0],"horizon":key[1],"eligible":bool(report.get("eligible_for_human_review")),
            "human_approved":approved,"active":active,"weight":round(weight,4),"report_hash":report.get("report_hash"),
            "reason":"prospective edge confirmed + human approval" if active else ("awaiting explicit human approval" if report.get("eligible_for_human_review") else report.get("reason")),
            "review":review,"report":report}
    if ledger is None:_CACHE[key]=(now,result)
    return result


def review_status(limit=50):
    return {"version":VERSION,"automatic_promotion":False,"reviews":REVIEW.rows(limit=limit)}
