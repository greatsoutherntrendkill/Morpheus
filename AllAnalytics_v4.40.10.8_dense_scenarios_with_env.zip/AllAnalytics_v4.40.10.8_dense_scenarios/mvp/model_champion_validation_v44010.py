"""AllAnalytics v4.40.10 — Champion & Validation Upgrade release wrapper."""
from __future__ import annotations
import model_correctness_v4409 as BASE
import forecast_contract_v4406 as CONTRACT
import champion_validation_v44010 as CV44010
import sealed_shadow_v44010 as SHADOW44010
import persistent_state_v44010 as PSTATE44010

VERSION="champion-validation-v4.40.10"
MODEL_GENERATION=CONTRACT.MODEL_GENERATION
TARGET4405=BASE.TARGET4405

def forecast_horizon(close,symbol:str,horizon:int=10,fast:bool=True,context:dict|None=None)->dict:
    out=BASE.forecast_horizon(close,symbol=symbol,horizon=int(horizon),fast=fast,context=context)
    if not out:return {}
    out=dict(out);out["base_model_version"]=out.get("version");out["version"]=VERSION;out["model_version"]=VERSION;out["model_generation"]=MODEL_GENERATION
    out["champion_validation_release"]={
        "version":VERSION,"solver":CV44010.SOLVER_VERSION,"nested_chronological_regularization":True,
        "data_driven_internal_regime_moe_weights":True,"persistent_event_store":str(PSTATE44010.event_db_path()),
        "persistent_governance_store":str(PSTATE44010.governance_db_path()),"sealed_shadow_version":SHADOW44010.VERSION,
        "sealed_shadow_used_for_training":False,
    }
    val=dict(out.get("validation") or {});val.update({
        "champion_validation_release":VERSION,"champion_solver":CV44010.SOLVER_VERSION,
        "nested_chronological_regularization":True,"regime_moe_internal_weights_data_driven":True,
        "sealed_shadow_used_for_training":False,"persistent_event_governance_state":True,
    });out["validation"]=val
    return out
