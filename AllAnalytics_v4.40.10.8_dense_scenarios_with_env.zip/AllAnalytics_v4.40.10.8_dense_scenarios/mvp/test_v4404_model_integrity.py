from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

import models as M
import dynamic_ensemble_v437 as DE
import distributional_forecast_v440 as DIST
import prospective_selection_v437 as SEL
import event_response_v439 as ER
import research_monthly_v4403 as RM
import short_forecast_v45 as SF
import market_data_v41 as MD
import model_integrity_v4406 as MI
import equity_forecast_v416 as EQ


def close_series(n=520, seed=404):
    rng=np.random.default_rng(seed)
    idx=pd.bdate_range('2024-01-02',periods=n)
    r=.00025+rng.normal(0,.011,n)
    return pd.Series(100*np.exp(np.cumsum(r)),index=idx)


def test_shared_target_keeps_neutral_and_unknown_separate():
    s=close_series(180)
    t=M.directional_target_frame(s,10)
    assert set(t.loc[t['state'].notna(),'state'].unique()).issubset({-1.0,0.0,1.0})
    assert t['state'].iloc[-10:].isna().all()
    assert t['y'].iloc[-10:].isna().all()
    assert t['neutral'].iloc[-10:].isna().all()
    neutral=t['state'].eq(0)
    assert neutral.any()
    assert t.loc[neutral,'y'].isna().all()
    assert t.loc[neutral,'neutral'].eq(1).all()


def test_recent_oos_audit_does_not_replace_frozen_holdout():
    r=M.walk_forward_direction(close_series(760),horizon=10,bootstrap_resamples=120)
    assert r
    assert r['target_version']==M.TARGET_VERSION
    assert 'recent_oos' in r
    assert r['recent_oos']['used_for_quality_gate'] is False
    assert r['validation']['rolling_recent_used_for_gate'] is False
    assert r['holdout']['used_for_quality_gate'] is False


def test_meta_split_separates_calibration_threshold_and_eval():
    n=180
    d=pd.DataFrame({
        'date':pd.bdate_range('2025-01-02',periods=n),
        'p_champion':np.linspace(.35,.7,n),
        'p_challenger':np.linspace(.4,.65,n),
        'y':np.tile([0,1],n//2),
    })
    tr,cal,thr,ev=DE._split_meta(d)
    assert max(tr.index)<min(cal.index)<min(thr.index)<min(ev.index)
    assert set(tr.index).isdisjoint(cal.index)
    assert set(cal.index).isdisjoint(thr.index)
    assert set(thr.index).isdisjoint(ev.index)


def test_distribution_has_post_audit_refit_and_dependence_adjustment():
    out=DIST.distribution_forecast(close_series(520),'AAPL',10,fast=False)
    assert out['status']=='ok'
    assert out['production_refit']['fit_n']>0
    assert out['production_refit']['calibration_n']>0
    assert out['production_refit']['calibration_matches_deployment_fit'] is True
    ev=out['evaluation']
    assert 'dependence_adjusted' in ev
    assert ev['dependence_adjusted']['effective_n'] <= ev['n']
    assert ev['block_bootstrap']['block_size'] >= 10


def test_prospective_guard_uses_moving_blocks_for_horizon():
    x=np.linspace(-.03,.04,80)+np.sin(np.arange(80)/5)*.01
    b=SEL._bootstrap_ci(x,n_boot=220,horizon=10)
    assert b['block_size']>=10
    assert b['effective_n']<=len(x)//10+1


def test_event_response_uses_pre_event_anchor_for_during_session():
    idx=pd.bdate_range('2026-09-10',periods=5)
    s=pd.Series([100,101,103,102,104],index=idx)
    e={'date':str(idx[1].date()),'session_timing':'during_session'}
    r=ER._response_after(s,e,1)
    assert r['entry_date']==str(idx[0].date())
    assert r['target_date']==str(idx[1].date())
    assert r['entry_anchor']=='previous_close_pre_event'
    assert round(r['return_pct'],6)==1.0


def test_monthly_research_is_explicitly_scenario_not_calibrated(monkeypatch):
    snap={
        'US':dict(RM.FALLBACK['US']),'RU':dict(RM.FALLBACK['RU']),
        'source':{'US':'test','RU':'test'},'db_live':True,
    }
    monkeypatch.setattr(RM,'_real_macro_snapshot',lambda payload:snap)
    monkeypatch.setattr(RM,'_meeting_model_status',lambda:{'active':False,'status':'collecting_pit_meeting_evidence'})
    payload={'rates':[{'country':'США','rate_name':'Ставка ФРС','rate':3.75},{'country':'Россия','rate_name':'Ключевая ставка','rate':14}],
             'events':[{'date':'2026-10-28','cb':'ФРС'},{'date':'2026-10-23','cb':'Банк России'}],'news':[]}
    out=RM.build(payload,as_of='2026-09-12',news=[])
    assert out['integrity_version']=='4.40.4'
    assert out['scenario_weights_calibrated'] is False
    assert out['probability_semantics']=='scenario_weights_not_calibrated_probabilities'
    assert out['trained_meeting_model']['active'] is False


def _intraday(up=True,n=240):
    t=pd.date_range('2026-09-07 09:30',periods=n,freq='5min')
    c=100+(np.arange(n)*(.012 if up else -.012))+np.sin(np.arange(n)/9)*.1
    return pd.DataFrame({'date':t,'open':c-.03,'high':c+.09,'low':c-.08,'close':c})


def test_intraday_number_is_labeled_technical_score(monkeypatch):
    monkeypatch.setattr(SF.MD43,'fetch_intraday',lambda *a,**k:MD.MarketResult('AAPL',_intraday(True),'test 5m',[]))
    out=SF.forecast('AAPL','1h',{'drivers':[]})
    assert out['status']=='ok'
    assert out['calibrated_probability'] is False
    assert out['probability_semantics']=='uncalibrated_technical_direction_score'
    assert out['technical_direction_score_up']==out['p_up']


def test_live_pipeline_uses_integrity_wrapper_and_generation(monkeypatch):
    base={'version':'dynamic-meta-ensemble-v4.35.0','p_up':.61,'p_down':.39,'p_neutral':.24,'p_move':.76,'conditional_p_up':.65,
          'abstain':False,'components':[],'scorecard':{'p_neutral':.24},'validation':{},'quality':{},
          'distribution_forecast':{},'distribution_version':'distributional-forecast-v4.40.4-integrity'}
    monkeypatch.setattr(MI.BASE440,'forecast_horizon',lambda *a,**k:dict(base))
    out=MI.forecast_horizon(close_series(300),'AAPL',10)
    assert out['version']==MI.VERSION
    assert out['base_model_version']=='dynamic-meta-ensemble-v4.35.0'
    assert out['model_generation']==MI.MODEL_GENERATION
    cp=out['class_probabilities']
    assert abs(sum(cp.values())-1.0)<1e-6
    assert cp['neutral']==.24
    assert out['directional_score_up']==out['p_up']
    assert out['validation']['normalized_three_state_probabilities'] is True
    assert out['validation']['single_live_source_of_truth'] is True
    assert EQ.META435.VERSION=="champion-validation-v4.40.10"
    assert EQ.META435.MODEL_GENERATION==MI.MODEL_GENERATION


def test_ui_marks_intraday_and_research_semantics():
    root=Path(__file__).parent
    html=(root/'site'/'index.html').read_text(encoding='utf-8')
    tech=(root/'site'/'technical_lab_v411.html').read_text(encoding='utf-8')
    assert '/api/research/monthly-v4404' in html
    assert 'Сценарные веса не являются откалиброванными вероятностями' in html
    assert 'Технический перевес роста' in tech
    assert 'не калиброванная вероятность' in tech


def test_policy_meeting_evidence_is_persistent_and_point_in_time(tmp_path):
    import policy_meeting_evidence_v4404 as P
    db=tmp_path/'meeting.sqlite3'
    outlook={
      'as_of':'2026-09-12','integrity_version':'4.40.4','probability_semantics':'scenario_weights_not_calibrated_probabilities',
      'signals':{'US':{'hawk':.1,'geo':.2},'RU':{'hawk':.2,'geo':.3}},
      'macro':[
        {'region':'US','kind':'inflation','path':[{'month':'2026-10','value':3.4}]},
        {'region':'US','kind':'labor','path':[{'month':'2026-10','value':4.2}]},
        {'region':'US','kind':'growth','path':[{'month':'2026-10','value':2.0}]},
        {'region':'RU','kind':'inflation','path':[{'month':'2026-10','value':6.2}]},
        {'region':'RU','kind':'labor','path':[{'month':'2026-10','value':2.3}]},
        {'region':'RU','kind':'growth','path':[{'month':'2026-10','value':.5}]},
      ],
      'rates':[
        {'region':'US','current':3.75,'source':'test','path':[{'month':'2026-10','meeting':'2026-10-28','probabilities':{'hike':10,'hold':70,'cut':20},'factors':[]}]},
        {'region':'RU','current':14.0,'source':'test','path':[{'month':'2026-10','meeting':'2026-10-23','probabilities':{'hike':5,'hold':60,'cut':35},'factors':[]}]},
      ]}
    r=P.record_outlook(outlook,db);assert r['inserted']==2
    st=P.status(db);assert st['snapshots']==2 and st['settled']==0
    # On the meeting date itself no settlement is allowed: date-only snapshots
    # cannot know whether the decision has already happened.
    same={**outlook,'as_of':'2026-10-23','rates':[{'region':'US','current':3.75,'path':[]},{'region':'RU','current':14.0,'path':[]}]}
    assert P.settle_recent(same,db)['settled']==0
    after={**outlook,'as_of':'2026-10-24','rates':[{'region':'US','current':3.75,'path':[]},{'region':'RU','current':13.5,'path':[]}]}
    assert P.settle_recent(after,db)['settled']==1
    assert P.status(db)['settled']==1
