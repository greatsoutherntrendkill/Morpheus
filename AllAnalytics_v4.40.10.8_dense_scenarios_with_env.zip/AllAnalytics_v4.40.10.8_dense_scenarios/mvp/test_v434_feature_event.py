import numpy as np
import pandas as pd

import feature_event_v434 as FE
import meta_forecast_v434 as META
import equity_forecast_v416 as E
import model_registry as MR


def series(seed=434, n=820, drift=.00035, vol=.010):
    rng=np.random.default_rng(seed)
    idx=pd.bdate_range(end=pd.Timestamp('2026-09-11'),periods=n)
    r=rng.normal(drift,vol,n)
    return pd.Series(100*np.exp(np.cumsum(r)),index=idx)


def frame(s):
    c=s.to_numpy(float)
    return pd.DataFrame({'date':s.index,'open':c,'high':c*1.004,'low':c*.996,'close':c})


def test_cross_sectional_snapshot_has_relative_breadth_and_drift_contract():
    out=FE.cross_sectional_snapshot('AAPL',series())
    assert out['version'].startswith('context-event-features')
    assert out['asset_class']=='equity'
    assert out['benchmark']=='^GSPC'
    assert -1 <= out['context_score'] <= 1
    assert 0 <= out['feature_coverage'] <= 1
    assert 0 <= out['feature_drift']['score'] <= 1
    assert 'correlation_regime' in out


def test_event_snapshot_detects_signed_relevant_news():
    news=[{
        'title':'ФРС снизила ставку после заседания',
        'summary':'Решение поддержало рынок акций США',
        'date':'2026-09-11','affected':'AAPL|^GSPC','dir':'up','impact_score':90,
    }]
    events=[{'date':'2026-09-11','cb':'ФРС','event':'Решение по ставке'}]
    out=FE.event_snapshot('AAPL',as_of='2026-09-11',news=news,events=events)
    assert out['risk_score'] > .5
    assert out['directional_bias'] > 0
    assert 'central_bank' in out['event_types']


def test_context_probability_is_conservative_and_event_risk_can_shrink():
    base=.68
    calm={'context_score':.8,'event_bias':.5,'event_risk':0,'drift_score':0,'coverage':1}
    risk={'context_score':0,'event_bias':0,'event_risk':1,'drift_score':.8,'coverage':1}
    a=FE.apply_context_probability(base,calm)
    b=FE.apply_context_probability(base,risk)
    assert .05 <= a['p_up'] <= .95
    assert .05 <= b['p_up'] <= .95
    assert a['p_up'] > base
    assert abs(b['p_up']-.5) < abs(base-.5)
    assert b['threshold_delta'] > 0


def test_v434_meta_exposes_context_features(monkeypatch):
    base={
        'p_up':.64,'p_down':.36,'abstain':False,'signal_strength':'умеренный','signal_threshold':.58,
        'regime':'trend_up|normal_vol','disagreement':False,
        'quality':{'trusted':True,'confidence':'средняя','bias':'bullish'},
        'components':[{'name':'production','p_up':.63,'weight':.55,'trusted':True},{'name':'vol_regime','p_up':.65,'weight':.45,'trusted':True}],
        'scorecard':{'n_eff':60,'edge':3.0,'p_neutral':.2},'validation':{}
    }
    ctx={
        'market':{'relative_strength_20d':.04,'breadth_20d':.68,'correlation_regime':'нормальная корреляция','feature_drift':{'score':.1,'alerts':[]}},
        'event':{'risk_score':.2,'directional_bias':.2,'event_types':['central_bank']},
        'context_score':.5,'event_bias':.2,'event_risk':.2,'drift_score':.1,'coverage':.9,'context_confidence':.8,
    }
    monkeypatch.setattr(META.META433,'forecast_horizon',lambda *a,**k:base)
    out=META.forecast_horizon(series(n=500),'AAPL',10,True,context=ctx)
    assert out['version']=='meta-context-v4.34.0'
    assert out['feature_version']==FE.VERSION
    assert out['context_features']['relative_strength_20d']==.04
    assert out['event_context']['event_types']==['central_bank']
    assert any(x['name']=='cross_sectional_context' for x in out['components'])
    assert 0.05 <= out['p_up'] <= .95


def test_equity_forecast_uses_v434_meta(monkeypatch,tmp_path):
    d=frame(series(n=760))
    monkeypatch.setattr(E,'RU_HISTORY_DIR',tmp_path)
    monkeypatch.setattr(E,'FAST_DISK_DIR',tmp_path/'fast')
    E.FAST_DISK_DIR.mkdir(parents=True,exist_ok=True)
    monkeypatch.setattr(E,'_yahoo_forecast_history',lambda *a,**k:(d.copy(),'history mock',[]))
    monkeypatch.setattr(E,'_append_live_ru',lambda x,s:x)
    row=E.forecast_fast('SBER.ME',(10,),force=True)
    assert row['status']=='ok'
    assert row['profile'] in {'fast-ui-v434','fast-ui-v435'}
    f=row['forecasts']['10']
    assert f['model_version']=='champion-validation-v4.40.10'
    assert 'context_features' in f
    assert 'event_context' in f
    assert 'feature_drift' in f


def test_registry_has_v434_contract(tmp_path):
    import sqlite3
    con=sqlite3.connect(tmp_path/'registry.db')
    try:
        MR.register_champion(con);MR.register_v433_models(con);MR.register_v434_models(con)
        rows={r[0] for r in con.execute('select model_version from model_registry')}
        assert MR.V434_CONTEXT_VERSION in rows
        assert MR.V434_META_VERSION in rows
    finally:
        con.close()


def test_frontend_and_api_expose_v434_context():
    from pathlib import Path
    root=Path(__file__).parent
    api=(root/'api.py').read_text(encoding='utf-8')
    index=(root/'site'/'index.html').read_text(encoding='utf-8')
    tech=(root/'site'/'technical_lab_v411.html').read_text(encoding='utf-8')
    assert '/api/models/quality-v434' in api
    assert 'loadOverviewDailyForecastV434' in index
    assert 'overviewModelContextV434' in index
    assert 'relative_strength_20d' in tech
    assert 'event_context' in tech
    assert 'feature_drift' in tech
