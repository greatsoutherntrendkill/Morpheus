#!/bin/zsh
set -e
cd "$(dirname "$0")/mvp"
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Для запуска нужен Python 3. Установите Python и повторите запуск.'
  read 'reply?Нажмите Enter, чтобы закрыть окно.'
  exit 1
fi
if [ ! -x .venv/bin/python ]; then python3 -m venv .venv; fi
source .venv/bin/activate
REQ_HASH=$(shasum -a 256 requirements.txt | awk '{print $1}')
if [ ! -f .venv/.requirements.sha256 ] || [ "$(cat .venv/.requirements.sha256)" != "$REQ_HASH" ]; then
  python -m pip install -r requirements.txt
  printf '%s\n' "$REQ_HASH" > .venv/.requirements.sha256
fi
export ALLANALYTICS_DATA_DIR="${ALLANALYTICS_DATA_DIR:-$PWD/AllAnalytics_Data}"
echo ''
echo 'Morpheus 4.40.10.31'
echo 'Главная:   http://127.0.0.1:8033/'
echo 'Платформа: http://127.0.0.1:8033/platform.html'
echo 'Оставьте окно открытым. Остановка: Control + C.'
python -m uvicorn api:app --host 127.0.0.1 --port 8033
