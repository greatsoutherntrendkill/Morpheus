
"""Morpheus v4.3 — внутридневные рыночные свечи.

Добавляет реальные интервалы 1 минута / 5 минут / 1 час поверх каскада v4.1.

Приоритет:
- крипто: Binance -> Bybit -> Yahoo;
- индексы MOEX: MOEX ISS candles -> Yahoo proxy (где доступно);
- прочие мировые активы: Yahoo Chart REST -> yfinance;
- CNY/RUB: рассчитывается из синхронных USD/RUB и USD/CNY.

Никакая свеча не интерполируется из дневных данных. Если внутридневной источник
не отвечает, API честно сообщает об отсутствии live-интервала.
"""
from __future__ import annotations

import math
import urllib.parse
from datetime import datetime, timedelta, timezone

import pandas as pd
import requests

import config as C
import market_data_v41 as D
import market_universe_v416 as MU416
import moex_fast_v419 as MOEX419

TIMEOUT=D.TIMEOUT
HEADERS=D.HEADERS
UA=D.UA

CRYPTO_MAP=D.CRYPTO_MAP

MOEX_YAHOO_PROXY={
    "IMOEX":"IMOEX.ME",
    "RTSI":"RTSI.ME",
    "RGBI":"RGBI.ME",
}

INTERVALS={
    "1m":{"yahoo":"1m","binance":"1m","bybit":"1","moex":1,"range":"5d","max_points":2200},
    "5m":{"yahoo":"5m","binance":"5m","bybit":"5","moex":1,"range":"1mo","max_points":2200},
    "1h":{"yahoo":"60m","binance":"1h","bybit":"60","moex":60,"range":"6mo","max_points":2200},
}

def _valid_intraday(symbol,df,min_rows=8,max_stale_hours=96):
    d=D._norm(df)
    if len(d)<min_rows:
        return D._empty()
    if not D.plausible(symbol,float(d.iloc[-1]["close"])):
        return D._empty()
    try:
        now=pd.Timestamp.now(tz="UTC").tz_convert(None)
        age=(now-pd.Timestamp(d.iloc[-1]["date"])).total_seconds()/3600
        if age>max_stale_hours:
            return D._empty()
    except Exception:
        pass
    return d

def yahoo_intraday(symbol,interval):
    spec=INTERVALS[interval]
    enc=urllib.parse.quote(symbol,safe="")
    errs=[]
    for host in ("query1.finance.yahoo.com","query2.finance.yahoo.com"):
        try:
            r=requests.get(
                f"https://{host}/v8/finance/chart/{enc}",
                params={"range":spec["range"],"interval":spec["yahoo"],
                        "events":"div,splits","includePrePost":"false"},
                headers=HEADERS,timeout=TIMEOUT
            )
            if r.status_code!=200:
                errs.append(f"Yahoo {host.split('.')[0]}: HTTP {r.status_code}")
                continue
            result=((r.json().get("chart") or {}).get("result") or [None])[0]
            if not result:
                errs.append(f"Yahoo {host.split('.')[0]}: пустой ответ")
                continue
            ts=result.get("timestamp") or []
            q=(((result.get("indicators") or {}).get("quote") or [{}])[0])
            n=min([len(ts)]+[len(q.get(k) or []) for k in ("open","high","low","close")])
            rows=[]
            for i in range(n):
                rows.append({"date":pd.to_datetime(ts[i],unit="s",utc=True),
                             "open":(q.get("open") or [])[i],
                             "high":(q.get("high") or [])[i],
                             "low":(q.get("low") or [])[i],
                             "close":(q.get("close") or [])[i]})
            d=_valid_intraday(symbol,pd.DataFrame(rows))
            if not d.empty:
                return d,f"Yahoo Chart · {interval}",errs
            errs.append(f"Yahoo {host.split('.')[0]}: свечи не прошли контроль")
        except Exception as e:
            errs.append(f"Yahoo {host.split('.')[0]}: {type(e).__name__}")
    return D._empty(),"",errs

def binance_intraday(symbol,interval,limit=1000):
    bs=CRYPTO_MAP.get(symbol)
    if not bs:
        return D._empty(),"",["Binance: не криптоактив"]
    try:
        r=requests.get("https://data-api.binance.vision/api/v3/klines",
                       params={"symbol":bs,"interval":INTERVALS[interval]["binance"],
                               "limit":min(1000,max(20,int(limit)))},
                       headers=HEADERS,timeout=TIMEOUT)
        if r.status_code!=200:
            return D._empty(),"",[f"Binance: HTTP {r.status_code}"]
        rows=[{"date":pd.to_datetime(int(x[0]),unit="ms",utc=True),
               "open":x[1],"high":x[2],"low":x[3],"close":x[4]} for x in r.json()]
        d=_valid_intraday(symbol,pd.DataFrame(rows),max_stale_hours=8)
        return (d,f"Binance · {interval}",[]) if not d.empty else (D._empty(),"",["Binance: нет свежих свечей"])
    except Exception as e:
        return D._empty(),"",[f"Binance: {type(e).__name__}"]

def bybit_intraday(symbol,interval,limit=1000):
    bs=CRYPTO_MAP.get(symbol)
    if not bs:
        return D._empty(),"",["Bybit: не криптоактив"]
    try:
        r=requests.get("https://api.bybit.com/v5/market/kline",
                       params={"category":"spot","symbol":bs,
                               "interval":INTERVALS[interval]["bybit"],
                               "limit":min(1000,max(20,int(limit)))},
                       headers=HEADERS,timeout=TIMEOUT)
        if r.status_code!=200:
            return D._empty(),"",[f"Bybit: HTTP {r.status_code}"]
        j=r.json()
        if int(j.get("retCode",-1))!=0:
            return D._empty(),"",[f"Bybit: код {j.get('retCode')}"]
        rows=[{"date":pd.to_datetime(int(x[0]),unit="ms",utc=True),
               "open":x[1],"high":x[2],"low":x[3],"close":x[4]}
              for x in ((j.get("result") or {}).get("list") or [])]
        d=_valid_intraday(symbol,pd.DataFrame(rows).sort_values("date"),max_stale_hours=8)
        return (d,f"Bybit · {interval}",[]) if not d.empty else (D._empty(),"",["Bybit: нет свежих свечей"])
    except Exception as e:
        return D._empty(),"",[f"Bybit: {type(e).__name__}"]

def _moex_candle_frame(rows, interval):
    """ISS begin is Moscow local bar-open time, never UTC or bar-close time."""
    raw = pd.DataFrame(rows)
    if raw.empty:
        return D._empty()
    raw["date"] = pd.to_datetime(raw["date"], errors="coerce").dt.tz_localize(
        "Europe/Moscow").dt.tz_convert("UTC")
    d = D._norm(raw)
    if interval == "5m" and not d.empty:
        grouped = d.set_index("date").resample("5min", label="left", closed="left")
        counts = grouped["close"].count()
        d = grouped.agg({"open":"first", "high":"max", "low":"min", "close":"last"})
        # Missing minutes must not silently become full five-minute observations.
        d = d.loc[counts == 5].dropna(subset=["close"]).reset_index()
    return d

def moex_intraday(symbol,interval):
    """VPN-resilient intraday candles for MOEX indices and shares.

    v4.25 routes Technical Lab through the same MOEX419 transport used by the
    working Markets page.  Russian equities were previously sent to Yahoo and the
    old index-only MOEX function, so PLZL.ME/SBER.ME/etc had no intraday history.
    """
    s=str(symbol or "").upper()
    is_share=MU416.is_ru_equity(s)
    is_index=s in C.MOEX_INDICES
    if not (is_share or is_index):
        return D._empty(),"",["MOEX ISS: инструмент не относится к поддерживаемому российскому universe"]
    market="shares" if is_share else "index"
    board="TQBR" if is_share else "SNDX"
    secid=MU416.moex_secid(s) if is_share else s
    base_iv=INTERVALS[interval]["moex"]
    # 5m is built from official 1m candles. The selected-asset terminal only
    # needs enough history for indicators/forecast, not a month of 1m bars.
    days={"1m":4,"5m":8,"1h":190}[interval]
    date_from=(pd.Timestamp.now()-pd.Timedelta(days=days)).strftime("%Y-%m-%d")
    path=f"/iss/engines/stock/markets/{market}/boards/{board}/securities/{secid}/candles.json"
    rows=[];pos=0;errs=[]
    try:
        while pos<5000:
            j,transport=MOEX419._request_json(path,{
                "iss.meta":"off","iss.only":"candles","from":date_from,
                "interval":base_iv,"start":pos,
                "candles.columns":"begin,open,high,low,close",
            })
            block=(j or {}).get("candles") or {}
            chunk=MOEX419._rows(block)
            if not chunk: break
            for x in chunk:
                rows.append({"date":x.get("begin"),"open":x.get("open"),
                             "high":x.get("high"),"low":x.get("low"),"close":x.get("close")})
            pos+=len(chunk)
            if len(chunk)<500: break
        d=_moex_candle_frame(rows,interval)
        d=_valid_intraday(symbol,d,max_stale_hours=120)
        if not d.empty:
            return d,f"MOEX ISS · {board} · {interval} · {transport}",errs
        errs.append("MOEX ISS: candles did not pass validation")
    except Exception as e:
        errs.append(f"MOEX ISS: {type(e).__name__}: {str(e)[:120]}")
    return D._empty(),"",errs

def yfinance_intraday(symbol,interval):
    try:
        import yfinance as yf
    except Exception:
        return D._empty(),"",["yfinance: пакет недоступен"]
    spec=INTERVALS[interval]
    try:
        raw=yf.download(symbol,period=spec["range"],interval=spec["yahoo"],
                        auto_adjust=True,progress=False,threads=False,prepost=False)
        if raw is None or raw.empty:
            return D._empty(),"",["yfinance: пусто"]
        # yfinance may return multiindex columns.
        if isinstance(raw.columns,pd.MultiIndex):
            try:
                raw.columns=raw.columns.get_level_values(0)
            except Exception:
                pass
        rows=pd.DataFrame({
            "date":raw.index,
            "open":raw.get("Open"),"high":raw.get("High"),
            "low":raw.get("Low"),"close":raw.get("Close")
        })
        d=_valid_intraday(symbol,rows)
        return (d,f"yfinance · {interval}",[]) if not d.empty else (D._empty(),"",["yfinance: свечи не прошли контроль"])
    except Exception as e:
        return D._empty(),"",[f"yfinance: {type(e).__name__}"]

def _cross_frames(a,b,symbol):
    if a.empty or b.empty:
        return D._empty()
    aa=D._norm(a).set_index("date");bb=D._norm(b).set_index("date")
    # Intraday timestamps from Yahoo normally align. If not, round to 1m before join.
    idx=aa.index.intersection(bb.index)
    if len(idx)<8:
        return D._empty()
    out=pd.DataFrame(index=idx)
    out["open"]=aa.loc[idx,"open"]/bb.loc[idx,"open"]
    out["close"]=aa.loc[idx,"close"]/bb.loc[idx,"close"]
    out["high"]=aa.loc[idx,"high"]/bb.loc[idx,"low"]
    out["low"]=aa.loc[idx,"low"]/bb.loc[idx,"high"]
    return _valid_intraday(symbol,out.reset_index())

def fetch_intraday(symbol,interval):
    interval=str(interval or "").lower()
    if interval not in INTERVALS:
        return D.MarketResult(symbol,D._empty(),"",[f"неподдерживаемый интервал {interval}"])
    errors=[]

    if symbol in CRYPTO_MAP:
        for fn in (binance_intraday,bybit_intraday):
            d,src,e=fn(symbol,interval);errors+=e
            if not d.empty:
                return D.MarketResult(symbol,d,src,errors)

    if MU416.is_ru_equity(symbol):
        d,src,e=moex_intraday(symbol,interval);errors+=e
        if not d.empty:
            return D.MarketResult(symbol,d,src,errors)
        # Do not silently route Russian shares to Yahoo as the primary source;
        # keep it only as a final recovery route.
        d,src,e=yahoo_intraday(symbol,interval);errors+=e
        if not d.empty:
            return D.MarketResult(symbol,d,src,errors)
        return D.MarketResult(symbol,D._empty(),"",errors)

    if symbol in C.MOEX_INDICES:
        d,src,e=moex_intraday(symbol,interval);errors+=e
        if not d.empty:
            return D.MarketResult(symbol,d,src,errors)
        proxy=MOEX_YAHOO_PROXY.get(symbol)
        if proxy:
            d,src,e=yahoo_intraday(proxy,interval);errors+=e
            if not d.empty:
                # Revalidate against original symbol's broad range.
                return D.MarketResult(symbol,d,src.replace(proxy,symbol),errors)
        return D.MarketResult(symbol,D._empty(),"",errors)

    if symbol=="CNYRUB":
        a=fetch_intraday("RUB=X",interval)
        b=fetch_intraday("CNY=X",interval)
        errors+=a.errors+b.errors
        d=_cross_frames(a.frame,b.frame,symbol)
        if not d.empty:
            return D.MarketResult(symbol,d,f"расчёт CNY/RUB · {interval}",errors)
        return D.MarketResult(symbol,D._empty(),"",errors)

    d,src,e=yahoo_intraday(symbol,interval);errors+=e
    if not d.empty:
        return D.MarketResult(symbol,d,src,errors)

    d,src,e=yfinance_intraday(symbol,interval);errors+=e
    if not d.empty:
        return D.MarketResult(symbol,d,src,errors)

    return D.MarketResult(symbol,D._empty(),"",errors)
