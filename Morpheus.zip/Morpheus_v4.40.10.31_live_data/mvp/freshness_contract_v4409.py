"""Morpheus v4.40.9 — feature freshness/staleness contract.

The contract makes source age explicit and prevents unlimited forward filling from
silently turning old observations into apparently current model inputs.
"""
from __future__ import annotations

import math
from typing import Mapping
import pandas as pd

VERSION = "feature-freshness-contract-v4.40.9"

# Limits are deliberately source-class specific.  ``*_FILL_LIMIT`` is expressed
# in rows of the target trading-day index, while warning/hard limits are calendar
# days so API/UI diagnostics remain easy to interpret.
MARKET_FILL_LIMIT = 5
MACRO_FILL_LIMIT = 45
MARKET_WARNING_DAYS = 4
MARKET_HARD_DAYS = 10
MACRO_WARNING_DAYS = 45
MACRO_HARD_DAYS = 75


def _ts(x):
    if x is None:
        return None
    try:
        t = pd.Timestamp(x)
        if t.tzinfo is not None:
            t = t.tz_convert(None)
        return t
    except Exception:
        return None


def clean_series(series) -> pd.Series:
    if series is None:
        return pd.Series(dtype=float)
    s = pd.Series(series).copy()
    try:
        s.index = pd.to_datetime(s.index)
    except Exception:
        pass
    s = s[~s.index.duplicated(keep="last")].sort_index()
    return s


def bounded_reindex_series(series, index, limit: int = MARKET_FILL_LIMIT) -> pd.Series:
    s = clean_series(series)
    idx = pd.DatetimeIndex(pd.to_datetime(index))
    if s.empty:
        return pd.Series(index=idx, dtype=float)
    return s.reindex(idx).ffill(limit=max(0, int(limit)))


def bounded_reindex_frame(frame: pd.DataFrame | None, index, limit: int = MACRO_FILL_LIMIT) -> pd.DataFrame:
    idx = pd.DatetimeIndex(pd.to_datetime(index))
    if frame is None or getattr(frame, "empty", True):
        return pd.DataFrame(index=idx)
    f = frame.copy()
    try:
        f.index = pd.to_datetime(f.index)
    except Exception:
        pass
    f = f[~f.index.duplicated(keep="last")].sort_index()
    return f.reindex(idx).ffill(limit=max(0, int(limit)))


def source_meta(name: str, series, as_of=None, *, warning_days: int = MARKET_WARNING_DAYS,
                hard_days: int = MARKET_HARD_DAYS, critical: bool = True) -> dict:
    s = clean_series(series).dropna()
    ref = _ts(as_of)
    if ref is None and len(s):
        ref = _ts(s.index[-1])
    if ref is not None and len(s):
        s = s.loc[s.index <= ref]
    if s.empty:
        return {
            "source": str(name), "age_days": None, "last_observation": None,
            "missing": True, "warning": bool(critical), "hard_stale": bool(critical),
            "warning_after_days": int(warning_days), "hard_after_days": int(hard_days),
            "critical": bool(critical),
        }
    last = _ts(s.index[-1])
    age = 0.0 if ref is None or last is None else max(0.0, float((ref.normalize()-last.normalize()).days))
    return {
        "source": str(name), "age_days": age,
        "last_observation": None if last is None else str(last.date()),
        "missing": False, "warning": bool(age > warning_days),
        "hard_stale": bool(age > hard_days),
        "warning_after_days": int(warning_days), "hard_after_days": int(hard_days),
        "critical": bool(critical),
    }


def summarize_sources(sources: Mapping[str, dict] | None) -> dict:
    src = dict(sources or {})
    ages = []
    warnings = []
    hard = []
    missing = []
    hard_critical = []
    for key, row in src.items():
        row = row or {}
        try:
            age = float(row.get("age_days"))
            if math.isfinite(age):
                ages.append(age)
        except Exception:
            pass
        if row.get("missing"):
            missing.append(str(key))
        if row.get("warning"):
            warnings.append(str(key))
        if row.get("hard_stale"):
            hard.append(str(key))
            if row.get("critical", True):
                hard_critical.append(str(key))
    return {
        "version": VERSION,
        "sources": src,
        "source_count": len(src),
        "max_age_days": max(ages) if ages else None,
        "warning_sources": warnings,
        "hard_stale_sources": hard,
        "missing_sources": missing,
        "hard_critical_sources": hard_critical,
        "has_warning": bool(warnings or missing),
        "hard_stale": bool(hard_critical),
    }
