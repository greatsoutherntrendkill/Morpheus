"""Descriptive completed-window diagnostics, never calibrated path probabilities."""
import numpy as np
import pandas as pd

VERSION='short-horizons-v4.40.10.17'
MINUTES={'30m':30,'1h':60,'2h':120,'4h':240}

def contiguous_tail(frame, interval_minutes):
    d=frame.sort_values('date').reset_index(drop=True)
    gaps=pd.to_datetime(d.date,utc=True).diff().dt.total_seconds().div(60)
    breaks=np.flatnonzero((gaps.ne(interval_minutes)&gaps.notna()).to_numpy())
    return d.iloc[int(breaks[-1]) if len(breaks) else 0:].copy()

def path_diagnostics(frame,horizon,interval_minutes,threshold):
    out={'version':VERSION,'status':'unavailable','calibrated':False,'basis':'completed_contiguous_windows',
         'threshold_basis':'current_threshold_applied_retrospectively','observations':0,'nonoverlap':0,
         'note':'Историческое описание при текущем пороге, не вероятность будущего касания. Порядок внутри одной свечи неизвестен.'}
    if threshold is None or not np.isfinite(threshold) or threshold<=0:return out
    bars=MINUTES[horizon]//interval_minutes
    d=frame.sort_values('date').reset_index(drop=True)
    if bars<1 or not {'open','high','low','close','date'}<=set(d):return out
    t=pd.to_datetime(d.date,utc=True);rows=[];last_end=-1;independent=0
    for start in range(len(d)-bars):
        end=start+bars
        if not t.iloc[start+1:end+1].diff().dropna().eq(pd.Timedelta(minutes=interval_minutes)).all():continue
        if t.iloc[start+1]-t.iloc[start]!=pd.Timedelta(minutes=interval_minutes):continue
        base=float(d.close.iloc[start]);w=d.iloc[start+1:end+1]
        values=w[['open','high','low','close']].to_numpy(float)
        if base<=0 or not np.isfinite(values).all() or (values<=0).any():continue
        upper=base*np.exp(threshold/100);lower=base*np.exp(-threshold/100)
        hi=np.flatnonzero(w.high.to_numpy()>=upper);lo=np.flatnonzero(w.low.to_numpy()<=lower)
        ih=int(hi[0])+1 if len(hi) else None;il=int(lo[0])+1 if len(lo) else None
        first=('both_same_bar' if ih==il else 'up' if ih<il else 'down') if ih and il else 'up' if ih else 'down' if il else 'neither'
        rows.append({'return':100*(float(w.close.iloc[-1])/base-1),'max':100*(float(w.high.max())/base-1),'min':100*(float(w.low.min())/base-1),'up':ih,'down':il,'first':first})
        if start>=last_end:independent+=1;last_end=end
    out.update(observations=len(rows),nonoverlap=independent)
    if len(rows)<30:return out
    out.update(status='descriptive',max_excursion_median_pct=float(np.median([r['max'] for r in rows])),min_excursion_median_pct=float(np.median([r['min'] for r in rows])),terminal_median_pct=float(np.median([r['return'] for r in rows])))
    out['first_touch_counts']={k:sum(r['first']==k for r in rows) for k in ('up','down','both_same_bar','neither')}
    out['median_touch_minutes']={k:float(np.median([r[k]*interval_minutes for r in rows if r[k] is not None])) if any(r[k] is not None for r in rows) else None for k in ('up','down')}
    # Fixed stress assumptions, not actual broker fees and not strategy returns.
    out['cost_sensitivity']=[{'round_trip_bps':bps,'windows_with_abs_move_above_cost':sum(abs(r['return'])>bps/100 for r in rows)} for bps in (5,10,25)]
    out['execution_note']='Издержки 5/10/25 б.п. — условные сценарии полного оборота. Учтён только размер конечного движения; это не доходность стратегии, спред и исполнение не измерены.'
    return out
