
from __future__ import annotations
import csv, json
from datetime import datetime, timezone
from pathlib import Path

import db
import model_registry as MR
import regime_models_v37 as R

ROOT=Path(__file__).parent
OUT=ROOT/"site"/"regime_v37.json"
CSV=ROOT/"regime_v37.csv"

def main():
    con=db.connect()
    try:
        MR.register_challenger(
            con,R.VERSION,"regime_mixture_of_experts",R.FEATURE_VERSION,
            R.LOCKED_CONFIG,
            "v3.7 regime-aware MoE + OOD guard; prospective holdout only; production champion unchanged",
            validation_version=R.VALIDATION_VERSION
        )
        payload=R.run_all(con)
        payload["generated_at"]=datetime.now(timezone.utc).replace(microsecond=0).isoformat()

        rows=[]
        for hrow in payload["horizons"]:
            h=hrow["horizon"]
            for r in hrow.get("live") or []:
                pid=MR.append_prediction_for_model(
                    con,R.VERSION,R.FEATURE_VERSION,r["symbol"],h,r["date"],r["final_research_p_up"],
                    quality={
                        "research":True,
                        "raw_moe_p_up":r["raw_moe_p_up"],
                        "calibrated_p_up":r["calibrated_p_up"],
                        "total_shrink_alpha":r["total_shrink_alpha"],
                        "regime_familiarity":r["regime_familiarity"],
                        "expert_disagreement":r["expert_disagreement"],
                        "risk_regime":r["risk_regime"],
                        "policy":"evidence_x_ood_x_agreement_v3.7",
                    },
                    macro_provenance={
                        "feature_version":R.FEATURE_VERSION,
                        "cross_market_lag":"1d",
                        "regime_thresholds":"expanding_shifted",
                        "prospective_holdout_start":payload["prospective_holdout_start"],
                    },
                    holdout_status="pre-holdout/research" if r["date"] < payload["prospective_holdout_start"]
                                   else "prospective-holdout/frozen"
                )
                rows.append({
                    "model_version":R.VERSION,"symbol":r["symbol"],"horizon":h,"date":r["date"],
                    "risk_regime":r["risk_regime"],"expert_class":r["expert_class"],
                    "raw_moe_p_up":r["raw_moe_p_up"],"calibrated_p_up":r["calibrated_p_up"],
                    "final_research_p_up":r["final_research_p_up"],
                    "evidence_alpha":r["evidence_alpha"],"ood_alpha":r["ood_alpha"],
                    "agreement_alpha":r["agreement_alpha"],
                    "regime_familiarity":r["regime_familiarity"],
                    "expert_disagreement":r["expert_disagreement"],
                    "n_eff":r["development_evidence"].get("n_eff"),
                    "prediction_id":pid,
                })

        evidence={
            "model_version":R.VERSION,
            "prospective_holdout_start":payload["prospective_holdout_start"],
            "packaged_data_last_date":payload["data_meta"]["last_date"],
            "prospective_realized_rows":sum(h["prospective_holdout"]["n_realized_rows"] for h in payload["horizons"]),
            "development":{
                str(h["horizon"]):{
                    "metrics":h.get("development"),
                    "cluster_date_bootstrap":h.get("cluster_date_bootstrap"),
                    "regime_development":h.get("regime_development"),
                } for h in payload["horizons"]
            }
        }
        did=MR.record_model_decision(
            con,"v3.7-regime-moe-prospective",
            "logreg-v3.2.0","logreg-v3.2.0","retain",evidence,
            "v3.7 Regime MoE remains a shadow challenger until the genuinely prospective holdout accumulates sufficient evidence."
        )
        payload["decision"]["decision_id"]=did

        OUT.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
        if rows:
            with CSV.open("w",newline="",encoding="utf-8") as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]))
                w.writeheader(); w.writerows(rows)

        # Merge lightweight live research layer into regular site payload.
        dp=ROOT/"site"/"data.json"
        if dp.exists():
            data=json.loads(dp.read_text(encoding="utf-8"))
            by={}
            for hrow in payload["horizons"]:
                h=str(hrow["horizon"])
                for r in hrow.get("live") or []:
                    by.setdefault(r["symbol"],{})[h]={
                        **r,
                        "model_version":R.VERSION,
                        "prospective_holdout":hrow.get("prospective_holdout"),
                        "development":hrow.get("development"),
                        "cluster_date_bootstrap":hrow.get("cluster_date_bootstrap"),
                        "regime_development":hrow.get("regime_development"),
                        "top_features_frozen":hrow.get("top_features_frozen"),
                    }
            for a in data.get("assets",[]):
                a["regime_moe_v37"]=by.get(a.get("symbol"),{})
            data["regime_model_version"]="3.7"
            data["regime_prospective_holdout_start"]=payload["prospective_holdout_start"]
            dp.write_text(json.dumps(data,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
            (ROOT/"site"/"data.js").write_text(
                "window.FORECASTS = "+json.dumps(data,ensure_ascii=False,separators=(",",":"))+";\n",
                encoding="utf-8"
            )

        print(json.dumps({
            "version":"3.7","model_version":R.VERSION,
            "assets":len(payload["data_meta"]["symbols"]),
            "horizons":len(payload["horizons"]),
            "prediction_rows":len(rows),
            "prospective_holdout_start":payload["prospective_holdout_start"],
            "decision":payload["decision"],
        },ensure_ascii=False,indent=2))
    finally:
        con.close()

if __name__=="__main__":
    main()
