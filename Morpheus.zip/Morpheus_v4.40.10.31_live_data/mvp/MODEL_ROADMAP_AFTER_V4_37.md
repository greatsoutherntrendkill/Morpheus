# Model roadmap after v4.37

## v4.38 — Asset-Class Specialists
- отдельные expert-модели для equities / FX / commodities / crypto;
- cross-sectional ranking для акций;
- sector-relative strength и breadth;
- разные feature sets и calibration по классам активов;
- routing по asset class + market regime;
- сравнение specialists с общей моделью через v4.37 prospective guard.

## v4.39 — Event Response Models
- отдельные модели реакции на FOMC / ECB / ЦБ РФ / CPI / earnings;
- surprise factor;
- historical sensitivity profiles;
- event-specific calibration и abstention;
- допуск event-моделей к весу только через prospective guard.

## Далее
После накопления достаточного prospective history можно переходить к более глубокой автоматизации model allocation, но automatic champion promotion остаётся запрещённой без отдельного решения.

## Отложенный Scenario Lab roadmap
Historical Analog Engine, Quant Scenario Model, Monte Carlo и LLM Scenario Intelligence сохраняются отдельно и будут подключены поверх более надёжного прогнозного ядра.
