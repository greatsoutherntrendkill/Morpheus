"""Direct-horizon models with expanding, release-purged evaluation and honest baselines."""
from __future__ import annotations
import hashlib,json,warnings,weakref
from collections import OrderedDict
_CACHE={}
def cache(d):
 key=id(d)
 item=_CACHE.get(key)
 if item is None or item["ref"]() is not d:
  item={"ref":weakref.ref(d,lambda ref,k=key:_CACHE.pop(k,None)),"groups":{s:g for s,g in d.groupby("series")},"values":OrderedDict()}
  _CACHE[key]=item
 return item

import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import ExtraTreesRegressor
from macro_policy_data_v19 import REGISTRY
VERSION='macro-policy-trained-19.5'

def frame(rows):
 d=pd.DataFrame(rows,columns=['series','period','available','value','source'])
 d['period']=pd.to_datetime(d.period);d['available']=pd.to_datetime(d.available,utc=True,format='ISO8601')
 d['value']=pd.to_numeric(d.value,errors='coerce');return d.sort_values(['series','period','available'])

def transformed(d,sid,cutoff):
 store=cache(d);key=(sid,pd.Timestamp(cutoff).value)
 if key in store['values']:return store['values'][key]
 source=store['groups'].get(sid)
 if source is None:return pd.Series(dtype=float)
 r=source[source.available<pd.Timestamp(cutoff)].drop_duplicates('period',keep='last').set_index('period').value.sort_index()
 spec=REGISTRY[sid]
 if r.empty:return r
 r=r.groupby(r.index.to_period(spec['freq'])).agg(lambda x:x.iloc[-1]).sort_index()
 # Reindex before shifting: twelve observations are not necessarily twelve months.
 r=r.reindex(pd.period_range(r.index.min(),r.index.max(),freq=spec['freq']))
 tr=spec['transform']
 if tr=='yoy':r=100*(r/r.shift(12)-1)
 elif tr=='annualized':r=100*((r/r.shift(1))**4-1)
 elif tr=='change':r=r-r.shift(1)
 r=r.replace([np.inf,-np.inf],np.nan);store['values'][key]=r
 if len(store['values'])>20000:store['values'].popitem(last=False)
 return r

def features(d,sid,cutoff):
 spec=REGISTRY[sid];x=[];names=[];last=None
 for key,meta in REGISTRY.items():
  if meta['country']!=spec['country']:continue
  z=transformed(d,key,cutoff);values=z.dropna()
  for lag in [0,1,2,3,6,12]:
   value=float(z.iloc[-1-lag]) if len(z)>lag else np.nan
   x.append(value);names.append(key+':lag'+str(lag))
  age=(pd.Timestamp(cutoff).tz_localize(None).to_period(meta['freq']).ordinal-values.index[-1].ordinal) if len(values) else np.nan
  x.append(float(age));names.append(key+':age')
  if key==sid and len(values):last=float(values.iloc[-1])
 return np.array(x),last,names

def first_targets(d,sid):
 r=d[(d.series==sid)&d.value.notna()].copy();freq=REGISTRY[sid]['freq']
 if r.empty:return {}
 targets={}
 if REGISTRY[sid]['kind']=='rate':
  # End-of-month policy target, not a monthly average or a meeting outcome.
  r['bucket']=r.period.dt.to_period('M')
  for period,g in r.groupby('bucket'):
   last_day=g.period.max();first=g[g.period==last_day].sort_values('available').iloc[0]
   end=(period+1).start_time.tz_localize('UTC')
   if period.end_time.normalize()!=last_day:continue
   targets[str(period)]=(float(first.value),max(first.available,end))
 else:
  for _,row in r.drop_duplicates('period',keep='first').iterrows():
   period=row.period.to_period(freq)
   z=transformed(d,sid,row.available+pd.Timedelta(microseconds=1))
   value=z.get(period,np.nan)
   if np.isfinite(value):targets[str(period)]=(float(value),row.available)
 return targets

def dataset(d,sid,horizon,as_of):
 spec=REGISTRY[sid];freq=spec['freq'];targets=first_targets(d,sid)
 if not targets:return []
 first=min(pd.Period(p,freq=freq) for p in targets);last=pd.Timestamp(as_of).tz_localize(None).to_period(freq)
 result=[]
 for p in pd.period_range(first,last,freq=freq):
  offset=(pd.Timestamp(as_of).tz_localize(None).normalize()-last.start_time).days
  issue_day=min(p.start_time+pd.Timedelta(days=offset),p.end_time.normalize())
  time_of_day=pd.Timestamp(as_of)-pd.Timestamp(as_of).normalize()
  issued=issue_day.tz_localize('UTC')+time_of_day;target=p+horizon-1;truth=targets.get(str(target))
  if truth is None or truth[1]<=issued:continue
  x,base,names=features(d,sid,issued)
  if base is None:continue
  seasonal=transformed(d,sid,issued).get(target-(12 if freq=='M' else 4),np.nan)
  result.append(dict(issued=issued,period=str(target),available=truth[1],y=truth[0],x=x,baseline=base,seasonal=float(seasonal) if pd.notna(seasonal) else base))
 return result

def estimator(name):
 if name=='ridge':return make_pipeline(SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),StandardScaler(),Ridge(alpha=10))
 if name=='trees':return make_pipeline(SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),ExtraTreesRegressor(n_estimators=48,min_samples_leaf=8,max_depth=5,random_state=1901,n_jobs=1))
 raise ValueError(name)

def predict(name,train,row):
 if name=='persistence':return row['baseline']
 if name=='seasonal':return row.get('seasonal',row['baseline'])
 m=estimator(name);x=np.array([t['x'] for t in train]);y=np.array([t['y']-t['baseline'] for t in train])
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',RuntimeWarning);m.fit(x,y)
 return float(row['baseline']+m.predict(row['x'][None,:])[0])

def quantile(errors,coverage=.8):
 if len(errors)<12:return None
 rank=min(len(errors),int(np.ceil((len(errors)+1)*coverage)));return float(np.sort(np.abs(errors))[rank-1])

def evaluate(d,sid,horizon,as_of):
 samples=dataset(d,sid,horizon,as_of);freq=REGISTRY[sid]['freq'];minimum=48 if freq=='M' else 24
 valid=36 if freq=='M' else 32;test=24 if freq=='M' else 12
 # Historical evaluation only uses outcomes already available at the actual run date.
 now=pd.Timestamp(as_of);samples=[s for s in samples if s['available']<now]
 if len(samples)<minimum+valid+test:return dict(status='insufficient_history',samples=len(samples),required=minimum+valid+test)
 start=len(samples)-valid-test;test_start=samples[-test]['issued'];candidates=['persistence','seasonal','ridge','trees'];validation=[]
 for row in samples[start:-test]:
  train=[s for s in samples if s['issued']<row['issued'] and s['available']<row['issued']]
  if len(train)<minimum or row['available']>=test_start:continue
  validation.append(dict(row=row,pred={n:predict(n,train,row) for n in candidates}))
 if len(validation)<8:return dict(status='insufficient_validation',samples=len(validation))
 split=len(validation)//2;calibration=validation[split:]
 # Selection outcomes must be known before the first calibration issue, too.
 selection=[v for v in validation[:split] if v['row']['available']<calibration[0]['row']['issued']]
 if len(selection)<8 or len(calibration)<12:return dict(status='insufficient_calibration',samples=len(calibration))
 scores={n:float(np.mean([abs(v['pred'][n]-v['row']['y']) for v in selection])) for n in candidates}
 chosen=min(candidates,key=lambda n:scores[n]);errors=[v['row']['y']-v['pred'][chosen] for v in calibration];base_errors=[v['row']['y']-v['row']['baseline'] for v in calibration];records=[]
 for row in samples[-test:]:
  train=[s for s in samples if s['issued']<row['issued'] and s['available']<row['issued']]
  predicted=predict(chosen,train,row)
  # Only residuals which would be published before this issue date enter calibration.
  known=errors+[t['actual']-t['prediction'] for t in records if pd.Timestamp(t['available'])<row['issued']]
  base_known=base_errors+[t['actual']-t['baseline'] for t in records if pd.Timestamp(t['available'])<row['issued']]
  base_radius=quantile(base_known[-60:])
  radius=quantile(known[-60:]);records.append(dict(issued=row['issued'].isoformat(),period=row['period'],available=row['available'].isoformat(),actual=row['y'],prediction=predicted,baseline=row['baseline'],baseline_lower=None if base_radius is None else row['baseline']-base_radius,baseline_upper=None if base_radius is None else row['baseline']+base_radius,lower=None if radius is None else predicted-radius,upper=None if radius is None else predicted+radius,train_n=len(train)))
 mae=float(np.mean([abs(r['prediction']-r['actual']) for r in records]));baseline_mae=float(np.mean([abs(r['baseline']-r['actual']) for r in records]));covered=[r['lower']<=r['actual']<=r['upper'] for r in records if r['lower'] is not None]
 paired=np.array([abs(r['prediction']-r['actual'])-abs(r['baseline']-r['actual']) for r in records])
 # Non-overlapping subsequence reports dependence limits rather than inflated significance.
 effective=len(records[::horizon]);improves=chosen not in ('persistence','seasonal') and mae<baseline_mae
 base_covered=[r['baseline_lower']<=r['actual']<=r['baseline_upper'] for r in records if r['baseline_lower'] is not None]
 return dict(status='evaluated',baseline_coverage=None if not base_covered else float(np.mean(base_covered)),baseline_calibration_errors=(base_errors+[r['actual']-r['baseline'] for r in records])[-60:],selected=chosen,validation_mae=scores,test_mae=mae,baseline_mae=baseline_mae,test_n=len(records),nonoverlap_n=effective,coverage=None if not covered else float(np.mean(covered)),nominal_coverage=.8,advantage_observed=improves,advantage_confirmed=False,records=records,calibration_errors=(errors+[r['actual']-r['prediction'] for r in records])[-60:],selection_cutoff=selection[-1]['row']['available'].isoformat(),test_start=test_start.isoformat(),calibration_start=calibration[0]['row']['issued'].isoformat(),selection_n=len(selection),calibration_n=len(calibration),samples=len(samples))

def forecast(d,sid,horizon,as_of,evaluation):
 spec=REGISTRY[sid];now=pd.Timestamp(as_of);period=now.tz_localize(None).to_period(spec['freq'])+horizon-1
 x,base,names=features(d,sid,now)
 if base is None or evaluation.get('status')!='evaluated':return dict(status='unavailable',reason=evaluation.get('status','missing_data'))
 fresh=freshness(d,sid,now)
 if not fresh['ok']:return dict(status='unavailable',reason='stale_target_history',freshness=fresh)
 samples=dataset(d,sid,horizon,as_of);train=[s for s in samples if s['available']<now];seasonal=transformed(d,sid,now).get(period-(12 if spec['freq']=='M' else 4),np.nan);row=dict(x=x,baseline=base,seasonal=float(seasonal) if pd.notna(seasonal) else base)
 # The holdout is a diagnostic; it does not retroactively select a different candidate.
 selected=evaluation['selected'];value=predict(selected,train,row);radius=quantile(evaluation['calibration_errors']);digest=hashlib.sha256(pd.util.hash_pandas_object(d[d.available<now],index=False).values.tobytes()).hexdigest()
 candidate=dict(model=selected,value=value,lower=None if radius is None else value-radius,upper=None if radius is None else value+radius)
 rejected=selected!='persistence' and evaluation['test_mae']>=evaluation['baseline_mae']
 if rejected:
  selected='persistence';value=base;radius=quantile(evaluation['baseline_calibration_errors'])
 return dict(status='ok',candidate=candidate,publication_reason='candidate_failed_holdout' if rejected else 'validation_selected',series=sid,period=str(period),horizon=horizon,issued=now.isoformat(),value=value,lower=None if radius is None else value-radius,upper=None if radius is None else value+radius,baseline=base,model=selected,version=VERSION,snapshot=digest,train_n=len(train),features=names,unit=spec['unit'],target_semantics='month_end_policy_target' if spec['kind']=='rate' else 'initial_publication',interval_semantics='empirical_80_percent_not_guaranteed',research_only=True,freshness=fresh,evaluation={k:v for k,v in evaluation.items() if k not in ['records','calibration_errors','baseline_calibration_errors']})


def freshness(d,sid,as_of):
 now=pd.Timestamp(as_of);r=d[(d.series==sid)&(d.available<now)&d.value.notna()]
 if r.empty:return dict(ok=False,reason='missing_target')
 latest=r.period.max();spec=REGISTRY[sid]
 age_days=(now.tz_localize(None).normalize()-latest).days
 limit=7 if spec['kind']=='rate' else (190 if spec['freq']=='Q' else 100)
 return dict(ok=age_days<=limit,observation=latest.date().isoformat(),age_days=age_days,max_age_days=limit)
