"""
Дашборд MVP. Запуск:  streamlit run app.py
Работает на том, что лежит в market.db (сначала: python update.py --demo или python update.py).
"""
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import streamlit as st

import config as C
import db
import analytics as A

st.set_page_config(page_title="Аналитическая панель", layout="wide")

con = db.connect()
NAMES = {**{k: v[0] for k, v in C.YF_PRICES.items()},
         **{k: v[2] for k, v in C.YF_CROSSES.items()},
         **{k: v[0] for k, v in C.MOEX_INDICES.items()}}
MACRO_NAMES = {k: v[0] for k, v in {**C.FRED_US, **C.FRED_RU}.items()}

syms = db.symbols(con)
if not syms:
    st.warning("База пуста. Запусти в терминале:  python update.py --demo")
    st.stop()

meta = db.read_meta(con)
st.title("Аналитическая панель: рынки, макро, ставки ЦБ")
st.caption("Обновление данных: " + ", ".join(f"{k}={v[:16]}" for k, v in meta.items()) or "—")

tab_over, tab_macro, tab_an, tab_fx = st.tabs(
    ["Обзор", "Макро и ставки", "Аналитика", "Сценарии"])

# ---------------------------- ОБЗОР ----------------------------
with tab_over:
    c1, c2 = st.columns([3, 1])
    label = c1.selectbox("Инструмент", syms,
                         format_func=lambda s: f"{NAMES.get(s, s)} ({s})")
    tf = c2.radio("Таймфрейм", ["День", "Неделя", "Месяц"], horizontal=True)
    rule = {"День": "D", "Неделя": "W", "Месяц": "ME"}[tf]
    df = db.read_prices(con, label)
    if df.empty:
        st.info("Нет данных по инструменту.")
    else:
        stats = A.summary_stats(df.set_index("date")["close"])
        cols = st.columns(len(stats))
        for c, (k, v) in zip(cols, stats.items()):
            c.metric(k, v)
        cndl = A.resample_ohlc(df, rule)
        cndl = A.moving_averages(cndl)
        fig = go.Figure()
        fig.add_candlestick(x=cndl["date"], open=cndl["open"], high=cndl["high"],
                            low=cndl["low"], close=cndl["close"], name="Цена",
                            increasing_line_color="#12a15b",
                            decreasing_line_color="#e0344a")
        for w, col in ((20, "#2962ff"), (50, "#f59e0b"), (200, "#8b5cf6")):
            if f"MA{w}" in cndl:
                fig.add_scatter(x=cndl["date"], y=cndl[f"MA{w}"], name=f"MA{w}",
                                line=dict(width=1.2, color=col))
        fig.update_layout(
            template="plotly_white", height=560,
            margin=dict(l=0, r=0, t=10, b=0), legend=dict(orientation="h"),
            xaxis=dict(rangeslider=dict(visible=True), rangeselector=dict(buttons=[
                dict(count=1, label="1М", step="month", stepmode="backward"),
                dict(count=3, label="3М", step="month", stepmode="backward"),
                dict(count=6, label="6М", step="month", stepmode="backward"),
                dict(count=1, label="1Г", step="year", stepmode="backward"),
                dict(step="all", label="Всё")])))
        st.plotly_chart(fig, use_container_width=True)
        st.caption("Тяни по графику для зума, двойной клик — сброс. Кнопки сверху и "
                   "ползунок снизу меняют период; переключатель таймфрейма — размер свечи.")

# ---------------------------- МАКРО ----------------------------
with tab_macro:
    import macro_features as MF
    outc = MF.meeting_outcomes(con)
    if not outc.empty:
        st.subheader("Заседания ЦБ: ожидание, факт, реакция рынка")
        show = outc.copy()
        show["Дата"] = show["date"].dt.strftime("%d.%m.%Y")
        show["Ожидание"] = show["expected_bp"].map(
            lambda v: "—" if pd.isna(v) else f"{v:+.0f} б.п.")
        show["Факт"] = show["actual_bp"].map(
            lambda v: "—" if v is None or pd.isna(v) else f"{v:+.0f} б.п.")
        show["Сюрприз"] = [MF.surprise_label(e, a)
                           for e, a in zip(outc["expected_bp"], outc["actual_bp"])]
        show["Реакция"] = show["reaction_pct"].map(
            lambda v: "—" if v is None or pd.isna(v) else f"{v:+.2f}%")
        st.dataframe(
            show[["Дата", "cb", "event", "Ожидание", "Факт", "Сюрприз", "Реакция"]]
            .rename(columns={"cb": "ЦБ", "event": "Событие"}),
            use_container_width=True, hide_index=True)
        st.caption("«Ожидание» — консенсус из seed_cb_calendar.csv (ведёшь сам). "
                   "«Факт» и «Реакция» считаются автоматически из истории ставок и цен: "
                   "факт — изменение ставки вокруг заседания, реакция — движение "
                   "инструмента-индикатора ЦБ за несколько дней.")

    st.subheader("Ставки центробанков мира")
    cb = db.read_cb_rates(con)
    if not cb.empty:
        st.dataframe(cb.rename(columns={
            "country": "Страна", "regulator": "Регулятор",
            "rate_name": "Ставка", "rate": "%", "trend": "Тренд",
            "as_of": "На дату"}), use_container_width=True, hide_index=True)

    st.subheader("Макроэкономика США / РФ")
    avail = [s for s in MACRO_NAMES if not db.read_macro(con, s).empty]
    if not avail:
        st.info("Макро не загружено (нужен FRED_API_KEY, либо запусти --demo).")
    else:
        chosen = st.multiselect("Показатели", avail,
                                default=avail[:4],
                                format_func=lambda s: f"{MACRO_NAMES.get(s, s)} ({s})")
        for s in chosen:
            m = db.read_macro(con, s)
            fig = px.line(m, x="date", y="value",
                          title=f"{MACRO_NAMES.get(s, s)}")
            fig.update_layout(template="plotly_white", height=260, margin=dict(l=0, r=0, t=30, b=0))
            st.plotly_chart(fig, use_container_width=True)

# ---------------------------- АНАЛИТИКА ----------------------------
with tab_an:
    st.subheader("Корреляция инструментов (по дневным доходностям)")
    pick = st.multiselect("Что сравнить", syms, default=syms[:min(6, len(syms))],
                          format_func=lambda s: NAMES.get(s, s))
    if len(pick) >= 2:
        wide = {}
        for s in pick:
            d = db.read_prices(con, s).set_index("date")["close"]
            wide[NAMES.get(s, s)] = d
        wide = pd.DataFrame(wide).dropna(how="all")
        corr = A.correlation_matrix(wide)
        fig = px.imshow(corr, text_auto=".2f", color_continuous_scale="RdBu",
                        zmin=-1, zmax=1, aspect="auto")
        fig.update_layout(template="plotly_white", height=460, margin=dict(l=0, r=0, t=10, b=0))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Выбери хотя бы два инструмента.")

# ---------------------------- СЦЕНАРИИ ----------------------------
with tab_fx:
    import models as M
    import macro_features as MF

    st.subheader("Направление и сценарии — в вероятностях, не как точный прогноз")
    s = st.selectbox("Инструмент ", syms, key="fc",
                     format_func=lambda x: f"{NAMES.get(x, x)} ({x})")
    df = db.read_prices(con, s)
    close = df.set_index("date")["close"]
    dxy = db.read_prices(con, "DX-Y.NYB").set_index("date")["close"] \
        if s != "DX-Y.NYB" and not db.read_prices(con, "DX-Y.NYB").empty else None

    # 1) Режим рынка — интерпретируемый контекст
    reg = M.regime(close)
    if reg:
        st.markdown("**Режим рынка**")
        rc = st.columns(len(reg))
        for c, (k, v) in zip(rc, reg.items()):
            c.metric(k, v)

    # 2) Сценарный веер + числовые ответы
    horizon = st.slider("Горизонт, дней", 5, 60, 10)
    fan, summ = M.scenario_paths(close, horizon=horizon)
    if fan is None:
        st.info("Мало истории для сценариев.")
    else:
        m1, m2, m3 = st.columns(3)
        m1.metric("Вероятность роста", f"{summ['p_up']*100:.0f}%",
                  help=f"Доля сценариев, где цена через {horizon} дн. выше сегодняшней")
        m2.metric("Ожидаемое изменение", f"{summ['exp_move_pct']:+.1f}%",
                  help="Медиана сценариев к текущей цене")
        m3.metric("Диапазон 10–90%",
                  f"{summ['lo_pct']:+.1f}% … {summ['hi_pct']:+.1f}%")

        last_date = df["date"].iloc[-1]
        future = pd.bdate_range(last_date, periods=horizon + 1)[1:]
        fig = go.Figure()
        fig.add_scatter(x=df["date"].iloc[-90:], y=close.iloc[-90:],
                        name="Факт", line=dict(color="#2962ff", width=1.8))
        fig.add_scatter(x=future, y=fan["p95"], line=dict(width=0), showlegend=False)
        fig.add_scatter(x=future, y=fan["p05"], name="5–95%", fill="tonexty",
                        line=dict(width=0), fillcolor="rgba(41,98,255,0.10)")
        fig.add_scatter(x=future, y=fan["p75"], line=dict(width=0), showlegend=False)
        fig.add_scatter(x=future, y=fan["p25"], name="25–75%", fill="tonexty",
                        line=dict(width=0), fillcolor="rgba(41,98,255,0.22)")
        fig.add_scatter(x=future, y=fan["p50"], name="Медиана",
                        line=dict(dash="dash", color="#e0344a"))
        fig.add_hline(y=summ["last"], line=dict(color="#94a3b8", dash="dot"))

        # заседания ЦБ: тонкая линия для будущих, точка по сюрпризу для прошлых.
        # подписи НЕ на графике (не наплывают) — они уходят в блок «Риски сценария» ниже
        outc = MF.meeting_outcomes(con)
        window_start = df["date"].iloc[-90]
        col_map = {"ястребиный сюрприз": "#e0344a", "голубиный сюрприз": "#12a15b",
                   "как ожидалось": "#94a3b8", "—": "#2962ff"}
        risks, pp = [], {"x": [], "y": [], "text": [], "color": []}
        for _, e in outc.iterrows():
            d = e["date"]
            if last_date < d <= future[-1]:
                exp = e["expected_bp"]
                fig.add_vline(x=d, line=dict(color="#f59e0b", dash="dot", width=1))
                risks.append((d, e["cb"],
                              "нет консенсуса" if pd.isna(exp) else f"ждут {exp:+.0f} б.п."))
            elif window_start <= d <= last_date:
                near = df.loc[df["date"] <= d, "close"]
                if not near.empty:
                    lab = MF.surprise_label(e["expected_bp"], e["actual_bp"])
                    act = "" if e["actual_bp"] is None or pd.isna(e["actual_bp"]) \
                        else f"{e['actual_bp']:+.0f} б.п. "
                    pp["x"].append(d); pp["y"].append(float(near.iloc[-1]))
                    pp["text"].append(f"{e['cb']}: {act}({lab})")
                    pp["color"].append(col_map.get(lab, "#2962ff"))
        if pp["x"]:
            fig.add_scatter(x=pp["x"], y=pp["y"], mode="markers", name="Заседания ЦБ",
                            text=pp["text"], hoverinfo="text",
                            marker=dict(size=11, color=pp["color"],
                                        line=dict(width=1, color="white")))
        fig.update_layout(template="plotly_white", height=430,
                          margin=dict(l=0, r=0, t=10, b=0), legend=dict(orientation="h"))
        st.plotly_chart(fig, use_container_width=True)

        # ------- НА ЧЁМ ОСНОВАН СЦЕНАРИЙ (факты) -------
        macro_now = MF.macro_features_for(con, s, close.index)
        exp = M.explain_latest(close, dxy, macro_now)
        st.markdown("**На чём основан сценарий сегодня**")
        if exp is None:
            st.caption("Недостаточно истории, чтобы разложить сигнал на факторы.")
        else:
            st.write(f"Модель оценивает вероятность роста завтра в "
                     f"**{exp['p_up']*100:.0f}%**. Ключевые факторы сейчас:")
            drv = exp["drivers"].head(6)
            for _, r in drv.iterrows():
                arrow = "🟢 за рост" if r["contribution"] > 0 else "🔴 против роста"
                st.write(f"- **{r['label']}**: текущее значение {r['value']:.3g} — "
                         f"{arrow} (вклад {r['contribution']:+.2f})")

        # ------- РИСКИ СЦЕНАРИЯ (события) -------
        st.markdown("**Риски сценария — что может его сломать**")
        risk_lines = []
        for d, cb, note in sorted(risks):
            risk_lines.append(f"- {d.strftime('%d.%m')} — заседание {cb} ({note})")
        if reg.get("Волатильность", "").startswith("высок"):
            risk_lines.append("- Повышенная волатильность — фактический разброс шире обычного.")
        if not risk_lines:
            risk_lines.append("- В горизонте нет заседаний ЦБ из календаря; главный риск — "
                              "внешние шоки и данные вне списка.")
        st.markdown("\n".join(risk_lines))

        rc2 = M.event_reaction(close, outc["date"])
        if rc2:
            e1, e2, e3 = st.columns(3)
            e1.metric("Событий в истории", rc2["Событий в истории"])
            e2.metric("|Движение| в день заседания",
                      f"{rc2['Ср. |движение| в день заседания, %']}%")
            e3.metric("|Движение| в обычный день",
                      f"{rc2['Ср. |движение| в обычный день, %']}%")

    st.divider()

    # 3) Направленная модель на признаках + честный скоркард
    st.subheader("Модель направления (след. день) — с проверкой walk-forward")
    use_macro = st.checkbox("Учитывать фундаментал (ставки, инфляция, carry)", value=True)
    macro = MF.macro_features_for(con, s, close.index) if use_macro else None
    if use_macro and (macro is None or macro.empty):
        st.caption("Фундаментальные ряды не загружены — нужен FRED_API_KEY "
                   "или запуск обновления. Модель пока на ценовых признаках.")
    res = M.walk_forward_daily(close, dxy, macro)
    if not res:
        st.info("Мало данных для обучения модели.")
    else:
        sc = res["scorecard"]
        if res["live_p_up"] is not None:
            p = res["live_p_up"]
            st.metric("Текущий сигнал: P(рост завтра)", f"{p*100:.0f}%",
                      help="Живой прогноз модели на последних данных")
        st.dataframe(pd.DataFrame([sc]).T.rename(columns={0: "значение"}),
                     use_container_width=True)
        eq = res["equity"]
        fig2 = go.Figure()
        fig2.add_scatter(x=eq["date"], y=eq["Стратегия"], name="Стратегия (long/flat)")
        fig2.add_scatter(x=eq["date"], y=eq["Buy&Hold"], name="Buy&Hold")
        fig2.update_layout(template="plotly_white", height=300, margin=dict(l=0, r=0, t=10, b=0),
                           legend=dict(orientation="h"),
                           title="Кривая капитала: модель против «купи и держи»")
        st.plotly_chart(fig2, use_container_width=True)
        lvl, txt = M.verdict(sc)
        (st.success if lvl == "ok" else st.warning)(txt)

        # вклад факторов — стандартизованные коэффициенты
        imp = M.feature_importance(close, dxy, macro)
        if imp is not None:
            st.markdown("**Вклад факторов в вероятность роста**")
            top = imp.head(12).iloc[::-1]
            fig3 = go.Figure(go.Bar(
                x=top["coef"], y=top["label"], orientation="h",
                marker_color=["#2ecc71" if c > 0 else "#e74c3c" for c in top["coef"]]))
            fig3.update_layout(template="plotly_white", height=380, margin=dict(l=0, r=0, t=10, b=0),
                               xaxis_title="коэффициент (+ повышает P роста)")
            st.plotly_chart(fig3, use_container_width=True)
            st.caption("Это ассоциации в данных, не причинность. Знаки нестабильны между "
                       "режимами — сверяйся со справочником FACTORS.md и скоркардом.")
