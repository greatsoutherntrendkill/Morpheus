"""Morpheus v4.40.1 — persistent evidence-store location and legacy discovery.

Forecast evidence must outlive a code release.  This module gives every future
Morpheus version a stable, user-level directory for prospective ledgers while
keeping explicit environment-variable overrides backwards compatible.

Default location
----------------
    ~/AllAnalytics_Data/evidence/

Overrides
---------
    ALLANALYTICS_EVIDENCE_DIR=/absolute/or/relative/path
    ALLANALYTICS_DATA_DIR=/base/path             # evidence is stored in /evidence
    ALLANALYTICS_LEGACY_EVIDENCE_DIRS=dir1:dir2  # os.pathsep separated

Exact ledger overrides (handled by the ledger modules) remain supported:
    ALLANALYTICS_FEEDBACK_DB
    ALLANALYTICS_DISTRIBUTION_FEEDBACK_DB
"""
from __future__ import annotations

import os
import hashlib
from datetime import datetime, timezone
from pathlib import Path

VERSION = "persistent-evidence-store-v4.40.1"


def _expand(value: str | os.PathLike | None) -> Path | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return Path(os.path.expandvars(os.path.expanduser(text))).resolve()


def evidence_root() -> Path:
    explicit = _expand(os.getenv("ALLANALYTICS_EVIDENCE_DIR"))
    if explicit is not None:
        root = explicit
    else:
        data_root = _expand(os.getenv("ALLANALYTICS_DATA_DIR"))
        root = (data_root / "evidence") if data_root is not None else (Path.home() / "AllAnalytics_Data" / "evidence")
    root.mkdir(parents=True, exist_ok=True)
    return root


def ledger_path(filename: str) -> Path:
    p = evidence_root() / str(filename)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _candidate_roots(module_file: str | os.PathLike) -> list[Path]:
    """Small, bounded search for previous unpacked Morpheus releases.

    We intentionally do *not* crawl the home directory.  Normal upgrades are
    usually unpacked as sibling release folders, so checking the current release
    parent and cwd parent recovers the previous runtime_cache automatically.
    """
    module_dir = Path(module_file).resolve().parent            # .../mvp
    project_dir = module_dir.parent                            # .../AllAnalytics_vX
    roots: list[Path] = [module_dir / "runtime_cache"]

    for base in (project_dir.parent, Path.cwd().resolve(), Path.cwd().resolve().parent):
        if not base.exists() or not base.is_dir():
            continue
        roots.append(base)
        try:
            for child in base.iterdir():
                if not child.is_dir():
                    continue
                name = child.name.lower()
                if "allanalytics" in name:
                    roots.extend([child / "runtime_cache", child / "mvp" / "runtime_cache"])
        except Exception:
            pass

    extra = os.getenv("ALLANALYTICS_LEGACY_EVIDENCE_DIRS", "")
    for raw in extra.split(os.pathsep):
        p = _expand(raw)
        if p is not None:
            roots.extend([p, p / "runtime_cache", p / "mvp" / "runtime_cache"])

    out: list[Path] = []
    seen: set[str] = set()
    for p in roots:
        try:
            key = str(p.resolve())
        except Exception:
            key = str(p)
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def legacy_db_candidates(module_file: str | os.PathLike, legacy_filename: str, target: str | os.PathLike | None = None) -> list[Path]:
    target_resolved = Path(target).resolve() if target else None
    candidates: list[Path] = []
    seen: set[str] = set()
    for root in _candidate_roots(module_file):
        if root.is_file():
            items = [root] if root.name == legacy_filename else []
        else:
            items = [root / legacy_filename]
        for p in items:
            try:
                rp = p.resolve()
            except Exception:
                rp = p
            if target_resolved is not None and rp == target_resolved:
                continue
            key = str(rp)
            if key in seen or not p.exists() or not p.is_file():
                continue
            seen.add(key)
            candidates.append(p)
    # Older/larger databases first is not necessarily best; deterministic newest
    # first makes migration prefer the most recently active release while INSERT
    # OR IGNORE keeps all distinct immutable forecasts from every candidate.
    return sorted(candidates, key=lambda p: (p.stat().st_mtime if p.exists() else 0, str(p)), reverse=True)



def source_fingerprint(path: str | os.PathLike) -> tuple[str, str]:
    p = Path(path)
    try:
        st = p.stat()
        value = f"{st.st_size}:{st.st_mtime_ns}"
    except Exception:
        value = "unknown"
    key = hashlib.sha256(str(p.resolve()).encode("utf-8")).hexdigest()[:20]
    return key, value

def store_status() -> dict:
    root = evidence_root()
    try:
        writable_test = root / ".write_test"
        writable_test.write_text(datetime.now(timezone.utc).isoformat(), encoding="utf-8")
        writable_test.unlink(missing_ok=True)
        writable = True
    except Exception:
        writable = False
    return {
        "version": VERSION,
        "root": str(root),
        "persistent": True,
        "writable": writable,
        "exact_ledger_overrides": {
            "directional": bool(os.getenv("ALLANALYTICS_FEEDBACK_DB")),
            "distribution": bool(os.getenv("ALLANALYTICS_DISTRIBUTION_FEEDBACK_DB")),
        },
    }
