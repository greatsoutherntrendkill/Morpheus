"""
political.py — политические/геополитические риски.
Список событий редактируемый (seed_political.csv); влияние на КАЖДЫЙ актив
оценивается независимо: severity события × чувствительность категории актива ->
балл 1..5 и направление (риск для цены вверх/вниз). Позже сюда можно подключить
новостной API вместо ручного сида.
"""
import pandas as pd
import config as C

# категория события -> {категория актива: (вес 0..1, направление для этого актива)}
# направление: +1 событие толкает цену вверх (напр. золото в risk-off), -1 вниз
SENS = {
    "war": {"Сырьё": (0.9, +1), "Крипто": (0.5, -1), "Индексы": (0.6, -1),
            "Фьючерсы": (0.6, -1), "Валюты": (0.4, -1), "Индексы РФ": (0.7, -1)},
    "sanctions": {"Валюты": (0.7, -1), "Индексы РФ": (0.9, -1),
                  "Индексы": (0.2, -1), "Сырьё": (0.3, +1)},
    "trade": {"Валюты": (0.7, -1), "Индексы": (0.6, -1), "Фьючерсы": (0.6, -1),
              "Крипто": (0.3, -1), "Сырьё": (0.3, +1)},
    "corporate": {"Индексы": (0.4, -1), "Фьючерсы": (0.4, -1), "Крипто": (0.3, -1)},
    "other": {"Индексы": (0.3, -1), "Крипто": (0.3, -1), "Сырьё": (0.3, +1)},
}
CAT_RU = {"war": "война/конфликт", "sanctions": "санкции", "trade": "торговые войны",
          "corporate": "корпоративные", "other": "прочее"}


def load_events() -> pd.DataFrame:
    try:
        return pd.read_csv(C.POLITICAL_SEED)
    except Exception:
        return pd.DataFrame(columns=["title", "category", "severity", "note", "date"])


def _norm(cat):
    return "Индексы" if (cat.startswith("Индексы") and cat != "Индексы РФ") else cat


def impact_for(asset_cat: str, events: pd.DataFrame) -> list:
    asset_cat = _norm(asset_cat)
    out = []
    for _, e in events.iterrows():
        w, d = SENS.get(e["category"], {}).get(asset_cat, (0, 0))
        if w <= 0:
            continue
        imp = int(min(5, max(1, round(float(e["severity"]) * w))))
        out.append({"title": e["title"], "category": CAT_RU.get(e["category"], e["category"]),
                    "severity": int(e["severity"]), "impact": imp, "direction": int(d),
                    "note": e.get("note", "") if isinstance(e.get("note", ""), str) else ""})
    out.sort(key=lambda x: -x["impact"])
    return out


def score(asset_cat: str, events: pd.DataFrame) -> float:
    imp = impact_for(asset_cat, events)
    if not imp:
        return 0.0
    s = sum(x["direction"] * x["impact"] for x in imp)
    return max(-1.0, min(1.0, s / 10.0))
