"""
indicators.py — альтернативные стратегии тех-анализа (индикаторы) и итоговый вывод.
Считается из OHLC. Даёт наложения для графика (MA, полосы Боллинджера) и сигналы
по двум стратегиям: трендовая (MA+MACD+RSI) и возврат к среднему (Боллинджер+RSI).
combined_verdict() соединяет тех-сигнал и макро в один вывод по активу.
"""
import numpy as np
import pandas as pd


def _ma(s, n): return s.rolling(n).mean()
def _ema(s, n): return s.ewm(span=n, adjust=False).mean()


def _rsi(s, n=14):
    d = s.diff()
    up = d.clip(lower=0).rolling(n).mean()
    dn = (-d.clip(upper=0)).rolling(n).mean()
    rs = up / dn.replace(0, np.nan)
    return 100 - 100 / (1 + rs)


def _macd(s, f=12, sl=26, sig=9):
    line = _ema(s, f) - _ema(s, sl)
    signal = _ema(line, sig)
    return line, signal, line - signal


def _boll(s, n=20, k=2):
    m = s.rolling(n).mean()
    sd = s.rolling(n).std()
    return m + k * sd, m, m - k * sd


def _last(x):
    return None if x.empty or pd.isna(x.iloc[-1]) else round(float(x.iloc[-1]), 4)


def analyze(df):
    """Возвращает последние значения, ряды для графика и сигналы двух стратегий."""
    if df.empty or len(df) < 30:
        return None
    c = df["close"]
    price = float(c.iloc[-1])
    ma20, ma50, ma200 = _ma(c, 20), _ma(c, 50), _ma(c, 200)
    up, mid, dn = _boll(c)
    r = _rsi(c)
    ml, ms, mh = _macd(c)

    dates = df["date"].dt.strftime("%Y-%m-%d").tolist()

    def series(s):
        return [None if pd.isna(v) else round(float(v), 4) for v in s]

    out = {
        "last": {"ma20": _last(ma20), "ma50": _last(ma50), "ma200": _last(ma200),
                 "rsi": _last(r), "macd_hist": _last(mh),
                 "boll_up": _last(up), "boll_mid": _last(mid), "boll_dn": _last(dn)},
        "series": {"dates": dates, "ma20": series(ma20), "ma50": series(ma50),
                   "ma200": series(ma200), "boll_up": series(up),
                   "boll_mid": series(mid), "boll_dn": series(dn)},
    }

    # --- стратегия «Индикаторы» (тренд + моментум) ---
    reasons, score = [], 0
    m50, m200 = ma50.iloc[-1], ma200.iloc[-1]
    if pd.notna(m50) and pd.notna(m200):
        if price > m50 > m200:
            score += 1; reasons.append("цена выше MA50 и MA200 — восходящий тренд")
        elif price < m50 < m200:
            score -= 1; reasons.append("цена ниже MA50 и MA200 — нисходящий тренд")
        else:
            reasons.append("средние переплетены — тренд неясен")
    if pd.notna(mh.iloc[-1]):
        if mh.iloc[-1] > 0:
            score += 1; reasons.append("MACD-гистограмма положительна — импульс вверх")
        else:
            score -= 1; reasons.append("MACD-гистограмма отрицательна — импульс вниз")
    if pd.notna(r.iloc[-1]):
        if r.iloc[-1] > 70:
            reasons.append(f"RSI {r.iloc[-1]:.0f} — перекупленность")
        elif r.iloc[-1] < 30:
            reasons.append(f"RSI {r.iloc[-1]:.0f} — перепроданность")
    ind_label = "бычий" if score >= 2 else "медвежий" if score <= -2 else "нейтральный"

    # --- стратегия «Боллинджер» (возврат к среднему) ---
    breasons = []
    u, d, mmid = up.iloc[-1], dn.iloc[-1], mid.iloc[-1]
    if pd.notna(u) and pd.notna(d):
        if price <= d:
            boll_label = "отскок вверх"
            breasons.append("цена у нижней полосы — перепродана, ожидается возврат к середине")
        elif price >= u:
            boll_label = "откат вниз"
            breasons.append("цена у верхней полосы — перекуплена, ожидается возврат к середине")
        else:
            pos = (price - d) / (u - d) if u > d else 0.5
            boll_label = "к середине"
            breasons.append(f"цена внутри канала ({pos*100:.0f}% ширины), тяготеет к MA20 {mmid:.2f}")
    else:
        boll_label, breasons = "нейтральный", ["недостаточно данных для полос"]

    out["signals"] = {
        "ind": {"label": ind_label, "score": score, "reasons": reasons},
        "boll": {"label": boll_label, "reasons": breasons},
    }
    return out


def _sign_label(x, up="за рост", dn="за падение", zero="нейтрально"):
    return up if x > 0.12 else dn if x < -0.12 else zero


def combined_verdict(smc_bias, ind_signal, macro_net, p_up, exp_move, lo, hi,
                     political_score=0.0):
    """Симбиоз: тех-анализ (SMC + индикаторы) × макро × политика -> один вывод."""
    ta_score = {"bull": 0.6, "bear": -0.6, "range": 0.0}.get(smc_bias, 0.0)
    ta_score += {"бычий": 0.4, "медвежий": -0.4}.get(ind_signal, 0.0)
    ta_score = max(-1, min(1, ta_score))
    macro_score = float(np.tanh(macro_net * 3))          # net вклад -> [-1,1]
    pol = max(-1.0, min(1.0, float(political_score)))
    combined = 0.45 * ta_score + 0.35 * macro_score + 0.20 * pol

    ta_label = _sign_label(ta_score, "за рост", "за падение")
    macro_label = _sign_label(macro_score)
    pol_label = _sign_label(pol, "поддержка", "давление", "нейтрально")
    if combined > 0.15:
        concl = "скорее рост"
    elif combined < -0.15:
        concl = "скорее падение"
    else:
        concl = "боковое движение"
    return {
        "ta_label": ta_label, "ta_score": round(ta_score, 2),
        "macro_label": macro_label, "macro_score": round(macro_score, 2),
        "pol_label": pol_label, "pol_score": round(pol, 2),
        "combined": round(combined, 2), "conclusion": concl,
        "p_up": p_up, "exp_move": exp_move, "range": [lo, hi],
    }
