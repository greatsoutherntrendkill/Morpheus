# Morpheus v4.25 — Technical Terminal Market Bridge

## Root causes fixed

1. Technical Lab API validated symbols only against static `site/data.json`, while the new US/MOEX equities were injected only in the browser. New equities therefore failed with HTTP 404 before market-data retrieval.
2. The Markets page used the resilient MOEX419 transport, while Technical Lab daily/intraday history still used older MOEX/Yahoo paths.
3. Technical Lab derived its displayed price from chart candles instead of the fast live quote route.
4. Daily chart cache was keyed only by `(symbol, interval)`, so a short window could be reused for a longer selected period.
5. Russian intraday equities were not routed through a dedicated MOEX shares/TQBR candles path.

## v4.25 architecture

- One canonical server-side market universe shared by Markets and Technical Lab.
- `/api/terminal/quote` provides a selected-instrument live quote without waiting for the global quote universe.
- Russian shares use MOEX419/TQBR for live data and history.
- Russian indices use MOEX419/SNDX.
- Daily terminal charts use resilient MOEX candles, with official board-history fallback.
- Intraday Russian shares and indices use the same VPN-resilient MOEX419 transport.
- 5-minute MOEX bars are built from official 1-minute bars.
- `/api/chart/history` and `/api/forecast/short` now accept the expanded equity universe.
- Equity forecast horizons support 1, 3, 5, 10, 20 and 30 days.
- Daily chart cache includes selected period to prevent short-history cache poisoning.
- Technical Lab header prefers the dedicated live quote over the last chart close.

## Scope

No M&A/IPO/news/valuation data was modified.
