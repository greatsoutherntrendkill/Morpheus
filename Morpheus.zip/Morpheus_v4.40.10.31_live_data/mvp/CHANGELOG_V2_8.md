# v2.8 — Purged validation foundation

- Fixed multi-horizon label leakage in walk-forward validation.
- Added `label_end_date` and point-in-time legal training sets.
- Baseline now uses the same legal information set as the model.
- Added explicit validation metadata to 1/5/10/20D model outputs.
- Added anti-leakage smoke tests.
- UI now displays `Purged walk-forward` and labels OOS observations as raw pending the next overlapping-target fix.
- Added `MODEL_ROADMAP.md` with staged validation/data/model roadmap.
