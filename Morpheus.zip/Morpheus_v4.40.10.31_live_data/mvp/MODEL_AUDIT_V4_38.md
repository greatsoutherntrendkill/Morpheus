# Model audit — v4.38

## Что именно улучшает v4.38
Предыдущая архитектура использовала сильное универсальное ядро. v4.38 добавляет специализацию: FX не должен получать ровно тот же feature recipe, что акция или криптоактив.

## Защита от переобучения
1. Specialist использует только point-in-time исторические признаки.
2. Target имеет neutral band, поэтому микрошум не маркируется как полноценный рост/падение.
3. Development split строго упорядочен по времени: train → selection → calibration → evaluation.
4. Алгоритм выбирается до untouched evaluation.
5. Слабый/отрицательный development skill сжимает вероятность к 50%.
6. Cross-sectional equity features строятся только по реально кэшированным историям других акций. Недостающие peer-data не синтезируются.
7. Specialist остаётся challenger и получает live-вес только после v4.37 paired prospective guard + human approval.
8. Automatic champion promotion остаётся запрещённым.

## Cross-sectional equities
В первой сессии истории всех акций могут ещё не быть локально. В этом случае интерфейс честно показывает недостаток peer sample. По мере обычной работы раздела Markets истории акций попадают в cache и реальный ranking становится доступнее без отдельного тяжёлого startup-запроса.

## Что версия не утверждает
v4.38 не утверждает, что specialist уже доказанно точнее общего ансамбля. Его преимущество должно быть подтверждено на будущих закрытых prospective forecasts. До этого его вес — 0.

## Validation
- `pytest -q`: 94 passed.
- `python -m py_compile`: пройден для новых/изменённых Python модулей.
- `node --check`: пройден для активных inline scripts `index.html` и `technical_lab_v411.html`.
- Полноценный внешний provider smoke-test в этой контейнерной среде не заявляется: он зависит от установленного runtime и сетевого доступа пользователя.
