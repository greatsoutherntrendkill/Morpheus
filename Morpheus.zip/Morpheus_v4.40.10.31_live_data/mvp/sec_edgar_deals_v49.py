
"""Morpheus v4.9 — SEC EDGAR Deals / IPO provider.

Только официальный SEC EDGAR:
- квартальные master.zip индексы для discovery;
- SEC Archives filing text для детализации;
- никакие демонстрационные сделки в live-список не подмешиваются.

Важно: SEC не требует API key. Для автоматического доступа нужен корректный
declared User-Agent с контактным e-mail. Укажите SEC_USER_AGENT в .env, например:
SEC_USER_AGENT=Morpheus Research your-email@example.com

Архитектура намеренно двухступенчатая:
1) index sync — быстро индексируем только релевантные формы;
2) lazy enrichment — подробности конкретной сделки парсятся только для строк,
   которые реально показываются пользователю / открываются в интерфейсе.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import html as html_lib
import io
import json
import os
import re
import sqlite3
import threading
import time
import urllib.error
import urllib.request
import urllib.parse
import zipfile
import requests
from pathlib import Path
from typing import Any

ROOT=Path(__file__).parent
DB_PATH=ROOT/"sec_deals.db"

MNA_EXPLICIT={"DEFM14A","PREM14A"}
MNA_CONFIRM={"S-4","S-4/A","F-4","F-4/A","SC TO-T","SC TO-T/A","SC 14D9","SC 14D9/A"}
MNA_FORMS=MNA_EXPLICIT|MNA_CONFIRM
IPO_FORMS={"424B4"}

SYNC_LOCK=threading.Lock()
HISTORY_THREAD=None
RATE_LOCK=threading.Lock()
LAST_REQUEST_AT=0.0
MAX_RPS=4.0  # below SEC 10 req/s cap; extra headroom for retries
LAST_ERROR=None
LAST_OK=None
SESSION=requests.Session()

MONEY_RE=re.compile(r"\$\s*([\d,.]+)\s*(billion|million|bn|mm)?",re.I)
PER_SHARE_RE=[
    re.compile(r"(?:cash consideration|merger consideration|purchase price|offer price)[^.$]{0,90}\$\s*([\d,.]+)\s+per\s+share",re.I),
    re.compile(r"\$\s*([\d,.]+)\s+per\s+share",re.I),
]
VALUE_PATTERNS=[
    re.compile(r"(?:transaction|deal|enterprise|equity)\s+value[^$]{0,90}\$\s*([\d,.]+)\s*(billion|million|bn|mm)?",re.I),
    re.compile(r"(?:valued at|aggregate consideration of|purchase price of)[^$]{0,90}\$\s*([\d,.]+)\s*(billion|million|bn|mm)?",re.I),
]
SHARES_RE=[
    re.compile(r"(?:offering|offer)\s+(?:of\s+)?([\d,.]+)\s+(?:shares|ordinary shares|common shares)",re.I),
    re.compile(r"([\d,.]+)\s+shares[^.]{0,80}(?:initial public offering|public offering)",re.I),
]
IPO_PRICE_RE=[
    re.compile(r"initial public offering price[^$]{0,80}\$\s*([\d,.]+)",re.I),
    re.compile(r"public offering price[^$]{0,40}\$\s*([\d,.]+)",re.I),
    re.compile(r"price to the public[^$]{0,40}\$\s*([\d,.]+)",re.I),
]
TICKER_RE=[
    re.compile(r"(?:Nasdaq|NYSE|New York Stock Exchange)[^.]{0,160}(?:symbol|ticker symbol)\s*[“\"']?([A-Z][A-Z0-9.\-]{0,7})",re.I),
    re.compile(r"(?:symbol|ticker symbol)\s*[“\"']([A-Z][A-Z0-9.\-]{0,7})[”\"']",re.I),
]


def _conn():
    con=sqlite3.connect(DB_PATH,timeout=30)
    con.row_factory=sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript("""
    CREATE TABLE IF NOT EXISTS sec_index_quarters(
      year INTEGER NOT NULL,
      quarter INTEGER NOT NULL,
      synced_at TEXT NOT NULL,
      candidate_count INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY(year,quarter)
    );
    CREATE TABLE IF NOT EXISTS sec_filings(
      accession TEXT PRIMARY KEY,
      cik TEXT,
      company TEXT,
      form TEXT,
      filed_date TEXT,
      archive_path TEXT,
      filing_url TEXT,
      kind TEXT,
      explicit INTEGER NOT NULL DEFAULT 0,
      verified INTEGER NOT NULL DEFAULT 0,
      detail_json TEXT,
      detail_fetched_at TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sec_filings_kind_date ON sec_filings(kind,filed_date DESC);
    CREATE INDEX IF NOT EXISTS idx_sec_filings_cik_date ON sec_filings(cik,filed_date DESC);
    """)
    return con


def configured()->bool:
    ua=(os.getenv("SEC_USER_AGENT") or "").strip()
    return bool(ua and "@" in ua and "example.com" not in ua and "your-email" not in ua)


def status()->dict[str,Any]:
    con=_conn()
    try:
        q=con.execute("SELECT COUNT(*) n, MIN(year) mn, MAX(year) mx FROM sec_index_quarters").fetchone()
        counts={r["kind"]:r["n"] for r in con.execute("SELECT kind,COUNT(*) n FROM sec_filings GROUP BY kind")}
    finally:
        con.close()
    return {
      "version":"4.9",
      "provider":"SEC EDGAR",
      "configured":configured(),
      "api_key_required":False,
      "requires_declared_user_agent":True,
      "indexed_quarters":int(q["n"] or 0),
      "indexed_from":q["mn"],
      "indexed_to":q["mx"],
      "filings":counts,
      "history_sync_running":bool(HISTORY_THREAD and HISTORY_THREAD.is_alive()),
      "last_ok":LAST_OK,
      "last_error":LAST_ERROR,
      "note":(
        "SEC EDGAR подключён. Сделки и IPO в интерфейсе берутся только из SEC."
        if configured()
        else "SEC EDGAR не требует ключа. Укажите SEC_USER_AGENT с вашим контактным e-mail в .env."
      ),
    }


def _headers()->dict[str,str]:
    ua=(os.getenv("SEC_USER_AGENT") or "").strip()
    if not configured():
        raise RuntimeError("SEC_USER_AGENT is not configured")
    # Do not set Host manually. requests derives it from the URL and transparently
    # handles gzip/deflate responses, which urllib did not do in v4.9.
    return {
        "User-Agent":ua,
        "Accept-Encoding":"gzip, deflate",
        "Accept":"*/*",
        "Connection":"keep-alive",
    }


def _throttle():
    global LAST_REQUEST_AT
    with RATE_LOCK:
        now=time.monotonic()
        wait=(1.0/MAX_RPS)-(now-LAST_REQUEST_AT)
        if wait>0:
            time.sleep(wait)
        LAST_REQUEST_AT=time.monotonic()


def _get_bytes(url:str,timeout:int=30)->bytes:
    global LAST_ERROR,LAST_OK
    headers=_headers()
    last=None
    for attempt in range(4):
        _throttle()
        try:
            r=SESSION.get(url,headers=headers,timeout=timeout,allow_redirects=True)
            if r.status_code==200:
                LAST_OK={
                    "url":url,
                    "status":200,
                    "at":dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                    "bytes":len(r.content),
                }
                LAST_ERROR=None
                return r.content
            msg=f"HTTP {r.status_code}"
            if r.status_code in {403,429,500,502,503,504}:
                last=RuntimeError(msg)
                LAST_ERROR={
                    "url":url,
                    "status":r.status_code,
                    "at":dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                    "message":msg,
                }
                time.sleep(min(8,1.2*(2**attempt)))
                continue
            r.raise_for_status()
        except Exception as exc:
            last=exc
            LAST_ERROR={
                "url":url,
                "status":getattr(getattr(exc,"response",None),"status_code",None),
                "at":dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                "message":type(exc).__name__+": "+str(exc)[:180],
            }
            time.sleep(min(8,1.2*(2**attempt)))
    raise last or RuntimeError("SEC request failed")


def _get_text(url:str,timeout:int=30)->str:
    b=_get_bytes(url,timeout)
    return b.decode("utf-8","ignore")


def diagnostic()->dict[str,Any]:
    """Small live connectivity check against the current SEC quarterly index."""
    today=dt.date.today()
    y,q=_quarter_for_date(today)
    urls=[
        f"https://www.sec.gov/Archives/edgar/full-index/{y}/QTR{q}/master.idx",
        f"https://www.sec.gov/Archives/edgar/full-index/{y}/QTR{q}/master.zip",
    ]
    if not configured():
        return {"ok":False,"configured":False,"message":"SEC_USER_AGENT не настроен"}
    errors=[]
    for u in urls:
        try:
            b=_get_bytes(u,20)
            return {
                "ok":True,"configured":True,"url":u,
                "bytes":len(b),"message":"SEC EDGAR доступен",
            }
        except Exception as exc:
            errors.append({"url":u,"error":type(exc).__name__,"message":str(exc)[:160]})
    return {"ok":False,"configured":True,"errors":errors,"last_error":LAST_ERROR}

def _quarter_for_date(d:dt.date)->tuple[int,int]:
    return d.year,(d.month-1)//3+1


def _quarters_between(start:dt.date,end:dt.date)->list[tuple[int,int]]:
    y,q=_quarter_for_date(start); ey,eq=_quarter_for_date(end)
    out=[]
    while (y,q)<=(ey,eq):
        out.append((y,q))
        q+=1
        if q==5:
            y+=1;q=1
    return out


def _accession_from_path(path:str)->str:
    name=path.rsplit("/",1)[-1]
    return name[:-4] if name.lower().endswith(".txt") else name


def _parse_master_idx(text:str)->list[dict[str,str]]:
    rows=[]
    start=False
    for line in text.splitlines():
        if not start:
            if line.startswith("-----"):
                start=True
            continue
        parts=line.split("|")
        if len(parts)!=5:
            continue
        cik,company,form,filed,path=[x.strip() for x in parts]
        if form not in MNA_FORMS and form not in IPO_FORMS:
            continue
        kind="mna" if form in MNA_FORMS else "ipo"
        rows.append({
            "cik":cik,"company":company,"form":form,"filed_date":filed,
            "archive_path":path,"accession":_accession_from_path(path),"kind":kind,
            "explicit":1 if form in MNA_EXPLICIT else 0,
        })
    return rows


def sync_quarter(year:int,quarter:int,force:bool=False)->dict[str,Any]:
    if year<1994 or quarter not in {1,2,3,4}:
        raise ValueError("invalid SEC quarter")
    con=_conn()
    try:
        hit=con.execute("SELECT * FROM sec_index_quarters WHERE year=? AND quarter=?",(year,quarter)).fetchone()
        if hit and not force:
            return {"year":year,"quarter":quarter,"cached":True,"candidates":hit["candidate_count"]}
    finally:
        con.close()

    zip_url=f"https://www.sec.gov/Archives/edgar/full-index/{year}/QTR{quarter}/master.zip"
    idx_url=f"https://www.sec.gov/Archives/edgar/full-index/{year}/QTR{quarter}/master.idx"
    text=None
    zip_error=None
    try:
        raw=_get_bytes(zip_url,45)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            name=next(n for n in z.namelist() if n.lower().endswith("master.idx"))
            text=z.read(name).decode("latin-1","ignore")
    except Exception as exc:
        zip_error=exc
    if text is None:
        try:
            text=_get_text(idx_url,45)
        except Exception:
            if zip_error:
                raise zip_error
            raise
    rows=_parse_master_idx(text)
    now=dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    con=_conn()
    try:
        for r in rows:
            url2="https://www.sec.gov/Archives/"+r["archive_path"].replace("\\","/")
            con.execute("""
              INSERT INTO sec_filings(accession,cik,company,form,filed_date,archive_path,filing_url,kind,explicit,verified,created_at)
              VALUES(?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(accession) DO UPDATE SET
                cik=excluded.cik,company=excluded.company,form=excluded.form,filed_date=excluded.filed_date,
                archive_path=excluded.archive_path,filing_url=excluded.filing_url,kind=excluded.kind,explicit=excluded.explicit
            """,(r["accession"],r["cik"],r["company"],r["form"],r["filed_date"],r["archive_path"],url2,r["kind"],r["explicit"],r["explicit"],now))
        con.execute("""
          INSERT INTO sec_index_quarters(year,quarter,synced_at,candidate_count) VALUES(?,?,?,?)
          ON CONFLICT(year,quarter) DO UPDATE SET synced_at=excluded.synced_at,candidate_count=excluded.candidate_count
        """,(year,quarter,now,len(rows)))
        con.commit()
    finally:
        con.close()
    return {"year":year,"quarter":quarter,"cached":False,"candidates":len(rows)}


def _sync_quarters(qs:list[tuple[int,int]],force:bool=False,stop_on_error:bool=False):
    out=[]
    for y,q in qs:
        try:
            out.append(sync_quarter(y,q,force))
        except Exception as e:
            out.append({"year":y,"quarter":q,"error":type(e).__name__})
            if stop_on_error:
                break
    return out


def ensure_range(range_id:str)->dict[str,Any]:
    today=dt.date.today()
    if range_id=="latest":
        y,q=_quarter_for_date(today)
        qs=[(y,q)]
        # At the very start of a quarter also index previous quarter.
        if today.day<=10 and today.month in {1,4,7,10}:
            prev=today-dt.timedelta(days=15)
            qs.insert(0,_quarter_for_date(prev))
        return {"mode":"sync","results":_sync_quarters(qs)}
    if range_id=="1y":
        start=today-dt.timedelta(days=370)
        return {"mode":"sync","results":_sync_quarters(_quarters_between(start,today))}
    if range_id=="2000":
        start=dt.date(2000,1,1)
        qs=_quarters_between(start,today)
        _start_history_sync(qs)
        return {"mode":"background","quarters":len(qs)}
    raise ValueError("range must be latest, 1y or 2000")


def _history_worker(qs):
    with SYNC_LOCK:
        _sync_quarters(qs)


def _start_history_sync(qs):
    global HISTORY_THREAD
    if HISTORY_THREAD and HISTORY_THREAD.is_alive():
        return
    HISTORY_THREAD=threading.Thread(target=_history_worker,args=(qs,),daemon=True,name="sec-history-sync")
    HISTORY_THREAD.start()


def _strip_sec_text(raw:str)->str:
    # Keep textual content, but collapse SEC/XHTML noise.
    raw=re.sub(r"(?is)<script.*?</script>|<style.*?</style>"," ",raw)
    raw=re.sub(r"(?is)<[^>]+>"," ",raw)
    raw=html_lib.unescape(raw)
    raw=re.sub(r"\s+"," ",raw)
    return raw.strip()


def _to_number(s:str)->float|None:
    try:
        return float(str(s).replace(",",""))
    except Exception:
        return None


def _money_value(num_s:str,scale:str|None)->float|None:
    v=_to_number(num_s)
    if v is None:return None
    sc=(scale or "").lower()
    if sc in {"billion","bn"}:v*=1_000_000_000
    elif sc in {"million","mm"}:v*=1_000_000
    return v


def _sentence(text:str,pos:int,window:int=320)->str:
    a=max(0,pos-window);b=min(len(text),pos+window)
    s=text[a:b]
    # trim to rough sentence boundaries
    l=max(s.rfind(". ",0,window),s.rfind("; ",0,window))
    if l>=0:s=s[l+2:]
    r=min([x for x in [s.find(". ",window),s.find("; ",window)] if x>=0] or [len(s)])
    return s[:r].strip()


def _extract_value(text:str)->float|None:
    for pat in VALUE_PATTERNS:
        m=pat.search(text)
        if m:
            return _money_value(m.group(1),m.group(2))
    return None


def _extract_per_share(text:str)->float|None:
    for pat in PER_SHARE_RE:
        m=pat.search(text)
        if m:
            return _to_number(m.group(1))
    return None


def _extract_counterparty(text:str,issuer:str)->str|None:
    """Extract only names that look like legal entities and occur near deal language.

    v4.10 deliberately rejects phrase fragments such as
    "PubCo due to forfeiture" / "service providers of ..." that the older loose
    regex could mistake for company names.
    """
    suffix=r"(?:Inc\.?|Incorporated|Corporation|Corp\.?|Company|Co\.?|LLC|L\.L\.C\.|Ltd\.?|Limited|PLC|plc|Holdings(?:,\s*Inc\.?)?|Group(?:,\s*Inc\.?)?|N\.V\.|S\.A\.|AG|SE)"
    entity=re.compile(rf"\b([A-Z][A-Za-z0-9&'’.\-/]*(?:[\s,]+[A-Z][A-Za-z0-9&'’.\-/]*){{0,8}}[\s,]+{suffix})\b")
    bad=("service providers","due to forfeiture","the company","public company accounting",
         "exchange agent","transfer agent","merger consideration")
    anchors=list(re.finditer(r"agreement and plan of merger|business combination agreement|merger agreement|tender offer|proposed merger|proposed acquisition",text,re.I))
    windows=[text[max(0,a.start()-700):min(len(text),a.end()+2200)] for a in anchors[:12]]
    if not windows:windows=[text[:5000]]
    for w in windows:
        for m in entity.finditer(w):
            x=re.sub(r"\s+"," ",m.group(1)).strip(" ,.;:-")
            low=x.lower()
            if low==issuer.lower() or any(b in low for b in bad):
                continue
            return x
    return None


def _extract_ticker(text:str)->str|None:
    for p in TICKER_RE:
        m=p.search(text)
        if m:return m.group(1).upper()
    return None


def _extract_exchange(text:str)->str|None:
    if re.search(r"\bNasdaq\b",text,re.I):return "Nasdaq"
    if re.search(r"New York Stock Exchange|\bNYSE\b",text,re.I):return "NYSE"
    return None


def _extract_shares(text:str)->float|None:
    for p in SHARES_RE:
        m=p.search(text)
        if m:
            v=_to_number(m.group(1))
            if v is not None:return v
    return None


def _extract_ipo_price(text:str)->float|None:
    for p in IPO_PRICE_RE:
        m=p.search(text)
        if m:
            return _to_number(m.group(1))
    return None


def _is_mna(text:str,form:str)->bool:
    if form in MNA_EXPLICIT:
        return True
    pat=re.compile(r"agreement and plan of merger|merger agreement|business combination agreement|tender offer|acquisition of",re.I)
    for m in pat.finditer(text):
        prefix=text[max(0,m.start()-140):m.start()].lower()
        sentence_start=max(prefix.rfind(". "),prefix.rfind("; "))
        clause=prefix[sentence_start+2:] if sentence_start>=0 else prefix
        if re.search(r"\b(?:no|not|without)\b",clause) or re.search(r"(?:does not|is not)\s",clause):
            continue
        return True
    return False


def _is_ipo(text:str)->bool:
    # Prevent 424B4 follow-ons / resale prospectuses from appearing as IPOs.
    pat=re.compile(r"\binitial public offering\b",re.I)
    for m in pat.finditer(text):
        prefix=text[max(0,m.start()-60):m.start()].lower()
        if re.search(r"\b(?:not|no|without)\b",prefix):
            continue
        return True
    return False


def _parse_detail(row:sqlite3.Row,raw:str)->dict[str,Any]:
    text=_strip_sec_text(raw)
    excerpt=text[:900]
    form=row["form"];kind=row["kind"]
    common={
      "accession":row["accession"],"kind":kind,"date":row["filed_date"],
      "company":row["company"],"cik":row["cik"],"form":form,
      "sec_url":row["filing_url"],"source":"SEC EDGAR",
      "source_note":f"SEC EDGAR · форма {form} · {row['filed_date']}",
    }
    if kind=="mna":
        verified=_is_mna(text,form)
        value=_extract_value(text)
        per_share=_extract_per_share(text)
        counterparty=_extract_counterparty(text,row["company"])
        status=(
          "definitive proxy" if form=="DEFM14A" else
          "preliminary proxy" if form=="PREM14A" else
          "registration / business combination" if form.startswith(("S-4","F-4")) else
          "tender offer" if form.startswith("SC TO") else
          "M&A filing"
        )
        return {**common,
          "verified":verified,"issuer":row["company"],"counterparty":counterparty,
          "headline_value":value,"per_share":per_share,"status":status,
          "summary":(
            f"SEC зарегистрировала {form}, относящуюся к слиянию или приобретению. "
            "Поля справа показываются только если они прямо извлечены из документа."
          ),
          "excerpt":excerpt,
        }
    verified=_is_ipo(text)
    price=_extract_ipo_price(text)
    shares=_extract_shares(text)
    ticker=_extract_ticker(text)
    exchange=_extract_exchange(text)
    proceeds=(price*shares) if price is not None and shares is not None else None
    return {**common,
      "verified":verified,"company":row["company"],"ticker":ticker,"exchange":exchange,
      "offer_price":price,"shares_offered":shares,"gross_proceeds":proceeds,
      "status":"final prospectus" if form=="424B4" else "IPO filing",
      "summary":"Финальный проспект SEC. В интерфейс попадает только документ, в котором прямо найдено указание на initial public offering.",
      "excerpt":excerpt,
    }


def enrich_accession(accession:str,force:bool=False)->dict[str,Any]:
    con=_conn()
    try:
        row=con.execute("SELECT * FROM sec_filings WHERE accession=?",(accession,)).fetchone()
        if not row:
            raise KeyError(accession)
        if row["detail_json"] and not force:
            return json.loads(row["detail_json"])
    finally:
        con.close()
    raw=_get_text(row["filing_url"],45)
    detail=_parse_detail(row,raw)
    now=dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    con=_conn()
    try:
        con.execute("UPDATE sec_filings SET detail_json=?,detail_fetched_at=?,verified=? WHERE accession=?",
                    (json.dumps(detail,ensure_ascii=False),now,1 if detail.get("verified") else 0,accession))
        con.commit()
    finally:
        con.close()
    return detail


def _date_start(range_id:str)->str:
    today=dt.date.today()
    if range_id=="latest":return (today-dt.timedelta(days=120)).isoformat()
    if range_id=="1y":return (today-dt.timedelta(days=370)).isoformat()
    return "2000-01-01"


def _candidate_rows(kind:str,range_id:str,limit:int,offset:int)->list[sqlite3.Row]:
    con=_conn()
    try:
        return con.execute("""
          SELECT * FROM sec_filings
          WHERE kind=? AND filed_date>=?
          ORDER BY filed_date DESC, accession DESC
          LIMIT ? OFFSET ?
        """,(kind,_date_start(range_id),limit,offset)).fetchall()
    finally:
        con.close()


def _cluster_mna(rows:list[sqlite3.Row])->list[sqlite3.Row]:
    """Collapse repeated filings by same filer within the same deal window."""
    out=[];last_by_cik={}
    priority={"DEFM14A":5,"PREM14A":4,"SC TO-T":3,"SC 14D9":3,"S-4":2,"F-4":2}
    for r in rows:
        try:d=dt.date.fromisoformat(r["filed_date"])
        except Exception:d=None
        prev=last_by_cik.get(r["cik"])
        if prev and d:
            pd=prev[1]
            if pd and abs((pd-d).days)<=180:
                # Keep the more informative representative form.
                oi=out.index(prev[0])
                if priority.get(r["form"].replace("/A",""),1)>priority.get(prev[0]["form"].replace("/A",""),1):
                    out[oi]=r;last_by_cik[r["cik"]]=(r,d)
                continue
        out.append(r);last_by_cik[r["cik"]]=(r,d)
    return out


def list_events(kind:str="mna",range_id:str="latest",limit:int=40,offset:int=0,enrich:int=20,force_sync:bool=False)->dict[str,Any]:
    if kind not in {"mna","ipo"}:raise ValueError("kind must be mna or ipo")
    if range_id not in {"latest","1y","2000"}:raise ValueError("invalid range")
    sync_info=None
    if configured():
        try:
            sync_info=ensure_range(range_id)
        except Exception as e:
            sync_info={"error":type(e).__name__}
    # Fetch extra rows because M&A clusters and IPO verification can reduce count.
    rows=_candidate_rows(kind,range_id,min(500,max(limit*6,80)),offset)
    if kind=="mna":
        rows=_cluster_mna(rows)

    result=[]
    enriched=0
    for r in rows:
        if len(result)>=limit:break
        detail=None
        if r["detail_json"]:
            try:detail=json.loads(r["detail_json"])
            except Exception:detail=None
        should_enrich=configured() and enriched<max(0,enrich)
        if should_enrich and (detail is None or force_sync):
            try:
                detail=enrich_accession(r["accession"],force=force_sync)
            except Exception:
                detail=None
            enriched+=1

        if kind=="ipo":
            # IPOs must be text-verified. Unknown rows are not exposed as deals.
            if not detail or not detail.get("verified"):
                continue
        else:
            # Explicit merger proxy forms are SEC-verified by form definition.
            if detail is None:
                detail={
                  "accession":r["accession"],"kind":"mna","date":r["filed_date"],
                  "company":r["company"],"issuer":r["company"],"counterparty":None,
                  "form":r["form"],"sec_url":r["filing_url"],"source":"SEC EDGAR",
                  "verified":bool(r["explicit"]),
                  "status":"SEC M&A filing","headline_value":None,"per_share":None,
                  "source_note":f"SEC EDGAR · форма {r['form']} · подробности загружаются при открытии.",
                }
            if not detail.get("verified"):
                continue
        result.append(detail)

    con=_conn()
    try:
        total=con.execute("SELECT COUNT(*) n FROM sec_filings WHERE kind=? AND filed_date>=?",
                          (kind,_date_start(range_id))).fetchone()["n"]
    finally:
        con.close()
    st=status()
    return {
      "version":"4.9","provider":"SEC EDGAR","kind":kind,"range":range_id,
      "configured":configured(),"sync":sync_info,"history_sync_running":st["history_sync_running"],
      "indexed_quarters":st["indexed_quarters"],"candidate_count":int(total),
      "count":len(result),"rows":result,
      "note":"В список попадают только SEC EDGAR filings. IPO дополнительно проверяются по тексту prospectus на 'initial public offering'.",
    }
