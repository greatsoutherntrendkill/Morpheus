# Model Audit — v2.7 legacy vs v2.8 purged walk-forward

Same stored market database; only validation logic changed. This isolates the effect of fixing multi-day label leakage.

## Aggregate 10D impact

- Assets compared: **33**
- Median OOS edge: **6.2 → 1.1 p.p.**
- Mean OOS edge: **2.93 → 2.37 p.p.**
- Edge decreased on **23** assets, increased on **9**, unchanged on **1**.
- 10D models passing current quality gate: **1 → 0**.

The drop does not prove every old edge was leakage, but it confirms the old information set materially affected reported model quality.

## Examples

| Asset | Edge old | Edge purged | Brier skill old | Brier skill purged | Accuracy old | Accuracy purged | OOS n old | OOS n purged |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ^GSPC | 11.3 | 10.2 | -43.6% | -67.0% | 47.4% | 39.8% | 97 | 88 |
| ^NDX | 10.3 | 27.3 | 4.1% | -6.5% | 59.8% | 59.1% | 97 | 88 |
| GC=F | -37.1 | -37.5 | -97.1% | -123.4% | 36.1% | 34.1% | 97 | 88 |
| BTC-USD | -20.6 | -28.4 | -76.2% | -105.0% | 48.5% | 43.2% | 97 | 88 |
| EURUSD=X | 6.4 | 6.2 | 0.5% | -1.5% | 59.1% | 56.2% | 171 | 162 |
| RUB=X | 7.6 | 7.4 | 2.7% | 1.9% | 53.2% | 53.7% | 171 | 162 |

## Important limitation still open

`OOS n` is still the raw count of overlapping H-day targets. v2.9 should replace the confidence/gate evidence count with a non-overlapping or block-dependent effective sample size.
