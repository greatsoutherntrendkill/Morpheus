"""Полное обновление Morpheus v3.9."""
from __future__ import annotations
import subprocess, sys

def run(*args):
    print('\n>>>',' '.join(args))
    subprocess.run(list(args),check=True)

def main():
    extra=sys.argv[1:]
    run(sys.executable,'update.py',*extra)
    run(sys.executable,'export_site.py')
    run(sys.executable,'build_cross_asset_v36.py')
    run(sys.executable,'build_regime_v37.py')
    run(sys.executable,'update_altdata_v39.py')
    print('\nAllAnalytics v3.9 обновлён.')

# v4.40.6 integrity: live forecasts come only from model_integrity_v4406 via API.
# unified_forecast_v39.py is retained as a legacy snapshot reader, not a live source.

if __name__=='__main__':
    main()
