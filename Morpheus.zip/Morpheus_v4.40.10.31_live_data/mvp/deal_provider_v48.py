"""Provider status / architecture for full M&A and IPO coverage.

v4.8 intentionally does not fabricate current transactions. The existing demo rows remain
until an institutional deal provider is connected.
"""
from __future__ import annotations
import os

def status():
    factset=bool(os.getenv("FACTSET_API_KEY") or os.getenv("FACTSET_USERNAME"))
    lseg=bool(os.getenv("LSEG_CLIENT_ID") and os.getenv("LSEG_CLIENT_SECRET"))
    return {
      "version":"4.8",
      "live_deals_connected": bool(factset or lseg),
      "active_provider":"LSEG" if lseg else "FactSet" if factset else None,
      "recommended":{
        "mna":"LSEG Deals M&A или FactSet Mergers DataFeed",
        "ipo":"LSEG Equity Capital Raising / DataScope Select или FactSet Corporate New Issues",
      },
      "required_for_full_history":True,
      "requested_history_start":"2000-01-01",
      "note":"Без лицензированного deals provider сайт не выдаёт демонстрационные сделки за актуальную полную историю.",
    }
