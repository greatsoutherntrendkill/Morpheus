# Morpheus v4.40.10.2 — Explainable Movement Ranges

## What changed

- Rewrote the Markets → Detail forecast copy in plain analytical Russian. The card now explains the three-state probabilities, what counts as a material move, and how to read the conditional directional probability.
- Added a compact movement panel with:
  - the exact volatility-adjusted material-move threshold used by the shared target contract;
  - the recent IQR of that threshold, so users can see how the noise boundary changed with volatility;
  - the distribution layer's expected absolute move as a scale estimate;
  - an optional directional scenario range.
- The directional scenario range is **not hard-coded** and is **not published for every asset**. It is derived from calibrated predictive quantiles (q75–q90 for upside / q10–q25 for downside) and is shown only when the distribution layer passes its own quality/effective-sample gate and the tail actually clears the material-move threshold.
- If distribution quality is weak or the predictive distribution crosses the neutral zone, the UI explicitly says that the directional range is not statistically reliable yet.
- News/event context remains an explanation layer only; it does not manufacture a narrower numerical price range.
- No change to directional model generation, target semantics, calibration, routing, prospective evidence, or v4.40.10 champion math.
- The new range guidance piggybacks on the existing market forecast response, so it does not add a separate API request or increase card-loading fan-out.

## Interpretation

“Significant move” means the same thing in the UI as in model training: an absolute future log-return beyond the current volatility-adjusted three-state threshold. “Typical move” is a distributional scale estimate, not a price target. “Directional range” is a calibrated strong-scenario tail, not a guaranteed outcome.
