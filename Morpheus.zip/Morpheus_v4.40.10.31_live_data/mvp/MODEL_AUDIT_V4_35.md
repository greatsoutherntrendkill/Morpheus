# Model Audit — Morpheus v4.35

## Что исправляет версия

До v4.35 ансамбль использовал консервативные, но всё же заранее заданные веса. Это означало, что компонент мог получать одинаковое влияние на разных горизонтах и режимах, даже если его реальная OOS-эффективность различалась.

v4.35 переводит этот слой на эмпирическую схему:

`component OOS predictions → regime/horizon reliability → time-ordered meta-learning → calibration → OOS threshold → reliability gate → published probability / no-edge`.

## Защита от leakage

- component forecasts, используемые meta-layer, уже являются OOS-прогнозами;
- meta training / calibration / evaluation делятся по времени;
- calibration slice предшествует evaluation slice;
- threshold выбирается только по development OOS evaluation;
- live outcome не используется для формирования текущего прогноза;
- context expert не получает полноценный learned weight до prospective settlement v4.36.

## Почему это безопаснее фиксированного ансамбля

Если regime model начинает работать хуже production model на конкретном горизонте, её OOS reliability снижается и вес уменьшается. Если обе модели расходятся, система не усредняет их так, будто они подтверждают друг друга: disagreement отдельно снижает conviction.

Reliability gate решает другую задачу, чем direction model: не "куда пойдёт цена", а "насколько исторически похожие по силе и согласованности прогнозы были надёжны".

## Ограничения

- Историческая performance context/event expert пока не имеет полноценного prospective ledger. Поэтому v4.35 сознательно оставляет этот слой advisory.
- Meta-learning не является гарантией улучшения на каждом активе. Если OOS meta edge отсутствует, threshold повышается, reliability снижается и система должна чаще выдавать `нет преимущества`.
- Promotion в champion запрещён до отдельного governance review.
