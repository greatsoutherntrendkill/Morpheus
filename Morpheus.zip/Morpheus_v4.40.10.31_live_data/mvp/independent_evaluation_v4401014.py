"""Frozen, paired evaluation of final published forecasts. No automatic promotion.
Three-state probabilities are scored on all resolved origins; conditional direction
is scored only on significant moves. Research replay is never untouched evidence.
"""
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd
import target_contract_v4405 as TARGET

VERSION='independent-evaluation-v4.40.10.14'
CLASSES=('down','neutral','up')
BASELINES=('uniform','frequency','trend')
CRITERIA={
 'min_paired_origins':120,'min_nonoverlap_origins':60,'min_nonoverlap_per_period':15,
 'periods':3,'family_alpha':.05,'min_relative_brier_gain':.02,
 'max_ece':.08,'coverage80_min':.72,'coverage80_max':.88,
 'max_width_ratio_to_empirical':1.5,'min_candidate_trades':30,
 'required_roundtrip_cost_bps':15,'bootstrap_samples':1999,
 'requires_untouched_prospective':True,'requires_point_in_time_source_archive':True,
 'automatic_promotion':False,
}

def digest(obj):
 return hashlib.sha256(json.dumps(obj,sort_keys=True,ensure_ascii=False,allow_nan=False,default=str).encode()).hexdigest()

def code_hash(root=None):
 root=Path(root or Path(__file__).parent)
 # No report/output files: writing an audit does not invalidate its source hash.
 return digest({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('*.py')) if not p.name.startswith('test_')})

def vector(prob):
 try:p=np.array([prob[k] for k in CLASSES],dtype=float)
 except (TypeError,KeyError,ValueError):return None
 if not np.isfinite(p).all() or np.any(p<0) or np.any(p>1) or abs(p.sum()-1)>2e-5:return None
 return p/p.sum() # Only undo published decimal rounding; invalid outputs are not repaired.

def losses(probs, states):
 p=np.asarray(probs,float); y=np.asarray(states,int)+1
 one=np.eye(3)[y]
 return np.sum((p-one)**2,axis=1), -np.log(np.clip(p[np.arange(len(y)),y],1e-12,1))

def calibration(probs,states,bins=5):
 p=np.asarray(probs,float);y=np.asarray(states,int)+1; out=[];weighted=[]
 for j,key in enumerate(CLASSES):
  total=0.
  for i in range(bins):
   lo=i/bins;hi=(i+1)/bins;mask=(p[:,j]>=lo)&((p[:,j]<=hi) if i==bins-1 else (p[:,j]<hi))
   n=int(mask.sum())
   if not n:continue
   pred=float(p[mask,j].mean());obs=float((y[mask]==j).mean())
   total+=n/len(y)*abs(pred-obs)
   out.append({'class':key,'lo':lo,'hi':hi,'n':n,'predicted':pred,'observed':obs})
  weighted.append(total)
 return {'macro_ece':float(np.mean(weighted)),'bins':out,'note':'Five fixed bins per class; small bins are descriptive only.'}

def nonoverlap(rows):
 selected=[];last_end=-1
 for r in sorted(rows,key=lambda r:r['origin_index']):
  if r['origin_index']>last_end:
   selected.append(r);last_end=r['target_index']
 return selected

def bootstrap_difference(values,block_length,alpha=.05,n_boot=1999,seed=4401014):
 """Circular moving-block bootstrap of paired chronological loss differences."""
 a=np.asarray(values,float);n=len(a);b=max(1,min(int(block_length),n))
 if n<8 or n//b<4:return {'mean':float(a.mean()) if n else None,'low':None,'high':None,'p_one_sided':None,'blocks':n//b,'block_length':b}
 rng=np.random.default_rng(seed);starts=rng.integers(0,n,size=(n_boot,math.ceil(n/b)))
 idx=(starts[:,:,None]+np.arange(b))%n;idx=idx.reshape(n_boot,-1)[:,:n]
 samples=a[idx].mean(axis=1);mu=float(a.mean())
 # H0 mean difference = 0. Positive means the candidate has smaller loss.
 centered=samples-mu;p=(1+int(np.sum(centered>=mu)))/(n_boot+1)
 return {'mean':mu,'low':float(np.quantile(samples,alpha/2)),'high':float(np.quantile(samples,1-alpha/2)),
         'p_one_sided':p,'blocks':n//b,'block_length':b,'method':'paired circular moving-block bootstrap'}

def holm(values):
 """Adjusted one-sided p-values across the predeclared family, including failures."""
 order=np.argsort(values);out=[1.]*len(values);running=0.
 for rank,i in enumerate(order):
  running=max(running,(len(values)-rank)*float(values[i]));out[int(i)]=min(1.,running)
 return out

def regime(close):
 c=pd.Series(close,dtype=float);lr=np.log(c/c.shift()).dropna()
 if len(lr)<120:return 'insufficient_history'
 ratio=lr.tail(20).std()/max(float(lr.tail(120).std()),1e-12)
 if ratio>=1.5:return 'high_volatility'
 change=np.log(c.iloc[-1]/c.iloc[-21]);noise=lr.tail(60).std()*np.sqrt(20)
 return 'uptrend' if change>noise*.5 else 'downtrend' if change<-noise*.5 else 'range'

def baselines(close,horizon):
 """All labels used here have already ended strictly BEFORE the forecast origin."""
 c=pd.Series(close,dtype=float);tf=TARGET.target_frame(c,horizon)
 done=tf[(tf.label_end<c.index[-1]) & tf.state.notna()].tail(504)
 if len(done)<40:raise ValueError('Insufficient resolved labels for paired baselines')
 def prob(d):
  counts=np.array([(d.state==v).sum() for v in [-1,0,1]],float)+1
  return {k:float(v) for k,v in zip(CLASSES,counts/counts.sum())}
 direction=np.sign(np.log(c/c.shift(20)))
 mask=direction.reindex(done.index)==direction.iloc[-1];trend=done.loc[mask]
 if len(trend)<30:trend=done
 qs=np.quantile(done.ret_fwd,[.1,.9]).tolist()
 return {'uniform':{'prob':dict.fromkeys(CLASSES,1/3),'interval80':qs,'abstain':True},
         'frequency':{'prob':prob(done),'interval80':qs},'trend':{'prob':prob(trend),'interval80':qs},
         'training':{'label_end_max':str(done.label_end.max()),'labels':len(done),'trend_labels':len(trend)}}

def interval_metrics(rows,name):
 points=[]
 for r in rows:
  z=r['forecasts'][name].get('interval80')
  if z is None:continue
  lo,hi=z;y=r['realized_log_return']
  if not np.isfinite([lo,hi,y]).all() or lo>hi:continue
  # Interval score is a proper score combining sharpness and missed coverage.
  score=hi-lo+10*max(lo-y,0)+10*max(y-hi,0)
  points.append((lo<=y<=hi,100*(np.exp(hi)-np.exp(lo)),100*score))
 if not points:return {'n':0,'coverage80':None,'width_price_pct':None,'interval_score_log_pct':None}
 a=np.asarray(points,float)
 return {'n':len(a),'coverage80':float(a[:,0].mean()),'width_price_pct':float(a[:,1].mean()),'interval_score_log_pct':float(a[:,2].mean())}

def metrics(rows,name):
 valid=[r for r in rows if vector(r['forecasts'].get(name,{}).get('prob')) is not None]
 if not valid:return {'n':0}
 p=np.array([vector(r['forecasts'][name]['prob']) for r in valid]);y=np.array([r['state'] for r in valid]);b,l=losses(p,y)
 significant=y!=0;den=p[:,0]+p[:,2];cp=np.divide(p[:,2],den,out=np.full(len(p),np.nan),where=den>0)
 cm=significant&np.isfinite(cp)
 cond={'n':int(cm.sum()),'brier':float(np.mean((cp[cm]-(y[cm]>0))**2)) if cm.any() else None}
 return {'n':len(valid),'brier':float(b.mean()),'log_loss':float(l.mean()),'accuracy':float(np.mean(p.argmax(1)==y+1)),
  'calibration':calibration(p,y),'conditional_direction':cond,
  'signal_share':float(np.mean([not r['forecasts'][name].get('abstain',True) for r in valid])),
  'interval':interval_metrics(valid,name)}

def paper_execution(rows,name,cost_bps):
 """Research-only, non-overlapping orders; next real open, exit at target close."""
 trades=[];last_exit=-1;missing=0
 for r in sorted(rows,key=lambda x:x['origin_index']):
  f=r['forecasts'].get(name,{})
  if f.get('abstain',True) or r['origin_index']<=last_exit:continue
  p=vector(f.get('prob'))
  if p is None:continue
  ret=r.get('next_open_to_target_return')
  if ret is None:missing+=1;continue
  side=1 if p[2]>p[0] else -1 if p[2]<p[0] else 0
  if not side:continue
  net=side*float(ret)-cost_bps/10000
  trades.append({'origin':r['origin'],'exit':r['target_date'],'side':side,'gross':side*float(ret),'net':net})
  last_exit=r['target_index']
 vals=np.array([x['net'] for x in trades]);wealth=np.cumprod(1+vals) if len(vals) else np.array([])
 path=np.r_[1,wealth];dd=path/np.maximum.accumulate(path)-1
 return {'n':len(trades),'skipped_no_open':missing,'roundtrip_cost_bps':cost_bps,
  'mean_net_pct':float(vals.mean()*100) if len(vals) else None,'compound_net_pct':float((wealth[-1]-1)*100) if len(vals) else None,
  'max_drawdown_pct':float(dd.min()*100) if len(vals) else None,'trades':trades,
  'net_mean_block_interval':bootstrap_difference(vals*100,2),
  'scope':'hypothetical_unlevered_proxy_not_executable_instrument','cost_basis':'assumed total commission+spread+slippage, not measured broker costs'}

def evaluate_group(rows,protocol):
 good=[r for r in rows if r.get('status')=='ok' and all(vector(r['forecasts'][n]['prob']) is not None for n in ('model',*BASELINES))]
 good=sorted(good,key=lambda r:r['origin_index']);h=rows[0]['horizon'];mode=rows[0]['mode'];sym=rows[0]['symbol']
 out={'symbol':sym,'horizon':h,'mode':mode,'attempted':len(rows),'paired':len(good),'unavailable':len(rows)-len(good),
      'nonoverlap':len(nonoverlap(good)),'metrics':{},'comparisons':{},'periods':{},'regimes':{},'execution':{},'status':'insufficient_evidence','passed':False}
 if not good:return out
 out['metrics']={n:metrics(good,n) for n in ('model',*BASELINES)}
 for period in range(3):
  part=[r for r in good if r['period']==period]
  out['periods'][str(period)]={'n':len(part),'nonoverlap':len(nonoverlap(part)),'metrics':{n:metrics(part,n) for n in ('model',*BASELINES)}}
 for label in sorted({r['regime'] for r in good}):
  part=[r for r in good if r['regime']==label];out['regimes'][label]={'n':len(part),'metrics':{n:metrics(part,n) for n in ('model',*BASELINES)}}
 y=[r['state'] for r in good];bm,lm=losses([vector(r['forecasts']['model']['prob']) for r in good],y)
 step=float(np.median(np.diff([r['origin_index'] for r in good]))) if len(good)>1 else 1
 block=max(2,math.ceil(h/max(step,1))+1)
 for n in BASELINES:
  bb,ll=losses([vector(r['forecasts'][n]['prob']) for r in good],y)
  stat=bootstrap_difference(bb-bm,block,n_boot=CRITERIA['bootstrap_samples'])
  stat['relative_brier_gain']=float(1-bm.mean()/bb.mean()) if bb.mean()>0 else None
  stat['log_loss_gain']=float(ll.mean()-lm.mean());out['comparisons'][n]=stat
 out['execution']={n:[paper_execution(good,n,c) for c in [5,15,30]] for n in ('model',*BASELINES)}
 # Descriptive diagnosis remains separate from a promotion decision.
 out['best_baseline']=min(BASELINES,key=lambda n:out['metrics'][n]['brier'])
 out['model_beats_all_on_point_estimate']=all(out['comparisons'][n]['mean']>0 for n in BASELINES)
 return out

def decision(group,protocol):
 c=protocol['criteria'];reasons=[]
 if protocol.get('evidence_scope')!='untouched_prospective':reasons.append('historical_development_only')
 if not protocol.get('point_in_time_archive_verified'):reasons.append('point_in_time_archive_incomplete')
 if group['paired']<c['min_paired_origins'] or group['nonoverlap']<c['min_nonoverlap_origins']:reasons.append('too_few_independent_outcomes')
 if len(group['periods'])<3 or any(p['nonoverlap']<c['min_nonoverlap_per_period'] for p in group['periods'].values()):reasons.append('insufficient_separate_periods')
 for n in BASELINES:
  comp=group['comparisons'].get(n,{})
  if comp.get('p_holm',1)>.05 or comp.get('low') is None or comp['low']<=0 or (comp.get('relative_brier_gain') or 0)<c['min_relative_brier_gain'] or (comp.get('log_loss_gain') or 0)<=0:
   reasons.append('no_robust_advantage_over_'+n)
 if any(any(p.get('metrics',{}).get('model',{}).get('brier',float('inf'))>=p.get('metrics',{}).get(n,{}).get('brier',-1) for n in BASELINES) for p in group['periods'].values()):reasons.append('advantage_not_stable_across_periods')
 mm=group['metrics'].get('model',{});iv=mm.get('interval',{});baseiv=group['metrics'].get('frequency',{}).get('interval',{})
 if mm.get('calibration',{}).get('macro_ece',1)>c['max_ece']:reasons.append('calibration_not_qualified')
 cov=iv.get('coverage80');width=iv.get('width_price_pct');bw=baseiv.get('width_price_pct')
 if cov is None or not c['coverage80_min']<=cov<=c['coverage80_max'] or width is None or not bw or width>bw*c['max_width_ratio_to_empirical']:reasons.append('interval_not_qualified')
 costs=group.get('execution',{}).get('model',[]);net=next((x for x in costs if x['roundtrip_cost_bps']==15),{})
 if net.get('n',0)<c['min_candidate_trades'] or (net.get('mean_net_pct') or 0)<=0 or (net.get('net_mean_block_interval',{}).get('low') or 0)<=0:reasons.append('economic_value_not_established')
 return {'passed':not reasons,'status':'eligible_for_review' if not reasons else 'not_confirmed','reasons':reasons,'automatic_promotion':False}

def report(rows,protocol):
 groups=[]
 for job in protocol['jobs']:
  part=[r for r in rows if (r['symbol'],r['horizon'],r['mode'])==(job['symbol'],job['horizon'],job['mode'])]
  if part:groups.append(evaluate_group(part,protocol))
 family=[g['comparisons'].get(n,{}).get('p_one_sided') or 1. for g in groups for n in BASELINES]
 # Include missing planned comparisons; absence cannot shrink multiplicity penalty.
 planned=len(protocol['jobs'])*len(BASELINES);family+= [1.]*(planned-len(family));adjusted=holm(family)
 for i,g in enumerate(groups):
  for j,n in enumerate(BASELINES):
   if n in g['comparisons']:g['comparisons'][n]['p_holm']=adjusted[3*i+j]
  g.update(decision(g,protocol))
 return {'version':VERSION,'generation':protocol['generation'],'created_at':pd.Timestamp.now(tz='UTC').isoformat(),
  'protocol_hash':digest(protocol),'code_hash':protocol['code_hash'],'evidence_scope':protocol['evidence_scope'],
  'point_in_time_archive_verified':False,'automatic_promotion':False,'criteria':protocol['criteria'],
  'scope_note':'Историческое воспроизведение текущей процедуры. Не независимая проверка на ещё не использованной истории.',
  'summary':{'attempted':len(rows),'paired':sum(g['paired'] for g in groups),'groups':len(groups),'planned_groups':len(protocol['jobs']),
             'point_estimate_wins':sum(g.get('model_beats_all_on_point_estimate',False) for g in groups),'qualified_groups':sum(g['passed'] for g in groups)},'groups':groups}
