"""Explicit replay clock. Context-local: historical audits cannot change live time."""
from contextlib import contextmanager
from contextvars import ContextVar
import pandas as pd
_REPLAY = ContextVar('allanalytics_replay_asof', default=None)

def now():
    return _REPLAY.get() or pd.Timestamp.now(tz='UTC')

def active():
    return _REPLAY.get() is not None

@contextmanager
def at(value):
    t=pd.Timestamp(value)
    t=t.tz_localize('UTC') if t.tzinfo is None else t.tz_convert('UTC')
    token=_REPLAY.set(t)
    try: yield t
    finally: _REPLAY.reset(token)

def available(row):
    """During replay, an article/calendar revision needs an observed arrival time."""
    if not active(): return True
    raw=row.get('first_seen_at') or row.get('available_at')
    if not raw: return False
    try:
        t=pd.Timestamp(raw); t=t.tz_localize('UTC') if t.tzinfo is None else t.tz_convert('UTC')
        return bool(pd.notna(t) and t<=now())
    except (ValueError,TypeError): return False
