# Morpheus v3.0 — Point-in-time Macro Audit

## Problem fixed

Previous versions stored the latest/current FRED history and approximated publication
availability with fixed lags such as CPI +45 days. That prevented some obvious
look-ahead, but revised historical values could still differ from the values that
market participants actually saw at the time.

## v3.0 rule

Predictive models prefer `macro_pit`, populated from FRED/ALFRED
`series/observations?output_type=4`.

For each observation we persist:

- `observation_date`
- `available_date` (`realtime_start`)
- `vintage_date`
- `realtime_end`
- `value`
- `source`
- `is_initial`

A macro observation is visible to the model only on/after `available_date`.

## Why initial releases

v3.0 intentionally uses the initial released value for backtests. This is a
conservative point-in-time dataset: later revisions are never back-filled into the
past. It may omit revisions that were legitimately known later, but it cannot benefit
from revisions published after the prediction date.

## Fail-closed behavior

`MACRO_ALLOW_LEGACY_LAG=0` by default.

If point-in-time data are unavailable:
- current/revised FRED can still be used in current-state UI;
- predictive macro features are omitted;
- the model does not silently fall back to revised history.

## Remaining limitation

FRED `realtime_start` is day-level availability, not an intraday timestamp. For
event-day/intraday models, official BLS/BEA/central-bank release timestamps should be
stored separately in a future version.

## Next model-data step

Full revision-aware vintage reconstruction:
use ALFRED revision events so that a backtest sees revisions only from the day they
became known.
