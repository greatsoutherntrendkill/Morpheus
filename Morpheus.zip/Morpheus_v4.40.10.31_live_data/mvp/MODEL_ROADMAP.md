# Morpheus Model Roadmap

## Goal
Build a point-in-time, reproducible, probabilistic forecasting stack where every published probability is backed by honest out-of-sample validation.

## P0 — Validation correctness

### 1. Purged walk-forward — DONE in v2.8
Problem: for H>1, legacy `X[:t], y[:t]` training could include labels whose outcomes ended after prediction date T.

Fix:
- every target stores `label_end_date`;
- at prediction T, train only on rows where `label_end_date <= T`;
- baseline uses the identical legal information set;
- model result exposes `validation.method = purged_walk_forward`;
- smoke test verifies the purge rule.

Acceptance:
- no training label can end after prediction timestamp;
- 1/5/10/20D all use the same rule;
- UI identifies purged validation.

### 2. Overlapping-target evaluation — DONE in v2.9
Problem: H-day targets overlap, so raw OOS count overstates independent evidence.

Implemented:
- phase-robust non-overlap evaluation for each horizon;
- report `n_raw`, `n_nonoverlap` and conservative `n_effective`;
- 500-resample moving-block bootstrap confidence intervals;
- quality gate uses effective evidence, non-overlap metrics and lower 95% CI bounds.

Acceptance:
- 10D gate cannot treat 200 overlapping daily forecasts as 200 independent observations;
- confidence intervals use block dependence.

### 3. Point-in-time macro / vintages — NEXT
Problem: revised macro values can leak information unavailable historically.

Plan:
- ALFRED vintages for FRED series;
- store observation_date, release_timestamp, vintage_timestamp, value;
- feature join rule: `available_at <= prediction_time`;
- replace fixed publication lags with actual releases where possible.

Acceptance:
- historical prediction can be reconstructed using only data known at that time.

### 4. Untouched final holdout
Problem: repeated iteration on the same OOS period creates model-selection leakage.

Plan:
- freeze a final chronological holdout never used for feature/model selection;
- development metrics and final metrics stored separately.

Acceptance:
- every production model has a final untouched test report.

### 5. Statistical uncertainty — PARTLY DONE in v2.9
Done:
- block-bootstrap confidence intervals for accuracy, edge, Brier skill and calibration;
- quality gate requires credible positive skill, not only a positive point estimate.

Still to add:
- reliability diagrams;
- probability-bucket realized returns;
- confidence intervals on those bucket statistics.

### 6. Model registry + prediction ledger
Plan:
- immutable prediction record: model_version, feature_version, data_cutoff, prediction_time, horizon, p_up, quantiles, confidence;
- later attach realized outcome;
- reproducible model cards.

---

## P1 — Data moat
1. Options: IV, skew, term structure, OI, implied move.
2. CFTC COT positioning.
3. EIA oil/gas inventories and production.
4. Crypto funding, OI, basis, liquidations, ETF/stablecoin flows.
5. ECB/BLS/BEA release-level data.

---

## P2 — Model stack

### Baseline — keep
- Logistic regression remains the interpretable benchmark.

### Nonlinear model
- LightGBM or CatBoost for interactions/nonlinearities.

### Regime model
- volatility, trend, inflation/rates and risk-on/off regimes;
- regime feature or mixture-of-experts.

### Distribution models
- quantile regression for Q10/Q25/Q50/Q75/Q90 returns;
- GARCH/EGARCH or ML volatility forecast;
- conformal intervals.

### Ensemble
- logistic + boosting + regime + distribution layer;
- probability calibration on strictly OOS predictions.

---

## P3 — Model productization
- prediction history;
- change-of-view explanations;
- alerts when confidence/regime/probability changes;
- model cards and reliability charts;
- asset-class-specific feature packs.

## Rule for every future model
A more complex model is accepted only if it improves an untouched/purged probabilistic benchmark after costs and uncertainty. Complexity alone is not an improvement.


## v3.0 — P0.3 DONE: point-in-time macro / ALFRED initial releases

Implemented:
- `macro_pit` table with observation_date, available_date, vintage_date and provenance;
- FRED `output_type=4` initial-release downloader;
- predictive macro features read PIT rows first;
- revised current FRED history is not silently used in historical ML;
- strict default: if PIT is unavailable, the macro layer is omitted;
- CBR key-rate history gets day-level PIT provenance;
- UI exposes macro-data mode and number of macro features used.

Still open after v3.0:
1. full revision-aware vintage reconstruction (legitimate revisions known at each date);
2. intraday release timestamps from BLS/BEA/central-bank sources;
3. untouched final holdout;
4. confidence intervals around economic performance metrics / multiple testing controls;
5. model registry and immutable prediction history.


## v3.1 — P0.4/P0.5 DONE: revision-aware PIT + release timestamps + frozen final holdout

Implemented:
- ALFRED `output_type=3` new/revised observation event history with pagination;
- every revision is applied only from its own `available_date`;
- revision-aware reconstruction of latest level, YoY and ~3-month macro features;
- `macro_release` table for intraday release metadata;
- 08:30 ET timestamp layer for BLS CPI/Employment and BEA GDP/PCE;
- 09:15 ET timestamp layer for Federal Reserve Industrial Production;
- fixed final holdout start (`FINAL_HOLDOUT_START=2026-04-01`);
- final holdout model/baseline are frozen on pre-holdout data;
- holdout outcomes never enter the development quality gate;
- holdout statistics are reported separately from development OOS.

### Remaining P0 before stronger ML
1. model registry + immutable prediction ledger;
2. lock/fingerprint data + feature versions used by each model;
3. multiple-testing controls and a formal champion/challenger promotion rule;
4. economic-value metrics net of costs;
5. then benchmark Logistic against LightGBM/CatBoost and regime models.
