"""Provider clients for revision-aware macro and future data-quality layers.

These functions are deliberately not wired into update.py automatically: enabling a new
provider changes data provenance and backtests, so it should be explicit and versioned.
"""
from __future__ import annotations

from datetime import date
import requests
import pandas as pd

TIMEOUT = 30


def fred_point_in_time(series_id: str, api_key: str, as_of: str | date,
                       observation_start="2015-01-01") -> pd.DataFrame:
    """FRED/ALFRED point-in-time observation snapshot using realtime_start/end.

    Use this for honest historical features: `as_of` is the information set date.
    """
    if not api_key:
        return pd.DataFrame(columns=["date", "value", "realtime_start", "realtime_end"])
    as_of = str(as_of)
    url = "https://api.stlouisfed.org/fred/series/observations"
    r = requests.get(url, timeout=TIMEOUT, params={
        "series_id": series_id, "api_key": api_key, "file_type": "json",
        "observation_start": observation_start,
        "realtime_start": as_of, "realtime_end": as_of,
    })
    r.raise_for_status()
    obs = r.json().get("observations", [])
    if not obs:
        return pd.DataFrame(columns=["date", "value", "realtime_start", "realtime_end"])
    out = pd.DataFrame(obs)
    out["value"] = pd.to_numeric(out["value"], errors="coerce")
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    return out.dropna(subset=["date", "value"])




def _fred_obs_to_pit(obs: list[dict], source: str = "alfred") -> pd.DataFrame:
    """Normalize FRED/ALFRED observation events to a revision-aware PIT table."""
    cols = ["observation_date", "available_date", "vintage_date",
            "realtime_end", "value", "source", "is_initial"]
    if not obs:
        return pd.DataFrame(columns=cols)
    out = pd.DataFrame(obs).copy()
    if "date" not in out.columns or "value" not in out.columns:
        return pd.DataFrame(columns=cols)
    out["value"] = pd.to_numeric(out["value"], errors="coerce")
    out["observation_date"] = pd.to_datetime(out["date"], errors="coerce")
    if "realtime_start" in out.columns:
        out["available_date"] = pd.to_datetime(out["realtime_start"], errors="coerce")
    else:
        out["available_date"] = out["observation_date"]
    out["vintage_date"] = out["available_date"]
    if "realtime_end" not in out.columns:
        out["realtime_end"] = ""
    out["source"] = source
    out = out.dropna(subset=["observation_date", "available_date", "value"])
    out = out.sort_values(["observation_date", "available_date"]).reset_index(drop=True)
    # The first appearance of an observation is the initial release; later
    # appearances are revisions that became known on their own available_date.
    out["is_initial"] = (~out.duplicated("observation_date", keep="first")).astype(int)
    return out[cols]


def _fred_observation_pages(series_id: str, api_key: str, output_type: int,
                            observation_start="2015-01-01") -> list[dict]:
    """Paginate FRED JSON observation results.

    FRED documents JSON limits for vintage output, so v3.1 never assumes that one
    huge request will contain a complete revision history.
    """
    if not api_key:
        return []
    url = "https://api.stlouisfed.org/fred/series/observations"
    limit = 2000
    offset = 0
    rows: list[dict] = []
    while True:
        params = {
            "series_id": series_id,
            "api_key": api_key,
            "file_type": "json",
            "observation_start": observation_start,
            "realtime_start": "1776-07-04",
            "realtime_end": str(date.today()),
            "output_type": int(output_type),
            "limit": limit,
            "offset": offset,
            "sort_order": "asc",
        }
        r = requests.get(url, timeout=TIMEOUT, params=params)
        r.raise_for_status()
        body = r.json()
        page = body.get("observations", []) or []
        rows.extend(page)
        count = int(body.get("count", len(rows)) or len(rows))
        offset += len(page)
        if not page or offset >= count:
            break
    return rows


def fred_initial_releases(series_id: str, api_key: str,
                          observation_start="2015-01-01") -> pd.DataFrame:
    """Initial release only (FRED output_type=4)."""
    rows = _fred_observation_pages(series_id, api_key, 4, observation_start)
    out = _fred_obs_to_pit(rows, "alfred_initial")
    if not out.empty:
        out["is_initial"] = 1
    return out


def fred_revision_history(series_id: str, api_key: str,
                          observation_start="2015-01-01") -> pd.DataFrame:
    """Full new+revised observation event stream (FRED output_type=3).

    Each row is a value that became known on its own realtime_start/available_date.
    This is the preferred v3.1 backtest input.
    """
    rows = _fred_observation_pages(series_id, api_key, 3, observation_start)
    return _fred_obs_to_pit(rows, "alfred_revision_event")


def fred_revision_events(series_id: str, api_key: str,
                         observation_start="2015-01-01") -> pd.DataFrame:
    """Backward-compatible alias."""
    return fred_revision_history(series_id, api_key, observation_start)


def bls_timeseries(series_ids: list[str], start_year: int, end_year: int,
                   registration_key: str | None = None) -> dict:
    """Official BLS Public Data API client for CPI/payroll/labour series."""
    body = {"seriesid": series_ids, "startyear": str(start_year), "endyear": str(end_year)}
    if registration_key:
        body["registrationkey"] = registration_key
    r = requests.post("https://api.bls.gov/publicAPI/v2/timeseries/data/",
                      json=body, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def eia_get(route: str, api_key: str, params: dict | None = None) -> dict:
    """EIA API v2 generic client; useful for oil/gas inventories and production."""
    if not api_key:
        raise ValueError("EIA_API_KEY is required")
    params = dict(params or {})
    params["api_key"] = api_key
    url = "https://api.eia.gov/v2/" + route.strip("/") + "/data/"
    r = requests.get(url, params=params, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def cftc_public_data(dataset: str, where: str | None = None, limit=5000) -> list[dict]:
    """CFTC Socrata public-data client for COT positioning datasets."""
    params = {"$limit": int(limit)}
    if where:
        params["$where"] = where
    url = f"https://publicreporting.cftc.gov/resource/{dataset}.json"
    r = requests.get(url, params=params, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


# ---------------------------------------------------------------------------
# v3.7 optional market-structure providers
# ---------------------------------------------------------------------------
def coinglass_get(path: str, api_key: str, params: dict | None = None) -> dict:
    """CoinGlass API V4 generic GET client.

    Authentication uses the CG-API-KEY header. The caller decides which endpoint
    is appropriate so feature provenance stays explicit.
    """
    if not api_key:
        raise ValueError("COINGLASS_API_KEY is required")
    url = "https://open-api-v4.coinglass.com/" + path.lstrip("/")
    r = requests.get(
        url, params=dict(params or {}),
        headers={"accept":"application/json","CG-API-KEY":api_key},
        timeout=TIMEOUT
    )
    r.raise_for_status()
    return r.json()


def coinglass_open_interest_history(symbol: str, api_key: str, interval="1d",
                                    limit=1000, start_time=None, end_time=None) -> dict:
    params={"symbol":symbol,"interval":interval,"limit":int(limit)}
    if start_time is not None: params["start_time"]=int(start_time)
    if end_time is not None: params["end_time"]=int(end_time)
    return coinglass_get("/api/futures/open-interest/aggregated-history",api_key,params)


def coinglass_funding_history(symbol: str, api_key: str, interval="1d",
                              limit=1000, start_time=None, end_time=None) -> dict:
    params={"symbol":symbol,"interval":interval,"limit":int(limit)}
    if start_time is not None: params["start_time"]=int(start_time)
    if end_time is not None: params["end_time"]=int(end_time)
    return coinglass_get("/api/futures/funding-rate/oi-weight-history",api_key,params)


def coinglass_liquidation_history(symbol: str, api_key: str, interval="1d",
                                  limit=1000, start_time=None, end_time=None) -> dict:
    params={"symbol":symbol,"interval":interval,"limit":int(limit)}
    if start_time is not None: params["start_time"]=int(start_time)
    if end_time is not None: params["end_time"]=int(end_time)
    return coinglass_get("/api/futures/liquidation/aggregated-history",api_key,params)


def massive_option_chain_snapshot(underlying: str, api_key: str,
                                  params: dict | None = None) -> dict:
    """Massive options-chain snapshot: IV, Greeks and open interest when entitled."""
    if not api_key:
        raise ValueError("OPTIONS_API_KEY is required")
    q=dict(params or {})
    q["apiKey"]=api_key
    url=f"https://api.massive.com/v3/snapshot/options/{underlying}"
    r=requests.get(url,params=q,timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()
