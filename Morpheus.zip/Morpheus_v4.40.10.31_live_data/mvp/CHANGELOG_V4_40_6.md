# Morpheus v4.40.6 — Learned Move / No-Move

## Factorized three-state forecast
The live model now explicitly solves two probability tasks:

1. `P(material move | current features)`
2. `P(up | material move, current features)`

The UI/API probability mass is reconstructed as UP / NEUTRAL / DOWN and sums to 1.

## Champion
- Added a dedicated Move/No-Move logistic model trained in the same purged walk-forward chronology as the directional model.
- Added OOS Move/No-Move Brier, skill and calibration diagnostics.
- Deployment move probability is feature-conditioned and calibrated when enough OOS evidence exists.

## Regime challenger
- Added global + regime-aware Move/No-Move expert routing.
- Rolling calibration uses only previous OOS observations.

## Asset specialist
- Added time-ordered Move/No-Move specialist fit.
- Specialist neutral mass can alter the final probability only if its own OOS move-model skill is positive and the existing prospective/human gate allows a live weight.

## Dynamic ensemble
- Learned move probabilities from champion and regime expert are combined using live routing weights.
- Context/event/specialist direction forecasts are blended on the conditional-direction scale, then the move probability is reapplied.
- Fixed a remaining prospective context-blend scale mismatch.

## Live identity
- New model generation: `directional-3state-move-model-v4.40.6`.
- Single live wrapper: `model_integrity_v4406.py`.

## Verification
- 141/141 pytest cases passed when the full suite is run in non-overlapping groups (the monolithic container run can hang due to test-order/environment interaction).
- Python compileall: OK.
- Static site export: OK (33 assets; network news fallback behaved correctly when NewsAPI was unavailable in the container).
- smoke_test.py: OK.
- JavaScript file + inline-script syntax: OK.
- Live synthetic forecast check: class probabilities sum to 1 and the move source is the learned Move/No-Move ensemble.
