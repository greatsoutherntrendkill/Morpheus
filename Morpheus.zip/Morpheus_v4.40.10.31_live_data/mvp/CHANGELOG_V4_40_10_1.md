# Morpheus v4.40.10.1 — Market Forecast Coverage

This patch does not change predictive-model mathematics. It fixes the Markets UI/API integration so supported non-equity assets expose the forecasts that already exist and can refresh them live.

## Fixed

- `unified()` now resolves forecasts in this order: live market forecast → legacy live unified forecast → packaged `model_horizons` snapshot.
- 10-day probabilities are visible for supported global indices, FX, metals, energy/commodities, futures and crypto instead of false `Нет расчёта` states.
- Market live forecasts now use `/api/markets/forecast` for non-equities; the existing equity/MOEX route is retained where its dedicated history fallback is useful.
- Cards distinguish `Рассчитываем прогноз`, `Исследовательская оценка`, `Подтверждённый сигнал`, `Нет преимущества` and genuine `Нет данных`.
- `conditional_p_up` + `p_neutral` is recognised as three-state output even when the compact static snapshot omits the full `class_probabilities` object.
- Forecast requests are queued only as cards enter the viewport, with the existing maximum of four concurrent calculations.
- Browser session cache avoids recalculating the same symbol/horizon after navigation within the site.
- Market detail requests the selected horizon live when it has not yet been refreshed, while immediately showing the packaged last-good snapshot.
- Current UI model metadata now identifies the v4.40.10 champion/validation pipeline rather than the older v4.40.8 routing label.

## Unchanged

- model generation: `directional-3state-move-champion-validation-v4.40.10`
- target definition and probabilities
- champion solver / calibration / routing
- prospective evidence and sealed shadow benchmark

This is intentionally a coverage/integration patch, not a new model generation.
