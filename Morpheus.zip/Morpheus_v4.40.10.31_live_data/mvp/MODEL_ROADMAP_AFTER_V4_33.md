# Следующие этапы Model Quality roadmap

## v4.34 — Feature & Event Layer
- cross-sectional relative-strength features;
- market breadth / dispersion / correlation regime;
- event-aware features: CPI, FOMC/ЦБ/ЕЦБ, earnings, dividends, M&A, sanctions;
- asset-class-specific feature sets;
- feature drift diagnostics.

## v4.35 — Dynamic Ensemble & Meta-Learning
- OOS-performance-weighted model weights by regime;
- meta-model predicting forecast reliability;
- threshold selection from development OOS instead of static cutoffs;
- calibration by horizon and regime.

## v4.36 — Prospective Feedback Loop
- immutable prediction ledger for v4.33+ forecasts;
- automatic settlement after horizon expires;
- error attribution by asset / horizon / regime / event type;
- rolling model leaderboard and controlled promotion review.

После этого Model Quality roadmap можно соединить с отложенным Scenario Intelligence roadmap: Historical Analog Engine, Quant Scenario Model и LLM interpretation layer.
