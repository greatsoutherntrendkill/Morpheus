# MODEL AUDIT — v4.39 Event Response Models

## Цель
Добавить событийный эксперт, не превращая новости в неконтролируемый sentiment-сигнал и не допуская look-ahead.

## Защита от leakage
- Текущее событие исключается из обучающей historical-sensitivity выборки: используются только даты строго раньше `as_of`.
- До появления фактического surprise event expert не выдаёт `p_up`.
- Пост-событийная доходность прошлых событий берётся по последующим торговым сессиям.
- Локальный archive содержит только события, реально появившиеся в calendar/news источниках проекта.

## Surprise contract
- Central bank: actual rate move − expected move.
- Inflation: actual − forecast/consensus.
- Earnings: structured surprise or explicit beat/miss.
- Обычный sentiment/dir новости не считается достаточным surprise.

## Ограничения данных
Текущий bundle содержит небольшое число структурированных событий. Поэтому во многих инструментах Event Response сначала будет работать как `awaiting_surprise` / `insufficient_event_history` и иметь 0% веса. Это ожидаемое и правильное поведение: исторические наблюдения не генерируются искусственно.

## Governance
Event Response — challenger. Production weight = 0 до paired prospective validation + human approval. Даже после допуска вес ограничен как satellite-компонент.

## Проверка
- `pytest -q`: 101 passed.
- `test_v439_event_response.py`: 7 passed.
- `py_compile`: passed.
- active JS `node --check`: passed.
