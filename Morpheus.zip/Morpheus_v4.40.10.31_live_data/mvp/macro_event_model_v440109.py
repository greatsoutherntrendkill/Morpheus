"""Event-conditioned risk overlay, never a fabricated directional probability.
Event studies are descriptive close-to-close associations, not causal estimates.
All prices are truncated before evaluation, and no outcome/consensus is inferred.
Scale candidates use expanding-window validation, blocked bootstrap and shrinkage.
The overlay can withhold a directional signal around unresolved events; it does
not silently reinterpret the champion's class probabilities or reliability score.
"""
import evaluation_clock_v4401014 as EC14
import data_contract_v4401013 as DATA13
import math, re, hashlib, json, time
import numpy as np
import pandas as pd
import macro_calendar_v440109 as CAL
import feature_event_v434 as FE
VERSION='macro-events-v4.40.10.9'
_CACHE={}

def utc(v):
 t=pd.Timestamp(v)
 return t.tz_localize('UTC') if t.tzinfo is None else t.tz_convert('UTC')

def clean(close,as_of):
 x=pd.Series(close,dtype=float).dropna().sort_index();x=x[x>0]
 x.index=pd.to_datetime(x.index).tz_localize(None).normalize()
 x=x[~x.index.duplicated(keep='last')]
 # Today's daily candle may still be forming; it must never train the event study.
 return x[x.index<utc(as_of).tz_localize(None).normalize()]

def relevant(kind,symbol):
 s=symbol.upper();p=FE.asset_profile(s)
 if kind.endswith('_us') or kind=='fed_rate':return True # USD funding/discount rates: cross-market exposure, not assumed coefficient
 if kind=='cbr_rate':return p.region=='RU' or s in {'RUB=X','CNYRUB'}
 if kind=='ecb_rate':return p.region=='EU' or s in {'EURUSD=X','GC=F','SI=F'}
 if kind=='boe_rate':return s in {'^FTSE','GBPUSD=X'}
 if kind=='boj_rate':return s in {'^N225','JPY=X','CNY=X','^HSI'}
 return False

def session_spec(symbol):
 p=FE.asset_profile(symbol)
 if p.asset_class=='crypto':return 'UTC','23:59'
 if p.region=='RU' or symbol in {'RUB=X','CNYRUB'}:return 'Europe/Moscow','18:50'
 if symbol=='^N225':return 'Asia/Tokyo','15:00'
 if symbol=='^HSI':return 'Asia/Hong_Kong','16:00'
 if p.region=='EU':return 'Europe/London','16:30'
 return 'America/New_York','16:00'

def event_session(e,index,symbol):
 d=pd.Timestamp(e['date']);tz,close_time=session_spec(symbol)
 if e.get('scheduled_at'):
  local=utc(e['scheduled_at']).tz_convert(tz);d=local.tz_localize(None).normalize()
  exact=DATA13.market(symbol)[2]
  close=DATA13.session_close(symbol,d) if exact else None
  if (exact and (pd.isna(close) or utc(e['scheduled_at'])>=close)) or (not exact and local.strftime('%H:%M')>=close_time):d+=pd.Timedelta(days=1)
 i=int(index.searchsorted(d))
 if i>=len(index) or (index[i]-d).days>4:return None
 return i

def summary(a):
 a=np.asarray(a,float);a=a[np.isfinite(a)]
 if not len(a):return {'n':0}
 n=len(a);win=float(np.mean(a>0));z=1.96;den=1+z*z/n;center=(win+z*z/(2*n))/den;half=z*np.sqrt(win*(1-win)/n+z*z/(4*n*n))/den
 return {'n':n,'median_return_pct':round(float(np.median(a)),4),'median_abs_pct':round(float(np.median(abs(a))),4),'q10_pct':round(float(np.quantile(a,.1)),4),'q90_pct':round(float(np.quantile(a,.9)),4),'positive_share':round(win,4),'positive_share_ci95':[round(center-half,4),round(center+half,4)]}

def scale_audit(samples):
 """Candidate predicts abs event return / prior trailing median(abs daily return).
 Train only on earlier events. Event dates reconstructed ex post are disclosed;
 therefore passing this diagnostic alone is NOT production probability approval.
 """
 pairs=[];history=[]
 for r in samples:
  y=r.get('normalized_abs')
  if y is None:continue
  if len(history)>=12:
   factor=1+(float(np.median(history))-1)*len(history)/(len(history)+24)
   factor=float(np.clip(factor,.75,2.5))
   pairs.append(abs(y-1)-abs(y-factor))
  history.append(y)
 n=len(pairs);mean=float(np.mean(pairs)) if n else None;ci=None
 if n>=8:
  rng=np.random.default_rng(440109);a=np.asarray(pairs);block=3;vals=[]
  for _ in range(400):
   starts=rng.integers(0,n,size=math.ceil(n/block));idx=np.concatenate([(s+np.arange(block))%n for s in starts])[:n];vals.append(float(a[idx].mean()))
  ci=[float(np.quantile(vals,.005)),float(np.quantile(vals,.995))] # 99%, conservative across event families
 factor=1+(float(np.median(history))-1)*len(history)/(len(history)+24) if history else 1
 ok=bool(n>=12 and ci and ci[0]>0 and factor>1)
 return {'n_test':n,'mae_improvement':mean,'improvement_ci99':ci,'diagnostic_pass':ok,'factor':round(float(np.clip(factor,1,2.5)),4),'production_approved':False,'reason':'Проверка масштаба по последовательным событиям; исторические версии расписания не восстановлены. Это исследовательская оценка.'}

def study(close,symbol,kind,events,as_of):
 x=clean(close,as_of);rets=np.log(x/x.shift(1))*100;rows=[];seen=set()
 for e in sorted(events,key=lambda r:r['date']):
  if e['type']!=kind or pd.Timestamp(e['date'])>=utc(as_of).tz_localize(None).normalize():continue
  i=event_session(e,x.index,symbol)
  if i is None or i<21 or i in seen:continue
  seen.add(i)
  if (x.index[i]-x.index[i-1]).days>5:continue
  base=float(np.median(abs(rets.iloc[max(1,i-60):i])))
  ret=float(rets.iloc[i]);r={'date':e['date'],'response_session':str(x.index[i].date()),'day_pct':ret,'pre_day_pct':float(rets.iloc[i-1]),'normalized_abs':abs(ret)/base if base>1e-8 else None}
  for h in [1,5]:
   r[f'post_{h}d_pct']=float(np.log(x.iloc[i+h]/x.iloc[i])*100) if i+h<len(x) else None
  rows.append(r)
 # Comparable non-event days in the same observed span, no future observations.
 start=pd.Timestamp(rows[0]['response_session']) if rows else x.index[-1] if len(x) else pd.Timestamp('2100-01-01')
 normal=[float(v) for i,v in enumerate(rets) if i not in seen and x.index[i]>=start and pd.notna(v)]
 return {'type':kind,'label':CAL.LABELS.get(kind,kind),'event_day':summary([r['day_pct'] for r in rows]),'before_day':summary([r['pre_day_pct'] for r in rows]),'after_1d':summary([r['post_1d_pct'] for r in rows if r['post_1d_pct'] is not None]),'after_5d':summary([r['post_5d_pct'] for r in rows if r['post_5d_pct'] is not None]),'other_days':summary(normal),'scale_validation':scale_audit(rows),'rows':rows,'causal_effect':False,'unit':'log_return_percent','session_basis':'previous_local_close_to_first_close_after_release'}

def news_risks(symbol,now,news=None):
 out=[];profile=FE.asset_profile(symbol)
 for r in FE._read_seed_news() if news is None else news:
  if not EC14.available(r):continue
  text=f"{r.get('title','')} {r.get('summary','')}"
  if not re.search(r'санкц|войн|эскалац|конфликт|тариф|пошлин|выбор|дефолт|блокад|sanction|war\b|conflict|tariff|election|default|blockade',text,re.I):continue
  stamp=r.get('published_at') or r.get('published') or r.get('date')
  if not stamp:continue
  try:age=(utc(now)-utc(stamp)).total_seconds()/86400
  except Exception:continue
  if not 0<=age<=7:continue
  if FE._symbol_relevance(symbol,profile,r)<.35:continue
  out.append({'title':str(r.get('title') or '')[:220],'published_at':str(stamp),'source_url':r.get('url') or r.get('link'),'direction_used':False,'age_hours':round(age*24,2)})
 return list({r['title']:r for r in out}.values())[:5]

def build(close,symbol,horizon,*,as_of=None,calendar=None,news=None):
 now=utc(as_of or pd.Timestamp.now(tz='UTC'));cal=calendar if calendar is not None else CAL.load();x=clean(close,now)
 intraday=str(horizon) in {'30m','1h','2h','4h'};h=1 if intraday else max(1,int(horizon))
 if intraday:end=now+pd.Timedelta(minutes={'30m':30,'1h':60,'2h':120,'4h':240}[str(horizon)])
 else:
  period=DATA13.target_period(symbol,x.index[-1] if len(x) else now,h)
  end=utc(period['target_close_utc']) if period.get('target_close_utc') else now+pd.Timedelta(days=h*2)
 window_exact=intraday or bool(period.get('target_close_utc'))
 events=[e for e in cal.get('events',[]) if relevant(e['type'],symbol)]
 upcoming=[];recent_releases=[];unknown_time=False
 for e in events:
  try:
   if utc(e['first_seen_at'])>now:continue
   t=utc(e['scheduled_at']) if e.get('scheduled_at') else utc(e['date'])
   if not e.get('scheduled_at'):
    if now.normalize()<=t<=end.normalize():unknown_time=True;upcoming.append({**e,'hours_until':None})
   elif now<=t<=end:upcoming.append({**e,'hours_until':round((t-now).total_seconds()/3600,2)})
   elif t<now<=t+pd.Timedelta(hours=24):recent_releases.append({**e,'hours_since':round((now-t).total_seconds()/3600,2)})
  except Exception:continue
 upcoming.sort(key=lambda e:e.get('scheduled_at') or e['date'])
 kinds=sorted(set(e['type'] for e in events));studies=[]
 for kind in kinds:studies.append(study(x,symbol,kind,events,now))
 # Calendar data cannot establish a causal effect, and broad daily candles cannot
 # isolate a 30-minute announcement reaction. Do not rescale intraday using daily study.
 rets=np.log(x/x.shift(1)).dropna();short=float(rets.tail(20).std()) if len(rets)>=20 else None;long=float(rets.tail(120).std()) if len(rets)>=120 else None
 ratio=short/long if short and long and long>0 else None
 stress={'realized_vol_ratio_20_120':round(ratio,3) if ratio else None,'elevated':bool(ratio and ratio>=1.5),'basis':'собственная реализованная волатильность актива; это не VIX и не стакан'}
 political=news_risks(symbol,now,news)
 near=[e for e in upcoming if e['hours_until'] is None or e['hours_until']<=24]
 # Explicit risk policy, not an estimated probability: new orders should not be
 # presented as an unconditional directional edge across an unresolved release.
 guard=bool(end<=now or near or recent_releases or (stress['elevated'] and any(n['age_hours']<=24 for n in political)))
 age=None
 try:age=max((now-utc(e.get('last_checked_at') or cal['retrieved_at'])).total_seconds()/86400 for e in events) if events else None
 except Exception:pass
 missing=['PMI/ISM, розница, заявки на пособие','инфляция и ВВП вне США','OPEC+, запасы EIA, решения НБК','отчётность отдельных компаний и неожиданные политические решения']
 return {'version':VERSION,'as_of':now.isoformat(),'price_history_through':str(x.index[-1].date()) if len(x) else None,'horizon':str(horizon),'horizon_end_utc':end.isoformat(),'horizon_calendar_exact':window_exact,'status':'ok' if events else 'calendar_unavailable','upcoming':upcoming[:30],'upcoming_count':len(upcoming),'recent_releases':recent_releases,'studies':studies,'market_stress':stress,'political_news':political,'forecast_expired':bool(end<=now),'signal_guard':guard,'guard_reason':('Срок этого расчёта уже завершился: нужна свежая закрытая история и новый прогноз.' if end<=now else 'Близкое или недавно вышедшее событие либо политический риск на напряжённом рынке: направленный сигнал требует повторной оценки после обновления данных.') if guard else None,'direction_adjustment_pp':0,'intraday_study_available':False,'calendar_age_days':round(age,2) if age is not None else None,'calendar_stale':age is None or age>7,'uncovered':missing,'limitations':'Наблюдаемая реакция за торговый день включает другие новости. Это не причинный эффект и не гарантированное движение. Исторического консенсуса и полной истории расписаний до публикации нет.'}

def apply(forecast,close,symbol,horizon,*,as_of=None):
 out=dict(forecast);now=utc(as_of or pd.Timestamp.now(tz='UTC'));cal=CAL.load()
 # Reuse heavy descriptive studies; the forecast/live event policy is keyed by minute.
 x=pd.Series(close,dtype=float);key=(symbol,str(horizon),now.floor('min').isoformat(),cal.get('retrieved_at'),DATA13.series_hash(x),DATA13.dependency_fingerprint())
 if key in _CACHE:context=_CACHE[key]
 else:
  context=build(close,symbol,horizon,as_of=now,calendar=cal)
  if len(_CACHE)>100:_CACHE.clear()
  _CACHE[key]=context
 out['macro_events']=context
 if context['signal_guard']:
  out['base_abstain']=out.get('abstain');out['abstain']=True;out['signal_strength']='событийный риск';out['event_signal_guard']=True
  # Core percentages/reliability are preserved as a conditional technical baseline.
  # No claim that abstention improves calibrated forecast performance.
  keytext='summary' if 'summary' in out else 'reason'
  out[keytext]=(out.get(keytext) or '')+' Прогноз требует осторожности: '+context['guard_reason']
 return out
