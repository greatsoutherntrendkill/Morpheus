# Morpheus v3.3 — Honest Champion/Challenger Benchmark

v3.3 does **not** replace the production champion automatically. It adds a locked,
reproducible benchmark of the existing Logistic Regression champion against two
non-linear challengers: LightGBM and CatBoost.

## What changed

- Added `challenger_models.py` with three model adapters using the exact same feature
  matrix, labels, purged walk-forward splits and frozen final holdout.
- Frozen challenger versions:
  - `lightgbm-v3.3.0`
  - `catboost-v3.3.0`
- Existing production champion stays `logreg-v3.2.0` until a manual promotion is justified.
- Hyperparameters are fixed in code before the final holdout is inspected.
- Final holdout is never used for tuning or the development quality gate.
- Added paired moving-block bootstrap against the champion on identical holdout dates.
- Added direct challenger-vs-champion deltas:
  - accuracy delta;
  - Brier improvement;
  - 95% paired bootstrap confidence intervals;
  - one-sided empirical p-values.
- Added Holm-Bonferroni correction across the benchmark family.
- Added 1D economic evidence after configurable one-way costs (default 2 bps):
  net Sharpe, total turnover and net log-return.
- Added a conservative portfolio-level promotion review gate. It can only mark a
  challenger **eligible for manual review**; it never promotes automatically.
- Challenger live probabilities are appended to the immutable prediction ledger under
  their own registered model versions.
- Added `/api/model-benchmark`.
- Added `benchmark_v33.py`, JSON/CSV benchmark exports and v3.3 integrity tests.

## Run

```bash
pip install -r requirements.txt
python update.py
python export_site.py
python benchmark_v33.py
python test_model_governance.py
python test_challenger_v33.py
python smoke_test.py
uvicorn api:app --reload --port 8000
```

Optional targeted benchmark:

```bash
python benchmark_v33.py --symbols "^GSPC,BTC-USD,EURUSD=X" --horizons "1,5,10,20"
```

## Promotion policy

A challenger needs multiple-testing-controlled frozen-holdout wins, no significant
holdout regression, positive median Brier improvement, and a meaningful median
1D net-Sharpe improvement after costs. Even then, v3.3 only marks it eligible for
manual promotion review. Promotion requires registering a new immutable champion version.

This prevents the final holdout from becoming another tuning set.
