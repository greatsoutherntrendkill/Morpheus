from alternative_data_v38 import build_snapshot
import json
s=build_snapshot(force=True)
print(json.dumps({
    'version':s.get('version'),
    'generated_at':s.get('generated_at'),
    'crypto':(s.get('crypto') or {}).get('status'),
    'options':(s.get('options') or {}).get('status'),
    'energy':(s.get('energy') or {}).get('status'),
},ensure_ascii=False,indent=2))
