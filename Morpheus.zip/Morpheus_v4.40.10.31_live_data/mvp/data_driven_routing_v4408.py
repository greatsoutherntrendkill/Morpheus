"""Morpheus v4.40.8 — Data-Driven Routing wrapper.

Prediction mathematics stay in the validated v4.40.7 robustness stack.  v4.40.8
changes *how components are routed*: OOS learns champion/regime blend weights and
settled prospective history may learn a publication trust gate after chronological
validation.  Hand-written asset priors and disagreement/drift/event threshold
penalties are no longer part of the performance router.
"""
from __future__ import annotations

import robustness_v4407 as BASE
import forecast_contract_v4406 as CONTRACT
import routing_policy_v4408 as ROUTE

VERSION="data-driven-routing-v4.40.8"
MODEL_GENERATION=CONTRACT.MODEL_GENERATION
TARGET4405=BASE.TARGET4405


def forecast_horizon(close, symbol: str, horizon: int=10, fast: bool=True, context: dict|None=None) -> dict:
    out=BASE.forecast_horizon(close,symbol=symbol,horizon=int(horizon),fast=fast,context=context)
    if not out:return {}
    out=dict(out)
    out["base_model_version"]=out.get("version")
    out["version"]=VERSION
    out["model_generation"]=MODEL_GENERATION
    routing=out.get("data_driven_routing") or {}
    out["routing_version"]=ROUTE.VERSION
    out["routing_policy"]={
        "version":ROUTE.VERSION,
        "core_blend_source":"chronological OOS Brier optimization with recent validation",
        "prospective_publish_source":"settled prospective evidence after fit/threshold/untouched-eval validation",
        "prospective_router_active":bool(((routing.get("prospective_publish") or {}).get("active"))),
        "prospective_router_reason":((routing.get("prospective_publish") or {}).get("reason")),
        "manual_asset_prior":False,
        "manual_disagreement_penalty":False,
        "manual_drift_event_threshold_penalty":False,
        "automatic_champion_promotion":False,
    }
    val=dict(out.get("validation") or {})
    val.update({"routing_version":VERSION,"data_driven_routing":True,"routing_policy_version":ROUTE.VERSION,
                "manual_performance_routing_reduced":True,"prospective_router_requires_untouched_audit":True})
    out["validation"]=val
    return out
