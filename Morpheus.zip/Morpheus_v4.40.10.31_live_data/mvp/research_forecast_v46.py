
"""Morpheus v4.6 — пользовательский макро-прогноз.

Модуль намеренно прост: он превращает уже отображаемые на сайте текущие
макро-показатели, направления и календарь ставок в понятные траектории
1 месяц / 6 месяцев / 1 год.

Это сценарная исследовательская оценка Morpheus, а не консенсус-прогноз
экономистов и не заранее утверждённое решение центрального банка.
"""
from __future__ import annotations
import math, re

HORIZONS=("1m","6m","1y")
HORIZON_LABELS={"1m":"1 месяц","6m":"6 месяцев","1y":"1 год"}

def _first_num(s):
    s=str(s or "").replace(",",".").replace("–","-")
    m=re.search(r"(-?\d+(?:\.\d+)?)",s)
    return float(m.group(1)) if m else None

def _kind(row):
    ind=(row.get("indicator") or "").lower()
    val=str(row.get("value") or "")
    if "кредит" in ind:
        return "qual"
    if "госдолг" in ind and "$" in val:
        return "trillion"
    if "%" in val or "ввп" in val.lower():
        return "percent"
    return "number"

QUAL_LEVEL={
    "сжатие":-2.0,"сильное снижение":-2.0,"снижение":-1.4,
    "замедление":-0.8,"слабый рост":0.35,"стабилизация":0.0,
    "без изменений":0.0,"умеренный рост":0.8,"рост":1.4,
}
def _qual_score(s):
    t=str(s or "").lower()
    for k,v in QUAL_LEVEL.items():
        if k in t:return v
    return 0.0

def _qual_text(v):
    if v<=-1.4:return "сжатие"
    if v<=-.55:return "замедление"
    if v<.35:return "стабилизация"
    if v<1.1:return "умеренный рост"
    return "рост"

def macro_projection(row):
    country=row.get("country","")
    ind=row.get("indicator","")
    value=row.get("value","—")
    fc=row.get("forecast","")
    factors=row.get("factors","")
    direction=float(row.get("dir") or 0)
    kind=_kind(row)
    current=_first_num(value)
    low_conf=("~" in str(value) or "около" in str(value).lower() or "умерен" in str(value).lower())

    # Indicator-specific drift makes the result more meaningful than a generic
    # +/− percentage while keeping assumptions intentionally conservative.
    key=(country,ind)
    rules={
      ("США","Безработица"):(0.05,0.20,0.30),
      ("Россия","Безработица"):(0.00,0.10,0.20),
      ("США","Госдолг"):(0.20,1.05,2.10),
      ("Россия","Госдолг"):(0.15,0.75,1.50),
      ("США","Дефицит бюджета"):(0.00,0.15,-0.15),
      ("Россия","Дефицит бюджета"):(0.10,0.35,0.10),
    }

    out=[]
    if kind=="qual":
        cur=_qual_score(value)
        target=_qual_score(fc)
        if target==0 and direction:
            target=.9*direction
        vals=[cur, cur+(target-cur)*.25, cur+(target-cur)*.70, target]
        labels=[str(value),_qual_text(vals[1]),_qual_text(vals[2]),_qual_text(vals[3])]
        for h,v,l in zip(("now","1m","6m","1y"),vals,labels):
            out.append({"horizon":h,"value":round(v,3),"display":l})
    elif current is not None:
        drift=rules.get(key)
        if drift is None:
            # Conservative generic path for percentages/numbers.
            sign=1 if direction>0 else -1 if direction<0 else 0
            scale=max(abs(current)*.015,.05)
            drift=(sign*scale*.25,sign*scale,sign*scale*1.65)
        vals=[current,current+drift[0],current+drift[1],current+drift[2]]
        for h,v in zip(("now","1m","6m","1y"),vals):
            if kind=="trillion":
                disp=f"~${v:.1f} трлн"
            elif kind=="percent":
                disp=f"~{v:.1f}%"
                if "ввп" in str(value).lower():disp+=" ВВП"
            else:
                disp=f"~{v:.2f}"
            out.append({"horizon":h,"value":round(v,4),"display":str(value) if h=="now" else disp})
    else:
        # Text-only indicators still get a visual direction index, explicitly
        # normalized so it is not mistaken for an observed macro value.
        target=1 if direction>0 else -1 if direction<0 else _qual_score(fc)
        vals=[0,target*.25,target*.7,target]
        labels=[str(value),"почти без изменений",fc or _qual_text(target),fc or _qual_text(target)]
        for h,v,l in zip(("now","1m","6m","1y"),vals,labels):
            out.append({"horizon":h,"value":round(v,3),"display":l})

    return {
        "country":country,"indicator":ind,"current":value,
        "forecast_text":fc,"factors":factors,
        "path":out,"confidence":"умеренная" if not low_conf else "пониженная",
        "chart_mode":"qualitative" if kind=="qual" or current is None else "numeric",
    }

def _event_for_country(country,events):
    map_cb={"США":"ФРС","Еврозона":"ЕЦБ","Россия":"Банк России"}
    cb=map_cb.get(country)
    if not cb:return None
    return next((e for e in events if e.get("cb")==cb),None)

def _trend_bias(trend):
    t=str(trend or "").lower()
    if "повыш" in t and "затем" not in t:return .25
    if "сниж" in t and "после сниж" not in t:return -.25
    if "пауза после сниж" in t or "удержание после сниж" in t:return -.10
    if "удержание после повыш" in t:return .08
    return 0.0

def rate_projection(row,events):
    current=float(row.get("rate") or 0)
    ev=_event_for_country(row.get("country"),events)
    bias=_trend_bias(row.get("trend"))
    if ev:
        p=ev.get("rate_probabilities") or {}
        # Expected next 25bp step. This is a scenario-weighted estimate, not an
        # approved future rate.
        next_delta=.25*((float(p.get("hike",0))-float(p.get("cut",0)))/100)
    else:
        next_delta=bias*.35

    # Respect explicit next-step forecast where present.
    f=str(row.get("forecast") or "")
    m=re.search(r"([+-]?\d+)\s*б",f,re.I)
    if m:
        next_delta=float(m.group(1))/100

    one_m=current+next_delta
    six_m=one_m+bias*2.0
    one_y=six_m+bias*2.0
    # No negative policy rates in this simplified UI model.
    vals=[current,max(-.5,one_m),max(-.5,six_m),max(-.5,one_y)]
    path=[{"horizon":h,"value":round(v,3),"display":f"{v:.2f}%"} for h,v in zip(("now","1m","6m","1y"),vals)]
    next_meeting=None
    if ev:
        probs=ev.get("rate_probabilities") or {}
        next_meeting={
            "date":ev.get("date"),"event":ev.get("event"),
            "estimated_rate":round(one_m,3),
            "probabilities":probs,
        }
    return {
        "country":row.get("country"),"rate_name":row.get("rate_name"),
        "current":current,"as_of":row.get("as_of"),"trend":row.get("trend"),
        "path":path,"next_meeting":next_meeting,
        "note":"Текущая ставка — фактическая. Будущие значения — модельная оценка, не утверждённое решение.",
    }

def build(payload):
    macros=[macro_projection(x) for x in payload.get("macro_stats") or []]
    events=payload.get("events") or []
    rates=[rate_projection(x,events) for x in payload.get("rates") or []]
    return {
        "version":"4.6",
        "horizons":[{"id":h,"label":HORIZON_LABELS[h]} for h in HORIZONS],
        "macro":macros,
        "rates":rates,
        "method_note":"Прогноз показывает базовую траекторию Morpheus при сохранении текущих условий. Он обновляется вместе с исходными данными.",
    }
