"""Versioned model-input contract. Charts may show live bars; forecasts may not.

Daily targets are price returns (fractions internally, percent only for display),
not total shareholder returns. Unknown corporate/roll adjustments are never guessed.
"""
from __future__ import annotations
import hashlib
import json
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd

VERSION = 'data-contract-v4.40.10.13'
CALENDAR_VERSION = 'exchange-calendars-4.11.2'
OHLC = ['open', 'high', 'low', 'close']


def utc(value=None):
    t = pd.Timestamp.now(tz='UTC') if value is None else pd.Timestamp(value)
    return t.tz_localize('UTC') if t.tzinfo is None else t.tz_convert('UTC')


def market(symbol):
    import market_universe_v416 as U
    s = str(symbol).upper()
    if s in {'BTC-USD','ETH-USD','SOL-USD','XRP-USD'}: return '24/7', 'UTC', True
    if U.is_us_equity(s) or s in {'^GSPC','^NDX','^DJI','^RUT'}: return 'XNYS', 'America/New_York', True
    spec={'^GDAXI':('XETR','Europe/Berlin'),'^FTSE':('XLON','Europe/London'),'^FCHI':('XPAR','Europe/Paris'),'^N225':('XTKS','Asia/Tokyo'),'^HSI':('XHKG','Asia/Hong_Kong')}
    if s in spec: return *spec[s], True
    if s.endswith('.ME') or s in {'IMOEX','RTSI','MOEXBC','RGBI'}: return 'MOEX_PROVIDER_SESSIONS', 'Europe/Moscow', False
    if s.endswith('=X') or s=='CNYRUB': return 'FX_PROVIDER_SESSIONS', 'America/New_York', False
    return 'PROVIDER_SESSIONS', 'UTC', False


@lru_cache(maxsize=20)
def calendar(name):
    import exchange_calendars as xc
    return xc.get_calendar(name, start='2000-01-01', end='2030-12-31')


def session_close(symbol, date):
    name, tz, exact = market(symbol)
    day=pd.Timestamp(date).tz_localize(None).normalize()
    if name=='24/7': return day.tz_localize('UTC')+pd.Timedelta(days=1)
    if exact:
        try: return calendar(name).schedule.loc[str(day.date()),'close']
        except (ValueError, KeyError): return pd.NaT
    # Until a provider gives a verified session-close timestamp, wait until the
    # following local day. Do not invent a closing auction for MOEX/FX/futures.
    return (day+pd.Timedelta(days=1)).tz_localize(tz).tz_convert('UTC')


def target_period(symbol, as_of, horizon):
    name, tz, exact=market(symbol); day=pd.Timestamp(as_of).tz_localize(None).normalize(); h=int(horizon)
    if h<=0: raise ValueError('positive horizon required')
    out={'origin_session':str(day.date()),'observations':h,'calendar':name,'calendar_version':CALENDAR_VERSION,
         'target_date':None,'target_close_utc':None,'date_status':'provider_schedule_required',
         'label':f'{h} торговых сессий' if exact else f'{h} дневных наблюдений','note':'Дата завершения зависит от календаря поставщика; календарные дни не подставляются вместо торговых сессий.'}
    if name=='24/7':
        end=day+pd.Timedelta(days=h)
        out.update(label=f'{h} календарных дней',target_date=str(end.date()),target_close_utc=session_close(symbol,end).isoformat(),date_status='scheduled',note='Крипторынок: дневные свечи UTC, включая выходные.')
    elif exact:
        try:
            sessions=calendar(name).schedule.loc[str((day+pd.Timedelta(days=1)).date()):str((day+pd.Timedelta(days=h*4+40)).date())].index
            end=sessions[h-1]
            out.update(target_date=str(end.date()),target_close_utc=session_close(symbol,end).isoformat(),date_status='scheduled',note='Срок отсчитывается от последней закрытой свечи по календарю биржи; внеплановые остановки могут сдвинуть дату.')
        except (ValueError,IndexError,KeyError): pass
    return out


def yahoo_price_frame(frame, result):
    """Yahoo quote OHLC are split-adjusted price levels. Do not apply adjclose:
    it also removes dividends and would silently change the price-return target.
    """
    d=frame.copy()
    d.attrs['price_basis']='split_adjusted_price'
    d.attrs['timestamp_kind']='utc_instant'
    d.attrs['exchange_timezone']=(result.get('meta') or {}).get('exchangeTimezoneName')
    d.attrs['corporate_events']=result.get('events') or {}
    return d


def fingerprint(frame, symbol, source, interval='1d'):
    cols=[c for c in ['date',*OHLC] if c in frame]
    rows=[[pd.Timestamp(r[0]).isoformat(),*[float(x) for x in r[1:]]] for r in frame[cols].itertuples(index=False,name=None)]
    obj={'version':VERSION,'symbol':symbol,'source':source,'interval':interval,'rows':rows,
         'price_basis':frame.attrs.get('price_basis','provider_price'), 'corporate_events':frame.attrs.get('corporate_events',{})}
    return hashlib.sha256(json.dumps(obj,sort_keys=True,allow_nan=False,default=str,separators=(',',':')).encode()).hexdigest()


def prepare(frame, symbol, source='', *, now=None, interval_minutes=None):
    """Return only unambiguous, completed input. Never interpolate missing closes.
    Provider date-only bars keep their trade-date label; UTC instants convert to
    exchange-local dates. For ambiguous duplicate revisions, discard that date.
    """
    attrs=dict(getattr(frame,'attrs',{})); d=pd.DataFrame(frame).copy().reset_index(drop=True)
    audit={'version':VERSION,'source':source,'input_rows':len(d),'return_unit':'log_return_fraction','distribution_return_unit':'log_return_percent','display_return_unit':'simple_price_percent',
           'target_basis':'price_return_excluding_cash_dividends','calendar':market(symbol)[0],
           'price_basis':attrs.get('price_basis','provider_price_adjustment_unverified'),'warnings':[]}
    if d.empty or not {'date','close'}<=set(d):
        audit.update(accepted_rows=0,status='unavailable');return pd.DataFrame(columns=['date',*OHLC]),audit
    ts=pd.to_datetime(d['date'],errors='coerce',utc=True)
    if interval_minutes is None:
        tz=attrs.get('exchange_timezone') or market(symbol)[1]
        # All-midnight timestamps denote provider trade dates, not local instants.
        instant=attrs.get('timestamp_kind')=='utc_instant' or bool(((ts.dropna().dt.hour!=0)|(ts.dropna().dt.minute!=0)).any())
        days=ts.dt.tz_convert(tz).dt.tz_localize(None).dt.normalize() if instant else ts.dt.tz_localize(None).dt.normalize()
        ends=days.map(lambda x: session_close(symbol,x) if pd.notna(x) else pd.NaT)
        d['date']=days
    else:
        d['date']=ts.dt.tz_convert(None)
        ends=ts+pd.Timedelta(minutes=int(interval_minutes))
    complete=pd.to_datetime(ends,utc=True,errors='coerce')+pd.Timedelta(seconds=60)<=utc(now)
    audit['unfinished_or_non_session_rows']=int((~complete).sum());d=d.loc[complete].copy()
    for col in OHLC:
        if col not in d: d[col]=d['close']
        d[col]=pd.to_numeric(d[col],errors='coerce')
    valid=np.isfinite(d[OHLC]).all(axis=1)&(d[OHLC]>0).all(axis=1)&(d.high>=d[['open','close','low']].max(axis=1))&(d.low<=d[['open','close','high']].min(axis=1))
    audit['invalid_rows']=int((~valid).sum());d=d.loc[valid].copy()
    conflicts=d.groupby('date')[OHLC].nunique().max(axis=1); bad=conflicts[conflicts>1].index
    audit['conflicting_dates']=len(bad); d=d.loc[~d.date.isin(bad)].drop_duplicates('date').sort_values('date').reset_index(drop=True)
    if interval_minutes is None and len(d)>1 and market(symbol)[2]:
        name=market(symbol)[0]
        expected=pd.date_range(d.date.iloc[0],d.date.iloc[-1],freq='D') if name=='24/7' else calendar(name).schedule.loc[str(d.date.iloc[0].date()):str(d.date.iloc[-1].date())].index
        missing=expected.difference(pd.DatetimeIndex(d.date))
        audit['missing_sessions']=len(missing)
        if len(missing):
            audit['missing_session_dates']=[str(x.date()) for x in missing]
            d=d.loc[d.date>missing[-1]].reset_index(drop=True)
            audit['warnings'].append('В истории пропущены торговые сессии: расчёт использует непрерывный участок после последнего пропуска, без интерполяции цен.')
    # A discontinuity can be a split, a roll or a true crash. Do not "correct"
    # it heuristically. Quarantine the earlier segment pending source evidence.
    if interval_minutes is None and len(d)>1:
        jumps=d.close.pct_change().abs()>0.45
        if jumps.any():
            cut=int(np.flatnonzero(jumps.to_numpy())[-1]);audit['quarantined_before']=str(d.iloc[cut].date.date());audit['quarantined_rows']=cut
            d=d.iloc[cut:].reset_index(drop=True)
            audit['warnings'].append('Резкий разрыв истории: ранняя часть исключена до проверки корпоративного события или смены контракта.')
    if str(symbol).endswith('=F'):
        audit['roll_policy']='provider_continuous_unverified';audit['warnings'].append('Непрерывный фьючерс: календарь смены контрактов и корректировка склейки поставщиком не подтверждены.')
    if str(symbol).endswith('.ME') and attrs.get('price_basis')!='split_adjusted_price':
        audit['warnings'].append('Архив сплитов поставщиком не подтверждён; дивидендные гэпы входят в изменение цены.')
    if not market(symbol)[2]: audit['warnings'].append('Точная будущая дата не публикуется без подтверждённого календаря сессий этого ряда.')
    d.attrs.update(attrs)
    audit.update(accepted_rows=len(d),status='ok' if len(d) else 'unavailable',data_hash=fingerprint(d,symbol,source,'1d' if interval_minutes is None else f'{interval_minutes}m'),
                 as_of=None if d.empty else pd.Timestamp(d.iloc[-1].date).isoformat())
    return d,audit


def calculation_key(audit, horizon, mode, generation, context=None):
    obj={'contract':VERSION,'model':generation,'as_of':audit.get('as_of'),'data_hash':audit.get('data_hash'),
         'horizon':horizon,'mode':mode,'dependencies':audit.get('dependency_hash'),'context':context or {}}
    return hashlib.sha256(json.dumps(obj,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()


def decorate(forecast, audit, symbol, horizon, mode):
    out=dict(forecast);out['data_integrity']=audit
    out['return_units']={'target':'log_return_fraction','distribution_and_movement':'log_return_percent','price_from_log_pct':'price * exp(log_pct / 100)','display_pct':'100 * expm1(log_pct / 100)'}
    if audit.get('as_of') and str(horizon).isdigit():
        out['target_period']=target_period(symbol,audit['as_of'],int(horizon))
        if out.get('summary'):out['summary']=out['summary'].replace(f'{horizon} дн.',out['target_period']['label'])
    out['calculation_identity']={'key':calculation_key(audit,horizon,mode,out.get('model_generation')), 'mode':mode,'data_hash':audit.get('data_hash'),'version':VERSION}
    return out


def series_hash(series):
    s=pd.Series(series,dtype=float)
    payload=[[pd.Timestamp(t).isoformat(),float(v) if pd.notna(v) else None] for t,v in s.items()]
    return hashlib.sha256(json.dumps(payload,separators=(',',':'),allow_nan=False).encode()).hexdigest()


@lru_cache(maxsize=256)
def _file_hash(path, size, mtime_ns):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dependency_fingerprint():
    """Content fingerprint, including SQLite WAL. No secrets or .env contents."""
    import os
    from persistent_state_v44010 import data_root
    root=Path(__file__).resolve().parent
    files=list(root.glob('*.py'))+list(root.glob('*.csv'))+[root/'macro_calendar_v440109.json',root/'market.db']
    files+=list(root.glob('*.db-wal'))
    for pattern in ('*.sqlite3','*.sqlite3-wal','*.db','*.db-wal'):
        files+=list(data_root().glob('events/'+pattern))+list(data_root().glob('governance/'+pattern))+list(data_root().glob('evidence/'+pattern))
        files+=list((root/'runtime_cache').glob(pattern))
    for key in ('ALLANALYTICS_EVENT_DB','ALLANALYTICS_PROMOTION_DB','ALLANALYTICS_FEEDBACK_DB','ALLANALYTICS_DISTRIBUTION_FEEDBACK_DB'):
        if os.getenv(key):
            q=Path(os.environ[key]).expanduser();files.extend([q,Path(str(q)+'-wal')])
    manifest={str(p.relative_to(root)) if p.is_relative_to(root) else str(p):_file_hash(str(p),p.stat().st_size,p.stat().st_mtime_ns) for p in files if p.is_file()}
    # Model switches influence numerical output. Exclude credentials by allowlist.
    manifest['settings']={k:v for k,v in sorted(os.environ.items()) if k.startswith(('MODEL_','FORECAST_','DISTRIBUTION_','SPECIALIST_','META_','REGIME_')) and not any(x in k for x in ('KEY','TOKEN','SECRET','PASSWORD'))}
    manifest['runtime']=runtime_versions()
    manifest['evaluation_date_utc']=str(utc().date())
    manifest['final_holdout_start']=os.getenv('FINAL_HOLDOUT_START')
    return hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()


def persist_input(frame, audit, symbol):
    """Store immutable accepted OHLC for exact input replay, separate from live cache."""
    from persistent_state_v44010 import data_root
    from uuid import uuid4
    out=dict(audit)
    try:
        directory=data_root()/'input_snapshots';directory.mkdir(parents=True,exist_ok=True)
        path=directory/(audit['data_hash']+'.json')
        payload={'symbol':symbol,'audit':audit,'metadata':dict(frame.attrs),'rows':[{**{c:float(getattr(r,c)) for c in OHLC},'date':pd.Timestamp(r.date).isoformat()} for r in frame.itertuples()]}
        if not path.exists():
            tmp=path.with_suffix('.'+uuid4().hex+'.tmp');tmp.write_text(json.dumps(payload,ensure_ascii=False,default=str),encoding='utf-8');tmp.replace(path)
        out.update(snapshot_file=path.name,snapshot_saved=True)
    except (OSError,KeyError,ValueError):out['snapshot_saved']=False
    return out


@lru_cache(maxsize=1)
def runtime_versions():
    from importlib.metadata import version, PackageNotFoundError
    import platform
    out={'python':platform.python_version()}
    for name in ('numpy','pandas','scikit-learn','scipy','exchange-calendars','lightgbm','catboost'):
        try:out[name]=version(name)
        except PackageNotFoundError:out[name]='not_installed'
    return out
