"""Append-only journal of server-issued daily forecasts, separate from research.
No inference or training reads this store. An outcome is never silently revised.
"""
from __future__ import annotations
from contextlib import closing
from pathlib import Path
from functools import lru_cache
import hashlib,json,math,sqlite3
import numpy as np
import pandas as pd
import data_contract_v4401013 as DATA
import target_contract_v4405 as TARGET
import evaluation_clock_v4401014 as CLOCK
from persistent_state_v44010 import data_root

VERSION='issued-forecast-journal-v4.40.10.15'
STATES={
 'awaiting_result':'Срок завершён; ожидается проверка истории','pending':'Срок ещё не завершён','settled':'Итог рассчитан','missing_target':'Нет закрытия на целевую дату',
 'calendar_unverified':'Расписание этого рынка не подтверждено','source_error':'Источник истории недоступен',
 'origin_missing':'В полученной истории нет исходной свечи','origin_revised':'Поставщик пересмотрел исходную цену',
 'future_origin':'Исходная свеча ещё не закрыта','invalid_contract':'Не хватает исходных данных прогноза','late_issue':'Прогноз выдан после первого следующего дневного закрытия',
 'history_gap':'В проверяемом отрезке пропущена торговая сессия','corrupt_snapshot':'Нарушена целостность сохранённого прогноза',
 'data_conflict':'В истории конфликтующие цены на одну дату','unsupported_horizon':'Внутридневная проверка ещё не подключена',
}

def stamp(value=None):return DATA.utc(value).isoformat()
def dump(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False,default=str)
def hashof(x):return hashlib.sha256(dump(x).encode()).hexdigest()
def number(x):
 try:
  v=float(x);return v if math.isfinite(v) else None
 except (TypeError,ValueError):return None

def probabilities(f):
 p=f.get('class_probabilities') or {};v=[number(p.get(k)) for k in ('down','neutral','up')]
 if any(x is None or x<0 or x>1 for x in v) or abs(sum(v)-1)>2e-5:return None
 return dict(zip(('down','neutral','up'),[x/sum(v) for x in v]))

class Journal:
 def __init__(self,path=None):
  self.path=Path(path or data_root()/'issued_forecasts'/'journal.sqlite3');self.path.parent.mkdir(parents=True,exist_ok=True)
  with closing(self.connect()) as c, c:
   c.executescript('''
   CREATE TABLE IF NOT EXISTS issues(
    id INTEGER PRIMARY KEY, issue_key TEXT UNIQUE NOT NULL, group_key TEXT NOT NULL,
    revision INTEGER NOT NULL, issued_at TEXT NOT NULL, symbol TEXT NOT NULL,horizon TEXT NOT NULL,
    generation TEXT NOT NULL, mode TEXT NOT NULL, origin_date TEXT, target_date TEXT,target_close TEXT,
    eligibility TEXT NOT NULL, snapshot TEXT NOT NULL, snapshot_hash TEXT NOT NULL,
    UNIQUE(group_key,revision));
   CREATE INDEX IF NOT EXISTS issue_group ON issues(group_key,id);
   CREATE INDEX IF NOT EXISTS issue_slice ON issues(symbol,generation,horizon,id);
   CREATE TABLE IF NOT EXISTS outcomes(
    id INTEGER PRIMARY KEY,issue_id INTEGER UNIQUE NOT NULL REFERENCES issues(id),settled_at TEXT NOT NULL,
    result TEXT NOT NULL,result_hash TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS attempts(
    id INTEGER PRIMARY KEY,issue_id INTEGER NOT NULL REFERENCES issues(id),checked_at TEXT NOT NULL,
    state TEXT NOT NULL,reason TEXT NOT NULL);
   CREATE INDEX IF NOT EXISTS attempt_issue ON attempts(issue_id,id DESC);
   CREATE TABLE IF NOT EXISTS failures(id INTEGER PRIMARY KEY,issued_at TEXT NOT NULL,symbol TEXT,origin TEXT,reason TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY,started_at TEXT NOT NULL,finished_at TEXT NOT NULL,result TEXT NOT NULL);
   ''')
   for table in ('issues','outcomes','attempts','failures','runs'):
    for op in ('UPDATE','DELETE'):
     c.execute(f"CREATE TRIGGER IF NOT EXISTS immutable_{table}_{op} BEFORE {op} ON {table} BEGIN SELECT RAISE(ABORT,'immutable journal'); END")
 def connect(self):
  c=sqlite3.connect(self.path,timeout=10);c.row_factory=sqlite3.Row
  c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA synchronous=FULL');c.execute('PRAGMA foreign_keys=ON');return c
 def record(self,payload,origin='api',now=None):
  if CLOCK.active():return {'recorded':False,'skipped':1,'reason':'historical_replay_not_live_issue'}
  now=DATA.utc(now);out={'version':VERSION,'recorded':True,'inserted':0,'existing':0,'issues':[]}
  forecasts=payload.get('forecasts') or {};sym=str(payload.get('symbol') or '').upper()
  if not forecasts:
   with closing(self.connect()) as c, c:c.execute('INSERT INTO failures(issued_at,symbol,origin,reason) VALUES(?,?,?,?)',(stamp(now),sym,origin,'Расчёт не выдал прогноз; история или модель недоступны.'))
   return {**out,'unavailable':1,'issues':[]}
  for h,f in forecasts.items():
   if not isinstance(f,dict):continue
   audit=f.get('data_integrity') or payload.get('data_integrity') or {};gen=f.get('model_generation') or 'unknown';mode=(f.get('calculation_identity') or {}).get('mode') or 'unknown'
   date=(f.get('target_period') or {}).get('origin_session') or audit.get('as_of') or payload.get('as_of')
   hist=payload.get('history') or [];entry=None
   for r in hist:
    if str(r.get('t') or r.get('date'))[:10]==str(date)[:10]:entry=number(r.get('c',r.get('close')))
   guide=f.get('movement_guidance') or {};band=number(guide.get('material_move_threshold_pct'))
   band=band/100 if band is not None else None
   # Full immutable input snapshot is authoritative when the UI history is rounded.
   snap=audit.get('input_snapshot') or audit.get('snapshot_file')
   path=data_root()/'input_snapshots'/(str(audit.get('data_hash'))+'.json')
   if path.is_file():
    try:
     saved=json.loads(path.read_text());rows=saved.get('rows') or []
     if rows and str(rows[-1].get('date'))[:10]==str(date)[:10]:entry=number(rows[-1].get('close'))
    except (OSError,ValueError):pass
   eligibility='eligible';period={}
   if not str(h).isdigit() or int(h)<=0:eligibility='unsupported_horizon'
   elif not date or entry is None or entry<=0 or band is None or band<=0 or probabilities(f) is None or gen=='unknown':eligibility='invalid_contract'
   else:
    try:
     period=DATA.target_period(sym,date,int(h))
     first=DATA.target_period(sym,date,1)
     if not period.get('target_close_utc'):eligibility='calendar_unverified'
     elif now < DATA.utc(DATA.session_close(sym,date))+pd.Timedelta(seconds=60):eligibility='future_origin'
     elif first.get('target_close_utc') and now>=DATA.utc(first['target_close_utc']):eligibility='late_issue'
    except Exception:eligibility='invalid_contract'
   snapshot={'forecast':f,'entry_price':entry,'threshold_log':band,'period':period,'source':payload.get('source'),
             'origin':origin,'input_hash':audit.get('data_hash'),'return_definition':'log(target_close / frozen_origin_close)',
             'issued_before':'first subsequent daily close; intraday elapsed time is not an independent new origin'}
   # Volatile request timestamps/calculation IDs do not create additional trials.
   meaning={'entry':entry,'band':band,'data_hash':audit.get('data_hash'),'period':period,
    'probabilities':f.get('class_probabilities'),'abstain':f.get('abstain'),'signal_threshold':f.get('signal_threshold'),
    'distribution':(f.get('distribution_forecast') or {}).get('quantiles'),
    'event_guard':bool(f.get('event_signal_guard') or (f.get('macro_events') or {}).get('signal_guard')),
    'confidence_score':f.get('confidence_score'),'confidence_status':f.get('confidence_status'),'model_version':f.get('model_version'),'target_version':f.get('target_version')}
   group=hashof([sym,str(h),gen,mode,str(date)]);key=hashof([group,meaning]);encoded=dump(snapshot)
   with closing(self.connect()) as c, c:
    c.execute('BEGIN IMMEDIATE')
    existing=c.execute('SELECT id,revision FROM issues WHERE issue_key=?',(key,)).fetchone()
    if existing:
     out['existing']+=1;out['issues'].append({'id':existing['id'],'revision':existing['revision'],'existing':True});continue
    revision=c.execute('SELECT COALESCE(MAX(revision),0)+1 FROM issues WHERE group_key=?',(group,)).fetchone()[0]
    cur=c.execute('INSERT INTO issues(issue_key,group_key,revision,issued_at,symbol,horizon,generation,mode,origin_date,target_date,target_close,eligibility,snapshot,snapshot_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
     (key,group,revision,stamp(now),sym,str(h),gen,mode,str(date)[:10] if date else None,period.get('target_date'),period.get('target_close_utc'),eligibility,encoded,hashof(snapshot)))
    i=cur.lastrowid;state='pending' if eligibility=='eligible' else eligibility
    c.execute('INSERT INTO attempts(issue_id,checked_at,state,reason) VALUES(?,?,?,?)',(i,stamp(now),state,STATES[state]))
    out['inserted']+=1;out['issues'].append({'id':i,'revision':revision,'eligibility':eligibility,'primary':revision==1})
  return out
 def _attempt(self,i,state,now,reason=None):
  with closing(self.connect()) as c, c:c.execute('INSERT INTO attempts(issue_id,checked_at,state,reason) VALUES(?,?,?,?)',(i,stamp(now),state,reason or STATES[state]))
 def settle(self,loader,limit=24,now=None):
  now=DATA.utc(now);start=stamp();counts={'checked':0,'settled':0,'unavailable':0};cache={}
  with closing(self.connect()) as c, c:
   # Last checked ordering prevents a permanently missing source starving newer issues.
   pending=c.execute('''SELECT i.*,(SELECT MAX(id) FROM attempts a WHERE a.issue_id=i.id) last_attempt
    FROM issues i LEFT JOIN outcomes o ON o.issue_id=i.id WHERE o.id IS NULL
    AND i.eligibility='eligible' AND i.target_close<=? ORDER BY last_attempt,i.id LIMIT ?''',(stamp(now),max(1,min(int(limit),200)))).fetchall()
  for r in pending:
   counts['checked']+=1;s=json.loads(r['snapshot']);i=r['id'];state=None
   if hashof(s)!=r['snapshot_hash']:self._attempt(i,'corrupt_snapshot',now);counts['unavailable']+=1;continue
   try:
    if r['symbol'] not in cache:
     try:cache[r['symbol']]=loader(r['symbol'])
     except Exception as exc:cache[r['symbol']]=exc
    raw=cache[r['symbol']]
    if isinstance(raw,Exception):raise raw
    d,audit=DATA.prepare(raw,r['symbol'],'journal settlement',now=now)
    if audit.get('conflicting_dates'):state='data_conflict'
    elif d.empty:state='source_error'
    else:
     audit=DATA.persist_input(d,audit,r['symbol'])
     d=d.set_index('date');origin=pd.Timestamp(r['origin_date']);target=pd.Timestamp(r['target_date'])
     if origin not in d.index:state='origin_missing'
     elif not math.isclose(float(d.loc[origin,'close']),s['entry_price'],rel_tol=1e-6,abs_tol=1e-8):state='origin_revised'
     elif target not in d.index:state='missing_target'
     else:
      period=s['period'];cal=period['calendar']
      expected=pd.date_range(origin,target,freq='D') if cal=='24/7' else DATA.calendar(cal).schedule.loc[str(origin.date()):str(target.date())].index
      if len(expected.difference(d.index)):state='history_gap'
      else:
       targetprice=float(d.loc[target,'close']);lr=math.log(targetprice/s['entry_price']);band=s['threshold_log']
       outcome='up' if lr>band else 'down' if lr<-band else 'neutral';p=probabilities(s['forecast'])
       qs=(s['forecast'].get('distribution_forecast') or {}).get('quantiles') or {};lo=number(qs.get('q10_return_pct'));hi=number(qs.get('q90_return_pct'))
       valid_interval=lo is not None and hi is not None and lo<=hi
       result={'target_date':r['target_date'],'target_price':targetprice,'log_return':lr,'simple_return_pct':100*math.expm1(lr),'outcome':outcome,
        'threshold_log':band,'brier':sum((p[k]-int(k==outcome))**2 for k in p),'log_loss':-math.log(max(1e-12,p[outcome])),
        'interval80_covered':bool(lo<=100*lr<=hi) if valid_interval else None,
        'interval80_width_price_pct':100*(math.exp(hi/100)-math.exp(lo/100)) if valid_interval else None,
        'history_snapshot':audit.get('snapshot_file'),'history_snapshot_saved':audit.get('snapshot_saved',False),'history_hash':audit.get('data_hash'),'checked_origin_price':s['entry_price'],'source':audit.get('source'),
        'delay_hours':max(0,(now-DATA.utc(r['target_close'])).total_seconds()/3600)}
       with closing(self.connect()) as c, c:
        cur=c.execute('INSERT OR IGNORE INTO outcomes(issue_id,settled_at,result,result_hash) VALUES(?,?,?,?)',(i,stamp(now),dump(result),hashof(result)))
        if cur.rowcount:counts['settled']+=1
       state='settled'
   except Exception as exc:
    state='source_error';self._attempt(i,state,now,'Источник не вернул проверяемую историю: '+type(exc).__name__);counts['unavailable']+=1;continue
   self._attempt(i,state,now)
   if state!='settled':counts['unavailable']+=1
  with closing(self.connect()) as c, c:c.execute('INSERT INTO runs(started_at,finished_at,result) VALUES(?,?,?)',(start,stamp(),dump(counts)))
  return counts
 def rows(self,limit=100,symbol=None,generation=None):
  where=[];params=[]
  if symbol:where.append('i.symbol=?');params.append(symbol.upper())
  if generation:where.append('i.generation=?');params.append(generation)
  query='''SELECT i.*,o.result,o.result_hash,o.settled_at,a.checked_at,a.state,a.reason FROM issues i
   LEFT JOIN outcomes o ON o.issue_id=i.id LEFT JOIN attempts a ON a.id=(SELECT MAX(id) FROM attempts WHERE issue_id=i.id)'''
  if where:query+=' WHERE '+' AND '.join(where)
  query+=' ORDER BY i.id DESC LIMIT ?';params.append(max(1,min(int(limit),10000)))
  with closing(self.connect()) as c, c:raw=c.execute(query,params).fetchall()
  result=[];now=DATA.utc()
  for r in raw:
   x=dict(r);snap=json.loads(x.pop('snapshot'));x['snapshot_valid']=hashof(snap)==x['snapshot_hash']
   x['forecast']=snap['forecast'];x['entry_price']=snap['entry_price'];x['threshold_log']=snap['threshold_log']
   x['result']=json.loads(x['result']) if x['result'] else None
   x['outcome_valid']=not x['result'] or hashof(x['result'])==x['result_hash']
   x['primary']=x['revision']==1;x['state']='settled' if x['result'] else x['state']
   if not x['snapshot_valid'] or not x['outcome_valid']:x['state']='corrupt_snapshot'
   x['state_label']=STATES.get(x['state'],x['state'])
   x['overdue']=bool(not x['result'] and x['target_close'] and DATA.utc(x['target_close'])<now and x['eligibility']=='eligible')
   if x['overdue'] and x['state']=='pending':
    x['state']='awaiting_result';x['state_label']=STATES['awaiting_result'];x['reason']=STATES['awaiting_result']
   x['overdue_hours']=max(0,(now-DATA.utc(x['target_close'])).total_seconds()/3600) if x['overdue'] else 0
   result.append(x)
  return result
 def detail(self,issue_id):
  with closing(self.connect()) as c, c:
   r=c.execute('SELECT * FROM issues WHERE id=?',(issue_id,)).fetchone()
   if not r:return None
   x=dict(r);x['snapshot']=json.loads(x['snapshot'])
   x['attempts']=[dict(a) for a in c.execute('SELECT checked_at,state,reason FROM attempts WHERE issue_id=? ORDER BY id',(issue_id,))]
   o=c.execute('SELECT * FROM outcomes WHERE issue_id=?',(issue_id,)).fetchone()
   x['outcome']=dict(o) if o else None
   if o:x['outcome']['result']=json.loads(o['result'])
   return x
 def dashboard(self,symbol=None,generation=None):
  rows=self.rows(10000,symbol,generation);groups={}
  for r in rows:
   key=(r['symbol'],r['horizon'],r['generation'],r['mode']);g=groups.setdefault(key,{'symbol':key[0],'horizon':key[1],'generation':key[2],'mode':key[3],'issues':0,'primary':0,'settled':0,'revisions':0,'overdue':0,'blocked':0,'samples':[]})
   g['issues']+=1;g['revisions']+=int(not r['primary']);g['primary']+=int(r['primary']);g['overdue']+=int(r['overdue']);g['blocked']+=int(r['eligibility']!='eligible')
   if r['primary'] and r['eligibility']=='eligible' and r['result'] and r['snapshot_valid'] and r['outcome_valid']:g['samples'].append(r)
  for g in groups.values():
   rs=sorted(g.pop('samples'),key=lambda x:x['origin_date']);g['settled']=len(rs);end='';non=[]
   for r in rs:
    if r['origin_date']>end:non.append(r);end=r['target_date']
   g['nonoverlap']=len(non);g['brier']=float(np.mean([r['result']['brier'] for r in rs])) if rs else None
   g['log_loss']=float(np.mean([r['result']['log_loss'] for r in rs])) if rs else None
   cov=[r['result']['interval80_covered'] for r in rs if r['result']['interval80_covered'] is not None];g['coverage80']=float(np.mean(cov)) if cov else None
   g['signal_share']=float(np.mean([not r['forecast'].get('abstain',True) for r in rs])) if rs else None
   g['quality_confirmed']=False;g['status']='collecting' if len(non)<60 else 'requires_independent_review';g['minimum_nonoverlap']=60
  with closing(self.connect()) as c, c:
   last=c.execute('SELECT * FROM runs ORDER BY id DESC LIMIT 1').fetchone();total=c.execute('SELECT COUNT(*) FROM issues').fetchone()[0];fails=c.execute('SELECT COUNT(*) FROM failures').fetchone()[0]
  return {'version':VERSION,'scope':'server_issued_forecasts','historical_results_imported':False,'used_for_training':False,'automatic_promotion':False,
   'total_issues':total,'shown_issues':len(rows),'truncated':len(rows)==10000,'unavailable_deliveries':fails,
   'groups':list(groups.values()),'rows':rows[:150],'last_run':dict(last) if last else None,
   'worker_note':'Проверка выполняется каждые 5 минут, пока запущен сервер. После перезапуска незавершённые записи проверяются снова.',
   'eligibility_note':'Выпуск до первого следующего дневного закрытия; выпуски после него исключены. Первое наблюдение может быть частично пройдено внутри дня. Пересмотры и режимы не удваивают число независимых дат.'}

@lru_cache(maxsize=1)
def journal():return Journal()
