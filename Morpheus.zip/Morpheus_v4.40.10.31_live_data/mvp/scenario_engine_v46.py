
"""Morpheus v4.6 — прозрачный сценарный анализ без внешнего LLM.

Цель — дать пользователю понятный market-impact разбор произвольной гипотезы
и позволить добавлять второе условие. Модуль использует:
- текущие цены из snapshot;
- ставки и макро-контекст;
- текущую новостную ленту;
- набор прозрачных shock-rules.

Результат является сценарной аналитикой, а не точным прогнозом.
"""
from __future__ import annotations
import re, math, hashlib

ASSET_ALIASES={
    "золото":"GC=F","gold":"GC=F",
    "нефть":"CL=F","нефти":"CL=F","brent":"CL=F","wti":"CL=F",
    "газ":"NG=F",
    "биткоин":"BTC-USD","bitcoin":"BTC-USD","btc":"BTC-USD",
    "эфир":"ETH-USD","ethereum":"ETH-USD",
    "s&p":"^GSPC","sp500":"^GSPC","s&p 500":"^GSPC",
    "nasdaq":"^NDX","насдак":"^NDX",
    "dow":"^DJI","доу":"^DJI",
    "рубл":"RUB=X","доллар":"DX-Y.NYB",
    "мосбирж":"IMOEX","imoex":"IMOEX",
    "серебр":"SI=F","медь":"HG=F",
}

SHOCKS=[
    ("hormuz",r"ормуз|иран.*блок|блок.*иран|перекры.*пролив|войн.*иран|иран.*войн",
     {"CL=F":(8,22),"GC=F":(2,7),"^GSPC":(-6,-2),"^NDX":(-8,-3),"DX-Y.NYB":(1,4),"BTC-USD":(-8,3)}),
    ("war",r"войн|вторг|военн|удар|атака|эскалац",
     {"GC=F":(2,8),"CL=F":(2,10),"^GSPC":(-7,-1),"^NDX":(-9,-2),"BTC-USD":(-10,4),"DX-Y.NYB":(1,4)}),
    ("sanctions",r"санкц|замороженн.*актив|резерв.*отдад|конфиск|экспортн.*контрол",
     {"GC=F":(1,5),"RUB=X":(2,10),"IMOEX":(-10,-3),"^GSPC":(-3,0),"^STOXX50E":(-5,-1),"CL=F":(0,6)}),
    ("satoshi",r"сатош|satoshi|личност.*биткоин|продаст.*биткоин|продаж.*биткоин",
     {"BTC-USD":(-25,-6),"ETH-USD":(-16,-4),"SOL-USD":(-20,-5),"XRP-USD":(-18,-4),"GC=F":(-1,2)}),
    ("rate_hike",r"повыс.*ставк|ставк.*повыс|жестк.*цб|жёстк.*цб",
     {"^GSPC":(-5,-1),"^NDX":(-7,-2),"GC=F":(-4,-1),"BTC-USD":(-8,-2),"DX-Y.NYB":(1,4)}),
    ("rate_cut",r"сниз.*ставк|ставк.*сниз|смягч.*цб",
     {"^GSPC":(1,5),"^NDX":(2,7),"GC=F":(0,4),"BTC-USD":(1,8),"DX-Y.NYB":(-4,-1)}),
    ("oil_supply",r"нефт.*постав|сократ.*добыч|опек|opec|эмбарго.*нефт",
     {"CL=F":(4,14),"^GSPC":(-3,0),"GC=F":(0,3)}),
    ("recession",r"рецесс|обвал.*эконом|резк.*безработ|кризис.*спрос",
     {"^GSPC":(-12,-4),"^NDX":(-14,-5),"CL=F":(-12,-4),"GC=F":(1,7),"DX-Y.NYB":(-2,3),"BTC-USD":(-15,-4)}),
    ("inflation",r"инфляц.*скач|ускор.*инфляц|цен.*резк.*выраст",
     {"GC=F":(2,8),"^GSPC":(-6,-1),"^NDX":(-8,-2),"DX-Y.NYB":(0,4),"CL=F":(0,6)}),
    ("crypto_risk",r"взлом.*бирж|крипто.*запрет|запрет.*крипто|стейблкоин.*крах|бирж.*обанкрот",
     {"BTC-USD":(-22,-6),"ETH-USD":(-24,-7),"SOL-USD":(-28,-8),"XRP-USD":(-24,-7)}),
    ("taiwan",r"тайван|taiwan|китай.*вторг|блокад.*тайван",
     {"^NDX":(-14,-5),"^GSPC":(-9,-3),"GC=F":(3,9),"CL=F":(1,7),"DX-Y.NYB":(1,5)}),
    ("bank_crisis",r"банк.*банкрот|банковск.*кризис|набег.*банк|bank run",
     {"^GSPC":(-10,-3),"^NDX":(-9,-2),"GC=F":(2,8),"BTC-USD":(-10,6),"DX-Y.NYB":(-3,2)}),
]

def _assets(payload):
    return {a.get("symbol"):a for a in payload.get("assets") or [] if a.get("symbol")}

def _mentioned_assets(q):
    t=q.lower()
    out=[]
    for k,s in ASSET_ALIASES.items():
        if k in t and s not in out:out.append(s)
    return out

def _matched_shocks(q):
    return [(name,moves) for name,pat,moves in SHOCKS if re.search(pat,q,re.I)]

def _combine_ranges(shocks):
    out={}
    for _,moves in shocks:
        for sym,(lo,hi) in moves.items():
            if sym not in out:out[sym]=[0.0,0.0]
            out[sym][0]+=lo;out[sym][1]+=hi
    # Cap implausible additive explosion.
    return {s:(max(-45,min(45,a)),max(-45,min(45,b))) for s,(a,b) in out.items()}

def _focus_ranges(question,ranges):
    mentioned=_mentioned_assets(question)
    if mentioned:
        keep={}
        for s in mentioned:
            if s in ranges:keep[s]=ranges[s]
            else:keep[s]=(-3,3)
        # plus up to three spillovers
        spill=[(s,r) for s,r in ranges.items() if s not in keep]
        spill.sort(key=lambda x:max(abs(x[1][0]),abs(x[1][1])),reverse=True)
        keep.update(spill[:3])
        return keep
    items=sorted(ranges.items(),key=lambda x:max(abs(x[1][0]),abs(x[1][1])),reverse=True)
    return dict(items[:6])

def _direction(lo,hi):
    mid=(lo+hi)/2
    if mid>=2:return "рост"
    if mid<=-2:return "падение"
    return "повышенная волатильность"

def _facts(payload,question,focus):
    facts=[]
    assets=_assets(payload)
    for sym in list(focus)[:3]:
        a=assets.get(sym)
        if a and a.get("last") is not None:
            facts.append(f"{a.get('name') or sym}: текущая цена около {a.get('last')}.")
    for r in payload.get("rates") or []:
        if r.get("country") in ("США","Еврозона","Россия"):
            facts.append(f"{r['country']}: ключевая ставка сейчас {r.get('rate')}%.")
        if len(facts)>=5:break
    # Current related news first.
    words=[w.lower() for w in re.findall(r"[A-Za-zА-Яа-яЁё]{5,}",question)][:10]
    scored=[]
    for n in payload.get("news") or []:
        text=((n.get("title") or "")+" "+(n.get("summary") or "")).lower()
        score=sum(1 for w in words if w in text)+float(n.get("impact_score") or 0)/100
        if score>0.2:scored.append((score,n))
    scored.sort(key=lambda x:x[0],reverse=True)
    for _,n in scored[:2]:
        facts.append(f"В текущей ленте: {n.get('title')}.")
    return facts[:6]

def _chain(shock_names,question):
    if "hormuz" in shock_names:
        return ["Риск перебоев поставок нефти","Рост премии за геополитический риск","Давление на инфляционные ожидания","Снижение аппетита к риску"]
    if "satoshi" in shock_names:
        return ["Резкий рост неопределённости вокруг крупных кошельков","Рост предложения BTC при продаже","Ликвидации плечевых позиций","Переток части капитала в другие активы"]
    if "sanctions" in shock_names:
        return ["Рост правовой и политической неопределённости","Пересмотр трансграничных потоков капитала","Переоценка валютного и странового риска","Повышенная волатильность связанных рынков"]
    if "rate_hike" in shock_names:
        return ["Рост стоимости денег","Снижение приведённой стоимости будущих денежных потоков","Давление на длинные риск-активы","Поддержка валюты соответствующей страны"]
    if "rate_cut" in shock_names:
        return ["Снижение стоимости денег","Поддержка кредитования и оценки риск-активов","Ослабление доходности кэша","Возможное давление на валюту"]
    if "war" in shock_names:
        return ["Рост геополитической премии","Уход части капитала в защитные активы","Рост волатильности сырья и валют","Давление на риск-активы"]
    return ["Изменение ожиданий участников рынка","Пересмотр риск-премии","Перераспределение капитала между активами","Новая волна волатильности"]

def analyze(payload,question,previous_question=None):
    q=(str(previous_question or "").strip()+" "+str(question or "").strip()).strip()
    if not q:
        raise ValueError("Введите сценарий")
    shocks=_matched_shocks(q)
    ranges=_combine_ranges(shocks)
    mentioned=_mentioned_assets(q)
    if not ranges:
        # Generic uncertain shock with focus on explicitly mentioned assets.
        for s in mentioned or ["^GSPC","GC=F","BTC-USD"]:
            ranges[s]=(-4,4)
    focus=_focus_ranges(q,ranges)
    assets=_assets(payload)
    shock_names=[x[0] for x in shocks]

    impacts=[]
    for sym,(lo,hi) in focus.items():
        a=assets.get(sym,{})
        impacts.append({
            "symbol":sym,"name":a.get("name") or sym,
            "direction":_direction(lo,hi),
            "range_pct":[round(lo,1),round(hi,1)],
            "current":a.get("last"),
        })

    # Scenario branches around the same central estimate.
    base=[]
    stress=[]
    soft=[]
    for x in impacts:
        lo,hi=x["range_pct"];mid=(lo+hi)/2
        base.append({"symbol":x["symbol"],"move_pct":round(mid,1)})
        stress.append({"symbol":x["symbol"],"move_pct":round(hi if abs(hi)>=abs(lo) else lo,1)})
        soft.append({"symbol":x["symbol"],"move_pct":round(mid*.4,1)})

    title="Сценарий: "+str(question).strip()
    summary=(
        "Наиболее вероятна не одна точная цена, а диапазон реакции. "
        "Сначала рынок переоценивает риск, затем движение зависит от того, "
        "насколько событие реально меняет поставки, денежные потоки и ожидания."
    )
    if "hormuz" in shock_names:
        summary="Главный канал — нефть и инфляционные ожидания. Чем дольше сохраняется риск для Ормузского пролива, тем сильнее поддержка нефти и золота и тем хуже фон для риск-активов."
    elif "satoshi" in shock_names:
        summary="Главный канал — доверие к рынку и возможное предложение BTC. Простое раскрытие личности может дать всплеск волатильности; крупная продажа монет существенно усиливает негативный сценарий."
    elif "sanctions" in shock_names:
        summary="Главный канал — правовой риск, валютные потоки и вероятность ответных мер. Реакция будет сильнее, если событие затронет доступ к резервам, расчётам или торговым потокам."

    confidence="средняя" if shocks else "низкая"
    return {
        "id":hashlib.sha1(q.encode("utf-8")).hexdigest()[:12],
        "question":str(question).strip(),
        "combined_question":q,
        "title":title,
        "summary":summary,
        "confidence":confidence,
        "horizon":"первые часы — 5 торговых дней",
        "impacts":impacts,
        "transmission":_chain(shock_names,q),
        "facts":_facts(payload,q,focus),
        "scenarios":[
            {"name":"Базовый","probability":55,"moves":base,
             "text":"Событие происходит, но рынок быстро получает больше информации и часть первого движения отыгрывается."},
            {"name":"Жёсткий","probability":25,"moves":stress,
             "text":"Шок длится дольше, затрагивает реальные потоки капитала, сырья или ликвидности и вызывает вторичные эффекты."},
            {"name":"Мягкий","probability":20,"moves":soft,
             "text":"Рынок воспринимает событие как ограниченное, появляются компенсирующие меры и движение остаётся умеренным."},
        ],
        "watch":[
            "Подтверждение события из нескольких надёжных источников",
            "Реальное изменение потоков сырья, капитала или ликвидности",
            "Реакция валют, доходностей и волатильности",
            "Ответ регуляторов и правительств",
        ],
        "note":"Сценарная аналитика Morpheus. Диапазоны — оценка возможной реакции, а не обещание движения цены.",
    }
