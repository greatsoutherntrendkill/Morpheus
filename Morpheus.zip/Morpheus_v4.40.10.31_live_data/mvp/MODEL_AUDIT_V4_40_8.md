# Model Audit — v4.40.8 Data-Driven Routing

## Objective

Reduce manual performance-routing constants without allowing small prospective samples to overfit live forecasts.

## What is learned now

### 1. Champion / regime-expert routing

The existing chronological OOS records are aligned by date. An older 70% slice estimates the Brier-optimal linear weight and the recent 30% slice validates it against an equal-weight baseline. A learned weight is used live only when it does not worsen recent OOS Brier; otherwise the route is 50/50.

### 2. Material-move routing

`P(material move)` is routed separately from conditional direction using the same fit/validation principle. This avoids assuming that the expert best at direction is automatically the expert best at distinguishing MOVE from NEUTRAL.

### 3. Prospective trust/publication

After at least 60 usable settled prospective forecasts, a logistic trust model may be fitted from features known at forecast time. Development is chronological:

`fit → threshold selection → untouched audit`

The route is enabled only if the untouched slice improves Brier relative to the native factorized trust estimate and the selected publication rule has positive realized utility. Otherwise it is disabled.

### 4. Satellite weights

Context, asset-specialist and event-response candidate weights are estimated on older paired prospective observations and must improve recent validation Brier. Human/promotion approval is still required, and the learned weight is bounded by the existing governance cap.

## Constants deliberately retained

Not every constant should be learned. v4.40.8 retains limits that are safety/governance policy rather than performance beliefs: maximum satellite influence, minimum evidence counts, chronological split requirements and hard robustness abstention rules for materially stale/corrupt data.

These limits protect the system while evidence is still accumulating and should only be relaxed through a separate validated governance change.

## Leakage controls

- No current/future outcome is used to route the forecast being produced.
- OOS blend fitting and validation are chronological.
- Prospective trust fitting, threshold selection and audit use separate chronological slices.
- Current-generation promotion reviews cannot inherit an approval report from a prior generation.
- Persistent evidence is not deleted or rewritten during upgrades.

## Expected behaviour on a fresh install

The OOS core blend can become learned immediately because it uses historical OOS model records. The prospective publish router is normally inactive at first and reports `collecting_prospective_evidence`. This is intentional: v4.40.8 must not manufacture confidence before enough settled live forecasts exist.
