'use strict';
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=(v,n=3)=>typeof v==='number'&&Number.isFinite(v)?v.toLocaleString('ru-RU',{maximumFractionDigits:n,minimumFractionDigits:n}):'—';
const pct=v=>typeof v==='number'&&Number.isFinite(v)?num(v*100,1)+'%':'—';
const NAMES={model:'Morpheus',uniform:'Без предпочтения · ⅓ / ⅓ / ⅓',frequency:'Частоты прошлых исходов',trend:'Частоты при похожем тренде'};
const ASSETS={'^GSPC':'S&P 500','BTC-USD':'Bitcoin','EURUSD=X':'EUR/USD','PLZL.ME':'Полюс','CL=F':'Нефть WTI · непрерывный ряд'};
const REGIMES={high_volatility:'Высокая волатильность',uptrend:'Восходящий тренд',downtrend:'Нисходящий тренд',range:'Боковое движение',insufficient_history:'Недостаточно истории'};
let data;
function options(el,values,label){el.innerHTML=values.map(v=>`<option value="${esc(v)}">${esc(label(v))}</option>`).join('')}
function line(label,value){return `<div class="statline"><span>${esc(label)}</span><b>${esc(value)}</b></div>`}
function render(){
 const g=data.groups.find(x=>x.symbol===$('#symbol').value&&x.horizon===Number($('#horizon').value)&&x.mode===$('#mode').value);
 if(!g){$('#sample').textContent='Для этого сочетания расчёт не проводился.';return}
 const labels=Object.keys(g.regimes),selected=$('#regime').value;
 options($('#regime'),['all',...labels],v=>v==='all'?'Все состояния':REGIMES[v]||v);$('#regime').value=labels.includes(selected)?selected:'all';
 const part=$('#regime').value==='all'?g.metrics:g.regimes[$('#regime').value].metrics;
 const n=part.model?.n||0;
 $('#sample').textContent=`${n} пар в выбранном срезе. Всего: ${g.paired} из ${g.attempted} запланированных; ${g.nonoverlap} без пересечения сроков. Недоступных расчётов: ${g.unavailable}. Этой выборки недостаточно для допуска.`;
 $('#scores').innerHTML=Object.keys(NAMES).map(k=>{const m=part[k]||{};return `<tr class="${k==='model'?'model':''}"><td>${esc(NAMES[k])}</td><td>${num(m.brier)}</td><td>${num(m.log_loss)}</td><td>${pct(m.calibration?.macro_ece)}</td><td>${pct(m.signal_share)}</td></tr>`}).join('');
 const iv=part.model?.interval||{},bi=part.frequency?.interval||{};
 $('#interval').innerHTML=line('Рассчитанных диапазонов',String(iv.n||0))+line('Попадание в диапазон 80%',pct(iv.coverage80))+line('Средняя ширина по цене',iv.width_price_pct==null?'—':num(iv.width_price_pct,2)+'%')+line('Ширина частотного ориентира',bi.width_price_pct==null?'—':num(bi.width_price_pct,2)+'%');
 const comp=g.comparisons[g.best_baseline]||{};const ci=comp.low==null?'Недостаточно блоков':`${num(comp.low,4)} … ${num(comp.high,4)}`;
 $('#stability').innerHTML=line('Ориентир с меньшей ошибкой',NAMES[g.best_baseline]||'—')+line('Разница Brier в пользу модели',num(comp.mean,4))+line('95%-й интервал разницы',ci)+line('Проверка после всех сравнений',comp.p_holm==null?'—':'p = '+num(comp.p_holm,4))+Object.entries(g.periods).map(([key,v])=>line(`Период ${Number(key)+1} · пар ${v.n}`,v.n?'Brier '+num(v.metrics.model.brier):'Нет данных')).join('')+'<p class="footnote">Устойчивость показана для всего выбранного периода. Интервал, включающий ноль, не подтверждает преимущество.</p>';
 $('#calibration').innerHTML=(part.model?.calibration?.bins||[]).map(b=>`<tr><td>${{up:'Рост',neutral:'Нейтрально',down:'Снижение'}[b.class]}</td><td>${pct(b.lo)}–${pct(b.hi)}</td><td>${pct(b.predicted)}</td><td>${pct(b.observed)}</td><td>${b.n}</td></tr>`).join('');
 $('#execution').innerHTML=(g.execution.model||[]).map(e=>`<tr><td>${num(e.roundtrip_cost_bps/100,2)}%</td><td>${e.n}${e.skipped_no_open?' · нет открытия: '+e.skipped_no_open:''}</td><td>${e.mean_net_pct==null?'—':num(e.mean_net_pct,2)+'%'}</td><td>${e.compound_net_pct==null?'—':num(e.compound_net_pct,2)+'%'}</td><td>${e.max_drawdown_pct==null?'—':num(e.max_drawdown_pct,2)+'%'}</td></tr>`).join('');
 $('#decision').innerHTML=`<div class="decision"><b>Оснований подтвердить надёжность пока нет</b><p>${g.model_beats_all_on_point_estimate?'На этих датах средняя ошибка ниже всех трёх ориентиров. Этого ещё недостаточно: результат должен повториться на новых данных.':'На этих датах модель не обошла все три простых ориентира по средней ошибке.'} Выборка мала, а полного архива доступности исходных данных нет. Процент уверенности не повышается; состав модели по этому отчёту автоматически не меняется.</p></div>`;
}
async function load(){try{
 const response=await fetch('evaluation_v4401014.json',{cache:'no-store'});if(!response.ok)throw new Error();data=await response.json();
 if(data.version!=='independent-evaluation-v4.40.10.14'||!Array.isArray(data.groups)||!data.groups.length)throw new Error();
 const s=data.summary;$('#totals').innerHTML=`<div class="total"><b>${s.attempted}</b><span>попыток расчёта</span></div><div class="total"><b>${s.groups}</b><span>актив × срок × режим расчёта</span></div><div class="total"><b>${s.qualified_groups}</b><span>прошли все правила допуска</span></div>`;
 options($('#symbol'),[...new Set(data.groups.map(g=>g.symbol))],v=>ASSETS[v]||v);options($('#horizon'),[...new Set(data.groups.map(g=>g.horizon))].sort((a,b)=>a-b),v=>Number(v)===1?'1 наблюдение':v+' наблюдений');
 $('#symbol').value='^GSPC';const q=new URLSearchParams(location.search);for(const id of ['symbol','horizon','mode'])if([...$('#'+id).options].some(o=>o.value===q.get(id)))$('#'+id).value=q.get(id);
 const missing=['symbol','horizon','mode'].filter(id=>q.has(id)&&![...$('#'+id).options].some(o=>o.value===q.get(id)));
 if(missing.length){$('#requested-note').hidden=false;$('#requested-note').textContent=`Для исходного выбора (${q.get('symbol')||'актив'}, срок ${q.get('horizon')||'—'}) сохранённого сравнения нет. Ниже можно посмотреть проверенные сочетания; их результаты не относятся автоматически к исходному прогнозу.`}
 for(const id of ['symbol','horizon','mode','regime'])$('#'+id).addEventListener('change',render);
 $('#provenance').textContent=`Сохранённый эксперимент · ${data.created_at.slice(0,10)} · ${data.generation}. Протокол: ${data.protocol_hash}. Отчёт охватывает пять активов и сроки 1, 10, 60 наблюдений; остальные активы и сроки ещё не проверены.`;
 $('#load-status').hidden=true;$('#results').hidden=false;render();
 }catch(e){$('#load-status').textContent='Отчёт пока недоступен. Это не означает нулевую ошибку или подтверждённую надёжность. Откройте страницу через запущенный сервер сайта.'}}
load();
