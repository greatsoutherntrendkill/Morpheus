/* Forecast timing and input provenance, deliberately separate from live quotes. */
window.DataIntegrity = (() => {
 const esc = x => String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const date = x => {if(!x)return '—';const s=String(x).slice(0,10).split('-');return s.length===3?s.reverse().join('.'):'—'};
 function render(f){
  const a=f?.data_integrity,t=f?.target_period;if(!a)return '';
  const mode=f?.calculation_identity?.mode;
  const timing=t?(t.target_date?`${t.label} · до ${date(t.target_date)}`:`${t.label} · точная дата не подтверждена`):'По закрытым внутридневным свечам';
  const warnings=(a.warnings||[]).map(x=>`<small>${esc(x)}</small>`).join('');
  return `<div class="data-integrity-note"><strong>${esc(timing)}</strong><span>История по ${date(a.as_of)} · ${a.accepted_rows??'—'} закрытых свечей${mode==='full'?' · полный расчёт':mode==='fast'?' · быстрый расчёт':''}</span>${t?.note?`<small>${esc(t.note)}</small>`:''}<small>Прогноз изменения цены; денежные дивиденды в доходность не добавляются.</small>${warnings}${f.journal_receipt?.recorded===false?'<small>Не удалось сохранить этот выпуск в журнале. Он не участвует в проверке качества.</small>':''}</div>`;
 }
 const pricePct = x => 100*Math.expm1(Number(x)/100);
 const band = x => {const v=Math.abs(Number(x));return `−${Math.abs(pricePct(-v)).toFixed(2)}% / +${pricePct(v).toFixed(2)}%`};
 return {render,pricePct,band};
})();
