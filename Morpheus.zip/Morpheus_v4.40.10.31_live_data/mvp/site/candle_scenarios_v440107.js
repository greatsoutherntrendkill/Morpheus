/* Conditional illustrations, never synthetic observations or a fitted OHLC forecast. */
(function(root){
'use strict';
const finite=x=>x!=null&&Number.isFinite(Number(x));
const mean=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:0;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
// Historical block bootstrap with a fitted EWMA decay; endpoints remain conditional.
function rngFor(text){let s=2166136261;for(const c of text)s=Math.imul(s^c.charCodeAt(0),16777619);return ()=>{s+=0x6D2B79F5;let t=Math.imul(s^(s>>>15),1|s);t^=t+Math.imul(t^(t>>>7),61|t);return ((t^(t>>>14))>>>0)/4294967296;};}
function empirical(rows){
 const returns=rows.slice(1).map((r,i)=>100*Math.log(r.c/rows[i].c));
 const initial=mean(returns.slice(0,Math.min(20,returns.length)).map(x=>x*x));
 // Rolling one-step variance errors, with no use of the observation being predicted.
 let alpha=.1,best=Infinity;
 if(returns.length>=40)for(const a of [.02,.05,.1,.2,.35]){
  let v=initial,loss=0;
  for(let i=20;i<returns.length;i++){const q=returns[i]*returns[i];loss+=(q-v)**2;v=(1-a)*v+a*q;}
  if(loss<best){best=loss;alpha=a;}
 }
 let v=initial;const records=[];
 for(let i=0;i<returns.length;i++){
  const r=rows[i+1],sigma=Math.sqrt(v),range=100*Math.log(r.h/r.l);
  records.push({r:returns[i],sigma,z:sigma>1e-8?returns[i]/sigma:0,
   upper:100*Math.log(r.h/Math.max(r.o,r.c)),lower:100*Math.log(Math.min(r.o,r.c)/r.l),range,
   volume:Number(r.v??r.volume)||0,stamp:String(r.t||''),row:i+1});
  v=(1-alpha)*v+alpha*returns[i]*returns[i];
 }
 const historical=Math.sqrt(mean(returns.map(x=>x*x)));
 // A flat close series can still have observed intrabar ranges.
 const rangeSigma=Math.sqrt(mean(records.map(r=>r.range*r.range))/(4*Math.log(2)));
 let rangeVariance=0;
 for(const r of records)rangeVariance=(1-alpha)*rangeVariance+alpha*r.range*r.range/(4*Math.log(2));
 const current=Math.sqrt(Math.max(v,rangeVariance))||rangeSigma;
 const day=String(rows.at(-1).t||'').slice(0,10);
 const recent=records.filter(r=>r.stamp.slice(0,10)===day);
 const session=recent.length>1?Math.sqrt(mean(recent.map(r=>r.r*r.r))):null;
 let runs=[],run=1;for(let i=1;i<returns.length;i++){if(Math.sign(returns[i])===Math.sign(returns[i-1]))run++;else{runs.push(run);run=1;}}runs.push(run);
 const block=clamp(Math.round(mean(runs)*2),2,8);
 return {records,current,historical,session,sessionBars:recent.length,alpha,block,rangeSigma};
}
function empiricalPath({stats,rows,n,group,initial,threshold,end,price,levels,random}){
 const {records,alpha,block}=stats;
 const pivot=Math.max(3,Math.round(n*.32)),points=[0],shapes=[];
 let variance=stats.current**2,idx=0;
 const observedLevels=[...(levels?.res||[]),...(levels?.sup||[])].map(x=>Number(x.p)).filter(x=>x>0&&Number.isFinite(x));
 // Nearest observed historical level; no unobserved stop/order volume is inferred.
 function proximity(p,hi,lo,sigma){return clamp(((hi-p)<(p-lo)?hi-p:lo-p)/Math.max(p*sigma/100,1e-9),-5,5);}
 const targetHi=Math.min(...observedLevels.filter(p=>p>price)),targetLo=Math.max(...observedLevels.filter(p=>p<price));
 const levelState=Number.isFinite(targetHi)&&Number.isFinite(targetLo)?proximity(price,targetHi,targetLo,stats.current):null;
 const candidates=records.map((r,i)=>{
  const window=rows.slice(Math.max(0,r.row-20),r.row+1),p=rows[r.row].c;
  const state=proximity(p,Math.max(...window.map(x=>x.h)),Math.min(...window.map(x=>x.l)),r.sigma||stats.current);
  return {i,score:Math.abs(Math.log((r.sigma+1e-8)/(stats.current+1e-8)))+(levelState==null?0:Math.abs(state-levelState))};
 }).sort((a,b)=>a.score-b.score);
 const pool=candidates.slice(0,Math.max(12,Math.ceil(candidates.length*.4)));
 for(let i=0;i<n;i++){
  if(i%block===0)idx=pool[Math.floor(random()*pool.length)].i;
  const rec=records[idx%records.length];idx++;
  const sigma=Math.sqrt(variance)||stats.rangeSigma;
  // Do not shrink bodies as 1/n: diffusion scales with sqrt(elapsed bar count).
  const scale=Math.sqrt(group),step=rec.z*sigma*scale;
  points.push(points.at(-1)+step);
  const ratio=rec.sigma>1e-8?sigma/rec.sigma:1;
  shapes.push({upper:rec.upper*ratio*scale,lower:rec.lower*ratio*scale,volume:rec.volume});
  variance=Math.min(Math.max(...records.map(r=>r.sigma*r.sigma),stats.current**2), (1-alpha)*variance+alpha*(rec.z*sigma)**2);
 }
 const conditioned=points.slice();
 // Brownian-bridge-style conditioning within each segment, not a fixed zigzag template.
 for(const [a,b,start,finish] of [[0,pivot,0,initial*threshold],[pivot,n,initial*threshold,end]]){
  for(let i=a;i<=b;i++){const t=(i-a)/(b-a);conditioned[i]=start+(finish-start)*t+(points[i]-points[a])-t*(points[b]-points[a]);}
 }
 // These illustrations are explicitly conditional on the initial direction.
 conditioned[1]=initial*Math.abs(conditioned[1]);
 let prev=price;const bars=[];
 for(let i=1;i<=n;i++){
  const o=prev,c=price*Math.exp(conditioned[i]/100),shape=shapes[i-1];
  const h=Math.max(o,c)*Math.exp(shape.upper/100),l=Math.min(o,c)*Math.exp(-shape.lower/100);
  const touched=observedLevels.find(p=>p>=l&&p<=h);
  const event=touched?(Math.min(o,c)<=touched&&Math.max(o,c)>=touched?'условное пересечение уровня':'условное касание или прокол уровня'):null;
  bars.push({o,c,h,l,fraction:i/n,event});prev=c;
 }
 return bars;
}

function build({forecast:f,candles,tf,horizon,category='',levels={}}){
 const g=f?.movement_guidance||{},last=candles?.at(-1),price=Number(last?.c);
 if(f?.status!=='ok'||!finite(price)||price<=0)return {available:false,reason:'Сценарии появятся после загрузки прогноза и графика.'};
 const threshold=finite(g.material_move_threshold_pct)?Math.abs(Number(g.material_move_threshold_pct)):null;
 const typical=finite(g.expected_abs_move_pct)?Math.abs(Number(g.expected_abs_move_pct)):null;
 if(!(threshold>0)||!(typical>0))return {available:false,reason:'Недостаточно данных о масштабе движения: сценарные свечи пока не строятся.'};
 const p=finite(f.conditional_p_up)?Number(f.conditional_p_up):finite(f.p_up)?Number(f.p_up):null;
 if(!finite(p)||p<0||p>1)return {available:false,reason:'Нет пригодной оценки направления.'};
 const direction=p===.5?0:p>.5?1:-1;
 const range=g.distribution_quality_ok===true?g.directional_scenario_range:null;
 const validRange=range&&finite(range.low_pct)&&finite(range.high_pct)&&Number(range.low_pct)>0&&Number(range.high_pct)>=Number(range.low_pct)&&((range.direction==='up'?1:-1)===direction);
 let magnitude=validRange?(Number(range.low_pct)+Number(range.high_pct))/2:Math.max(threshold,typical);
 if(!Number.isFinite(magnitude)||magnitude>=95||threshold>=95)return {available:false,reason:'Масштаб слишком велик для надёжного отображения короткими сценариями.'};
 const session=/акци|индекс|фьючер|сырь/i.test(category)?390:1440;
 const horizonMinutes=({'30m':30,'1h':60,'2h':120,'4h':240})[String(horizon)]||Number(horizon)*session;
 const stepMinutes=({'1min':1,'5min':5,'15min':15,'30min':30,'1h':60,'4h':240,'1d':session,'1w':session*5,'1mo':session*21,'3mo':session,'6mo':session,'1y':session,'3y':session})[tf];
 if(!(horizonMinutes>0)||!(stepMinutes>0))return {available:false,reason:'Этот временной масштаб пока не поддерживается.'};
 const nativeBars=horizonMinutes/stepMinutes,n=clamp(Math.ceil(nativeBars),48,52),group=nativeBars/n;
 const rows=(candles||[]).slice(-1200).filter(z=>[z.o,z.h,z.l,z.c].every(x=>finite(x)&&Number(x)>0)&&z.h>=Math.max(z.o,z.c)&&z.l<=Math.min(z.o,z.c));
 if(rows.length<12)return {available:false,reason:'Нужно не менее 12 корректных свечей для исторических сценариев.'};
 const stats=empirical(rows);
 if(!(stats.current>0))return {available:false,reason:'В истории нет измеримого движения для построения сценариев.'};
 const random=rngFor(JSON.stringify([tf,horizon,price,rows.map(r=>[r.t,r.o,r.h,r.l,r.c]),threshold,magnitude]));
 const nearby=(direction>0?levels?.res:levels?.sup)||[];
 const loMag=validRange?Number(range.low_pct):Math.max(threshold,magnitude*.85),hiMag=validRange?Number(range.high_pct):magnitude*1.15;
 const level=nearby.map(z=>Number(z.p)).find(v=>Number.isFinite(v)&&direction*Math.log(v/price)*100>=loMag&&direction*Math.log(v/price)*100<=hiMag);
 // Historical levels annotate; they do not change forecast endpoints.
 const paths=[1,-1].map((initial,pathIndex)=>{
  const end=direction*(validRange?Number(range.low_pct)+(Number(range.high_pct)-Number(range.low_pct))*(pathIndex===0?.4:.6):magnitude*(pathIndex===0?.95:1.05));
  const bars=empiricalPath({stats,rows,n,group,initial,threshold,end,price,levels,random});
  return {label:pathIndex===0?'Сценарий I':'Сценарий II',initial,end,bars};
 });
 const eventRisk=!!f.macro_events?.signal_guard||!!f.macro_events?.political_news?.length;
 if(paths.some(p=>p.bars.some(z=>![z.o,z.h,z.l,z.c].every(v=>Number.isFinite(v)&&v>0))))return {available:false,reason:'История даёт нестабильный масштаб; сценарии не построены.'};
 return {available:true,method:'historical_block_bridge_v21',diagnostics:{historyBars:rows.length,currentVol:stats.current,historicalVol:stats.historical,sessionVol:stats.session,sessionBars:stats.sessionBars,ewmaAlpha:stats.alpha,blockLength:stats.block,volumeBars:stats.records.filter(r=>r.volume>0).length,orderBook:false,eventRisk},riskNote:eventRisk?'Есть событийный риск: фактическое движение может выйти за исторический масштаб.':f.macro_events?.calendar_stale?'Календарь событий требует обновления.':'',level:level||null,price,threshold,typical,magnitude,direction,paths,n,nativeBars,group,horizon:String(horizon),endLabel:/^\d{4}-\d{2}-\d{2}$/.test(f.target_period?.target_date||'')?f.target_period.target_date.split('-').reverse().join('.'):(f.target_period?.calendar==='24/7'?horizon+' дн.':f.target_period?horizon+' набл.':null),range:validRange?range:null,abstain:!!f.abstain,
  pathSemantics:'conditional_illustration_not_hit_probability',
  timeNote:group>1.1?`Укрупнённые шаги: ≈ ${Number(group.toPrecision(2))} свечей в одном` :group<.9?'Условные шаги внутри выбранной свечи':'Шаг сценария примерно равен шагу свечей',
  qualityNote:validRange?`Подтверждённый диапазон: ${direction>0?'рост':'снижение'} ${Math.abs(100*Math.expm1(direction*Number(range.low_pct)/100)).toFixed(2)}–${Math.abs(100*Math.expm1(direction*Number(range.high_pct)/100)).toFixed(2)}%. Конечные ориентиры расположены внутри него.`:'Масштаб по истории; направленный диапазон не подтверждён.'};
}
function active(chart){return chart.scenario?.available&&chart.offset===0;}
function historyRight(chart,d){return active(chart)?d.pR+(d.W-d.pL-d.pR)*.38:d.pR;}
function values(chart){return active(chart)?chart.scenario.paths.flatMap(p=>p.bars.flatMap(z=>[z.h,z.l])):[];}
function draw(chart,vis,d,ys,palette){
 if(!active(chart))return;
 const s=chart.scenario,ctx=chart.ctx,right=d.W-d.pR,left=d.W-historyRight(chart,d),width=right-left;
 if(width<32)return;
 const x0=left+9,x1=right-10,step=(x1-x0)/s.n,progress=chart.scenarioProgress??1;
 const histStep=(left-d.pL)/(vis.end-vis.start),bw=clamp(step*.74,.65,7);
 ctx.save();ctx.beginPath();ctx.rect(left,d.pT,width,d.priceH-d.pT-d.pB);ctx.clip();
 ctx.fillStyle=palette.tint;ctx.fillRect(left,d.pT,width,d.priceH-d.pT-d.pB);
 ctx.strokeStyle=palette.muted;ctx.globalAlpha=.45;ctx.setLineDash([3,5]);ctx.beginPath();ctx.moveTo(left,d.pT);ctx.lineTo(left,d.priceH-d.pB);ctx.stroke();ctx.globalAlpha=1;ctx.setLineDash([]);
 // The band is the material-move threshold, not a confidence interval.
 ctx.fillStyle=palette.band;const y1=ys.y(s.price*Math.exp(s.threshold/100)),y2=ys.y(s.price*Math.exp(-s.threshold/100));ctx.fillRect(left,y1,width,y2-y1);
 for(const [pi,path] of s.paths.entries()){
  ctx.strokeStyle=pi===0?palette.first:palette.second;ctx.globalAlpha=.4;ctx.setLineDash([2,4]);ctx.beginPath();ctx.moveTo(left,ys.y(s.price));
  path.bars.slice(0,Math.ceil(s.n*progress)).forEach((z,i)=>ctx.lineTo(x0+(i+.5)*step,ys.y(z.c)));ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
  path.bars.forEach((z,i)=>{
   if(i>=Math.ceil(s.n*progress))return;
   const x=x0+(i+.5)*step+(pi===0?-bw*.12:bw*.12),top=Math.min(ys.y(z.o),ys.y(z.c)),height=Math.max(2,Math.abs(ys.y(z.o)-ys.y(z.c))),col=z.c>=z.o?palette.up:palette.down;
   ctx.strokeStyle=col;ctx.lineWidth=1;ctx.setLineDash([]);ctx.beginPath();ctx.moveTo(x,ys.y(z.h));ctx.lineTo(x,ys.y(z.l));ctx.stroke();ctx.setLineDash([]);
   ctx.fillStyle=palette.bg;ctx.fillRect(x-bw/2,top,bw,height);ctx.strokeRect(x-bw/2,top,bw,height);

  });
 }
 ctx.restore();
 // Labels stay in reserved rows, independent of price extremes and panel height.
 ctx.save();ctx.font='10px Arial';ctx.textAlign='left';ctx.textBaseline='top';
 for(let i=0;i<2;i++){ctx.fillStyle=i===0?palette.first:palette.second;ctx.fillText(s.paths[i].label,left+7,d.pT+5+i*15,Math.max(25,width-14))}
 ctx.fillStyle=palette.muted;ctx.font='9px Arial';ctx.textAlign='right';ctx.fillText(s.endLabel||('+'+({'30m':'30 мин','1h':'1 ч','2h':'2 ч','4h':'4 ч'}[s.horizon]||s.horizon+' дн.')),right-3,d.priceH-d.pB+7,width-6);ctx.restore();
}
function svg(chart,vis,d,sy,palette){
 if(!active(chart))return '';
 const s=chart.scenario,left=d.W-historyRight(chart,d),right=d.W-d.pR,width=right-left,step=(width-19)/s.n,histStep=(left-d.pL)/(vis.end-vis.start),bw=clamp(step*.74,.65,7);
 let out=`<line x1="${left}" y1="${d.pT}" x2="${left}" y2="${d.priceH-d.pB}" stroke="${palette.muted}" stroke-dasharray="3 5"/><rect x="${left}" y="${sy(s.price*Math.exp(s.threshold/100))}" width="${width}" height="${sy(s.price*Math.exp(-s.threshold/100))-sy(s.price*Math.exp(s.threshold/100))}" fill="${palette.muted}" opacity=".07"/>`;
 for(const [pi,path] of s.paths.entries()){
  out+=`<text x="${left+7}" y="${d.pT+12+pi*15}" font-family="Arial" font-size="10" fill="${pi?palette.second:palette.first}">${path.label}</text>`;
  for(const [i,z] of path.bars.entries()){
   const x=left+9+(i+.5)*step+(pi===0?-bw*.12:bw*.12),top=Math.min(sy(z.o),sy(z.c)),height=Math.max(2,Math.abs(sy(z.o)-sy(z.c))),col=z.c>=z.o?palette.up:palette.down;
   out+=`<line x1="${x}" x2="${x}" y1="${sy(z.h)}" y2="${sy(z.l)}" stroke="${col}" /><rect x="${x-bw/2}" y="${top}" width="${bw}" height="${height}" fill="none" stroke="${col}"/>`;
  }
 }
 const label=s.endLabel||({'30m':'30 мин','1h':'1 ч','2h':'2 ч','4h':'4 ч'})[s.horizon]||s.horizon+' дн.';
 out+=`<text x="${right-4}" y="${d.priceH-18}" text-anchor="end" font-family="Arial" font-size="9" fill="${palette.muted}">Условные пути · ${s.endLabel?label:"+"+label}</text><text x="${right-4}" y="${d.priceH-5}" text-anchor="end" font-family="Arial" font-size="8" fill="${palette.muted}">Время справа показано отдельно</text>`;return out;
}

const api={build,active,historyRight,values,draw,svg};if(typeof module!=='undefined')module.exports=api;else root.CandleScenarios=api;
})(typeof window!=='undefined'?window:this);
