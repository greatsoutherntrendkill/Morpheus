import * as THREE from './assets/three.module.js';
const host=document.getElementById('globe'),story=document.querySelector('.hero-story'),label=document.getElementById('russia-label');
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
let paused=reduced.matches,visible=true,progress=0,frame=0,loaded=false;
const toggle=document.getElementById('motion-toggle');
function setPause(value){paused=value;toggle.setAttribute('aria-pressed',String(paused));toggle.setAttribute('aria-label',paused?'Возобновить вращение планеты':'Приостановить вращение планеты');toggle.textContent=paused?'▷':'Ⅱ';}
setPause(paused);toggle.addEventListener('click',()=>setPause(!paused));reduced.addEventListener('change',e=>setPause(e.matches));
try {
 const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setClearColor(0x000000,0);renderer.outputColorSpace=THREE.SRGBColorSpace;
 host.appendChild(renderer.domElement);
 renderer.domElement.setAttribute('aria-hidden','true');
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(38,1,.1,100);
 camera.position.set(0,0,9.7);
 const root=new THREE.Group();scene.add(root);
 const radius=2.45;
 const loader=new THREE.TextureLoader();
 const day=loader.load(new URL('./assets/earth-day.jpg',import.meta.url).href,()=>{loaded=true;host.classList.add('globe-ready')});
 const night=loader.load(new URL('./assets/earth-night.jpg',import.meta.url).href);
 day.colorSpace=night.colorSpace=THREE.SRGBColorSpace;
 day.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());
 const earth=new THREE.Mesh(new THREE.SphereGeometry(radius,96,64),new THREE.MeshPhongMaterial({map:day,color:0x354c60,emissiveMap:night,emissive:0xb8d6ea,emissiveIntensity:1.25,specular:0x101921,shininess:5}));root.add(earth);
 scene.add(new THREE.AmbientLight(0x9cbed2,.13));
 const sun=new THREE.DirectionalLight(0xbad9ee,1.35);sun.position.set(-5,4,5);scene.add(sun);
 const atmosphere=new THREE.Mesh(new THREE.SphereGeometry(radius*1.028,80,48),new THREE.ShaderMaterial({vertexShader:'varying vec3 vNormal; varying vec3 vPosition; void main(){vNormal=normalize(normalMatrix*normal);vec4 p=modelViewMatrix*vec4(position,1.0);vPosition=p.xyz;gl_Position=projectionMatrix*p;}',fragmentShader:'varying vec3 vNormal;varying vec3 vPosition;void main(){float rim=1.0-abs(dot(normalize(vNormal),normalize(-vPosition)));float glow=pow(rim,5.0);gl_FragColor=vec4(0.24,0.58,0.84,glow*0.5);}',transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.FrontSide}));root.add(atmosphere);
 const geo=(lat,lon,r=radius)=>{const p=lat*Math.PI/180,t=lon*Math.PI/180;return new THREE.Vector3(r*Math.cos(p)*Math.cos(t),r*Math.sin(p),-r*Math.cos(p)*Math.sin(t));};
 const russia=geo(55.75,37.62),destinations=[[51.5,-.12],[52.5,13.4],[40.7,-74],[25.2,55.3],[19.07,72.87],[31.2,121.47],[35.7,139.7],[1.35,103.8]];
 const lines=[];
 const regionNames={1:"ЕВРОПА",2:"США",3:"ОАЭ",5:"КИТАЙ",6:"ЯПОНИЯ"};
 const pinMaterial=new THREE.MeshBasicMaterial({color:0xc3ffe0,transparent:true,opacity:0});
 const pin=new THREE.Mesh(new THREE.SphereGeometry(.029,12,12),pinMaterial);pin.position.copy(russia.clone().multiplyScalar(1.009));root.add(pin);
 destinations.forEach(([lat,lon],i)=>{
  const end=geo(lat,lon),points=[];const a=russia.clone().normalize(),b=end.clone().normalize();const angle=Math.acos(THREE.MathUtils.clamp(a.dot(b),-1,1));
  for(let j=0;j<=100;j++){const t=j/100;const v=a.clone().multiplyScalar(Math.sin((1-t)*angle)).add(b.clone().multiplyScalar(Math.sin(t*angle))).divideScalar(Math.sin(angle));v.normalize().multiplyScalar(radius+.018+Math.sin(Math.PI*t)*(.25+angle*.32));points.push(v);}
  const curve=new THREE.CatmullRomCurve3(points),geometry=new THREE.TubeGeometry(curve,100,.006,5,false);geometry.setDrawRange(0,0);
  const material=new THREE.MeshBasicMaterial({color:i%3===0?0x95f1be:0x72c89a,transparent:true,opacity:.75});const arc=new THREE.Mesh(geometry,material);root.add(arc);
  const dot=new THREE.Mesh(new THREE.SphereGeometry(.018,8,8),new THREE.MeshBasicMaterial({color:0xe0ffe9}));dot.visible=false;root.add(dot);
  const endpoint=new THREE.Mesh(new THREE.SphereGeometry(.022,10,10),new THREE.MeshBasicMaterial({color:0xade6c4,transparent:true,opacity:0}));endpoint.position.copy(end.multiplyScalar(1.008));root.add(endpoint);
  let tag=null;if(regionNames[i]){tag=document.createElement("div");tag.className="region-label";tag.textContent=regionNames[i];host.appendChild(tag);}
  lines.push({geometry,material,curve,dot,endpoint,index:i,tag});
 });
 const starPositions=[];let seed=42;const rand=()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646;};for(let i=0;i<250;i++)starPositions.push((rand()-.5)*28,(rand()-.5)*20,-8-rand()*8);
 const starGeo=new THREE.BufferGeometry();starGeo.setAttribute('position',new THREE.Float32BufferAttribute(starPositions,3));const stars=new THREE.Points(starGeo,new THREE.PointsMaterial({color:0x8ca7ad,size:.012,transparent:true,opacity:.45}));scene.add(stars);
 const orient=(lat,lon)=>new THREE.Quaternion().setFromEuler(new THREE.Euler(lat*Math.PI/180,-Math.PI/2-lon*Math.PI/180,0,'XYZ'));
 const qStart=orient(18,15),qEnd=orient(51,63);
 let width=0,height=0,rotation=0,last=0;
 function resize(){width=host.clientWidth;height=host.clientHeight;renderer.setSize(width,height);camera.aspect=width/height;camera.updateProjectionMatrix();}
 new ResizeObserver(resize).observe(host);resize();
 const updateScroll=()=>{progress=THREE.MathUtils.clamp(-story.getBoundingClientRect().top/(story.offsetHeight-innerHeight),0,1)};
 addEventListener('scroll',updateScroll,{passive:true});updateScroll();
 new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;},{threshold:0}).observe(story);
 const ease=(a,b,t)=>{const x=THREE.MathUtils.clamp((t-a)/(b-a),0,1);return x*x*(3-2*x);};
 function render(time){frame=requestAnimationFrame(render);if(document.hidden||!visible){last=time;return;}if(time-last<30)return;const dt=Math.min((time-last)/1000,.05);last=time;
  const zoom=reduced.matches?0:ease(.08,.78,progress),mobile=width<760;
  if(!paused&&!reduced.matches&&progress<.12)rotation+=dt*.032;
  root.quaternion.copy(qStart).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),rotation)).slerp(qEnd,zoom);
  root.position.set(mobile?zoom*.16:zoom*1.85,mobile?-1.4-zoom*.3:-1.52+zoom*1.16,0);
  camera.position.z=mobile?11.8-zoom*1.1:9.7-zoom*1.8;
  // Keep the globe readable on narrow screens without cropping the whole hemisphere.
  const scale=mobile?Math.min(1,width/440):1;root.scale.setScalar(scale);
  lines.forEach(({geometry,material,curve,dot,endpoint,index,tag})=>{const draw=reduced.matches?1:ease(.39+index*.035,.64+index*.035,progress);geometry.setDrawRange(0,Math.floor(geometry.index.count*draw/3)*3);endpoint.material.opacity=draw>.98?.85:0;dot.visible=draw>.99;if(dot.visible){const t=paused||reduced.matches?.6:(time*.00008+index*.13)%1;dot.position.copy(curve.getPoint(t));}material.opacity=.75; if(tag){const world=endpoint.getWorldPosition(new THREE.Vector3()),center=root.getWorldPosition(new THREE.Vector3()),front=world.clone().sub(center).normalize().dot(camera.position.clone().sub(world).normalize())>.18;const projected=world.clone().project(camera);tag.style.left=`${(projected.x*.5+.5)*width+8}px`;tag.style.top=`${(-projected.y*.5+.5)*height-18}px`;tag.style.opacity=front&&draw>.99&&!mobile?".85":"0";}});
  pinMaterial.opacity=reduced.matches?.8:ease(.35,.55,progress);
  renderer.render(scene,camera);
  const screen=pin.getWorldPosition(new THREE.Vector3()).project(camera);label.style.left=`${(screen.x*.5+.5)*width+12}px`;label.style.top=`${(-screen.y*.5+.5)*height-12}px`;label.style.opacity=String(reduced.matches?.8:ease(.36,.58,progress));
 }
 requestAnimationFrame(render);
 renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();host.classList.remove('globe-ready');cancelAnimationFrame(frame);});
 window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);renderer.dispose();});
 window.morpheusGlobe={get ready(){return loaded},get progress(){return progress}};
} catch(error){host.classList.add('globe-unavailable');toggle.hidden=true;console.warn('Morpheus: статичный режим планеты.');}
