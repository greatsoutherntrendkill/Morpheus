Official logo: https://www.figma.com/design/TfLY4KAMBmgjhoiUu7VneX/Morpheus?node-id=1124-427
Original source pixels retained in morpheus-official-source.png. SVG uses a tight viewport around the original artwork, without redrawing the logo. Main green #00D364, black #080A09, white #FFFFFF.
