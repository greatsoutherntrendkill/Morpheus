/* Local analysis preferences only. Never persist quotes or forecasts. */
(()=>{'use strict';
const KEY='aa-continuity-v27',tech=location.pathname.includes('technical_lab'),$=s=>document.querySelector(s);
const horizons=['30m','1h','2h','4h','1','3','5','10','20','30','60'];
const times=['1min','5min','15min','30min','1h','4h','1d','1w','1mo','3mo','6mo','1y','3y'];
let storageOK=true,opener=null;
function valid(v){return v&&v.version===1&&['markets','technical'].includes(v.kind)&&typeof v.symbol==='string'&&/^[A-Za-z0-9^=._-]{1,24}$/.test(v.symbol)&&horizons.includes(v.horizon)&&(v.kind!=='markets'||v.horizon!=='3')&&(v.kind!=='technical'||times.includes(v.timeframe))&&(v.kind!=='markets'||['22','66','126','252'].includes(v.range));}
function read(){try{const v=JSON.parse(localStorage.getItem(KEY));return v?.disabled?{disabled:true}:valid(v)?v:null}catch(e){return null}}
function write(v){try{localStorage.setItem(KEY,JSON.stringify(v));storageOK=true}catch(e){storageOK=false}renderResume()}
function save(){if(read()?.disabled)return;let v;
 if(tech)v={version:1,kind:'technical',symbol,horizon:String(shortForecastH),timeframe:selectedTimeframe};
 else v={version:1,kind:'markets',symbol:marketSymbol,horizon:String(marketH),range:$('#market-chart-timeframe')?.value||'126'};
 if(valid(v))write(v);
}
const lessons=[
 ['risk','Доходность и риск','Как читать масштаб движения',[
 'Доходность показывает изменение цены. Риск — насколько сильно результат может отличаться от ожидаемого, в том числе в худшую сторону.',
 'Вероятность роста 60% не означает доходность 60%. Даже частые небольшие выигрыши могут быть перекрыты редкими крупными потерями.',
 'Сравнивайте срок прогноза, возможный размер движения и качество проверки модели. Типичный масштаб — ориентир, а не предел потерь.']],
 ['rates','Ставки и облигации','Почему цена меняется после решения ЦБ',[
 'Когда рыночные доходности растут, цена уже выпущенной облигации с фиксированным купоном обычно снижается. У длинных облигаций эта чувствительность часто выше.',
 'Цена реагирует не только на решение центрального банка, но и на отличие от ожиданий. Ожидаемое повышение ставки может быть учтено в цене заранее.',
 'Коридор FFR — диапазон целевой ставки ФРС. Он не равен диапазону возможной доходности облигации. Учитывайте срок, купон и кредитный риск.']],
 ['inflation','Инфляция','Почему важны единицы и период',[
 'Инфляция за месяц и за год измеряет разные отрезки времени. Снижение годовой инфляции не обязательно означает падение цен: они могут расти медленнее.',
 'Сравнивайте показатели за одинаковый период, с одинаковой сезонной корректировкой. Годовая динамика также зависит от уровня цен год назад — базы сравнения.',
 'Для реакции рынка важно отличие публикации от ожиданий и возможная реакция центрального банка. Первые оценки могут пересматриваться.']],
 ['correlation','Связь и причина','Как не переоценить совпадение',[
 'Если два актива движутся вместе, это ещё не значит, что один вызывает движение другого. На оба может влиять общий фактор — например ставка или курс валюты.',
 'Связь меняется со временем. Корреляция цен может быть обманчивой из-за общего тренда; для анализа движения часто рассматривают доходности.',
 'Проверка на новых данных важнее красивого совпадения в прошлом. Смотрите число наблюдений, период проверки и сравнение с простым ориентиром.']]
];
const dialog=document.createElement('dialog');dialog.id='cx-lesson';dialog.className='cx-dialog';dialog.setAttribute('aria-labelledby','cx-title');document.body.append(dialog);
function openLesson(id,button){const l=lessons.find(x=>x[0]===id);if(!l)return;opener=button;dialog.innerHTML='<div class="cx-kicker">КОРОТКИЙ УРОК · 2 МИНУТЫ</div><h2 id="cx-title"></h2><div class="cx-reading"></div><button type="button" class="cx-primary" id="cx-close">Вернуться к анализу</button>';$('#cx-title').textContent=l[1];for(const text of l[3]){const p=document.createElement('p');p.textContent=text;$('.cx-reading').append(p)}$('#cx-close').textContent=tech||currentPage!=='learning'?'Вернуться к анализу':'Вернуться к урокам';$('#cx-close').onclick=()=>dialog.close();dialog.showModal();$('#cx-close').focus()}
dialog.addEventListener('close',()=>{if(opener?.isConnected)opener.focus()});
dialog.addEventListener('keydown',e=>{if(e.key==='Tab'){e.preventDefault();$('#cx-close').focus()}});
function lessonButtons(){const el=document.createElement('div');el.className='cx-lessons';for(const l of lessons){const b=document.createElement('button');b.type='button';b.textContent=l[1];b.dataset.lesson=l[0];b.addEventListener('click',()=>openLesson(l[0],b));el.append(b)}return el}
const context=document.createElement('section');context.className='cx-context';context.setAttribute('aria-label','Объяснения к анализу');context.innerHTML='<strong>Разобраться в цифрах</strong><p>Короткие объяснения. Выбранный инструмент и срок останутся на месте.</p>';context.append(lessonButtons());
if(tech){const target=$('.right');if(target){const compact=document.createElement('details');compact.className='cx-compact';compact.innerHTML='<summary>Уроки и сохранение анализа</summary>';compact.append(context);target.append(compact)}}else{
 const target=$('#market-forecast');if(target)target.before(context);
 const macro=$('#macro-policy-root');if(macro){const help=document.createElement('details');help.className='cx-compact';help.innerHTML='<summary>Как читать ставки и макропоказатели</summary>';help.append(lessonButtons());macro.before(help)}
 const course=$('.aa-course');if(course){const block=document.createElement('section');block.className='cx-context';block.innerHTML='<div class="cx-kicker">СЛЕДУЮЩИЙ ШАГ</div><h2>Четыре темы для чтения аналитики</h2><p>Начните с темы, которая встретилась в вашем анализе.</p>';block.append(lessonButtons());course.append(block)}
 const old=window.selectMarket;if(typeof old==='function')window.selectMarket=function(...args){const result=old.apply(this,args);save();return result};
}
const resume=document.createElement('section');resume.className='cx-resume';resume.setAttribute('aria-label','Последний анализ');
resume.innerHTML='<div><span class="cx-kicker">ВАШ АНАЛИЗ</span><h2>Продолжить с того же места</h2><p id="cx-saved" aria-live="polite"></p><small>Сохраняются только настройки в этом браузере. Цены и прогноз загружаются заново.</small></div><div class="cx-actions"><button class="cx-primary" id="cx-resume" type="button">Продолжить анализ →</button><button id="cx-clear" type="button">Забыть последний анализ</button><label><input id="cx-remember" type="checkbox"> Запоминать мой выбор</label></div>';
if(!tech){const target=$('[data-page-view="overview"] .aa-navhub')||$('[data-page-view="overview"] .page-top');if(target)target.after(resume)}else{context.append(resume);resume.querySelector('h2').textContent='Настройки анализа';}
function labelH(h){return {'30m':'30 минут','1h':'1 час','2h':'2 часа','4h':'4 часа','1':'1 день','3':'3 дня','5':'5 дней','10':'10 дней','20':'20 дней','30':'1 месяц','60':'3 месяца'}[h]}
function renderResume(){const v=read(),b=resume.querySelector('#cx-resume');b.hidden=!valid(v);resume.querySelector('#cx-clear').hidden=!valid(v);resume.querySelector('#cx-remember').checked=!v?.disabled;resume.querySelector('#cx-saved').textContent=!storageOK?'Браузер не разрешил сохранение. Анализ продолжает работать.':v?.disabled?'Запоминание выключено.':valid(v)?`${v.symbol} · прогноз на ${v.kind==='technical'&&['30','60'].includes(v.horizon)?v.horizon+' дней':labelH(v.horizon)} · ${v.kind==='technical'?'технический график':'рынки'}`:'Выберите инструмент и срок — здесь появится ваш последний анализ.'}
resume.querySelector('#cx-clear').onclick=()=>{try{localStorage.removeItem(KEY)}catch(e){storageOK=false}renderResume()};
resume.querySelector('#cx-remember').onchange=e=>{write(e.target.checked?null:{disabled:true})};
resume.querySelector('#cx-resume').onclick=()=>{const v=read();if(!valid(v))return;if(v.kind==='technical'){const q=new URLSearchParams({symbol:v.symbol,timeframe:v.timeframe,forecast:v.horizon});location.href='technical_lab_v411.html?'+q;return}
 if(tech){location.href='platform.html?resume=1#markets';return}
 if(typeof bySym!=='function'||!bySym(v.symbol)){resume.querySelector('#cx-saved').textContent='Инструмент пока не загружен. Повторите после загрузки рынков.';return}
 marketH=v.horizon;marketChartPeriod=Number(v.range);$('#market-chart-timeframe').value=v.range;selectMarket(v.symbol);$('#market-chart-timeframe').dispatchEvent(new Event('change',{bubbles:true}));
};
document.addEventListener('change',e=>{if(['market-forecast-horizon','market-chart-timeframe','asset','timeframe','short-forecast-horizon'].includes(e.target.id))save()});
window.addEventListener('storage',e=>{if(e.key===KEY)renderResume()});renderResume();
// Resumption is an explicit action, never a redirect on ordinary page load.
if(!tech&&new URLSearchParams(location.search).get('resume')==='1'){let tries=0;const timer=setInterval(()=>{const v=read();if(valid(v)&&typeof bySym==='function'&&bySym(v.symbol)){clearInterval(timer);resume.querySelector('#cx-resume').click();history.replaceState(null,'',location.pathname+'#markets')}else if(++tries>40)clearInterval(timer)},250)}
})();
