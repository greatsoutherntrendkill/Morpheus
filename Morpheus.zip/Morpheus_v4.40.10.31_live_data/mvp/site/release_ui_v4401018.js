(function(root){
'use strict';
const probability=x=>(typeof x==='number'||typeof x==='string'&&x.trim()!=='')&&Number.isFinite(Number(x))&&Number(x)>=0&&Number(x)<=1?Number(x):null;
function direction(f){
 if(!f||f.calibrated_probability===false)return null;
 const p=probability(f.conditional_p_up)??probability(f.p_up);
 if(p===null)return null;
 const score=Math.max(p,1-p)*100;
 return {p,dir:p>=.5?'рост':'падение',prob:score,band:score>70?'strong':score>=55?'moderate':'weak'};
}
function nextEvent(rows,now=new Date()){
 const today=now.toISOString().slice(0,10);
 return (rows||[]).filter(e=>/^\d{4}-\d{2}-\d{2}$/.test(e.date||'')&&Number.isFinite(Date.parse(e.date))&&new Date(e.date).toISOString().slice(0,10)===e.date&&e.date>=today).sort((a,b)=>a.date.localeCompare(b.date))[0]||null;
}
function rates(r){
 const values=['hike','cut','hold'].map(k=>r?.[k]);
 if(values.some(v=>!(typeof v==='number'||typeof v==='string'&&v.trim()!=='')||!Number.isFinite(Number(v))||Number(v)<0||Number(v)>100)||Math.abs(values.reduce((s,v)=>s+Number(v),0)-100)>1)return null;
 return values.map(Number);
}
const api={probability,direction,nextEvent,rates};if(typeof module!=='undefined')module.exports=api;else root.ReleaseUI=api;
})(typeof window!=='undefined'?window:this);
