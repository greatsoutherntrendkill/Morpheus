(()=>{'use strict';
const tech=location.pathname.includes('technical_lab'),link=document.createElement('a');
link.className='vx-skip';link.href='#vx-content';link.textContent=tech?'Перейти к графику':'Перейти к содержимому';document.body.prepend(link);
link.addEventListener('click',e=>{e.preventDefault();const target=tech?document.querySelector('#chart'):document.querySelector('.page.active');if(target){if(!target.hasAttribute('tabindex'))target.setAttribute('tabindex','-1');target.focus({preventScroll:true});target.scrollIntoView({block:'start',behavior:'instant'})}});
if(tech){
 const source=document.querySelector('#source');source.setAttribute('role','status');source.setAttribute('aria-live','polite');source.setAttribute('aria-atomic','true');
 const notice=document.createElement('div');notice.className='vx-empty';notice.hidden=true;notice.innerHTML='<strong>История пока недоступна</strong><p>Для этого инструмента и интервала не получены свечи. Можно повторить запрос или выбрать другой интервал. Дневная история не заменяет минутные свечи.</p><button type="button">Повторить загрузку истории</button>';
 const right=document.querySelector('.right');right.prepend(notice);
 const button=notice.querySelector('button');button.onclick=async()=>{button.disabled=true;button.textContent='Загружаем…';try{await loadData(true)}finally{button.disabled=false;button.textContent='Повторить загрузку истории'}};
 new MutationObserver(()=>{notice.hidden=!/Нет пригодной истории/.test(source.textContent)}).observe(source,{childList:true,subtree:true,characterData:true});
}
})();
