/* FFR boundaries share one scale and one selection animation. */
(function(root){
'use strict';
const selections=new Map(),frames=new Map();
const valid=path=>Array.isArray(path)&&path.length>0&&path.every(z=>Number.isFinite(z.lower)&&Number.isFinite(z.upper)&&z.lower<=z.upper);
function geometry(path,W,H){
 const p=12,values=path.flatMap(z=>[z.lower,z.upper]);let lo=Math.min(...values),hi=Math.max(...values),pad=Math.max(.04,(hi-lo)*.22);lo-=pad;hi+=pad;
 return {x:i=>path.length===1?W/2:p+i*(W-2*p)/(path.length-1),y:v=>H-p-(v-lo)/(hi-lo)*(H-2*p),p};
}
function sample(path,index,key){const a=Math.floor(index),b=Math.min(path.length-1,a+1),f=index-a;return path[a][key]*(1-f)+path[b][key]*f;}
function draw(canvas,path,active,onSelect){
 if(!valid(path))return false;
 const rect=canvas.getBoundingClientRect(),W=rect.width,H=rect.height;if(W<=0||H<=0)return true;
 const d=root.devicePixelRatio||1;canvas.width=Math.round(W*d);canvas.height=Math.round(H*d);
 const ctx=canvas.getContext('2d');ctx.setTransform(d,0,0,d,0,0);
 const style=getComputedStyle(document.body),upper=style.getPropertyValue('--accent').trim()||'#b7f45c',lower=style.getPropertyValue('--ffr-lower').trim()||'#79b8da',grid=style.getPropertyValue('--grid').trim()||'#324236';
 const g=geometry(path,W,H),target=Math.max(0,path.findIndex(z=>(z.month||z.horizon)===active)),id='ffr-'+(canvas.dataset.rateChart||'0');
 const old=selections.get(id),from=old?.signature===path.map(z=>z.month||z.horizon).join('|')?old.index:target;
 const signature=path.map(z=>z.month||z.horizon).join('|');
 if(frames.has(id))cancelAnimationFrame(frames.get(id));
 function paint(index){
  ctx.clearRect(0,0,W,H);ctx.strokeStyle=grid;ctx.lineWidth=1;
  for(const y of [H*.25,H*.75]){ctx.beginPath();ctx.moveTo(g.p,y);ctx.lineTo(W-g.p,y);ctx.stroke();}
  ctx.beginPath();path.forEach((z,i)=>i?ctx.lineTo(g.x(i),g.y(z.upper)):ctx.moveTo(g.x(i),g.y(z.upper)));[...path].reverse().forEach((z,i)=>ctx.lineTo(g.x(path.length-1-i),g.y(z.lower)));ctx.closePath();ctx.fillStyle=upper;ctx.globalAlpha=.07;ctx.fill();ctx.globalAlpha=1;
  for(const [key,color] of [['upper',upper],['lower',lower]]){
   ctx.strokeStyle=color;ctx.lineWidth=2;ctx.lineJoin='round';ctx.beginPath();path.forEach((z,i)=>i?ctx.lineTo(g.x(i),g.y(z[key])):ctx.moveTo(g.x(i),g.y(z[key])));ctx.stroke();
   for(let i=0;i<path.length;i++){ctx.beginPath();ctx.arc(g.x(i),g.y(path[i][key]),2,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();}
   ctx.beginPath();ctx.arc(g.x(index),g.y(sample(path,index,key)),4.5,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();
  }
  selections.set(id,{index,signature});
 }
 const reduced=root.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 if(reduced||from===target)paint(target);
 else {const start=performance.now();paint(from);const tick=now=>{if(!canvas.isConnected)return;const t=Math.min(1,(now-start)/200),e=t*t*(3-2*t);paint(from+(target-from)*e);if(t<1)frames.set(id,requestAnimationFrame(tick));};frames.set(id,requestAnimationFrame(tick));}
 canvas._researchState={path,activeH:active,ffr:true};canvas.setAttribute('role','img');canvas.setAttribute('aria-label',`Коридор FFR: ${path[target].display||''}; ${path[target].label||active}. Нижняя и верхняя границы.`);
 canvas.style.cursor='pointer';canvas.onclick=ev=>{const r=canvas.getBoundingClientRect(),i=Math.max(0,Math.min(path.length-1,Math.round((ev.clientX-r.left-g.p)/Math.max(1,r.width-2*g.p)*(path.length-1))));onSelect(path[i].month||path[i].horizon);};
 return true;
}
function svg(path,active,escape){
 if(!valid(path))return null;const W=520,H=220,g=geometry(path,W,H-35),colors={upper:'#80b83e',lower:'#4f94bd'},target=Math.max(0,path.findIndex(z=>(z.month||z.horizon)===active));
 return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">${['lower','upper'].map(key=>`<polyline fill="none" stroke="${colors[key]}" stroke-width="2" points="${path.map((z,i)=>`${g.x(i)},${g.y(z[key])}`).join(' ')}"/><circle cx="${g.x(target)}" cy="${g.y(path[target][key])}" r="4.5" fill="${colors[key]}"/>`).join('')}${path.map((z,i)=>`<text x="${g.x(i)}" y="192" text-anchor="middle" font-family="Arial" font-size="10" fill="#738578">${escape(z.label||z.month||'')}</text>`).join('')}<text x="12" y="214" font-family="Arial" font-size="11" fill="${colors.lower}">Нижняя граница</text><text x="180" y="214" font-family="Arial" font-size="11" fill="${colors.upper}">Верхняя граница</text></svg>`;
}
const api={valid,geometry,sample,draw,svg};root.FFRCorridor=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
