"""Register Morpheus v4.37 prospective selection guard artifacts."""
import db
import model_registry as MR

if __name__ == "__main__":
    con=db.connect()
    try:
        MR.register_champion(con)
        MR.register_v433_models(con)
        MR.register_v434_models(con)
        MR.register_v435_models(con)
        MR.register_v437_models(con)
        rows=con.execute(
            "SELECT model_version,role,status FROM model_registry WHERE model_version IN (?,?) ORDER BY model_version",
            (MR.V437_ENSEMBLE_VERSION,MR.V437_GUARD_VERSION),
        ).fetchall()
        print(rows)
    finally:
        con.close()
