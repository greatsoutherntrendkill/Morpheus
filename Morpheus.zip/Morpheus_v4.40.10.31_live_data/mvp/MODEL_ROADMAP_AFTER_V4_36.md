# Model roadmap after v4.36

## v4.37 — Prospective Model Selection & Promotion Guard
- статистически сравнить ensemble/challengers на prospective ledger;
- confidence intervals / bootstrap для разницы метрик;
- минимальный sample size и stability gates;
- разрешить context/event layer получить вес только при доказанном prospective edge;
- human-review promotion workflow, без автоматической смены champion.

## v4.38 — Asset-Class Specialists
- отдельные expert-модели для equity / FX / commodities / crypto;
- cross-sectional ranking для акций;
- sector-relative strength и breadth;
- динамический routing по asset class и regime.

## v4.39 — Event Response Models
- отдельные event-conditioned модели FOMC / ECB / ЦБ РФ / CPI / earnings;
- surprise factor;
- исторические sensitivity profiles;
- event-specific calibration и abstention.

## Отложенный Scenario Lab roadmap
Historical Analog Engine, Quant Scenario Model и LLM Scenario Intelligence остаются отдельным сохранённым roadmap и будут подключаться поверх более надёжного прогнозного ядра.
