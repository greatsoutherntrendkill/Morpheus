"""Слой хранения на SQLite. Файл market.db лежит рядом. Ключей и серверов не нужно."""
import sqlite3
from datetime import datetime, timezone
import pandas as pd
from config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS prices (
    symbol TEXT, date TEXT, open REAL, high REAL, low REAL, close REAL,
    PRIMARY KEY (symbol, date)
);
CREATE TABLE IF NOT EXISTS macro (
    series TEXT, date TEXT, value REAL,
    PRIMARY KEY (series, date)
);
CREATE TABLE IF NOT EXISTS macro_pit (
    series TEXT,
    observation_date TEXT,
    available_date TEXT,
    vintage_date TEXT,
    realtime_end TEXT,
    value REAL,
    source TEXT,
    is_initial INTEGER DEFAULT 1,
    PRIMARY KEY (series, observation_date, available_date)
);
CREATE TABLE IF NOT EXISTS macro_release (
    series TEXT,
    observation_date TEXT,
    available_date TEXT,
    release_at TEXT,
    publisher TEXT,
    precision TEXT,
    source TEXT,
    PRIMARY KEY (series, observation_date, available_date)
);
CREATE TABLE IF NOT EXISTS cb_rates (
    country TEXT PRIMARY KEY, regulator TEXT, rate_name TEXT,
    rate REAL, trend TEXT, as_of TEXT
);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
"""


def connect():
    con = sqlite3.connect(DB_PATH)
    con.executescript(SCHEMA)
    try:
        import model_registry as MR
        MR.ensure_schema(con)
    except Exception:
        pass
    # миграция старых баз: добавляем OHLC-колонки, если их нет
    for col in ("open", "high", "low"):
        try:
            con.execute(f"ALTER TABLE prices ADD COLUMN {col} REAL")
        except sqlite3.OperationalError:
            pass
    con.commit()
    return con


def upsert_prices(con, symbol: str, df: pd.DataFrame):
    """df: date + close; опционально open/high/low. Если OHLC нет — берём close."""
    has = {c: c in df.columns for c in ("open", "high", "low")}
    rows = []
    for _, r in df.iterrows():
        c = r["close"]
        if pd.isna(c):
            continue
        o = r["open"] if has["open"] and pd.notna(r.get("open")) else c
        h = r["high"] if has["high"] and pd.notna(r.get("high")) else c
        lo = r["low"] if has["low"] and pd.notna(r.get("low")) else c
        rows.append((symbol, str(pd.Timestamp(r["date"]).date()),
                     float(o), float(h), float(lo), float(c)))
    con.executemany(
        "INSERT OR REPLACE INTO prices VALUES (?,?,?,?,?,?)", rows)
    con.commit()
    return len(rows)




def delete_prices(con, symbol: str):
    con.execute("DELETE FROM prices WHERE symbol = ?", (symbol,))
    con.commit()


def replace_prices(con, symbol: str, df: pd.DataFrame):
    """Atomically replace the whole stored history for one symbol.

    This prevents stale/demo rows (especially exchange holidays) from surviving
    a later real-data update and showing up as isolated spikes on charts.
    """
    con.execute("DELETE FROM prices WHERE symbol = ?", (symbol,))
    con.commit()
    return upsert_prices(con, symbol, df)


def replace_macro(con, series: str, df: pd.DataFrame):
    """Replace a complete macro series so demo/live data never get mixed."""
    con.execute("DELETE FROM macro WHERE series = ?", (series,))
    con.commit()
    return upsert_macro(con, series, df)


def upsert_macro(con, series: str, df: pd.DataFrame):
    rows = [(series, str(pd.Timestamp(d).date()), float(v))
            for d, v in zip(df["date"], df["value"]) if pd.notna(v)]
    con.executemany("INSERT OR REPLACE INTO macro VALUES (?,?,?)", rows)
    con.commit()
    return len(rows)




def delete_macro_pit(con, series: str):
    con.execute("DELETE FROM macro_pit WHERE series = ?", (series,))
    con.commit()


def replace_macro_pit(con, series: str, df: pd.DataFrame):
    """Replace point-in-time/vintage rows for one macro series."""
    con.execute("DELETE FROM macro_pit WHERE series = ?", (series,))
    con.commit()
    return upsert_macro_pit(con, series, df)


def upsert_macro_pit(con, series: str, df: pd.DataFrame):
    """Persist ALFRED-style rows.

    Required columns: observation_date, available_date, value.
    Optional: vintage_date, realtime_end, source, is_initial.
    """
    if df is None or df.empty:
        return 0
    rows = []
    for _, r in df.iterrows():
        obs = r.get("observation_date", r.get("date"))
        avail = r.get("available_date", r.get("realtime_start"))
        val = r.get("value")
        if pd.isna(obs) or pd.isna(avail) or pd.isna(val):
            continue
        vintage = r.get("vintage_date", avail)
        rt_end = r.get("realtime_end", "")
        source = r.get("source", "alfred")
        initial = r.get("is_initial", 1)
        rows.append((
            series,
            str(pd.Timestamp(obs).date()),
            str(pd.Timestamp(avail).date()),
            str(pd.Timestamp(vintage).date()) if pd.notna(vintage) else str(pd.Timestamp(avail).date()),
            "" if pd.isna(rt_end) else str(rt_end),
            float(val),
            str(source),
            int(bool(initial)),
        ))
    con.executemany(
        """INSERT OR REPLACE INTO macro_pit
           (series, observation_date, available_date, vintage_date, realtime_end,
            value, source, is_initial)
           VALUES (?,?,?,?,?,?,?,?)""", rows)
    con.commit()
    return len(rows)


def read_macro_pit(con, series=None) -> pd.DataFrame:
    q = """SELECT series, observation_date, available_date, vintage_date,
                  realtime_end, value, source, is_initial
           FROM macro_pit"""
    params = ()
    if series:
        q += " WHERE series = ?"
        params = (series,)
    df = pd.read_sql_query(
        q + " ORDER BY available_date, observation_date",
        con, params=params,
    )
    if not df.empty:
        for c in ("observation_date", "available_date", "vintage_date"):
            df[c] = pd.to_datetime(df[c], errors="coerce")
    return df




def replace_macro_releases(con, series: str, df: pd.DataFrame):
    con.execute("DELETE FROM macro_release WHERE series = ?", (series,))
    con.commit()
    return upsert_macro_releases(con, series, df)


def upsert_macro_releases(con, series: str, df: pd.DataFrame):
    if df is None or df.empty:
        return 0
    rows = []
    for _, r in df.iterrows():
        obs = r.get("observation_date")
        avail = r.get("available_date")
        if pd.isna(obs) or pd.isna(avail):
            continue
        rows.append((
            series,
            str(pd.Timestamp(obs).date()),
            str(pd.Timestamp(avail).date()),
            str(r.get("release_at", "") or ""),
            str(r.get("publisher", "") or ""),
            str(r.get("precision", "date_only") or "date_only"),
            str(r.get("source", "") or ""),
        ))
    con.executemany(
        """INSERT OR REPLACE INTO macro_release
           (series, observation_date, available_date, release_at,
            publisher, precision, source)
           VALUES (?,?,?,?,?,?,?)""", rows)
    con.commit()
    return len(rows)


def read_macro_releases(con, series=None) -> pd.DataFrame:
    q = """SELECT series, observation_date, available_date, release_at,
                  publisher, precision, source
           FROM macro_release"""
    params = ()
    if series:
        q += " WHERE series = ?"
        params = (series,)
    df = pd.read_sql_query(q + " ORDER BY available_date, observation_date",
                           con, params=params)
    if not df.empty:
        for c in ("observation_date", "available_date"):
            df[c] = pd.to_datetime(df[c], errors="coerce")
    return df


def upsert_cb_rates(con, df: pd.DataFrame):
    cols = ["country", "regulator", "rate_name", "rate", "trend", "as_of"]
    rows = [tuple(r[c] for c in cols) for _, r in df.iterrows()]
    con.executemany(
        "INSERT OR REPLACE INTO cb_rates VALUES (?,?,?,?,?,?)", rows)
    con.commit()
    return len(rows)


def get_meta(con, key, default=None):
    row = con.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row[0] if row else default


def set_meta(con, key, value):
    con.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", (key, str(value)))
    con.commit()


def stamp(con, key):
    set_meta(con, key, datetime.now(timezone.utc).isoformat(timespec="seconds"))


# ---- чтение (для дашборда) ----
def read_prices(con, symbol=None) -> pd.DataFrame:
    q = "SELECT symbol, date, open, high, low, close FROM prices"
    params = ()
    if symbol:
        q += " WHERE symbol = ?"
        params = (symbol,)
    df = pd.read_sql_query(q + " ORDER BY date", con, params=params,
                           parse_dates=["date"])
    return df


def read_macro(con, series=None) -> pd.DataFrame:
    q = "SELECT series, date, value FROM macro"
    params = ()
    if series:
        q += " WHERE series = ?"
        params = (series,)
    return pd.read_sql_query(q + " ORDER BY date", con, params=params,
                             parse_dates=["date"])


def read_cb_rates(con) -> pd.DataFrame:
    return pd.read_sql_query("SELECT * FROM cb_rates", con)


def read_meta(con) -> dict:
    return dict(con.execute("SELECT key, value FROM meta").fetchall())


def symbols(con) -> list:
    return [r[0] for r in con.execute(
        "SELECT DISTINCT symbol FROM prices ORDER BY symbol").fetchall()]
