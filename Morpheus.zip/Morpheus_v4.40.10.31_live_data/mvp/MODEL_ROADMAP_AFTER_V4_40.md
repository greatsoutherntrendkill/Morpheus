# Model roadmap after v4.40

v4.40 завершает следующий слой из плана улучшения forecasting core: после honest direction/confidence система теперь умеет отдельно оценивать распределение исхода и expected move.

## Следующий модельный этап — v4.41 Regime/Event-Conditioned Distribution Review
После того как v4.40 начнёт накапливать prospective interval history:
- сравнить coverage и pinball loss по asset class, horizon и regime;
- отдельно проверить distribution around macro/event windows против обычных дней;
- обучать correction не глобально, а по regime/asset-class только там, где выборка достаточна;
- проверить, нужен ли отдельный tail specialist для high-volatility / event regimes;
- не усложнять distribution routing без prospective evidence.

## Затем
- Historical Analog Engine — остаётся частью отложенного Scenario Lab roadmap;
- Quant Scenario / Monte Carlo / options-implied move fusion — после стабилизации distribution coverage;
- LLM/Scenario Intelligence — поверх численного forecasting core, а не вместо него.

Automatic champion promotion остаётся запрещён.
