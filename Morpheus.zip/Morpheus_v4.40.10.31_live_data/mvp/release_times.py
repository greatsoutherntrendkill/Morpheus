"""Publisher-aware macro release timestamps for v3.1.

ALFRED supplies the actual day a value/revision became available. For selected
major U.S. releases we additionally attach the standard official publication
time, which is useful for future intraday models. Daily/EOD models continue to
gate on available_date, so a missing exact time cannot create look-ahead.
"""
from __future__ import annotations

from datetime import datetime, time
from zoneinfo import ZoneInfo
import pandas as pd

ET = ZoneInfo("America/New_York")
UTC = ZoneInfo("UTC")

# Exact standard release times for the major series used by the project.
# Dates themselves come from ALFRED available_date; only the intraday clock is
# supplied here.
SERIES_SCHEDULE = {
    "CPIAUCSL": ("BLS", time(8, 30), "official_standard_time"),
    "CPILFESL": ("BLS", time(8, 30), "official_standard_time"),
    "UNRATE": ("BLS", time(8, 30), "official_standard_time"),
    "PAYEMS": ("BLS", time(8, 30), "official_standard_time"),
    "PCEPI": ("BEA", time(8, 30), "official_standard_time"),
    "GDPC1": ("BEA", time(8, 30), "official_standard_time"),
    "INDPRO": ("Federal Reserve", time(9, 15), "official_standard_time"),
}


def release_timestamp(series: str, available_date) -> dict:
    d = pd.Timestamp(available_date)
    spec = SERIES_SCHEDULE.get(series)
    if spec is None:
        return {
            "release_at": "",
            "publisher": "",
            "precision": "date_only",
            "source": "alfred_available_date",
        }
    publisher, clock, source = spec
    local = datetime.combine(d.date(), clock, tzinfo=ET)
    return {
        "release_at": local.astimezone(UTC).isoformat(),
        "publisher": publisher,
        "precision": "scheduled_time",
        "source": source,
    }


def build_release_rows(series: str, pit: pd.DataFrame) -> pd.DataFrame:
    if pit is None or pit.empty:
        return pd.DataFrame(columns=[
            "observation_date", "available_date", "release_at",
            "publisher", "precision", "source"
        ])
    rows = []
    # Multiple revisions can occur for the same observation. Each revision gets
    # its own timestamp keyed by available_date.
    for _, r in pit.iterrows():
        meta = release_timestamp(series, r["available_date"])
        rows.append({
            "observation_date": r["observation_date"],
            "available_date": r["available_date"],
            **meta,
        })
    return pd.DataFrame(rows)
