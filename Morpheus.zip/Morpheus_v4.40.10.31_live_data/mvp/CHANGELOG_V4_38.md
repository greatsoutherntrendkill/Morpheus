# Morpheus v4.38 — Asset-Class Specialists

## Главная идея
v4.38 добавляет отдельные specialist-модели для акций, индексов, валют, сырья и криптоактивов. Они используют разные наборы признаков и маршрутизируются по классу актива, региону и текущему рыночному режиму.

Specialist не получает вес автоматически. С первого прогноза его вероятность сохраняется в prospective ledger как challenger. Влияние на итоговую вероятность разрешается только после paired prospective validation v4.37 и явного ручного approval.

## Что добавлено
- `asset_specialists_v438.py` — отдельные class-specific experts.
- Трёхсостоянийная цель: значимый рост / нейтральное движение / значимое падение с volatility-adjusted neutral band.
- Отдельные feature sets для equity / index / FX / commodity / crypto.
- Point-in-time benchmark momentum, relative strength, volatility, correlation, breadth и dispersion.
- Для акций — настоящий cross-sectional rank и sector-relative features только по реально уже загруженным peer histories. Если peer-истории отсутствуют, признак остаётся недоступным; суррогат не подставляется.
- Внутри specialist используется time-ordered development pipeline: train → model-selection → calibration → untouched evaluation.
- Выбор между консервативными Logistic Regression / HistGradientBoosting / ExtraTrees по chronologically later selection slice.
- Отрицательный development skill автоматически сильно сжимает specialist probability к 50%.
- 180-секундный in-memory cache specialist fit для снижения нагрузки.
- `prospective_selection_v438.py` — статистический + human-review guard нового expert.
- Максимальный specialist satellite weight ограничен сверху; automatic promotion запрещён.
- Technical Lab показывает класс модели, route, feature coverage, specialist probability, peer availability и статус допуска.

## Новые API
- `/api/models/quality-v438?symbol=SBER.ME&horizon=10`
- `/api/models/specialist-v438?symbol=SBER.ME&horizon=10`
- `/api/models/selection-v438?symbol=SBER.ME&horizon=10&window_days=180`
- `/api/models/specialist-gate-v438?symbol=SBER.ME&horizon=10`
- `/api/models/promotion-v438/status`
- `POST /api/models/promotion-v438/review`

Старые v4.33–v4.37 diagnostic endpoints сохранены как compatibility contracts.

## Governance
В Model Registry добавлены:
- `asset-class-specialists-v4.38.0`
- `asset-specialist-selection-guard-v4.38.0`

Оба артефакта зарегистрированы как frozen challenger. Champion автоматически не меняется.

## Validation
- Новый suite v4.38: 6/6.
- Полный проектный pytest suite: 94/94.
- Python `py_compile`: пройден.
- Active inline JavaScript `node --check`: пройден.
