"""Morpheus v4.40.1 — evidence/readiness monitor for the next model stage.

This module never trains or reweights a forecast model.  It only answers:
"Do we have enough *prospective* observations, across enough independent market
sessions and contexts, to justify a regime/event-conditioned distribution review?"
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone

import numpy as np

import distribution_feedback_v440 as DIST
import prospective_feedback_v436 as DIRECTION
import evidence_store_v4401 as STORE

VERSION = "evidence-readiness-v4.40.1"

# Deliberately conservative, review-oriented thresholds.  These are minimum
# evidence gates, not claims that the observations are statistically independent.
BASE_SETTLED_MIN = 300
BASE_DATES_MIN = 40
SEGMENT_N_MIN = 75
SEGMENT_DATES_MIN = 15
HORIZON_N_MIN = 100
HORIZON_DATES_MIN = 25
EVENT_N_MIN = 30
EVENT_DATES_MIN = 5


def _pct(num, den):
    return round(100.0 * float(num) / float(den), 1) if den else 0.0


def _group(rows, key_fn):
    groups = defaultdict(list)
    for r in rows:
        groups[str(key_fn(r) or "unknown")].append(r)
    out = []
    for key, items in groups.items():
        dates = {str(x.get("data_as_of") or "")[:10] for x in items if x.get("data_as_of")}
        out.append({"key": key, "n": len(items), "unique_dates": len(dates)})
    return sorted(out, key=lambda x: (x["n"], x["unique_dates"], x["key"]), reverse=True)


def _coverage(rows):
    if not rows:
        return {"coverage_50": None, "coverage_80": None, "mean_pinball": None, "median_mae_pct": None}
    def mean(field):
        vals = [float(r[field]) for r in rows if r.get(field) is not None]
        return round(float(np.mean(vals)), 4) if vals else None
    return {
        "coverage_50": mean("covered50"),
        "coverage_80": mean("covered80"),
        "mean_pinball": round(float(np.mean([float(r["pinball_mean"]) for r in rows if r.get("pinball_mean") is not None])), 6)
            if any(r.get("pinball_mean") is not None for r in rows) else None,
        "median_mae_pct": mean("median_abs_error"),
    }


def _progress(value, target):
    return min(100.0, round(100.0 * float(value) / float(target), 1)) if target else 100.0


def _segment_ready(item, n_min=SEGMENT_N_MIN, dates_min=SEGMENT_DATES_MIN):
    return bool(int(item.get("n") or 0) >= n_min and int(item.get("unique_dates") or 0) >= dates_min)


def readiness() -> dict:
    rows = DIST.LEDGER.rows(limit=20000, settled_only=True)
    total = len(rows)
    unique_dates = len({str(r.get("data_as_of") or "")[:10] for r in rows if r.get("data_as_of")})

    horizons = _group(rows, lambda r: int(r.get("horizon") or 0))
    regimes = _group(rows, lambda r: r.get("regime"))
    assets = _group(rows, lambda r: r.get("asset_class"))
    events = _group([r for r in rows if int(r.get("event_active") or 0) == 1], lambda r: r.get("event_type"))

    horizon_ready = [x for x in horizons if _segment_ready(x, HORIZON_N_MIN, HORIZON_DATES_MIN)]
    regime_ready = [x for x in regimes if x["key"] != "unknown" and _segment_ready(x)]
    asset_ready = [x for x in assets if x["key"] != "unknown" and _segment_ready(x, SEGMENT_N_MIN, 20)]
    event_ready = [x for x in events if x["key"] != "unknown" and _segment_ready(x, EVENT_N_MIN, EVENT_DATES_MIN)]

    base_ready = total >= BASE_SETTLED_MIN and unique_dates >= BASE_DATES_MIN
    regime_review_ready = bool(base_ready and len(horizon_ready) >= 1 and len(regime_ready) >= 2)
    event_review_ready = bool(base_ready and len(event_ready) >= 1)

    if regime_review_ready and event_review_ready:
        state = "READY_FOR_FULL_V4_41_REVIEW"
        label = "READY"
        reason = "достаточно prospective evidence для regime- и event-conditioned review"
    elif regime_review_ready:
        state = "READY_FOR_REGIME_REVIEW"
        label = "READY"
        reason = "достаточно данных для regime review; event-conditioned review ещё накапливает независимые события"
    elif total < 100 or unique_dates < 20:
        state = "NOT_READY"
        label = "NOT READY"
        reason = "prospective история ещё слишком мала для сегментации без высокого риска подгонки"
    else:
        state = "COLLECTING"
        label = "COLLECTING"
        reason = "базовая история растёт, но ещё не выполнены минимальные coverage gates по датам/режимам"

    blockers = []
    if total < BASE_SETTLED_MIN:
        blockers.append({"metric": "settled_forecasts", "current": total, "target": BASE_SETTLED_MIN})
    if unique_dates < BASE_DATES_MIN:
        blockers.append({"metric": "unique_forecast_dates", "current": unique_dates, "target": BASE_DATES_MIN})
    if not horizon_ready:
        best = horizons[0] if horizons else {"n": 0, "unique_dates": 0, "key": None}
        blockers.append({"metric": "mature_horizon", "current": best, "target": {"n": HORIZON_N_MIN, "unique_dates": HORIZON_DATES_MIN}})
    if len(regime_ready) < 2:
        blockers.append({"metric": "mature_regimes", "current": len(regime_ready), "target": 2})

    cov = _coverage(rows)
    quality_flags = []
    if cov["coverage_80"] is not None and not 0.72 <= cov["coverage_80"] <= 0.88:
        quality_flags.append("coverage_80 materially differs from nominal 80%; investigate calibration when sample is mature")
    if cov["coverage_50"] is not None and not 0.42 <= cov["coverage_50"] <= 0.58:
        quality_flags.append("coverage_50 materially differs from nominal 50%; investigate interval width/bias when sample is mature")

    store = STORE.store_status()
    dist_status = DIST.status()
    dir_status = DIRECTION.status()
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    return {
        "version": VERSION,
        "generated_at": now,
        "state": state,
        "label": label,
        "reason": reason,
        "automatic_model_changes": False,
        "ready_for_v441_regime_review": regime_review_ready,
        "ready_for_v441_event_review": event_review_ready,
        "base_evidence": {
            "settled": total,
            "settled_target": BASE_SETTLED_MIN,
            "settled_progress_pct": _progress(total, BASE_SETTLED_MIN),
            "unique_forecast_dates": unique_dates,
            "unique_dates_target": BASE_DATES_MIN,
            "unique_dates_progress_pct": _progress(unique_dates, BASE_DATES_MIN),
            **cov,
        },
        "thresholds": {
            "base_settled_min": BASE_SETTLED_MIN,
            "base_unique_dates_min": BASE_DATES_MIN,
            "horizon_n_min": HORIZON_N_MIN,
            "horizon_unique_dates_min": HORIZON_DATES_MIN,
            "regime_segment_n_min": SEGMENT_N_MIN,
            "regime_segment_unique_dates_min": SEGMENT_DATES_MIN,
            "event_n_min": EVENT_N_MIN,
            "event_unique_dates_min": EVENT_DATES_MIN,
        },
        "segments": {
            "horizons": [{**x, "ready": _segment_ready(x, HORIZON_N_MIN, HORIZON_DATES_MIN)} for x in horizons],
            "regimes": [{**x, "ready": x["key"] != "unknown" and _segment_ready(x)} for x in regimes],
            "asset_classes": [{**x, "ready": x["key"] != "unknown" and _segment_ready(x, SEGMENT_N_MIN, 20)} for x in assets],
            "events": [{**x, "ready": x["key"] != "unknown" and _segment_ready(x, EVENT_N_MIN, EVENT_DATES_MIN)} for x in events],
        },
        "mature_segment_counts": {
            "horizons": len(horizon_ready),
            "regimes": len(regime_ready),
            "asset_classes": len(asset_ready),
            "event_types": len(event_ready),
        },
        "blockers": blockers,
        "quality_flags": quality_flags,
        "store": store,
        "ledgers": {"distribution": dist_status, "directional": dir_status},
    }
