# Morpheus v4.39 — Event Response Models

## Главная идея
v4.39 добавляет отдельный event-response challenger для ФРС, ЕЦБ, Банка России, инфляционных релизов и корпоративной отчётности. Он не заменяет v4.38 specialists и не получает вес автоматически.

Ключевой принцип: **событие не становится направленным сигналом до появления факта**. До публикации решения/релиза модель может только повысить неопределённость и порог публикации. После события направление рассчитывается только из измеримого surprise и исторической реакции актива на тот же тип события.

## Что добавлено
- `event_response_v439.py` — классификация событий, surprise parser, накопительный локальный event archive, историческая чувствительность и live event challenger.
- Поддерживаемые типы: `fed_rate`, `ecb_rate`, `cbr_rate`, `inflation_us/eu/ru`, `earnings`.
- Surprise центрального банка = фактическое изменение ставки минус ожидание, нормированное на 25 б.п.
- Surprise инфляции = факт минус консенсус; текст используется только если явно присутствуют обе величины.
- Earnings surprise использует структурированный surprise либо явный beat/miss; произвольный sentiment не подменяет surprise.
- Историческая чувствительность строится только по событиям строго **до** даты текущего прогноза.
- Реакция считается по фактическим последующим торговым сессиям, а не по календарным дням.
- Для направленного event forecast требуется минимум 6 прошлых сопоставимых событий; `quality_ok` требует более строгого порога.
- `runtime_cache/event_archive_v439.json` хранит только реально наблюдавшиеся события из локального calendar/news потока. Синтетические исторические даты не добавляются.
- Исправлена обработка поля `published` в event context v4.34; ранее seed-news без `published_at/date` могли ошибочно считаться сегодняшними.
- Исправлена прямая релевантность `affected` для списка объектов `{symbol, name}`.
- `prospective_selection_v439.py` — отдельный paired prospective + human-review guard для event-response expert.
- Максимальный event satellite weight ограничен; automatic promotion запрещён.
- Technical Lab показывает тип события, статус surprise, размер исторической выборки, event probability и статус допуска.

## Governance
Новый Event Response по умолчанию имеет **0% веса**. Ненулевой вес возможен только после:
1. накопления paired prospective результатов;
2. прохождения bootstrap/calibration/time-stability guard;
3. явного human approval.

Upcoming event без известного surprise никогда не выбирает направление рынка.

## Новые API
- `/api/models/quality-v439?symbol=SBER.ME&horizon=10`
- `/api/models/event-response-v439?symbol=SBER.ME&horizon=10`
- `/api/models/event-history-v439?symbol=SBER.ME&horizon=10`
- `/api/models/selection-v439?symbol=SBER.ME&horizon=10&window_days=365`
- `/api/models/event-gate-v439?symbol=SBER.ME&horizon=10`
- `/api/models/promotion-v439/status`
- `POST /api/models/promotion-v439/review`

Старые диагностические endpoints v4.33–v4.38 сохранены.

## Model Registry
Добавлены frozen challengers:
- `event-response-models-v4.39.0`
- `event-response-selection-guard-v4.39.0`

Champion автоматически не меняется.

## Validation
- Новый suite v4.39: **7/7**.
- Полный проектный pytest suite: **101/101**.
- Python `py_compile`: пройден.
- Active inline JavaScript `node --check`: пройден.
- Script structure: `index.html` 3/3, `technical_lab_v411.html` 2/2.
- Registry registration v4.39: проверена, оба артефакта зарегистрированы как frozen challenger.
