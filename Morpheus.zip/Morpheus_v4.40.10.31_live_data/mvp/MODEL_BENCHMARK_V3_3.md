# MODEL BENCHMARK v3.3

This package contains a **smoke benchmark** on three representative assets
(S&P 500, BTC/USD and EUR/USD) across 1/5/10/20D. It is included to prove that the
full v3.3 pipeline executes end-to-end. Run `python benchmark_v33.py` with no
`--symbols` argument for the full configured universe.

## Locked comparison

- Champion: `logreg-v3.2.0`
- Challengers: `lightgbm-v3.3.0`, `catboost-v3.3.0`
- Features: `features-pit-v3.1.0`
- Validation: `paired-purged-nonoverlap-bootstrap-holdout-v3.3`
- Final holdout used for tuning: **No**
- Automatic promotion: **No**
- Transaction-cost assumption for 1D economic check: **2 bps one-way**

## Included smoke-benchmark result

LightGBM:
- 12 comparable holdout tests
- 1 Holm-significant Brier win
- 0 Holm-significant losses
- median holdout Brier improvement: +0.017781
- median 1D net-Sharpe delta vs champion: -0.4072
- not eligible for promotion review

CatBoost:
- 12 comparable holdout tests
- 4 Holm-significant Brier wins
- 0 Holm-significant losses
- median holdout Brier improvement: +0.084248
- median 1D net-Sharpe delta vs champion: -0.3889
- not eligible for promotion review

These numbers are **not a full-universe model-selection conclusion**. They are a
packaged end-to-end diagnostic. The full-universe run is the next statistical
evidence step and uses the same locked configurations.
