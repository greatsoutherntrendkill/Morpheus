# Morpheus v4.40.4 — Model Integrity

## Forecast target and probability semantics

- Introduced one shared volatility-adjusted three-state target: `UP / NEUTRAL / DOWN`.
- Neutral observations remain neutral and unknown future observations remain `NaN`; neither is silently coerced to `DOWN`.
- Live forecasts expose normalized `class_probabilities = {up, neutral, down}` that sum to 1.
- Legacy `p_up/p_down` remain for backward compatibility as directional scores used by older gates/UI, and are explicitly labelled as such.
- Fixed a duplicate `p_neutral` output path in the dynamic ensemble that could overwrite the correctly calculated neutral mass.
- Asset-specialist and event-response blending now use consistent conditional-direction semantics.

## Validation and calibration

- Meta-model fitting, probability calibration, signal-threshold tuning and final evaluation use separate chronological blocks.
- Calibration used by deployment is matched to the refitted deployment model rather than being reused from a different fit.
- Reliability/confidence diagnostics are evaluated outside their fit block.
- Frozen historical benchmark remains immutable; a separate recent rolling OOS audit is reported and is not silently substituted into the quality gate.
- Overlapping-horizon prospective and distribution diagnostics use dependence-aware effective sample size / moving-block bootstrap logic.

## Distribution forecast

- Preserved untouched distribution audit.
- Added a post-audit production refit on the allowed history plus a deployment-matched calibration tail.
- Distribution diagnostics now report dependence-adjusted sample information.

## Events

- Event-response returns use session-aware anchors. Events occurring during a session are measured from the previous close rather than from a close that may already contain the event reaction.
- Event structures support timing metadata for more accurate future CPI/FOMC/earnings handling.

## Monthly policy research

- Fed and Bank of Russia monthly percentages are explicitly labelled `scenario weights`, not calibrated probabilities.
- v4.40.4 does not pretend the heuristic v4.40.3 research layer is a trained meeting-level ML model.
- Added persistent pre-meeting point-in-time snapshot collection in `policy_meeting_evidence_v4404.py` so a future meeting model can be trained without retrospective leakage.

## Intraday research

- Short-horizon 30m–4h output is labelled as an uncalibrated technical direction score rather than a calibrated probability.

## Live architecture

- `model_integrity_v4404.py` is the live integrity wrapper and adds a new generation identifier.
- Equity/live API path uses the integrity wrapper as the single source of truth while preserving older diagnostic modules for backward compatibility.
- Prospective evidence from earlier releases is retained; v4.40.4 is a new model generation and should not be merged blindly with older semantics when comparing accuracy.

## Verification

Final release verification:
- `133 passed` across the complete pytest suite;
- Python `compileall`: OK;
- static site export: OK;
- `smoke_test.py`: OK;
- inline/site JavaScript syntax: OK;
- ZIP integrity: checked during release packaging.
