"""Quick sanity checks for a generated Morpheus v3.1 package."""
import json
import os
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd

import models
import sources
import news
import export_site
import db
import macro_features
import external_apis
import release_times

ROOT = Path(__file__).parent


def main():
    # Cross OHLC bounds.
    d = pd.to_datetime(["2026-01-02"])
    num = pd.DataFrame({"date": d, "open": [10.0], "high": [12.0], "low": [9.0], "close": [11.0]})
    den = pd.DataFrame({"date": d, "open": [2.0], "high": [2.2], "low": [1.8], "close": [2.0]})
    x = sources.compute_cross(num, den).iloc[0]
    assert np.isclose(x["high"], 12 / 1.8)
    assert np.isclose(x["low"], 9 / 2.2)

    # v3.1 gate uses effective/non-overlap evidence and 95% CI, not raw point estimates.
    q = models.quality_gate({
        "Наблюдений (effective)": 80,
        "Преимущество non-overlap, п.п.": 4.0,
        "Brier skill non-overlap, %": 5.0,
        "Calibration error non-overlap": 0.05,
        "Edge CI95 low, п.п.": -0.3,
        "Brier skill CI95 low, %": 1.0,
    }, 0.9)
    assert not q["trusted"] and q["bias"] == "neutral"

    q2 = models.quality_gate({
        "Наблюдений (effective)": 90,
        "Преимущество non-overlap, п.п.": 5.0,
        "Brier skill non-overlap, %": 6.0,
        "Calibration error non-overlap": 0.05,
        "Edge CI95 low, п.п.": 1.2,
        "Brier skill CI95 low, %": 1.4,
    }, 0.62)
    assert q2["trusted"] and q2["bias"] == "bullish"

    # Purged multi-day walk-forward: a training label is legal only after its
    # forward horizon has fully elapsed. For H=3 and prediction on day 6, rows
    # ending on/before day 6 are eligible; later outcomes must be excluded.
    dts = pd.bdate_range("2026-01-01", periods=10)
    label_ends = pd.Series(dts, index=dts).shift(-3).dropna().to_numpy()
    eligible = models._purged_train_indices(label_ends, dts[5], t=5)
    assert eligible.tolist() == [0, 1, 2], eligible.tolist()

    # H-day daily forecasts overlap. The independent stream must step by H, and
    # effective evidence can never exceed ceil(N/H) for H>1.
    ii = models._nonoverlap_indices(103, 10)
    assert ii.tolist()[:4] == [0, 10, 20, 30] and len(ii) == 11
    yy = np.array(([0,1]*52)[:103], dtype=float)
    pp = np.linspace(.35,.65,103)
    bb = np.full(103,.5)
    neff = models._effective_oos_n(pp, yy, bb, 10)
    assert 1 <= neff <= 11, neff
    ci = models._moving_block_bootstrap_ci(pp, yy, bb, horizon=10, n_boot=100, seed=1)
    assert ci["block_size"] >= 10 and ci["n_boot"] == 100
    assert ci["edge_low"] <= ci["edge_high"]

    # v3.1: development validation is purged/dependence-aware and the final
    # holdout is frozen: no holdout outcome can become training data for a later
    # holdout prediction.
    old_holdout = os.environ.get("FINAL_HOLDOUT_START")
    os.environ["FINAL_HOLDOUT_START"] = "2025-06-02"
    rng = np.random.default_rng(7)
    synth = pd.Series(
        100*np.exp(np.cumsum(rng.normal(0,.01,850))),
        index=pd.bdate_range("2022-06-01", periods=850)
    )
    wf = models.walk_forward_direction(synth, horizon=10, min_train=220, retrain_every=20)
    assert wf and wf["scorecard"].get("Purged walk-forward") is True
    assert wf["scorecard"].get("Non-overlap evaluation") is True
    assert wf["scorecard"]["Наблюдений (effective)"] <= wf["scorecard"]["Наблюдений (non-overlap)"]
    assert wf.get("validation", {}).get("method") == "purged_significant_direction_nonoverlap_block_bootstrap_with_frozen_final_holdout"
    ho = wf.get("holdout", {})
    assert ho.get("enabled") is True and ho.get("used_for_quality_gate") is False
    assert ho.get("frozen_model") is True
    assert ho.get("train_max_date") < ho.get("start")
    if old_holdout is None:
        os.environ.pop("FINAL_HOLDOUT_START", None)
    else:
        os.environ["FINAL_HOLDOUT_START"] = old_holdout


    # v3.1 revision-aware macro. A revision changes the reconstructed feature
    # only from the date that revision became public.
    con = sqlite3.connect(":memory:")
    con.executescript(db.SCHEMA)
    db.replace_macro(con, "CPIAUCSL", pd.DataFrame({
        "date": pd.to_datetime(["2025-01-01","2026-01-01"]),
        "value": [999.0,999.0],
    }))
    pit = pd.DataFrame({
        "observation_date": pd.to_datetime(["2025-01-01","2026-01-01","2025-01-01"]),
        "available_date": pd.to_datetime(["2025-02-10","2026-02-10","2026-03-10"]),
        "vintage_date": pd.to_datetime(["2025-02-10","2026-02-10","2026-03-10"]),
        "realtime_end": ["","",""],
        "value": [100.0,110.0,102.0],
        "source": ["alfred_revision_event"]*3,
        "is_initial": [1,1,0],
    })
    db.replace_macro_pit(con, "CPIAUCSL", pit)
    idx = pd.bdate_range("2026-02-02","2026-03-20")
    old_legacy = os.environ.get("MACRO_ALLOW_LEGACY_LAG")
    os.environ["MACRO_ALLOW_LEGACY_LAG"] = "0"
    raw = macro_features._raw_daily(con, idx)
    assert not (raw["CPIAUCSL"] == 999.0).any(), "revised current FRED leaked into PIT"
    yoy_before_revision = raw.loc[pd.Timestamp("2026-02-11"),"CPIAUCSL__yoy"]
    yoy_after_revision = raw.loc[pd.Timestamp("2026-03-11"),"CPIAUCSL__yoy"]
    assert np.isclose(yoy_before_revision,10.0,atol=.05)
    assert np.isclose(yoy_after_revision,(110/102-1)*100,atol=.05)
    audit = macro_features.macro_data_audit(con)
    assert audit["mode"] == "point_in_time_revision_aware"
    assert audit["revision_rows"] == 1
    if old_legacy is None:
        os.environ.pop("MACRO_ALLOW_LEGACY_LAG",None)
    else:
        os.environ["MACRO_ALLOW_LEGACY_LAG"] = old_legacy
    con.close()

    # ALFRED event normalization marks first observation as initial and later
    # realtime_start rows as revisions.
    norm = external_apis._fred_obs_to_pit([
        {"date":"2026-01-01","value":"321.5","realtime_start":"2026-02-10","realtime_end":"2026-03-09"},
        {"date":"2026-01-01","value":"322.0","realtime_start":"2026-03-10","realtime_end":"9999-12-31"},
    ])
    assert norm["is_initial"].tolist() == [1,0]
    assert str(norm.iloc[1]["available_date"].date()) == "2026-03-10"

    # Major release timestamps carry official intraday clock precision.
    ts = release_times.release_timestamp("CPIAUCSL","2026-08-12")
    assert ts["precision"] == "scheduled_time" and "12:30:00+00:00" in ts["release_at"]


    # Error-page payloads must be quarantined even after a translator/proxy failure.
    bad = "Error 500 (Server Error)!!1 500. That's an error. There was an error. Please try again later. That's all we know."
    assert news.is_error_payload(bad)
    rows = news.filter_and_rank([{"title": bad, "summary": bad, "source": "Fortune", "published": "2026-09-05T10:00:00Z"}],
                                [{"symbol": "^GSPC", "name": "S&P 500"}])
    assert rows == []

    # Display-only cleaner must remove a short cluster of bogus S&P bars.
    dates = pd.bdate_range("2026-01-01", periods=80)
    base = np.linspace(7000, 7600, len(dates))
    d = pd.DataFrame({"date": dates, "open": base, "high": base*1.01, "low": base*.99, "close": base})
    d.loc[40:42, ["open", "close"]] *= 1.17
    d.loc[40:42, "high"] = d.loc[40:42, ["open", "close"]].max(axis=1)*1.02
    d.loc[40:42, "low"] = d.loc[40:42, ["open", "close"]].min(axis=1)*.98
    ch = export_site.chart_safe_df(d, "^GSPC")
    med = ch["close"].rolling(11, center=True, min_periods=5).median()
    assert ((ch["close"]/med-1).abs().fillna(0) < .07).all()

    # Generated payload structure.
    data = json.loads((ROOT / "site" / "data.json").read_text(encoding="utf-8"))
    assert data["assets"]
    assert all("model_horizons" in a and "model_quality" in a for a in data["assets"])
    assert all("macro_data" in a for a in data["assets"])
    for a in data["assets"]:
        for h,m in (a.get("model_horizons") or {}).items():
            sc=m.get("scorecard") or {}
            assert sc.get("nonoverlap") is True
            assert sc.get("n_eff", 0) <= sc.get("n_nonoverlap", 0) <= sc.get("n_raw", 0)
            assert isinstance(sc.get("edge_ci"), list) and len(sc["edge_ci"]) == 2
            assert isinstance(sc.get("brier_skill_ci"), list) and len(sc["brier_skill_ci"]) == 2
            assert "holdout" in m and m["holdout"].get("used_for_quality_gate") is False
    assert all((a.get("forecast_text") or {}).get("rating") not in {"buy", "sell"} for a in data["assets"])

    # News intelligence fields.
    for n in data.get("news", []):
        assert "relevance_score" in n
        assert "impact_score" in n
        assert "sentiment_label" in n
        assert "channels" in n


    # No obvious broken labels or error-page news should reach the UI.
    public_data = (ROOT / "site" / "data.json").read_text(encoding="utf-8").lower()
    assert "error 500" not in public_data and "server error" not in public_data and "please try again later" not in public_data
    index_html = (ROOT / "site" / "platform.html").read_text(encoding="utf-8")
    assert "undefined…undefined" not in index_html

    assert 'src="data.js?v=' in index_html
    assert 'id="map-world"' in index_html and 'id="map-overview"' in index_html
    assert 'id="asset-grid"' in index_html and 'id="provider-grid"' in index_html
    assert 'Единый прогноз' in index_html
    assert 'Alternative Data Terminal' not in index_html and 'Market News Terminal' not in index_html
    assert '<summary>Market & Macro Indicators' not in index_html

    # The browser renders chart_history, not raw model history.
    # Test the actual display payload and use asset-class-aware thresholds.
    crypto = {"BTC-USD","ETH-USD","SOL-USD","XRP-USD"}
    commodities = {"GC=F","SI=F","CL=F","NG=F","HG=F"}
    fx = {"EURUSD=X","GBPUSD=X","JPY=X","AUDUSD=X","USDCAD=X","RUB=X","CNYRUB","DX-Y.NYB"}
    equity_futures = {"ES=F","NQ=F"}

    for a in data["assets"]:
        hist = a.get("chart_history") or a.get("history") or []
        sym = a["symbol"]
        if sym in crypto:
            th = .22
        elif sym in commodities:
            th = .16
        elif sym in fx:
            th = .055
        elif sym.startswith("^") or sym in equity_futures or sym in {"IMOEX","RTSI","MOEXBC","RGBI"}:
            th = .075
        else:
            th = .10

        for i in range(1, len(hist)-1):
            prev, cur, nxt = hist[i-1]["c"], hist[i]["c"], hist[i+1]["c"]
            if prev > 0 and nxt > 0:
                neigh = (prev+nxt)/2
                gap = abs(prev/nxt-1)
                # Only flag a bar if both neighbours agree closely and the middle bar
                # is implausibly far away for this asset class.
                assert not (gap < .035 and abs(cur/neigh-1) > th), (sym, hist[i])

    # Real secrets are allowed in this user-specific .env but MUST NOT leak into browser assets.
    env = ROOT / ".env"
    assert env.exists(), "requested .env is missing"
    secrets = []
    for line in env.read_text(encoding="utf-8").splitlines():
        if "=" not in line or line.lstrip().startswith("#"):
            continue
        k, v = line.split("=", 1)
        if k.endswith("API_KEY") and v.strip():
            secrets.append(v.strip())
    public = (ROOT / "site" / "platform.html").read_text(encoding="utf-8") + (ROOT / "site" / "data.js").read_text(encoding="utf-8")
    assert all(secret not in public for secret in secrets), "API secret leaked to public frontend"

    print(f"OK: {len(data['assets'])} assets; {len(data.get('news', []))} news rows; secrets stay server-side")


if __name__ == "__main__":
    main()
