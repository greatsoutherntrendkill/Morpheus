
"""One-command v3.6 refresh.

Examples:
    python refresh_v36.py
    python refresh_v36.py --no-fred
    python refresh_v36.py --demo

Sequence:
1) update market/macro data;
2) rebuild champion site snapshot + settle matured champion forecasts;
3) rebuild frozen/prospective pooled cross-asset challengers.
"""
from __future__ import annotations
import subprocess, sys

def run(cmd):
    print("\\n>>>"," ".join(cmd))
    subprocess.run(cmd,check=True)

def main():
    args=sys.argv[1:]
    run([sys.executable,"update.py",*args])
    run([sys.executable,"export_site.py"])
    run([sys.executable,"build_cross_asset_v36.py"])
    print("\\nAllAnalytics v3.6 refresh complete.")

if __name__=="__main__":
    main()
