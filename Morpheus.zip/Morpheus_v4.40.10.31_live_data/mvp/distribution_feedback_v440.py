"""Prospective ledger for v4.40 distribution forecasts.

v4.40.1 storage upgrade
-----------------------
The forecast/settlement logic is still v4.40, but its evidence now lives in a
persistent user-level store instead of inside a release folder.  New forecast
snapshots also retain asset class, market regime and event context so later
regime/event-conditioned reviews can be performed without reconstructing the
past from current data.

The ledger is monitoring only; results cannot promote or reweight a model
automatically.
"""
from __future__ import annotations
from contextlib import closing

import hashlib
import json
import math
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

import evidence_store_v4401 as EVIDENCE4401

VERSION = "distribution-feedback-v4.40.1"
SCHEMA_VERSION = 2
LEGACY_DB_NAME = "distribution_feedback_v440.sqlite3"
DEFAULT_DB = EVIDENCE4401.ledger_path("distribution_feedback.sqlite3")
QS = (0.10, 0.25, 0.50, 0.75, 0.90)


def _now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _finite(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _norm_history(frame):
    d = pd.DataFrame(frame).copy() if not isinstance(frame, pd.DataFrame) else frame.copy()
    if d.empty:
        return pd.DataFrame(columns=["date", "close"])
    d = d.rename(columns={"t": "date", "c": "close", "Date": "date", "Close": "close"})
    if "date" not in d or "close" not in d:
        return pd.DataFrame(columns=["date", "close"])
    d["date"] = pd.to_datetime(d["date"], errors="coerce").dt.tz_localize(None)
    d["close"] = pd.to_numeric(d["close"], errors="coerce")
    return d.dropna(subset=["date", "close"]).sort_values("date").drop_duplicates("date", keep="last")[["date", "close"]]


def _pinball(y, p, q):
    e = float(y) - float(p)
    return max(q * e, (q - 1) * e)


def _json(value):
    return json.dumps(value if value is not None else {}, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _event_context(forecast: dict) -> tuple[int, str | None, str | None]:
    er = (forecast or {}).get("event_response") or {}
    ev = er.get("event") or {}
    status = str(er.get("status") or "")
    event_type = ev.get("type") or er.get("event_type")
    event_actor = ev.get("actor") or ev.get("cb")
    active = bool(event_type and status not in {"", "no_near_event"})
    return int(active), (str(event_type) if event_type else None), (str(event_actor) if event_actor else None)


def _asset_class(forecast: dict) -> str | None:
    spec = (forecast or {}).get("asset_specialist") or {}
    value = spec.get("asset_class") or (forecast or {}).get("specialist_asset_class")
    return str(value) if value else None


def path_is_persistent(path: str | Path) -> bool:
    try:
        return Path(path).resolve().parent == EVIDENCE4401.evidence_root().resolve()
    except Exception:
        return False


class Ledger:
    def __init__(self, path=None):
        self.path = Path(path or os.getenv("ALLANALYTICS_DISTRIBUTION_FEEDBACK_DB") or DEFAULT_DB).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()
        self.migration_report = self._migrate_legacy() if path is None else {
            "sources": [], "forecasts_imported": 0, "settlements_imported": 0, "errors": []
        }

    def _con(self):
        c = sqlite3.connect(self.path, timeout=6)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        c.execute("PRAGMA busy_timeout=6000")
        c.execute("PRAGMA foreign_keys=ON")
        return c

    @staticmethod
    def _cols(con, table: str) -> set[str]:
        return {str(r[1]) for r in con.execute(f"PRAGMA table_info({table})").fetchall()}

    def _ensure_column(self, con, table: str, name: str, ddl: str):
        if name not in self._cols(con, table):
            con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")

    def _init(self):
        with closing(self._con()) as c, c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS distribution_forecast_ledger(
              id INTEGER PRIMARY KEY AUTOINCREMENT, forecast_key TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL,
              symbol TEXT NOT NULL,horizon INTEGER NOT NULL,data_as_of TEXT NOT NULL,entry_price REAL NOT NULL,
              distribution_version TEXT NOT NULL,q10 REAL NOT NULL,q25 REAL NOT NULL,q50 REAL NOT NULL,q75 REAL NOT NULL,q90 REAL NOT NULL,
              expected_abs_move REAL,quality_ok INTEGER NOT NULL,options_json TEXT NOT NULL,diagnostics_json TEXT NOT NULL,origin TEXT NOT NULL,
              asset_class TEXT, regime TEXT, event_active INTEGER NOT NULL DEFAULT 0, event_type TEXT, event_actor TEXT);
            CREATE INDEX IF NOT EXISTS idx_dist_pending ON distribution_forecast_ledger(symbol,horizon,data_as_of);
            CREATE TABLE IF NOT EXISTS distribution_settlement_ledger(
              id INTEGER PRIMARY KEY AUTOINCREMENT,forecast_id INTEGER NOT NULL UNIQUE,settled_at TEXT NOT NULL,target_as_of TEXT NOT NULL,
              target_price REAL NOT NULL,realized_return_pct REAL NOT NULL,covered50 INTEGER NOT NULL,covered80 INTEGER NOT NULL,
              pinball_mean REAL NOT NULL,crps_like REAL NOT NULL,median_abs_error REAL NOT NULL,abs_move_error REAL,
              FOREIGN KEY(forecast_id) REFERENCES distribution_forecast_ledger(id));
            CREATE TABLE IF NOT EXISTS distribution_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            """)
            # Forward migration when a v4.40 database is used as an explicit path.
            self._ensure_column(c, "distribution_forecast_ledger", "asset_class", "TEXT")
            self._ensure_column(c, "distribution_forecast_ledger", "regime", "TEXT")
            self._ensure_column(c, "distribution_forecast_ledger", "event_active", "INTEGER NOT NULL DEFAULT 0")
            self._ensure_column(c, "distribution_forecast_ledger", "event_type", "TEXT")
            self._ensure_column(c, "distribution_forecast_ledger", "event_actor", "TEXT")
            c.execute("CREATE INDEX IF NOT EXISTS idx_dist_context ON distribution_forecast_ledger(asset_class,regime,event_active,event_type,data_as_of)")
            c.execute("INSERT OR REPLACE INTO distribution_meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
            c.execute("INSERT OR REPLACE INTO distribution_meta(key,value) VALUES('evidence_store_version',?)", (EVIDENCE4401.VERSION,))
            c.commit()

    def _migrate_legacy(self) -> dict:
        report = {"sources": [], "forecasts_imported": 0, "settlements_imported": 0, "errors": []}
        candidates = EVIDENCE4401.legacy_db_candidates(__file__, LEGACY_DB_NAME, self.path)
        base_cols = [
            "forecast_key","created_at","symbol","horizon","data_as_of","entry_price","distribution_version",
            "q10","q25","q50","q75","q90","expected_abs_move","quality_ok","options_json","diagnostics_json","origin"
        ]
        extra_cols = ["asset_class","regime","event_active","event_type","event_actor"]
        settlement_cols = [
            "settled_at","target_as_of","target_price","realized_return_pct","covered50","covered80",
            "pinball_mean","crps_like","median_abs_error","abs_move_error"
        ]
        for src in candidates:
            try:
                fp_key, fp_value = EVIDENCE4401.source_fingerprint(src)
                meta_key = f"legacy_import:{fp_key}"
                with closing(self._con()) as probe, probe:
                    seen = probe.execute("SELECT value FROM distribution_meta WHERE key=?", (meta_key,)).fetchone()
                if seen and str(seen[0]) == fp_value:
                    continue
                scon = sqlite3.connect(src, timeout=4.0); scon.row_factory = sqlite3.Row
                tables = {r[0] for r in scon.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if "distribution_forecast_ledger" not in tables:
                    scon.close(); continue
                source_cols = self._cols(scon, "distribution_forecast_ledger")
                frows = scon.execute("SELECT * FROM distribution_forecast_ledger ORDER BY id").fetchall()
                if not frows:
                    scon.close()
                    with closing(self._con()) as c, c:
                        c.execute("INSERT OR REPLACE INTO distribution_meta(key,value) VALUES(?,?)", (meta_key, fp_value)); c.commit()
                    continue
                srows = scon.execute("SELECT * FROM distribution_settlement_ledger ORDER BY id").fetchall() if "distribution_settlement_ledger" in tables else []
                source_id_to_key = {int(r["id"]): str(r["forecast_key"]) for r in frows}
                imported_f = imported_s = 0
                with closing(self._con()) as c, c:
                    all_cols = base_cols + extra_cols
                    q = ",".join("?" for _ in all_cols)
                    for r in frows:
                        vals = [r[col] for col in base_cols]
                        vals.extend([r[col] if col in source_cols else (0 if col == "event_active" else None) for col in extra_cols])
                        cur = c.execute(f"INSERT OR IGNORE INTO distribution_forecast_ledger({','.join(all_cols)}) VALUES({q})", vals)
                        imported_f += int(bool(cur.rowcount))
                    qs = ",".join("?" for _ in (["forecast_id"] + settlement_cols))
                    for r in srows:
                        key = source_id_to_key.get(int(r["forecast_id"]))
                        if not key: continue
                        target = c.execute("SELECT id FROM distribution_forecast_ledger WHERE forecast_key=?", (key,)).fetchone()
                        if not target: continue
                        vals = [int(target[0])] + [r[col] for col in settlement_cols]
                        cur = c.execute(f"INSERT OR IGNORE INTO distribution_settlement_ledger(forecast_id,{','.join(settlement_cols)}) VALUES({qs})", vals)
                        imported_s += int(bool(cur.rowcount))
                    c.execute("INSERT OR REPLACE INTO distribution_meta(key,value) VALUES(?,?)", (meta_key, fp_value))
                    c.commit()
                scon.close()
                report["sources"].append(str(src))
                report["forecasts_imported"] += imported_f
                report["settlements_imported"] += imported_s
            except Exception as exc:
                report["errors"].append({"source": str(src), "error": type(exc).__name__})
        return report

    def record_row(self, row: dict, origin="api"):
        symbol = str(row.get("symbol") or "").upper()
        asof = str(row.get("as_of") or "")[:10]
        d = _norm_history(row.get("history") or [])
        entry = _finite(d.iloc[-1]["close"]) if len(d) else None
        if not symbol or not asof or entry is None:
            return {"inserted": 0, "existing": 0, "skipped": 1}
        ins = exist = skip = 0
        with closing(self._con()) as c, c:
            for raw_h, f in (row.get("forecasts") or {}).items():
                try:
                    h = int(raw_h)
                except Exception:
                    skip += 1; continue
                f = f or {}
                dist = f.get("distribution_forecast") or {}
                q = dist.get("quantiles") or {}
                vals = [_finite(q.get(k)) for k in ("q10_return_pct", "q25_return_pct", "q50_return_pct", "q75_return_pct", "q90_return_pct")]
                if dist.get("status") != "ok" or any(v is None for v in vals):
                    skip += 1; continue
                ver = str(dist.get("version") or f.get("distribution_version") or "unknown")
                payload = f"{symbol}|{h}|{asof}|{ver}|" + "|".join(f"{v:.5f}" for v in vals)
                key = hashlib.sha256(payload.encode()).hexdigest()
                diag = {
                    "evaluation": dist.get("evaluation") or {},
                    "calibration": dist.get("calibration") or {},
                    "feature_coverage": dist.get("feature_coverage"),
                    "compute_profile": dist.get("compute_profile"),
                }
                event_active, event_type, event_actor = _event_context(f)
                cur = c.execute("""INSERT OR IGNORE INTO distribution_forecast_ledger(
                    forecast_key,created_at,symbol,horizon,data_as_of,entry_price,distribution_version,q10,q25,q50,q75,q90,
                    expected_abs_move,quality_ok,options_json,diagnostics_json,origin,asset_class,regime,event_active,event_type,event_actor)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (key,_now(),symbol,h,asof,float(entry),ver,*[float(v) for v in vals],_finite(dist.get("expected_abs_move_pct")),int(bool(dist.get("quality_ok"))),
                     _json(dist.get("options_benchmark") or {}),_json(diag),str(origin),_asset_class(f),str(f.get("regime")) if f.get("regime") else None,
                     event_active,event_type,event_actor))
                if cur.rowcount:
                    ins += 1
                else:
                    exist += 1
            c.commit()
        return {"inserted": ins, "existing": exist, "skipped": skip}

    def _pending(self, limit=18):
        with closing(self._con()) as c, c:
            rows = c.execute("""SELECT f.* FROM distribution_forecast_ledger f LEFT JOIN distribution_settlement_ledger s ON s.forecast_id=f.id
                              WHERE s.forecast_id IS NULL ORDER BY f.data_as_of,f.id LIMIT ?""", (max(120, int(limit) * 12),)).fetchall()
        today = pd.Timestamp.utcnow().tz_localize(None).normalize(); out = []
        for r in rows:
            z = dict(r)
            try:
                base = pd.Timestamp(z["data_as_of"]).normalize()
            except Exception:
                continue
            if (today - base).days >= max(1, int(z["horizon"])):
                out.append(z)
                if len(out) >= limit:
                    break
        return out

    def settle_due(self, history_loader: Callable[[str], object], limit=18):
        rows = self._pending(limit); cache = {}; settled = unavailable = errors = 0
        for f in rows:
            sym = f["symbol"]
            if sym not in cache:
                try:
                    cache[sym] = history_loader(sym)
                except Exception as exc:
                    cache[sym] = exc
            hist = cache[sym]
            if isinstance(hist, Exception):
                errors += 1; continue
            d = _norm_history(hist); base = pd.Timestamp(f["data_as_of"]); future = d[d["date"] > base]
            h = int(f["horizon"])
            if len(future) < h:
                unavailable += 1; continue
            target = future.iloc[h-1]
            ret = math.log(float(target["close"]) / float(f["entry_price"])) * 100.0
            qs = [float(f[k]) for k in ("q10", "q25", "q50", "q75", "q90")]
            pb = float(np.mean([_pinball(ret, qs[i], QS[i]) for i in range(5)]))
            covered50 = int(qs[1] <= ret <= qs[3]); covered80 = int(qs[0] <= ret <= qs[4])
            abs_err = abs(abs(ret) - float(f["expected_abs_move"])) if f["expected_abs_move"] is not None else None
            try:
                with closing(self._con()) as c, c:
                    cur = c.execute("""INSERT OR IGNORE INTO distribution_settlement_ledger(
                      forecast_id,settled_at,target_as_of,target_price,realized_return_pct,covered50,covered80,pinball_mean,crps_like,median_abs_error,abs_move_error)
                      VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (f["id"],_now(),str(pd.Timestamp(target["date"]).date()),float(target["close"]),ret,covered50,covered80,pb,2*pb,abs(ret-qs[2]),abs_err))
                    c.commit(); settled += int(bool(cur.rowcount))
            except Exception:
                errors += 1
        return {"settled": settled, "unavailable": unavailable, "errors": errors, "checked": len(rows)}

    def status(self):
        with closing(self._con()) as c, c:
            total = int(c.execute("SELECT COUNT(*) FROM distribution_forecast_ledger").fetchone()[0])
            done = int(c.execute("SELECT COUNT(*) FROM distribution_settlement_ledger").fetchone()[0])
            unique_dates = int(c.execute("SELECT COUNT(DISTINCT data_as_of) FROM distribution_forecast_ledger").fetchone()[0])
            settled_dates = int(c.execute("""SELECT COUNT(DISTINCT f.data_as_of) FROM distribution_forecast_ledger f
                                              JOIN distribution_settlement_ledger s ON s.forecast_id=f.id""").fetchone()[0])
            first = c.execute("SELECT MIN(created_at) FROM distribution_forecast_ledger").fetchone()[0]
            last = c.execute("SELECT MAX(settled_at) FROM distribution_settlement_ledger").fetchone()[0]
        return {
            "version": VERSION, "schema_version": SCHEMA_VERSION, "forecasts": total, "settled": done,
            "pending": max(0, total-done), "unique_forecast_dates": unique_dates, "settled_forecast_dates": settled_dates,
            "first_recorded_at": first, "last_settled_at": last, "database": self.path.name, "database_path": str(self.path),
            "persistent_store": path_is_persistent(self.path), "migration": self.migration_report,
            "automatic_promotion": False,
        }

    def rows(self, limit=5000, settled_only=False):
        sql = """SELECT f.*,s.settled_at,s.target_as_of,s.target_price,s.realized_return_pct,s.covered50,s.covered80,
                 s.pinball_mean,s.crps_like,s.median_abs_error,s.abs_move_error
                 FROM distribution_forecast_ledger f LEFT JOIN distribution_settlement_ledger s ON s.forecast_id=f.id"""
        if settled_only:
            sql += " WHERE s.forecast_id IS NOT NULL"
        sql += " ORDER BY f.id DESC LIMIT ?"
        with closing(self._con()) as c, c:
            return [dict(r) for r in c.execute(sql, (max(1, min(int(limit), 20000)),)).fetchall()]

    def scorecard(self, window_days=365, symbol=None, horizon=None):
        where = ["date(f.data_as_of)>=date('now',?)"]
        args = [f"-{max(30,min(int(window_days),3650))} days"]
        if symbol:
            where.append("f.symbol=?"); args.append(str(symbol).upper())
        if horizon is not None:
            where.append("f.horizon=?"); args.append(int(horizon))
        sql = f"""SELECT f.*,s.realized_return_pct,s.covered50,s.covered80,s.pinball_mean,s.crps_like,s.median_abs_error,s.abs_move_error
                FROM distribution_forecast_ledger f JOIN distribution_settlement_ledger s ON s.forecast_id=f.id WHERE {' AND '.join(where)} ORDER BY f.data_as_of"""
        with closing(self._con()) as c, c:
            rows = [dict(r) for r in c.execute(sql, args).fetchall()]
        if not rows:
            return {"version": VERSION, "n": 0, "automatic_promotion": False, "reason": "no settled distribution forecasts"}
        return {
            "version": VERSION, "n": len(rows), "coverage_50": round(float(np.mean([r["covered50"] for r in rows])), 4),
            "coverage_80": round(float(np.mean([r["covered80"] for r in rows])), 4),
            "mean_pinball": round(float(np.mean([r["pinball_mean"] for r in rows])), 6),
            "crps_like": round(float(np.mean([r["crps_like"] for r in rows])), 6),
            "median_mae_pct": round(float(np.mean([r["median_abs_error"] for r in rows])), 4),
            "expected_abs_move_mae_pct": round(float(np.mean([r["abs_move_error"] for r in rows if r["abs_move_error"] is not None])), 4)
                if any(r["abs_move_error"] is not None for r in rows) else None,
            "unique_forecast_dates": len({str(r["data_as_of"]) for r in rows}),
            "automatic_promotion": False,
        }


LEDGER = Ledger()


def record_forecast_row(row, origin="api"):
    return LEDGER.record_row(row, origin)


def settle_due(history_loader, limit=18):
    return LEDGER.settle_due(history_loader, limit)


def status():
    return LEDGER.status()


def scorecard(window_days=365, symbol=None, horizon=None):
    return LEDGER.scorecard(window_days, symbol, horizon)
