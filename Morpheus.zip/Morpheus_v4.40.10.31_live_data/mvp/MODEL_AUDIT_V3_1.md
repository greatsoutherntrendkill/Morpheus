# Morpheus v3.1 — Revision-Aware Validation Audit

## 1. ALFRED revisions

v3.0 used initial releases only. This was conservative and prevented future
revisions from leaking backward, but it did not reproduce legitimate revisions
that market participants had already seen later.

v3.1 ingests FRED/ALFRED `output_type=3` ("new and revised observations only").
Each event has its own `available_date` (`realtime_start`).

The macro state is reconstructed chronologically:
1. apply all new/revised values known on that date;
2. keep the latest vintage of every observation known at that point;
3. derive latest level, YoY and ~3-month change from that state;
4. forward-fill only after the event date.

A revision can therefore alter a historical-derived feature only from the day the
revision became public.

## 2. Release timestamps

`macro_release` stores:
- series
- observation_date
- available_date
- release_at
- publisher
- precision
- source

For selected major series the actual ALFRED availability date is combined with
the publisher's standard scheduled clock:
- BLS CPI / Employment Situation: 08:30 ET
- BEA GDP / Personal Income and Outlays: 08:30 ET
- Federal Reserve Industrial Production: 09:15 ET

Other series remain `date_only`; the system does not invent an exact clock.

## 3. Frozen final holdout

Default boundary: `2026-04-01`.

Development metrics and the quality gate use only dates before this boundary.
For final-holdout predictions:
- labels must still satisfy the normal horizon purge;
- the model is fit once using only pre-holdout rows;
- the baseline is frozen on the same pre-holdout information;
- later holdout outcomes are never used to retrain subsequent holdout predictions.

The live model may refit on all currently known history after the holdout audit is
computed, but that cannot change the recorded final-holdout results.

## 4. Quick price-only diagnostic on the packaged snapshot

The packaged database did not contain live ALFRED revisions in this execution
environment, so these examples are only a plumbing diagnostic, not the official
v3.1 macro-aware model audit:

- S&P 500 10D: holdout raw N 103; non-overlap edge +10.0 pp; Brier skill -48.0%;
  edge CI includes zero.
- Bitcoin 10D: holdout raw N 103; edge -24.1 pp; Brier skill -85.7%.
- EUR/USD 10D: holdout raw N 103; edge +18.2 pp; Brier skill +4.8%;
  edge and Brier-skill CIs still include zero.

These examples reinforce why the holdout is an audit layer rather than a new
source of tuning decisions.

## 5. Next step

Before adding a nonlinear model, create an immutable Model Registry / Prediction
Ledger and formal champion-vs-challenger promotion rules. This prevents repeated
experimentation from silently overfitting the final test.
