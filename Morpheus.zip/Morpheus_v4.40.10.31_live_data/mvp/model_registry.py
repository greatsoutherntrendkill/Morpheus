"""v3.2 model governance: immutable registry, prediction ledger, champion/challenger policy."""
from __future__ import annotations
import hashlib, json, sqlite3
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

MODEL_FAMILY = "logistic_regression"
MODEL_VERSION = "logreg-v3.2.0"
FEATURE_VERSION = "features-pit-v3.1.0"
VALIDATION_VERSION = "purged-nonoverlap-bootstrap-holdout-v3.1"
CHALLENGER_VALIDATION_VERSION = "paired-purged-nonoverlap-bootstrap-holdout-v3.3"


def _utcnow(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat()
def _sha(path):
    p=Path(path)
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16] if p.exists() else "missing"

def code_fingerprint(root=None):
    root=Path(root or Path(__file__).parent)
    parts=[_sha(root/x) for x in ("models.py","macro_features.py","release_times.py","challenger_models.py","model_quality_v433.py","meta_forecast_v433.py","feature_event_v434.py","meta_forecast_v434.py")]
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:20]

def ensure_schema(con: sqlite3.Connection):
    con.executescript("""
    CREATE TABLE IF NOT EXISTS model_registry (
      model_version TEXT PRIMARY KEY, model_family TEXT NOT NULL, feature_version TEXT NOT NULL,
      validation_version TEXT NOT NULL, code_hash TEXT NOT NULL, role TEXT NOT NULL,
      status TEXT NOT NULL, registered_at TEXT NOT NULL, frozen_at TEXT NOT NULL,
      config_json TEXT NOT NULL, notes TEXT
    );
    CREATE TABLE IF NOT EXISTS prediction_ledger (
      prediction_id TEXT PRIMARY KEY, model_version TEXT NOT NULL, feature_version TEXT NOT NULL,
      symbol TEXT NOT NULL, horizon INTEGER NOT NULL, prediction_time TEXT NOT NULL,
      data_cutoff TEXT NOT NULL, p_up REAL, quality_json TEXT NOT NULL,
      macro_provenance_json TEXT NOT NULL, holdout_status TEXT NOT NULL,
      realized_at TEXT, realized_return REAL, realized_up INTEGER,
      created_at TEXT NOT NULL,
      UNIQUE(model_version,symbol,horizon,data_cutoff)
    );
    CREATE TABLE IF NOT EXISTS challenger_runs (
      run_id TEXT PRIMARY KEY, challenger_version TEXT NOT NULL, champion_version TEXT NOT NULL,
      symbol TEXT NOT NULL, horizon INTEGER NOT NULL, evaluated_at TEXT NOT NULL,
      dev_json TEXT NOT NULL, holdout_json TEXT NOT NULL, economic_json TEXT NOT NULL,
      decision TEXT NOT NULL, reason TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS promotion_history (
      promotion_id TEXT PRIMARY KEY, from_version TEXT, to_version TEXT NOT NULL,
      promoted_at TEXT NOT NULL, rule_version TEXT NOT NULL, evidence_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS model_decisions (
      decision_id TEXT PRIMARY KEY, decided_at TEXT NOT NULL, rule_version TEXT NOT NULL,
      champion_before TEXT NOT NULL, selected_version TEXT NOT NULL, action TEXT NOT NULL,
      evidence_hash TEXT NOT NULL, evidence_json TEXT NOT NULL, rationale TEXT NOT NULL
    );
    CREATE TRIGGER IF NOT EXISTS prediction_ledger_no_update BEFORE UPDATE ON prediction_ledger
    WHEN OLD.realized_at IS NOT NULL OR NEW.model_version != OLD.model_version
      OR NEW.feature_version != OLD.feature_version OR NEW.symbol != OLD.symbol
      OR NEW.horizon != OLD.horizon OR NEW.prediction_time != OLD.prediction_time
      OR NEW.data_cutoff != OLD.data_cutoff OR NEW.p_up IS NOT OLD.p_up
      OR NEW.quality_json != OLD.quality_json OR NEW.macro_provenance_json != OLD.macro_provenance_json
      OR NEW.holdout_status != OLD.holdout_status
    BEGIN SELECT RAISE(ABORT,'prediction ledger is immutable; only first realization attachment is allowed'); END;
    CREATE TRIGGER IF NOT EXISTS prediction_ledger_no_delete BEFORE DELETE ON prediction_ledger
    BEGIN SELECT RAISE(ABORT,'prediction ledger is immutable'); END;
    CREATE TRIGGER IF NOT EXISTS model_registry_no_update BEFORE UPDATE ON model_registry
    BEGIN SELECT RAISE(ABORT,'model registry rows are immutable; register a new version'); END;
    CREATE TRIGGER IF NOT EXISTS model_registry_no_delete BEFORE DELETE ON model_registry
    BEGIN SELECT RAISE(ABORT,'model registry rows are immutable'); END;
    CREATE TRIGGER IF NOT EXISTS model_decisions_no_update BEFORE UPDATE ON model_decisions
    BEGIN SELECT RAISE(ABORT,'model decisions are immutable'); END;
    CREATE TRIGGER IF NOT EXISTS model_decisions_no_delete BEFORE DELETE ON model_decisions
    BEGIN SELECT RAISE(ABORT,'model decisions are immutable'); END;
    """)
    con.commit()

def register_champion(con):
    ensure_schema(con); now=_utcnow()
    cfg={"algorithm":"custom logistic regression","horizons":[1,5,10,20],"macro":"revision-aware PIT","final_holdout_used_for_gate":False}
    con.execute("""INSERT OR IGNORE INTO model_registry VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
      (MODEL_VERSION,MODEL_FAMILY,FEATURE_VERSION,VALIDATION_VERSION,code_fingerprint(),"champion","frozen",now,now,json.dumps(cfg,sort_keys=True),"v3.2 governance baseline"))
    con.commit()

def append_prediction(con, symbol, horizon, data_cutoff, p_up, quality, macro_provenance, holdout):
    register_champion(con)
    key=f"{MODEL_VERSION}|{symbol}|{horizon}|{data_cutoff}"
    pid=hashlib.sha256(key.encode()).hexdigest()[:24]; now=_utcnow()
    hs="final_holdout" if (holdout or {}).get("enabled") and data_cutoff >= str((holdout or {}).get("start") or "9999") else "development/live"
    con.execute("""INSERT OR IGNORE INTO prediction_ledger
      (prediction_id,model_version,feature_version,symbol,horizon,prediction_time,data_cutoff,p_up,quality_json,macro_provenance_json,holdout_status,realized_at,realized_return,realized_up,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,NULL,NULL,NULL,?)""",
      (pid,MODEL_VERSION,FEATURE_VERSION,symbol,int(horizon),now,str(data_cutoff),None if p_up is None else float(p_up),json.dumps(quality or {},sort_keys=True),json.dumps(macro_provenance or {},sort_keys=True),hs,now))
    con.commit(); return pid

def settle_predictions(con):
    """Attach outcomes once, without rewriting the original prediction."""
    rows=con.execute("SELECT prediction_id,symbol,horizon,data_cutoff FROM prediction_ledger WHERE realized_at IS NULL").fetchall(); n=0
    for pid,sym,h,cut in rows:
        px=con.execute("SELECT date,close FROM prices WHERE symbol=? AND date>=? ORDER BY date LIMIT ?",(sym,cut,int(h)+1)).fetchall()
        if len(px) < int(h)+1: continue
        r=float(px[-1][1])/float(px[0][1])-1
        con.execute("UPDATE prediction_ledger SET realized_at=?,realized_return=?,realized_up=? WHERE prediction_id=? AND realized_at IS NULL",(_utcnow(),r,int(r>0),pid)); n+=1
    con.commit(); return n


def live_track_record(con, model_version, symbol, horizon):
    """Read-only public track record from the immutable prediction ledger."""
    ensure_schema(con)
    rows=con.execute(
        """SELECT p_up,realized_up,realized_return,data_cutoff,realized_at
           FROM prediction_ledger
           WHERE model_version=? AND symbol=? AND horizon=?
           ORDER BY data_cutoff""",
        (model_version,symbol,int(horizon))
    ).fetchall()
    total=len(rows)
    settled=[r for r in rows if r[1] is not None]
    correct=0
    briers=[]
    rets=[]
    for p,y,rr,_,_ in settled:
        if p is not None:
            pred=1 if float(p)>=0.5 else 0
            correct += int(pred==int(y))
            briers.append((float(p)-float(y))**2)
        if rr is not None:
            rets.append(float(rr))
    first=rows[0][3] if rows else None
    last=rows[-1][3] if rows else None
    return {
        "predictions":int(total),
        "realized":int(len(settled)),
        "pending":int(total-len(settled)),
        "directional_accuracy":None if not settled else round(correct/len(settled)*100,1),
        "brier":None if not briers else round(sum(briers)/len(briers),4),
        "mean_realized_return_pct":None if not rets else round(sum(rets)/len(rets)*100,3),
        "first_prediction_date":first,
        "last_prediction_date":last,
    }

def promotion_decision(challenger, champion):
    """Conservative promotion rule. Final holdout is evidence, never tuning data."""
    req=("holdout_edge_ci_low","holdout_brier_skill_ci_low","net_sharpe","effective_n")
    if any(challenger.get(k) is None for k in req): return False,"missing locked holdout/economic evidence"
    if challenger["effective_n"] < 30: return False,"effective N < 30"
    if challenger["holdout_edge_ci_low"] <= 0 or challenger["holdout_brier_skill_ci_low"] <= 0: return False,"holdout lower CI does not beat zero"
    if challenger["net_sharpe"] <= max(0,champion.get("net_sharpe",0)): return False,"no net economic-value improvement"
    return True,"eligible for manual promotion; register a new immutable champion version"

def registry_snapshot(con):
    ensure_schema(con)
    models=[dict(zip(["model_version","model_family","feature_version","validation_version","code_hash","role","status","registered_at","frozen_at","config_json","notes"],r)) for r in con.execute("SELECT * FROM model_registry ORDER BY registered_at DESC")]
    for m in models: m["config"]=json.loads(m.pop("config_json"))
    total=con.execute("SELECT COUNT(*) FROM prediction_ledger").fetchone()[0]
    realized=con.execute("SELECT COUNT(*) FROM prediction_ledger WHERE realized_at IS NOT NULL").fetchone()[0]
    return {"models":models,"ledger":{"predictions":total,"realized":realized,"pending":total-realized},"promotion_rule":"locked holdout CI + effective N + net economic value; manual promotion only"}

def register_challenger(con, model_version, model_family, feature_version, config, notes="",
                        validation_version=CHALLENGER_VALIDATION_VERSION):
    """Register a frozen challenger artifact. Existing rows can never be edited."""
    ensure_schema(con); now=_utcnow()
    con.execute("INSERT OR IGNORE INTO model_registry VALUES (?,?,?,?,?,?,?,?,?,?,?)",
      (model_version,model_family,feature_version,validation_version,code_fingerprint(),"challenger","frozen",now,now,json.dumps(config or {},sort_keys=True),notes))
    con.commit()


def append_prediction_for_model(con, model_version, feature_version, symbol, horizon,
                                data_cutoff, p_up, quality=None, macro_provenance=None,
                                holdout_status="development/live"):
    """Append an immutable prediction for any registered model version."""
    ensure_schema(con)
    row=con.execute("SELECT 1 FROM model_registry WHERE model_version=?",(model_version,)).fetchone()
    if not row:
        raise ValueError(f"model version is not registered: {model_version}")
    key=f"{model_version}|{symbol}|{int(horizon)}|{data_cutoff}"
    pid=hashlib.sha256(key.encode()).hexdigest()[:24]; now=_utcnow()
    con.execute("""INSERT OR IGNORE INTO prediction_ledger
      (prediction_id,model_version,feature_version,symbol,horizon,prediction_time,data_cutoff,p_up,quality_json,macro_provenance_json,holdout_status,realized_at,realized_return,realized_up,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,NULL,NULL,NULL,?)""",
      (pid,model_version,feature_version,symbol,int(horizon),now,str(data_cutoff),
       None if p_up is None else float(p_up),json.dumps(quality or {},sort_keys=True),
       json.dumps(macro_provenance or {},sort_keys=True),str(holdout_status),now))
    con.commit()
    return pid



V433_CHALLENGER_VERSION = "vol-regime-challenger-v4.33.0"
V433_META_VERSION = "meta-quality-v4.33.0"
V433_FEATURE_VERSION = "volatility-neutral-regime-features-v4.33.0"
V433_VALIDATION_VERSION = "purged-regime-online-calibration-meta-gate-v4.33"

def register_v433_models(con):
    """Register v4.33 research artifacts without promoting either one to champion."""
    register_challenger(
        con,V433_CHALLENGER_VERSION,"regime_logistic_challenger",V433_FEATURE_VERSION,
        {
            "target":"volatility-adjusted three-state (up / neutral / down)",
            "neutral_sigma":0.35,"min_abs_move":0.002,
            "regime_experts":True,"calibration":"rolling OOS Platt",
            "abstention":True,"automatic_promotion":False,
        },
        notes="v4.33 volatility-aware regime challenger; research only",
        validation_version=V433_VALIDATION_VERSION,
    )
    register_challenger(
        con,V433_META_VERSION,"conservative_meta_ensemble",V433_FEATURE_VERSION,
        {
            "components":[MODEL_VERSION,V433_CHALLENGER_VERSION],
            "disagreement_shrink":True,"dynamic_no_edge_gate":True,
            "automatic_promotion":False,
        },
        notes="v4.33 meta layer combining champion and calibrated regime challenger",
        validation_version=V433_VALIDATION_VERSION,
    )

def record_challenger_run(con, challenger_version, symbol, horizon, dev, holdout, economic, champion_version=MODEL_VERSION):
    ensure_schema(con); now=_utcnow()
    evidence={**(holdout or {}),**(economic or {})}
    ok,reason=promotion_decision(evidence,economic.get("champion",{}) if economic else {})
    raw=f"{challenger_version}|{champion_version}|{symbol}|{horizon}|{now}"
    rid=hashlib.sha256(raw.encode()).hexdigest()[:24]
    con.execute("INSERT INTO challenger_runs VALUES (?,?,?,?,?,?,?,?,?,?,?)",
      (rid,challenger_version,champion_version,symbol,int(horizon),now,json.dumps(dev or {},sort_keys=True),json.dumps(holdout or {},sort_keys=True),json.dumps(economic or {},sort_keys=True),"eligible" if ok else "reject",reason))
    con.commit(); return {"run_id":rid,"eligible":ok,"reason":reason}

def record_promotion(con, from_version, to_version, evidence):
    """Audit an explicit promotion decision; registry artifacts themselves stay immutable."""
    ensure_schema(con); now=_utcnow(); raw=f"{from_version}|{to_version}|{now}"
    pid=hashlib.sha256(raw.encode()).hexdigest()[:24]
    con.execute("INSERT INTO promotion_history VALUES (?,?,?,?,?)",(pid,from_version,to_version,now,"v3.2",json.dumps(evidence or {},sort_keys=True)))
    con.commit(); return pid


def record_model_decision(con, rule_version, champion_before, selected_version, action, evidence, rationale):
    """Append an immutable governance decision; identical evidence is idempotent."""
    ensure_schema(con)
    payload=json.dumps(evidence or {},sort_keys=True,separators=(",",":"))
    evidence_hash=hashlib.sha256(payload.encode()).hexdigest()
    raw=f"{rule_version}|{champion_before}|{selected_version}|{action}|{evidence_hash}"
    did=hashlib.sha256(raw.encode()).hexdigest()[:24]
    now=_utcnow()
    con.execute("""INSERT OR IGNORE INTO model_decisions
      (decision_id,decided_at,rule_version,champion_before,selected_version,action,evidence_hash,evidence_json,rationale)
      VALUES (?,?,?,?,?,?,?,?,?)""",
      (did,now,str(rule_version),str(champion_before),str(selected_version),str(action),evidence_hash,payload,str(rationale)))
    con.commit(); return did


V434_CONTEXT_VERSION = "context-feature-expert-v4.34.0"
V434_META_VERSION = "meta-context-v4.34.0"
V434_FEATURE_VERSION = "cross-sectional-event-features-v4.34.0"
V434_VALIDATION_VERSION = "pit-cross-sectional-event-drift-gate-v4.34"

def register_v434_models(con):
    """Register v4.34 feature/event artifacts as frozen challengers only."""
    register_challenger(
        con,V434_CONTEXT_VERSION,"cross_sectional_event_context",V434_FEATURE_VERSION,
        {
            "features":["relative_strength","market_breadth","dispersion","correlation_regime","asset_class_context","event_risk","feature_drift"],
            "point_in_time_market_context":True,"live_event_layer":True,
            "max_directional_adjustment_pp":5.0,"automatic_promotion":False,
        },
        notes="v4.34 low-weight cross-sectional/event context expert; research only",
        validation_version=V434_VALIDATION_VERSION,
    )
    register_challenger(
        con,V434_META_VERSION,"context_aware_meta_ensemble",V434_FEATURE_VERSION,
        {
            "base":V433_META_VERSION,"context_component":V434_CONTEXT_VERSION,
            "event_uncertainty_shrink":True,"feature_drift_gate":True,
            "automatic_promotion":False,
        },
        notes="v4.34 meta layer: v4.33 core + cross-sectional/event features",
        validation_version=V434_VALIDATION_VERSION,
    )

V435_DYNAMIC_VERSION = "dynamic-meta-ensemble-v4.35.0"
V435_RELIABILITY_VERSION = "reliability-meta-v4.35.0"
V435_VALIDATION_VERSION = "oos-stacked-calibrated-threshold-v4.35"


def register_v435_models(con):
    """Register v4.35 dynamic ensemble/meta-learning artifacts as challengers."""
    register_challenger(
        con,V435_DYNAMIC_VERSION,"dynamic_oos_meta_ensemble",V434_FEATURE_VERSION,
        {
            "components":[V433_META_VERSION,V434_META_VERSION],
            "weighting":"horizon_regime_oos_reliability",
            "meta_learning":"time_ordered_oos_stacking",
            "calibration":"pre_evaluation_platt",
            "threshold":"development_oos_selected",
            "disagreement_routing":True,
            "automatic_promotion":False,
        },
        notes="v4.35 dynamic ensemble; learns weights/meta-combination from prior OOS component predictions",
        validation_version=V435_VALIDATION_VERSION,
    )
    register_challenger(
        con,V435_RELIABILITY_VERSION,"forecast_reliability_meta",V434_FEATURE_VERSION,
        {
            "target":"directional_call_correctness",
            "inputs":["directional_strength","component_disagreement","meta_margin"],
            "training":"past meta OOS predictions only",
            "automatic_promotion":False,
        },
        notes="v4.35 reliability gate; estimates whether a published direction deserves trust",
        validation_version=V435_VALIDATION_VERSION,
    )

# v4.37 — prospective selection / human-review governance
V437_ENSEMBLE_VERSION = "guarded-dynamic-ensemble-v4.37.0"
V437_GUARD_VERSION = "prospective-selection-guard-v4.37.0"
V437_VALIDATION_VERSION = "paired-bootstrap-stability-human-review-v4.37"


def register_v437_models(con):
    """Register v4.37 guarded ensemble/governance artifacts as challengers.

    Registration is intentionally *not* a promotion.  The registry keeps the
    existing champion untouched; v4.37 merely records the candidate and its
    prospective validation contract.
    """
    register_challenger(
        con,V437_ENSEMBLE_VERSION,"prospective_guarded_dynamic_ensemble",V434_FEATURE_VERSION,
        {
            "base":V435_DYNAMIC_VERSION,
            "prospective_feedback":"v4.36 append-only ledger",
            "component_selection":"paired prospective bootstrap",
            "context_weight":"zero unless statistically eligible + human approved",
            "automatic_promotion":False,
        },
        notes="v4.37 dynamic ensemble with prospective model-selection guard",
        validation_version=V437_VALIDATION_VERSION,
    )
    register_challenger(
        con,V437_GUARD_VERSION,"model_selection_governance",V434_FEATURE_VERSION,
        {
            "minimum_sample":{"settled":60,"significant":30},
            "paired_bootstrap_ci":0.95,
            "time_stability_segments":3,
            "human_review_required":True,
            "automatic_promotion":False,
        },
        notes="v4.37 governance layer; no candidate can self-promote",
        validation_version=V437_VALIDATION_VERSION,
    )

# v4.38 — asset-class specialists
V438_SPECIALIST_VERSION = "asset-class-specialists-v4.38.0"
V438_GUARD_VERSION = "asset-specialist-selection-guard-v4.38.0"
V438_VALIDATION_VERSION = "time-ordered-specialist-development-v4.38+paired-prospective-human-review"


def register_v438_models(con):
    """Register v4.38 specialist router and its governance layer as challengers."""
    register_challenger(
        con,V438_SPECIALIST_VERSION,"asset_class_specialist_router",V434_FEATURE_VERSION,
        {
            "asset_classes":["equity","index","fx","commodity","crypto"],
            "features":"class_specific_point_in_time",
            "target":"volatility_adjusted_up_neutral_down",
            "equity_cross_section":"cached_real_peer_histories_only",
            "calibration":"time_ordered_development_platt",
            "routing":"asset_class+region+market_regime",
            "live_weight":"zero unless prospective guard + human approval",
            "automatic_promotion":False,
        },
        notes="v4.38 separate asset-class experts; predictions are logged prospectively before they may influence production",
        validation_version=V438_VALIDATION_VERSION,
    )
    register_challenger(
        con,V438_GUARD_VERSION,"asset_specialist_governance",V434_FEATURE_VERSION,
        {
            "baseline":V437_ENSEMBLE_VERSION,
            "paired_prospective":True,
            "minimum_sample":{"settled":60,"significant":30},
            "human_review_required":True,
            "max_satellite_weight":0.24,
            "automatic_promotion":False,
        },
        notes="v4.38 specialist governance; class expert remains satellite-only until prospective evidence and approval",
        validation_version=V438_VALIDATION_VERSION,
    )

# v4.39 — event response models
V439_EVENT_VERSION = "event-response-models-v4.39.0"
V439_GUARD_VERSION = "event-response-selection-guard-v4.39.0"
V439_VALIDATION_VERSION = "point-in-time-event-sensitivity-v4.39+paired-prospective-human-review"


def register_v439_models(con):
    """Register event-response challenger and governance layer without promotion."""
    register_challenger(
        con,V439_EVENT_VERSION,"event_response_specialist",V434_FEATURE_VERSION,
        {
            "event_types":["fed_rate","ecb_rate","cbr_rate","inflation_us","inflation_eu","inflation_ru","earnings"],
            "surprise":"explicit_actual_minus_expectation_only",
            "historical_sensitivity":"same_event_type_strictly_before_forecast_date",
            "upcoming_event_policy":"risk_only_until_surprise_is_observed",
            "local_archive":"observed events only; no synthetic dates",
            "live_weight":"zero unless prospective guard + human approval",
            "automatic_promotion":False,
        },
        notes="v4.39 event response challenger; no directional prior is invented for an unresolved event",
        validation_version=V439_VALIDATION_VERSION,
    )
    register_challenger(
        con,V439_GUARD_VERSION,"event_response_governance",V434_FEATURE_VERSION,
        {
            "baseline":"core_meta",
            "paired_prospective":True,
            "minimum_sample":{"settled":60,"significant":30},
            "human_review_required":True,
            "max_satellite_weight":0.16,
            "automatic_promotion":False,
        },
        notes="v4.39 governance; event expert cannot self-promote or steer direction before the actual surprise is known",
        validation_version=V439_VALIDATION_VERSION,
    )

# v4.40 — distributional forecast / expected move
V440_DISTRIBUTION_VERSION = "distributional-forecast-v4.40.0"
V440_MONITOR_VERSION = "distribution-feedback-v4.40.0"
V440_VALIDATION_VERSION = "purged-time-ordered-quantile-conformal-v4.40+prospective-interval-scoring"


def register_v440_models(con):
    """Register the v4.40 distribution/risk artifacts without granting direction weight."""
    register_challenger(
        con,V440_DISTRIBUTION_VERSION,"distributional_quantile_forecast",V434_FEATURE_VERSION,
        {
            "target":"future log return distribution",
            "quantiles":[0.10,0.25,0.50,0.75,0.90],
            "intervals":[0.50,0.80],
            "calibration":"chronological split conformal widening",
            "expected_move":"direct absolute-return model + realised-volatility conditioning",
            "options_benchmark":"local mapped IV snapshot when available; benchmark only",
            "directional_weight":0.0,
            "automatic_promotion":False,
        },
        notes="v4.40 distribution/risk layer; adds calibrated ranges and expected move but cannot alter guarded p_up",
        validation_version=V440_VALIDATION_VERSION,
    )
    register_challenger(
        con,V440_MONITOR_VERSION,"distribution_prospective_monitor",V434_FEATURE_VERSION,
        {
            "metrics":["coverage_50","coverage_80","pinball_loss","crps_like","median_mae","expected_abs_move_mae"],
            "append_only":True,
            "automatic_promotion":False,
        },
        notes="v4.40 prospective scoring for distribution coverage; monitoring only",
        validation_version=V440_VALIDATION_VERSION,
    )
