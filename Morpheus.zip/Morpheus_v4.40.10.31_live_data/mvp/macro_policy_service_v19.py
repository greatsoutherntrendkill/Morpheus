"""Training worker, immutable forecast/fact ledger and public read model."""
from __future__ import annotations
from contextlib import closing
from datetime import datetime,timezone
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,threading,gzip
from dotenv import load_dotenv
load_dotenv(Path(__file__).parent/".env")
import pandas as pd
import macro_policy_data_v19 as D
import macro_policy_model_v19 as M
STOP=threading.Event();SEED_LOCK=threading.Lock()
LOCK=threading.Lock();POOL=ThreadPoolExecutor(max_workers=1);STATE={'running':False,'stage':'idle','error':None}

def utc():return datetime.now(timezone.utc).isoformat()
def read_bundle():
 p=D.data_dir()/'latest.json'
 if not p.exists():p=Path(__file__).parent/'site/macro_policy_v19_results.json'
 if not p.exists():return {'version':M.VERSION,'forecasts':[],'evaluations':[],'as_of':None}
 try:return json.loads(p.read_text())
 except (OSError,ValueError):return {'version':M.VERSION,'forecasts':[],'evaluations':[],'as_of':None,'error':'saved_result_unavailable'}

def record(c,f):
 if f.get('status')!='ok':return None
 key='|'.join(str(f[k]) for k in ['series','period','horizon','model','snapshot','version'])+'|'+f['issued'][:10]
 ident=hashlib.sha256(key.encode()).hexdigest()
 with c:c.execute('INSERT OR IGNORE INTO forecasts VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(ident,f['issued'],f['series'],f['period'],f['horizon'],f['model'],f['value'],f['lower'],f['upper'],f['baseline'],f['snapshot'],json.dumps(f,ensure_ascii=False,allow_nan=False)))
 return ident

def settle(c,d,as_of):
 now=pd.Timestamp(as_of);targets={s:M.first_targets(d,s) for s in D.REGISTRY if D.REGISTRY[s]['kind']!='feature'}
 for f in c.execute('SELECT * FROM forecasts').fetchall():
  target=targets.get(f['series'],{}).get(f['period'])
  if not target or not pd.Timestamp(f['issued'])<target[1]<now:continue
  with c:c.execute('INSERT OR IGNORE INTO outcomes VALUES(?,?,?,?,?)',(f['id'],utc(),target[1].isoformat(),target[0],'FRED/ALFRED initial'))
  z=M.transformed(d,f['series'],now);val=z.get(pd.Period(f['period'],freq=D.REGISTRY[f['series']]['freq']))
  if val is not None and pd.notna(val) and float(val)!=target[0]:
   # Revision availability is the latest input for this target or its comparison period.
   spec=D.REGISTRY[f['series']];period=pd.Period(f['period'],freq=spec['freq']);periods=[period]
   if spec['transform']=='yoy':periods.append(period-12)
   elif spec['transform'] in ('annualized','change'):periods.append(period-1)
   r=d[(d.series==f['series'])&(d.available<now)]
   available=r[r.period.dt.to_period(spec['freq']).isin(periods)].available.max().isoformat()
   with c:c.execute('INSERT OR IGNORE INTO revisions(forecast_id,recorded,available,value) VALUES(?,?,?,?)',(f['id'],utc(),available,float(val)))

def journal():
 with closing(D.connect()) as c, c:
  total=c.execute('SELECT count(*) FROM forecasts').fetchone()[0]
  summary=[dict(r) for r in c.execute('''SELECT f.series,f.horizon,count(*) AS issues,count(o.value) AS resolved,avg(abs(f.value-o.value)) AS mae,avg(abs(f.baseline-o.value)) AS baseline_mae FROM forecasts f LEFT JOIN outcomes o ON f.id=o.forecast_id WHERE f.id=(SELECT f2.id FROM forecasts f2 WHERE f2.series=f.series AND f2.period=f.period AND f2.horizon=f.horizon ORDER BY f2.issued,f2.id LIMIT 1) GROUP BY f.series,f.horizon''')]
  data=[dict(r) for r in c.execute('SELECT f.id,f.issued,f.series,f.period,f.horizon,f.model,f.value,f.lower,f.upper,f.baseline,f.metadata,o.value AS actual,(SELECT r.value FROM revisions r WHERE r.forecast_id=f.id ORDER BY r.available DESC LIMIT 1) AS revised,o.available AS actual_available FROM forecasts f LEFT JOIN outcomes o ON f.id=o.forecast_id ORDER BY f.issued DESC LIMIT 500')]
 for r in data:
  r['version']=json.loads(r.pop('metadata')).get('version')
  r['error']=None if r['actual'] is None else abs(r['value']-r['actual']);r['baseline_error']=None if r['actual'] is None else abs(r['baseline']-r['actual'])
 return dict(rows=data,total=total,summary=summary,summary_rule='Первый выпуск на каждый целевой период и срок; повторные пересчёты не увеличивают вес одного факта.',note='Реальные выпуски этого сервера; исторические проверки сюда не добавляются. Первые публикации факта не заменяются пересмотрами.')

def coverage():
 with closing(D.connect()) as c, c:stats={r['series']:dict(r) for r in c.execute('SELECT series,count(*) rows,min(period) first,max(period) last,max(available) available FROM observations GROUP BY series')}
 return [dict(code=code,country=name,status='connected' if code=='US' and stats else 'needs_release_archive',series=[dict(id=s,**spec,**stats.get(s,{})) for s,spec in D.REGISTRY.items() if spec['country']==code],needed=None if code=='US' and stats else 'Нужен проверенный архив публикаций и пересмотров, календарь решений и точное определение целевой ставки. Текущий снимок недостаточен для обучения.') for code,name in D.COUNTRIES.items()]

def train(as_of=None,horizons=(1,2,3),series=None):
 replay=as_of is not None
 as_of=as_of or utc();forecasts=[];evaluations=[]
 with closing(D.connect()) as c, c:d=M.frame(D.rows(c))
 if d.empty:raise ValueError('no_release_history')
 for sid in series or [s for s,v in D.REGISTRY.items() if v['kind']!='feature']:
  for h in horizons:
   STATE['stage']=sid+' · '+str(h)
   evaluation=M.evaluate(d,sid,h,as_of);f=M.forecast(d,sid,h,as_of,evaluation)
   f.setdefault('series',sid);f.setdefault('horizon',h);forecasts.append(f);evaluations.append(dict(series=sid,horizon=h,**evaluation))
 # Separately learned bounds may cross: suppress both, never swap them silently.
 for h in horizons:
  lo=next((f for f in forecasts if f['series']=='DFEDTARL' and f['horizon']==h),None);hi=next((f for f in forecasts if f['series']=='DFEDTARU' and f['horizon']==h),None)
  if lo and hi and lo.get('value') is not None and hi.get('value') is not None and lo['value']>hi['value']:
   for f in (lo,hi):f.update(status='unavailable',reason='ffr_bounds_crossed')
 issued=utc()
 for f in forecasts:
  f['data_cutoff']=as_of
  if not replay:
   f['issued']=issued
   actual=M.first_targets(d,f['series']).get(f.get('period'))
   if actual and actual[1]<pd.Timestamp(issued):f.update(status='unavailable',reason='target_already_published')
 with closing(D.connect()) as c, c:
  if not replay:
   for f in forecasts:record(c,f)
  settle(c,d,issued)
 out=dict(version=M.VERSION,as_of=as_of,registry=D.REGISTRY,forecasts=forecasts,evaluations=evaluations,coverage=coverage(),method='Отдельная модель каждого показателя и срока. Обучение только на доступных публикациях; сравнение с последним значением, Ridge и деревьями. Интервалы по прошлым ошибкам; покрытие не гарантируется.',journal=journal())
 if replay:return out
 target=D.data_dir()/'latest.json';temp=target.with_suffix('.tmp');temp.write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False));temp.replace(target);return out

def job(refresh_inputs=True):
 try:
  seed_history()
  if refresh_inputs:
   STATE['stage']='Загрузка публикаций';key=os.environ.get('FRED_API_KEY','')
   if not key:raise ValueError('FRED_API_KEY_required')
   status=D.refresh(key);STATE['input_status']=status
   if not any(x['status']=='ok' for x in status):raise ValueError('providers_unavailable')
  after=fingerprint()
  previous=read_bundle()
  if previous.get('input_fingerprint')==after and previous.get('version')==M.VERSION:
   with closing(D.connect()) as c, c:settle(c,M.frame(D.rows(c)),utc())
   STATE['stage']='Новых публикаций нет'
  else:
   result=train();result['input_fingerprint']=after
   target=D.data_dir()/'latest.json';temp=target.with_suffix('.tmp');temp.write_text(json.dumps(result,ensure_ascii=False,allow_nan=False));temp.replace(target)
   STATE['stage']='Готово';STATE['last_success']=utc()
 except Exception as e:STATE['error']=str(e) if isinstance(e,ValueError) else type(e).__name__;STATE['stage']='Не удалось обновить'
 finally:
  with LOCK:STATE['running']=False

def start(refresh_inputs=True):
 with LOCK:
  if not STATE['running']:STATE.update(running=True,error=None);POOL.submit(job,refresh_inputs)
 return dict(STATE)

def public():
 result=read_bundle();result['worker']=dict(STATE);result['journal']=journal();result['key_configured']=bool(os.getenv('FRED_API_KEY'));result['stale']=not result.get('as_of') or (pd.Timestamp(utc())-pd.Timestamp(result['as_of'])).total_seconds()>7*86400;return result


def seed_history():
 """Bootstrap only verified public observations; never import past forecasts as live issues."""
 with SEED_LOCK:
  with closing(D.connect()) as c, c:
   if c.execute('SELECT count(*) FROM observations').fetchone()[0]:return
   seed=Path(__file__).parent/'model_data/macro_policy_observations.json.gz'
   if not seed.exists():return
   with gzip.open(seed,'rt',encoding='utf-8') as f:rows=json.load(f)
   with c:c.executemany('INSERT OR IGNORE INTO observations VALUES(?,?,?,?,?)',[(r['series'],r['period'],r['available'],r['value'],r['source']) for r in rows])

def fingerprint():
 with closing(D.connect()) as c, c:
  return hashlib.sha256(json.dumps(D.rows(c),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def start_scheduler():
 STOP.clear()
 def loop():
  while not STOP.is_set():
   if os.getenv('FRED_API_KEY') and os.getenv('MACRO_POLICY_AUTO_UPDATE','1')!='0':start(True)
   STOP.wait(21600)
 threading.Thread(target=loop,daemon=True,name='macro-policy-publications').start()

def stop_scheduler():STOP.set()
