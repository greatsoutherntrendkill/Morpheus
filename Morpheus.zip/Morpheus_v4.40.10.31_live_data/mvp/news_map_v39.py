"""Привязка новостей Morpheus к карте мира без внешнего геокодера."""
from __future__ import annotations
import re

RULES=[
    (r'фрс|fomc|сша|америк|вашингтон|treasury|доллар', 'США', -98.5, 38.5),
    (r'евросоюз|\bес\b|европа|ецб|герман|франц|брюссел|санкц', 'Европа', 10.5, 50.5),
    (r'росси|\bрф\b|цб рф|москв|рубл|мосбирж|офз', 'Россия', 37.6, 55.8),
    (r'китай|пекин|народн.*банк кит|юан', 'Китай', 116.4, 39.9),
    (r'япони|токио|банк японии|иен', 'Япония', 139.7, 35.7),
    (r'индия|дели|рупи', 'Индия', 77.2, 28.6),
    (r'великобрит|лондон|банк англии|фунт', 'Великобритания', -0.1, 51.5),
    (r'опек|сауд|ближн|ирак|иран|нефт|brent|wti', 'Ближний Восток', 46.7, 24.7),
    (r'бразил|бразилиа|реал', 'Бразилия', -47.9, -15.8),
    (r'австрал|сидней|резервн.*банк австрал', 'Австралия', 151.2, -33.9),
]

def _cyryl(s):
    return bool(re.search(r'[А-Яа-яЁё]', str(s or '')))

def locate(row:dict)->dict:
    text=' '.join(str(row.get(k,'') or '') for k in ('title','summary','source')).lower()
    region='Глобально'; lon=0.0; lat=12.0
    for pat,name,x,y in RULES:
        if re.search(pat,text,re.I): region=name; lon=x; lat=y; break
    if region=='Глобально':
        aff=' '.join(str(x.get('symbol','')) for x in (row.get('affected') or []))
        if any(s in aff for s in ('IMOEX','RGBI','RUB=X')):
            region,lon,lat='Россия',37.6,55.8
        elif any(s in aff for s in ('^GSPC','^NDX','^DJI','DX-Y.NYB')):
            region,lon,lat='США',-98.5,38.5
        elif any(s in aff for s in ('CL=F','BZ=F')):
            region,lon,lat='Ближний Восток',46.7,24.7
    impact=int(row.get('impact_score') or row.get('relevance_score') or 0)
    return {**row,'map_region':region,'map_lon':lon,'map_lat':lat,'map_impact':max(1,min(100,impact)),
            'russian_text':_cyryl(row.get('title'))}

def enrich(rows):
    return [locate(r) for r in (rows or []) if _cyryl(r.get('title'))]
