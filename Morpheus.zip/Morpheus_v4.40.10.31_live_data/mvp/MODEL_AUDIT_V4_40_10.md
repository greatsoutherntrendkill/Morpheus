# Model audit — v4.40.10

v4.40.10 does not change the target definition. It changes solver discipline and validation/governance isolation.

## Guarantees added

1. Hyperparameter selection is nested inside legal historical training data and does not use final holdout, prospective outcomes or shadow evidence.
2. RegimeMoE internal weights can deviate from 45/35/20 only after chronological OOS Brier improvement.
3. Shadow prospective records are deterministically excluded from every training/routing/promotion path.
4. Event history and human governance decisions persist across code releases.
5. New model generation and cache contract prevent v4.40.9 cached forecasts from being treated as v4.40.10 forecasts.

## Deliberately unchanged

- three-state target and neutral band;
- factorized `P(MOVE) × P(direction | MOVE)` semantics;
- quality-aware Directional ↔ Distribution consistency gate;
- zero production influence for unapproved challengers;
- feature freshness/staleness contract;
- no automatic champion promotion.
