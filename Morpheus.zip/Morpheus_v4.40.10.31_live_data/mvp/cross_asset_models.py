
"""Morpheus v3.6 — pooled cross-asset research models.

Core rules:
- one global chronological clock across all assets;
- no same-day cross-market look-ahead: cross-asset factors are lagged one day;
- H-day labels are legal for training only after label_end < prediction_date;
- prospective final holdout starts after the packaged data cutoff and is never tuned on;
- calibration is fitted only on pre-holdout development OOS predictions;
- published research probability is evidence-shrunk toward 50%, while raw probability
  remains available for audit.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json, math
import numpy as np
import pandas as pd

import config as C
import db
import models as M
import macro_features as MF

PROSPECTIVE_HOLDOUT_START = pd.Timestamp("2026-09-08")
FEATURE_VERSION = "cross-asset-pit-v3.6.0"
VALIDATION_VERSION = "global-time-purged-cluster-bootstrap-prospective-holdout-v3.6"
MODEL_VERSIONS = {
    "pooled_logistic": "pooled-logreg-v3.6.1",
    "pooled_lightgbm": "pooled-lightgbm-v3.6.1",
}
HORIZONS=(1,5,10,20)
RETRAIN_EVERY=40
MIN_TRAIN_DATES=180

NAMES = {**{k:v[0] for k,v in C.YF_PRICES.items()},
         **{k:v[2] for k,v in C.YF_CROSSES.items()},
         **{k:v[0] for k,v in C.MOEX_INDICES.items()}}
CATS = {**{k:v[1] for k,v in C.YF_PRICES.items()},
        **{k:v[3] for k,v in C.YF_CROSSES.items()},
        **{k:v[1] for k,v in C.MOEX_INDICES.items()}}
PUBLIC=[s for s in NAMES if s!="CNY=X"]

LOCKED_CONFIGS = {
    "pooled_logistic":{"lr":0.20,"n_iter":280,"l2":0.03},
    "pooled_lightgbm":{
        "n_estimators":100,"learning_rate":0.03,"num_leaves":9,"max_depth":4,
        "min_child_samples":60,"subsample":0.85,"colsample_bytree":0.80,
        "reg_alpha":0.25,"reg_lambda":1.5,"random_state":42,"n_jobs":1,
        "verbosity":-1,
    },
}

def _region(cat):
    if "США" in cat or cat=="Фьючерсы": return "us"
    if "Европ" in cat: return "europe"
    if "Азии" in cat: return "asia"
    if "РФ" in cat: return "russia"
    return "global"

def _clean_close(con,sym):
    df=db.read_prices(con,sym)
    if df is None or df.empty: return pd.Series(dtype=float)
    d=df.copy()
    d["date"]=pd.to_datetime(d["date"])
    d["close"]=pd.to_numeric(d["close"],errors="coerce")
    d=d.dropna(subset=["date","close"]).sort_values("date").drop_duplicates("date",keep="last")
    d=d[d["close"]>0]
    return d.set_index("date")["close"].astype(float)

def _market_groups():
    cats=CATS
    eq=[s for s in PUBLIC if cats.get(s,"").startswith("Индексы") and cats.get(s)!="Индексы РФ"]
    eq += [s for s in ("ES=F","NQ=F") if s in PUBLIC]
    crypto=[s for s in PUBLIC if cats.get(s)=="Крипто"]
    cmd=[s for s in PUBLIC if cats.get(s)=="Сырьё"]
    fx=[s for s in PUBLIC if cats.get(s)=="Валюты"]
    return {"eq":sorted(set(eq)),"crypto":crypto,"cmd":cmd,"fx":fx}

def _mean_cols(df, cols):
    use=[c for c in cols if c in df]
    return df[use].mean(axis=1) if use else pd.Series(np.nan,index=df.index)

def build_base_panel(con):
    """One feature panel shared by every horizon."""
    closes={s:_clean_close(con,s) for s in PUBLIC}
    closes={s:v for s,v in closes.items() if len(v)>=260}
    wide=pd.concat(closes,axis=1).sort_index()
    wide.columns=list(closes)
    ret=np.log(wide/wide.shift(1))
    mom20=np.log(wide/wide.shift(20))
    groups=_market_groups()

    # Cross-market state is lagged one calendar row to avoid US-close -> Asia-close
    # same-date timing leakage.
    cross=pd.DataFrame(index=wide.index)
    cross["x_eq_r1_l1"]=_mean_cols(ret,groups["eq"]).shift(1)
    cross["x_eq_mom20_l1"]=_mean_cols(mom20,groups["eq"]).shift(1)
    cross["x_crypto_r1_l1"]=_mean_cols(ret,groups["crypto"]).shift(1)
    cross["x_crypto_mom20_l1"]=_mean_cols(mom20,groups["crypto"]).shift(1)
    cross["x_cmd_r1_l1"]=_mean_cols(ret,groups["cmd"]).shift(1)
    cross["x_cmd_mom20_l1"]=_mean_cols(mom20,groups["cmd"]).shift(1)
    cross["x_fx_r1_l1"]=_mean_cols(ret,groups["fx"]).shift(1)
    cross["x_breadth_l1"]=(ret.gt(0).mean(axis=1)).shift(1)
    cross["x_dispersion_l1"]=ret.std(axis=1).shift(1)
    eqr=_mean_cols(ret,groups["eq"])
    cross["x_eq_vol20_l1"]=eqr.rolling(20).std().shift(1)
    if "DX-Y.NYB" in wide:
        dxy=wide["DX-Y.NYB"]
        cross["x_dxy_r1_l1"]=np.log(dxy/dxy.shift(1)).shift(1)
        cross["x_dxy_mom20_l1"]=np.log(dxy/dxy.shift(20)).shift(1)
    cross["x_risk_on_l1"]=cross.get("x_eq_mom20_l1",0)-cross.get("x_dxy_mom20_l1",0)

    # Revision-aware macro state, already publication-timestamp aligned.
    try:
        raw=MF._raw_daily(con,pd.DatetimeIndex(wide.index))
        derived,_=MF._derive(raw)
        macro=derived.shift(1).copy()
        # same-day official releases are known by market close; no extra shift needed.
        macro=macro[[c for c in macro if macro[c].notna().sum()>=40]]
    except Exception:
        macro=pd.DataFrame(index=wide.index)

    cats=sorted({CATS.get(s,"") for s in closes})
    syms=sorted(closes)
    rows=[]
    targets={}
    for sym,close in closes.items():
        f=M.build_features(close,None,None).copy()
        f=f.join(cross.reindex(f.index))
        if not macro.empty:
            f=f.join(macro.reindex(f.index))
        cat=CATS.get(sym,"")
        reg=_region(cat)
        for c in cats: f["class__"+_slug(c)]=1.0 if c==cat else 0.0
        for s in syms: f["asset__"+_slug(s)]=1.0 if s==sym else 0.0
        for r in ("us","europe","asia","russia","global"):
            f["region__"+r]=1.0 if r==reg else 0.0

        # Explicit economically motivated interactions.
        is_crypto=float(cat=="Крипто"); is_cmd=float(cat=="Сырьё")
        is_us=float(cat=="Индексы США" or cat=="Фьючерсы"); is_ru=float(cat=="Индексы РФ")
        if "x_dxy_mom20_l1" in f:
            f["int_dxy_crypto"]=f["x_dxy_mom20_l1"]*is_crypto
            f["int_dxy_cmd"]=f["x_dxy_mom20_l1"]*is_cmd
        if "x_eq_vol20_l1" in f:
            f["int_vol_us"]=f["x_eq_vol20_l1"]*is_us
            f["int_vol_crypto"]=f["x_eq_vol20_l1"]*is_crypto
        if "us_real10y" in f:
            f["int_real10y_us"]=f["us_real10y"]*is_us
            f["int_real10y_crypto"]=f["us_real10y"]*is_crypto
        if "ru_key" in f:
            f["int_ru_key_ru"]=f["ru_key"]*is_ru

        f["date"]=f.index
        f["symbol"]=sym
        f["close"]=close.reindex(f.index)
        rows.append(f.reset_index(drop=True))

        t=pd.DataFrame(index=close.index)
        t["close"]=close
        targets[sym]=t

    panel=pd.concat(rows,ignore_index=True)
    panel=panel.sort_values(["date","symbol"]).reset_index(drop=True)
    meta={"symbols":syms,"categories":cats,"rows":len(panel),
          "first_date":str(pd.Timestamp(panel.date.min()).date()),
          "last_date":str(pd.Timestamp(panel.date.max()).date()),
          "cross_market_features_lagged_one_day":True,
          "macro_revision_aware":True}
    return panel,targets,meta

def _slug(s):
    import re
    return re.sub(r"[^a-zA-Z0-9]+","_",str(s)).strip("_").lower() or "unknown"

def add_target(panel, targets, horizon):
    parts=[]
    h=int(horizon)
    for sym,g in panel.groupby("symbol",sort=False):
        close=targets[sym]["close"]
        tgt=M.directional_target_frame(close,h)
        x=g.copy()
        ix=pd.DatetimeIndex(pd.to_datetime(x["date"]))
        x["label_end"]=tgt["label_end"].reindex(ix).to_numpy()
        x["ret_fwd"]=tgt["ret_fwd"].reindex(ix).to_numpy()
        x["state"]=tgt["state"].reindex(ix).to_numpy()
        x["neutral"]=tgt["neutral"].reindex(ix).to_numpy()
        x["y"]=tgt["y"].reindex(ix).to_numpy()
        parts.append(x)
    out=pd.concat(parts,ignore_index=True)
    return out.sort_values(["date","symbol"]).reset_index(drop=True)


class _Prep:
    def fit(self,X):
        X=np.asarray(X,float)
        med=np.nanmedian(X,axis=0)
        med=np.where(np.isfinite(med),med,0.0)
        self.med=med
        return self
    def transform(self,X):
        X=np.asarray(X,float)
        return np.where(np.isfinite(X),X,self.med)

class PooledLogistic:
    def __init__(self):
        from sklearn.linear_model import LogisticRegression
        self.prep=_Prep()
        self.m=LogisticRegression(C=8.0,max_iter=250,solver="lbfgs",random_state=42)
    def fit(self,X,y):
        z=self.prep.fit(X).transform(X)
        self.mu=z.mean(0); self.sd=z.std(0)+1e-9
        zs=(z-self.mu)/self.sd
        self.m.fit(zs,y); return self
    def proba(self,X):
        z=self.prep.transform(X)
        return np.asarray(self.m.predict_proba((z-self.mu)/self.sd)[:,1],float)
    def importance(self):
        a=np.abs(np.asarray(self.m.coef_[0],float)); s=float(a.sum()) or 1.0
        return a/s

class PooledLightGBM:
    def __init__(self):
        from lightgbm import LGBMClassifier
        self.prep=_Prep()
        self.m=LGBMClassifier(**LOCKED_CONFIGS["pooled_lightgbm"])
    def fit(self,X,y):
        z=self.prep.fit(X).transform(X)
        self.m.fit(z,y); return self
    def proba(self,X): return np.asarray(self.m.predict_proba(self.prep.transform(X))[:,1],float)
    def importance(self):
        a=np.abs(np.asarray(self.m.feature_importances_,float)); s=float(a.sum()) or 1.0
        return a/s

FACTORIES={"pooled_logistic":PooledLogistic,"pooled_lightgbm":PooledLightGBM}

def _feature_cols(df):
    skip={"date","symbol","close","label_end","ret_fwd","y"}
    return [c for c in df.columns if c not in skip]

def _baseline_for_rows(train, test):
    global_p=float(train.y.mean()) if len(train) else .5
    by=train.groupby("symbol").y.mean().to_dict()
    return np.asarray([float(by.get(s,global_p)) for s in test.symbol],float)

def walkforward(panel_h, model_name, horizon):
    """Global-date purged walk-forward. Same model is applied to all assets on each date."""
    df=panel_h.dropna(subset=["y","label_end","date"]).copy()
    df["date"]=pd.to_datetime(df["date"]); df["label_end"]=pd.to_datetime(df["label_end"])
    df=df[df["date"]<PROSPECTIVE_HOLDOUT_START].copy()
    dates=np.array(sorted(pd.unique(df["date"])),dtype="datetime64[ns]")
    if len(dates)<=MIN_TRAIN_DATES+30: return pd.DataFrame(),None,[]

    cols=_feature_cols(df)
    out=[]; model=None; base_by=None; last_fit_i=-999
    for i,d64 in enumerate(dates[MIN_TRAIN_DATES:],start=MIN_TRAIN_DATES):
        d=pd.Timestamp(d64)
        test=df[df.date==d]
        if test.empty: continue
        # Legal labels across every asset must have finished strictly before prediction date.
        train=df[(df.date<d)&(df.label_end<d)]
        if len(train)<2500: continue
        if model is None or i-last_fit_i>=RETRAIN_EVERY:
            model=FACTORIES[model_name]().fit(train[cols].to_numpy(float),train.y.to_numpy(float))
            last_fit_i=i
            base_by=train.groupby("symbol").y.mean().to_dict()
            global_p=float(train.y.mean())
        p=model.proba(test[cols].to_numpy(float))
        bp=np.asarray([float(base_by.get(s,global_p)) for s in test.symbol],float)
        for j,(_,r) in enumerate(test.iterrows()):
            out.append({"date":r.date,"symbol":r.symbol,"y":float(r.y),
                        "label_end":r.label_end,"feature_available_at":r.date,"ret_fwd":float(r.ret_fwd),"p":float(p[j]),"base":float(bp[j])})
    return pd.DataFrame(out),cols,dates.tolist()

def _fit_platt(p,y):
    from sklearn.linear_model import LogisticRegression
    p=np.clip(np.asarray(p,float),1e-5,1-1e-5); y=np.asarray(y,float)
    if len(p)<100 or len(np.unique(y))<2: return None
    x=np.log(p/(1-p)).reshape(-1,1)
    return LogisticRegression(C=2.0,max_iter=200,solver="lbfgs",random_state=42).fit(x,y)

def _apply_platt(cal,p):
    if cal is None: return np.asarray(p,float)
    p=np.clip(np.asarray(p,float),1e-5,1-1e-5)
    return np.asarray(cal.predict_proba(np.log(p/(1-p)).reshape(-1,1))[:,1],float)

def _metric(p,y,b):
    m=M._metric_bundle(np.asarray(p,float),np.asarray(y,float),np.asarray(b,float))
    return {k:round(float(v)*100,3) if k in ("acc","base") else round(float(v),6)
            for k,v in m.items()}

def _cluster_block_bootstrap(oos,horizon,n_boot=500,seed=360):
    """Fast date-cluster moving-block bootstrap.

    Each date is a cluster containing every asset available that day. Resampling
    date blocks preserves both cross-sectional dependence and H-day time dependence.
    """
    if oos.empty: return {}
    g=oos.copy()
    g["model_correct"]=((g.p>=.5)==g.y).astype(float)
    g["base_correct"]=((g.base>=.5)==g.y).astype(float)
    g["brier_sq"]=(g.p-g.y)**2
    g["base_brier_sq"]=(g.base-g.y)**2
    d=(g.groupby("date",sort=True)
         .agg(n=("y","size"),mc=("model_correct","sum"),bc=("base_correct","sum"),
              bs=("brier_sq","sum"),bbs=("base_brier_sq","sum"))
         .reset_index())
    n_dates=len(d)
    if n_dates<25: return {}
    block=min(n_dates,max(5,int(horizon)))
    rng=np.random.default_rng(seed+int(horizon)*17+n_dates)
    starts=max(1,n_dates-block+1)
    arr=d[["n","mc","bc","bs","bbs"]].to_numpy(float)
    edge=[]; bskill=[]
    for _ in range(int(n_boot)):
        idx=[]
        while len(idx)<n_dates:
            st=int(rng.integers(0,starts))
            idx.extend(range(st,min(st+block,n_dates)))
        z=arr[np.asarray(idx[:n_dates],int)].sum(axis=0)
        n,mc,bc,bs,bbs=z
        edge.append(((mc-bc)/n)*100.0)
        bskill.append((1.0-bs/bbs)*100.0 if bbs>1e-12 else 0.0)
    edge=np.asarray(edge); bskill=np.asarray(bskill)
    return {
        "global_dates":int(n_dates),
        "effective_date_cap":int(max(1,n_dates//max(1,int(horizon)))),
        "block_dates":int(block),"resamples":int(n_boot),
        "edge_ci95":[round(float(np.percentile(edge,2.5)),3),round(float(np.percentile(edge,97.5)),3)],
        "brier_skill_ci95":[round(float(np.percentile(bskill,2.5)),3),round(float(np.percentile(bskill,97.5)),3)],
    }

def _asset_evidence(oos,sym,horizon):
    g=oos[oos.symbol==sym].sort_values("date")
    if len(g)<10:
        return {"n_raw":len(g),"n_eff":0}
    p=g.p.to_numpy(); y=g.y.to_numpy(); b=g.base.to_numpy()
    no,nno,ph=M._phase_nonoverlap_metrics(p,y,b,int(horizon))
    ne=M._effective_oos_n(p,y,b,int(horizon))
    return {"n_raw":int(len(g)),"n_nonoverlap":int(nno),"n_eff":int(ne),
            "edge":round(float(no["edge"]),3),"brier_skill":round(float(no["brier_skill"]),3),
            "ece":round(float(no["ece"]),4)}

def _top_importance(model,cols,n=12):
    a=np.asarray(model.importance(),float)
    order=np.argsort(a)[::-1][:n]
    return [{"feature":str(cols[i]),"importance":round(float(a[i]),6)} for i in order]

def run_horizon(panel,targets,horizon):
    ph=add_target(panel,targets,horizon)
    cols=_feature_cols(ph)
    result={"horizon":int(horizon),"prospective_holdout_start":str(PROSPECTIVE_HOLDOUT_START.date()),
            "holdout_used_for_tuning":False,"models":{}}
    for name in FACTORIES:
        oos,used_cols,_=walkforward(ph,name,horizon)
        if oos.empty:
            result["models"][name]={"error":"insufficient development OOS"}
            continue

        # Calibration diagnostic: fit on early 60% of OOS dates, score on later 40%.
        ud=np.array(sorted(pd.unique(oos.date)))
        cut=ud[max(1,int(len(ud)*.60))-1]
        early=oos[(oos.date<=cut)&(oos.label_end<=cut)]; late=oos[oos.date>cut].copy()
        cal_diag=_fit_platt(early.p,early.y)
        late_cal=_apply_platt(cal_diag,late.p) if len(late) else np.array([])
        calib_check={
            "fit_last_date":str(pd.Timestamp(cut).date()),
            "evaluation_first_date":None if late.empty else str(pd.Timestamp(late.date.min()).date()),
            "raw":_metric(late.p,late.y,late.base) if len(late) else {},
            "platt":_metric(late_cal,late.y,late.base) if len(late) else {},
        }

        # Live calibrator may use every PRE-HOLDOUT OOS prediction.
        cal_live=_fit_platt(oos.p,oos.y)

        # Frozen prospective-holdout model: training data cannot cross the boundary.
        frozen_train=ph[(pd.to_datetime(ph.date)<PROSPECTIVE_HOLDOUT_START)&
                        (pd.to_datetime(ph.label_end)<PROSPECTIVE_HOLDOUT_START)&
                        ph.y.notna()].copy()
        model=FACTORIES[name]().fit(frozen_train[cols].to_numpy(float),frozen_train.y.to_numpy(float))

        # Current/latest row per asset. Before holdout this is the seed live forecast;
        # once new dates arrive, the same pre-holdout fit remains frozen.
        live=[]
        for sym,g in ph.groupby("symbol"):
            gg=g.sort_values("date")
            r=gg.iloc[-1]
            X=r[cols].to_numpy(dtype=float).reshape(1,-1)
            raw=float(model.proba(X)[0])
            cal=float(_apply_platt(cal_live,np.array([raw]))[0])
            ev=_asset_evidence(oos,sym,horizon)
            sample_alpha=min(1.0,max(0.0,ev.get("n_eff",0)/30.0))
            # Evidence quality matters as well as count. Weak/poorly calibrated
            # asset-level OOS evidence gets additional shrinkage toward 50%.
            bs=float(ev.get("brier_skill",-999))
            ece=float(ev.get("ece",1.0))
            if bs>0 and ece<=0.15:
                skill_alpha=1.0
            elif bs>-2.0 and ece<=0.20:
                skill_alpha=0.5
            else:
                skill_alpha=0.25
            alpha=sample_alpha*skill_alpha
            shrunk=float(np.clip(.5+alpha*(cal-.5),.05,.95))
            live.append({
                "symbol":sym,"date":str(pd.Timestamp(r.date).date()),
                "raw_p_up":round(raw,4),"calibrated_p_up":round(cal,4),
                "evidence_shrunk_p_up":round(shrunk,4),"shrink_alpha":round(alpha,3),
                "development_evidence":ev,
            })

        overall=_metric(oos.p,oos.y,oos.base)
        cluster=_cluster_block_bootstrap(oos,horizon)
        result["models"][name]={
            "version":MODEL_VERSIONS[name],"locked_config":LOCKED_CONFIGS[name],
            "development_rows":int(len(oos)),
            "development_global_dates":int(oos.date.nunique()),
            "development":overall,
            "cluster_date_bootstrap":cluster,
            "calibration_check":calib_check,
            "frozen_train_rows":int(len(frozen_train)),
            "frozen_train_max_label_end":str(pd.Timestamp(frozen_train.label_end.max()).date()),
            "top_features_frozen":_top_importance(model,cols),
            "live":live,
        }

        # Prospective holdout. On future refreshes the model remains frozen on
        # pre-holdout data; newly realized rows are evaluated without refitting.
        hold=ph[pd.to_datetime(ph.date)>=PROSPECTIVE_HOLDOUT_START].dropna(subset=["y","label_end"]).copy()
        hold_info={
            "status":"awaiting_new_data" if hold.empty else "accumulating_frozen_holdout",
            "n_realized_rows":int(len(hold)),
            "n_global_dates":int(hold.date.nunique()) if not hold.empty else 0,
            "used_for_tuning":False,
            "frozen_model":True,
        }
        if not hold.empty:
            hp_raw=model.proba(hold[cols].to_numpy(float))
            hp_cal=_apply_platt(cal_live,hp_raw)
            by_ev={s:_asset_evidence(oos,s,horizon) for s in hold.symbol.unique()}
            hp_shr=[]
            for pp,s in zip(hp_cal,hold.symbol):
                ev=by_ev.get(s,{})
                sample_alpha=min(1.0,max(0.0,ev.get("n_eff",0)/30.0))
                bs=float(ev.get("brier_skill",-999)); ece=float(ev.get("ece",1.0))
                skill_alpha=1.0 if bs>0 and ece<=0.15 else 0.5 if bs>-2.0 and ece<=0.20 else 0.25
                alpha=sample_alpha*skill_alpha
                hp_shr.append(float(np.clip(.5+alpha*(float(pp)-.5),.05,.95)))
            base=_baseline_for_rows(frozen_train,hold)
            htmp=pd.DataFrame({"date":pd.to_datetime(hold.date),"symbol":hold.symbol.to_numpy(),
                               "y":hold.y.to_numpy(float),"p":np.asarray(hp_shr,float),"base":base})
            hold_info.update({
                "first_date":str(pd.Timestamp(hold.date.min()).date()),
                "last_date":str(pd.Timestamp(hold.date.max()).date()),
                "raw":_metric(hp_raw,hold.y,base),
                "calibrated":_metric(hp_cal,hold.y,base),
                "evidence_shrunk":_metric(hp_shr,hold.y,base),
                "cluster_date_bootstrap":_cluster_block_bootstrap(htmp,horizon,n_boot=500,seed=936),
            })
        result["models"][name]["prospective_holdout"]=hold_info
    return result

def run_all(con):
    panel,targets,meta=build_base_panel(con)
    horizons=[run_horizon(panel,targets,h) for h in HORIZONS]
    return {
        "version":"3.6","feature_version":FEATURE_VERSION,
        "validation_version":VALIDATION_VERSION,
        "prospective_holdout_start":str(PROSPECTIVE_HOLDOUT_START.date()),
        "prospective_holdout_rule":"new data only; current package ends before holdout; never tune on holdout",
        "data_meta":meta,"models":MODEL_VERSIONS,"horizons":horizons,
        "decision":{
            "production_champion":"logreg-v3.2.0",
            "action":"retain",
            "reason":"v3.6 pooled models are new research challengers; prospective final holdout has zero realized observations at package time"
        }
    }
