# Morpheus v4.31 — Market Detail History + Live Price + Alt Fallback + Pulse Explorer

- Repaired malformed external script tags that caused inline reliability/price helpers to be ignored by the browser.
- Market detail chart now fetches selected asset history lazily through `/api/chart/history`, including MOEX supplemental instruments.
- “Простыми словами” now adds up to three news items scored specifically for the selected asset.
- Overview current price renders immediately from last known history and upgrades to `/api/terminal/quote` without leaving a permanent dash.
- Alternative Data uses real API data when available, local last-good snapshots next, and transparent market-derived proxies as the final fallback. Provider-only metrics are never fabricated.
- Pulse classifies directional conviction as strong >70%, moderate 55–70%, weak <55%, and adds an explorable strong-signal list.
- Added compact data-health indicators in Pulse.
