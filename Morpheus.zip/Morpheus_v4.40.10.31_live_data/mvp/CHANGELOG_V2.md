# Changelog — Morpheus v2.1

## Trust / forecasting
- Removed unconditional BUY/SELL from the public layer.
- Added ML quality gate: OOS observations + accuracy edge + Brier skill + calibration error.
- Added separate 1/5/10/20 trading-day directional models.
- Replaced Gaussian Monte Carlo with historical block bootstrap for scenario ranges.
- Historical scenario and ML forecast are labelled as separate objects.
- Corrected log-return equity curves (`exp(cumsum(log_return))`).
- Removed duplicated `event_reaction()` and `surprise_label()` definitions.

## Data correctness
- Oil news keywords now map to WTI (`CL=F`) instead of gold.
- Cross OHLC uses ratio bounds (high≈num_high/den_low, low≈num_low/den_high).
- MOEX ISS loader uses OPEN/HIGH/LOW/CLOSE when available instead of fake flat candles.
- Added prepared FRED/ALFRED point-in-time, BLS, EIA and CFTC provider clients.

## UX/UI
- New first-screen Market Pulse.
- Main flow: Market Pulse → Watchlist → Markets → News & Risks → Events → Research.
- Macro/rates/politics/scenario tools moved into expandable Research modules.
- Search added to hero.
- Asset cards show bias + confidence + raw probability, not recommendations.
- Asset detail shows OOS model quality and 1/5/10/20 horizons before technical context.
- Brand accent separated from bullish green.
- Mobile navigation and responsive layouts added; 390px viewport smoke-tested without horizontal overflow.
- External news content is HTML-escaped and external URLs are protocol-filtered.

## Backend / delivery
- `export_site.py` writes both `site/data.js` and `site/data.json`.
- Static payload reduced from roughly 3 MB to roughly 2.2 MB by limiting chart history.
- Added optional read-only FastAPI backend (`api.py`) as a migration path to lazy loading.
- Real `.env` removed from distributable project; `.env.example` only.

## Still intentionally not solved
- Point-in-time macro vintages are not yet persisted in `market.db`.
- Fixed publication lags remain an approximation until release timestamps/vintages are integrated.
- Scenario Lab coefficients are still heuristic and explicitly labelled illustrative.
- Options IV/skew/OI, CFTC COT and EIA features require the next data-integration stage.
