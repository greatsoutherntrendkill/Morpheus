# Alternative-data model readiness

The new feeds are valuable, but not every live metric is automatically safe for a historical ML backtest.

## CoinGlass — closest to model-ready

The sync requests up to 730 daily observations for OI, OI-weighted funding and liquidations. This can become a crypto feature layer after verifying actual plan coverage and timestamp completeness.

Candidate future features:
- log OI change 1D / 7D / 20D;
- funding level and rolling z-score;
- long-vs-short liquidation share;
- liquidation intensity relative to OI;
- OI × price direction interaction.

## Massive Options — live intelligence first

The option-chain snapshot endpoint is current-state data, not historical chain reconstruction. It is excellent for the dashboard, but it should not enter a backtest until historical option snapshots are available under the subscribed plan/provider.

Candidate future features:
- 25-delta skew;
- ATM IV term slope;
- put/call OI;
- OI concentration near spot;
- IV minus realized volatility.

## EIA — historical but release-time sensitive

EIA series have long histories, but weekly inventory observations must be aligned to the public release date/time rather than naively back-filled to the observation week.

Candidate future features:
- crude inventory surprise/change;
- gas storage change and seasonal percentile;
- production momentum;
- physical balance regime.

## CFTC — public, mapping-sensitive

No private key is necessary. The key task is contract mapping and preserving distinctions between TFF and Disaggregated classifications.
