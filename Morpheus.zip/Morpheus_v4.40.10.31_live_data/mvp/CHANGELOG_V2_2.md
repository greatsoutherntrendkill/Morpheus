# Morpheus v2.2 — Market News Terminal

## Added
- News API `/v2/everything` integration with keys kept server-side in `.env`.
- English + Russian finance discovery query, recency window and local ranking.
- Deterministic finance-news filter: relevance, freshness, deduplication, event class,
  affected assets, market-context sentiment, transmission channels and impact score.
- Pexels fallback for stories without publisher imagery; fallback images are explicitly
  labelled as illustrations and include Pexels/photographer attribution.
- Black/green duotone Market News Terminal on the homepage.
- UI category filters and `HIGH IMPACT >= 60` toggle.
- `/api/news?category=...&min_impact=...` filtering.

## Important
News classification is context, not a price forecast and does not bypass the ML quality gate.
External API keys are intentionally not exposed to `data.js` or browser JavaScript.
