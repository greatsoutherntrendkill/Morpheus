# Morpheus data/API roadmap

## P0 — data integrity before more models
1. **FRED/ALFRED point-in-time vintages** — eliminate revision/look-ahead leakage in macro backtests.
2. **Actual release timestamps** for CPI/payroll/GDP instead of fixed `LAG_DAYS` approximations.
3. Persist `source`, `available_at`, `vintage`, `ingested_at`, and `model_version` with every feature/prediction.

## P1 — highest expected forecasting value
- **Options chain / implied volatility / skew / open interest** for S&P/Nasdaq/FX/crypto where licensed.
- **CFTC COT** positioning for futures, FX, metals, energy and index futures.
- **EIA API v2** inventories/production for oil and natural gas.
- **BLS / BEA official APIs** for labour, CPI and national accounts.

## P2 — event and narrative layer
- **GDELT** or another licensed news/event feed for entity/event extraction.
- Use a multilingual financial NLP model for sentiment/event classification; keep LLM extraction structured and auditable.
- **SEC EDGAR** if single-stock coverage is added.

## Model policy
- Separate models by horizon (1/5/10/20d) and asset class.
- Directional label only after OOS quality gate.
- Evaluate accuracy, Brier score/skill, calibration error, stability across rolling windows and costs where a strategy is shown.
- Prefer calibrated tree/linear ensembles and quantile models before LSTM/Transformer on small daily datasets.
