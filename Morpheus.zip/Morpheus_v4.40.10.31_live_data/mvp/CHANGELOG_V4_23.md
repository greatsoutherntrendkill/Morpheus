# v4.23 — Forecast Architecture Rebuild

- Replaced Russian fast-forecast `/candles` dependency with documented MOEX daily history endpoint.
- Added board-history -> market-history fallback for board migrations.
- Reused the last successful MOEX network transport before trying slower fallbacks.
- Browser forecast fallback now loads MOEX `history` JSONP instead of candles.
- Fixed 60-vs-61 close off-by-one error in the block-bootstrap model path.
- Removed test-generated GAZP/SBER forecast cache from release artifacts.
- Prevented pytest from writing production forecast cache.
- Added forecast diagnostics endpoint.
- Kept live quotes, M&A/IPO, news, valuation and other data pipelines unchanged.
