# v3.0 — Point-in-time Macro

- Added SQLite `macro_pit`.
- Added ALFRED/FRED initial-release downloader (`output_type=4`).
- Separated current/revised macro history from predictive point-in-time history.
- Predictive macro layer is strict PIT by default.
- Removed silent revised-FRED fallback from model features.
- Added CBR PIT provenance.
- Added macro provenance to every asset payload and Model Quality UI.
- Added tests proving a revised current macro value cannot appear before PIT availability.
- Added parser test proving `realtime_start` becomes `available_date`.
- Added `/api/pulse` macro-data provenance.
