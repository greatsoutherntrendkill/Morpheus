from alternative_data_v39 import build_snapshot
import json
s=build_snapshot(force=True)
print(json.dumps({
    'version':s.get('version'),
    'generated_at':s.get('generated_at'),
    'крипта':(s.get('crypto') or {}).get('status'),
    'опционы':(s.get('options') or {}).get('status'),
    'энергетика':(s.get('energy') or {}).get('status'),
    'сводка':s.get('digest') or [],
},ensure_ascii=False,indent=2))
