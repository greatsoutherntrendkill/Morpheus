# Morpheus v2.5

- Root-cause fix for chart spikes: real updates now replace per-symbol history instead of mixing with stale demo rows.
- Added isolated-stale-row detection and tighter wick validation as a second safety layer.
- Reduced chart overlay clutter.
- News error pages (500/502/503/404 etc.) and Biztoc aggregator rows are filtered out.
- Publisher images are validated/downloaded locally; failed images fall back to Pexels and are cached locally.
- No AA text placeholder: a failed image area is removed instead of showing a fake badge.
