"""Independent minute quote refresh. Snapshot prices never masquerade as live data."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from threading import RLock, Event, Thread, local
from urllib.parse import quote
from pathlib import Path
import json, math, time, os
import requests

INTERVAL = 60
CRYPTO = {'BTC-USD':'BTCUSDT','ETH-USD':'ETHUSDT','SOL-USD':'SOLUSDT','XRP-USD':'XRPUSDT'}
INDICES = {'IMOEX','RTSI','MOEXBC','RGBI'}
_TLS = local()

def utc(ts=None):
    return datetime.fromtimestamp(time.time() if ts is None else ts, timezone.utc).isoformat()

def timestamp(value):
    try:
        if not value or len(str(value)) < 10:return None
        dt=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        return dt.replace(tzinfo=timezone.utc).timestamp() if dt.tzinfo is None else dt.timestamp()
    except (ValueError, TypeError):return None

def valid_price(value):
    try:return math.isfinite(float(value)) and float(value)>0
    except (ValueError,TypeError):return False

def get_json(url, params=None):
    # Session.request deliberately avoids the legacy global multi-route retry patch.
    # Finite per-request timeouts keep a slow provider from monopolizing the pool.
    if not hasattr(_TLS,'session'):
        _TLS.session=requests.Session()
        proxy=os.getenv('ALLANALYTICS_EGRESS_PROXY')
        if proxy:_TLS.session.proxies.update(http=proxy,https=proxy)
        _TLS.session.headers.update({'User-Agent':'Mozilla/5.0','Accept':'application/json','Cache-Control':'no-cache'})
    r=_TLS.session.get(url,params=params,timeout=(2,4))
    r.raise_for_status()
    return r.json()

def single_quote(symbol):
    if symbol=='CNYRUB':
        rub=single_quote('RUB=X');cny=single_quote('CNY=X')
        return {'last':rub['last']/cny['last'],'chg1d':None,
                'as_of':min(rub['as_of'],cny['as_of']),
                'source':'Расчётный кросс-курс · USD/RUB ÷ USD/CNY (Yahoo Finance)'}
    errors=[]
    if symbol in CRYPTO:
        for host in ['data-api.binance.vision','api.binance.com']:
            try:
                j=get_json('https://'+host+'/api/v3/ticker/24hr',{'symbol':CRYPTO[symbol]})
                return {'last':float(j['lastPrice']),'chg1d':float(j['priceChangePercent']),
                        'as_of':utc(j['closeTime']/1000),'source':'Binance · 24h ticker'}
            except Exception as exc:errors.append(type(exc).__name__)
        raise RuntimeError('Binance: '+', '.join(errors))
    for host in ['query2.finance.yahoo.com','query1.finance.yahoo.com']:
        try:
            j=get_json(f'https://{host}/v8/finance/chart/{quote(symbol,safe="")}',{'range':'1d','interval':'1m'})
            m=j['chart']['result'][0]['meta'];last=m['regularMarketPrice']
            prev=m.get('chartPreviousClose') or m.get('previousClose')
            return {'last':last,'chg1d':(last/prev-1)*100 if prev else None,
                    'as_of':utc(m['regularMarketTime']),'source':'Yahoo Finance · market quote',
                    'exchange':m.get('exchangeName'),'market_state':m.get('marketState')}
        except Exception as exc:errors.append(type(exc).__name__)
    raise RuntimeError('Yahoo Finance: '+', '.join(errors))

def moex_quotes(symbols, indices=False):
    market='index' if indices else 'shares';board='SNDX' if indices else 'TQBR'
    j=get_json(f'https://iss.moex.com/iss/engines/stock/markets/{market}/boards/{board}/securities.json',
               {'iss.meta':'off','iss.only':'securities,marketdata'})
    def block(name):
        b=j.get(name,{})
        return {str(row.get('SECID')):row for row in [dict(zip(b.get('columns',[]),r)) for r in b.get('data',[])]}
    securities=block('securities');data=block('marketdata');out={}
    for symbol in symbols:
        sec=symbol.removesuffix('.ME');m=data.get(sec,{}) or {};s=securities.get(sec,{}) or {}
        last=m.get('CURRENTVALUE') if indices else m.get('LAST')
        dt=m.get('SYSTIME')
        if valid_price(last) and dt:
            # SYSTIME contains a date, unlike UPDATETIME (time-of-day only).
            # SYSTIME is the exchange snapshot time, not necessarily a trade time.
            dt=str(dt).replace(' ','T')
            if '+' not in dt and not dt.endswith('Z'):dt+='+03:00'
            change=m.get('LASTCHANGEPRCNT') if not indices else m.get('CHANGE')
        else:
            last=s.get('PREVPRICE') or s.get('PREVLEGALCLOSEPRICE') or m.get('LASTVALUE')
            dt=str(s.get('PREVDATE') or '')
            dt=dt+'T23:59:00+03:00' if len(dt)==10 else None
            change=None
        out[symbol]={'last':last,'chg1d':change,'as_of':dt,'source':'MOEX ISS · '+board,'timestamp_kind':'exchange_snapshot'}
    return out

class QuoteService:
    def __init__(self, fetch=single_quote, batch=moex_quotes, clock=time.time, cache_path=None):
        self.fetch,self.batch,self.clock=fetch,batch,clock
        self.lock=RLock();self.stop_event=Event();self.assets={};self.rows={};self.attempts={};self.pending=set()
        self.pool=ThreadPoolExecutor(max_workers=12,thread_name_prefix='minute-quotes')
        self.worker=None;self.cache_path=Path(cache_path) if cache_path else None
        if self.cache_path:
            try:self.rows=json.loads(self.cache_path.read_text())
            except (OSError,ValueError):pass
    def register(self, assets):
        with self.lock:
            for a in assets:
                if a.get('symbol'):self.assets[a['symbol']]={k:a.get(k) for k in ['symbol','name','category']}
    def start(self):
        if self.worker:return
        self.worker=Thread(target=self._loop,daemon=True,name='minute-quote-scheduler');self.worker.start()
    def _loop(self):
        while not self.stop_event.is_set():
            self.refresh();self.stop_event.wait(1)
    def close(self):
        self.stop_event.set()
        if self.worker:self.worker.join(timeout=2)
        self.pool.shutdown(wait=False,cancel_futures=True)
    def refresh(self, force=False, only=None):
        now=self.clock()
        with self.lock:
            due=[s for s in (only or self.assets) if s in self.assets and s not in self.pending and
                 now-self.attempts.get(s,-1e12)>=(5 if force else INTERVAL)]
            for s in due:self.pending.add(s);self.attempts[s]=now
        ru=[s for s in due if s.endswith('.ME')];ix=[s for s in due if s in INDICES]
        for group,is_index in [(ru,False),(ix,True)]:
            if group:self.pool.submit(self._batch,group,is_index)
        for s in due:
            if s not in ru and s not in ix:self.pool.submit(self._one,s)
    def _one(self,s):
        try:self._store(s,self.fetch(s))
        except Exception as exc:self._store(s,None,str(exc)[:180])
    def _batch(self,syms,indices):
        try:
            rows=self.batch(syms,indices)
            for s in syms:self._store(s,rows.get(s))
        except Exception as exc:
            for s in syms:self._store(s,None,str(exc)[:180])
    def _store(self,s,row,error=None):
        now=self.clock();ts=timestamp((row or {}).get('as_of'))
        limit=180 if s in CRYPTO else 96*3600
        accepted=row and valid_price(row.get('last')) and ts is not None and -300<=now-ts<=limit
        with self.lock:
            old=self.rows.get(s,{})
            # Never overwrite a newer quote with an older provider response.
            if accepted and ts >= (timestamp(old.get('as_of')) or 0):
                self.rows[s]={**row,'symbol':s,'fetched_at':utc(now),'checked_at':utc(now),'error':None}
            else:
                self.rows[s]={**old,'symbol':s,'checked_at':utc(now),'error':error or 'Источник не вернул пригодную свежую котировку'}
            self.pending.discard(s)
            if self.cache_path:
                try:
                    self.cache_path.parent.mkdir(parents=True,exist_ok=True)
                    tmp=self.cache_path.with_suffix('.tmp');tmp.write_text(json.dumps(self.rows,ensure_ascii=False));tmp.replace(self.cache_path)
                except OSError:pass
    def snapshot(self, only=None):
        now=self.clock()
        with self.lock:
            result=[]
            for s in (only or self.assets):
                raw=dict(self.rows.get(s,{}))
                ts=timestamp(raw.get('as_of'));checked=timestamp(raw.get('fetched_at'))
                age=now-ts if ts is not None else None
                usable=valid_price(raw.get('last')) and age is not None and -300<=age<=(180 if s in CRYPTO else 96*3600)
                stale=not usable or not checked or now-checked>90 or bool(raw.get('error'))
                state='unavailable' if not usable else 'stale' if stale else 'latest_trade' if age>1200 else 'fresh'
                result.append({**self.assets.get(s,{}),**raw,'symbol':s,
                    'last':raw.get('last') if usable else None,'chg1d':raw.get('chg1d') if usable else None,
                    'last_known':raw.get('last'),'stale':stale,'status':state,'age_seconds':age,
                    'refreshing':s in self.pending,'history':[]})
            return {'version':'4.40.10.31','refresh_seconds':INTERVAL,'server_time':utc(now),
                    'refreshing':any(s in self.pending for s in (only or self.assets)),
                    'summary':{'total':len(result),'live':sum(not r['stale'] for r in result),
                               'snapshot_fallback':0,'stale':sum(r['stale'] and r['last'] is not None for r in result),
                               'failed':[r['symbol'] for r in result if r['last'] is None]},'quotes':result}
