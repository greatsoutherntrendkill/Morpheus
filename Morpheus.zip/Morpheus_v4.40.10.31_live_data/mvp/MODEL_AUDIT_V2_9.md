# Model Audit — v2.9 dependence-aware validation

## Core result
v2.9 materially reduces apparent certainty without changing the underlying logistic model or feature set. That is intentional: this release improves measurement of model quality rather than trying to improve the model itself.

### Aggregate snapshot
| Horizon | v2.8 median raw N | v2.9 median effective N | v2.8 trusted | v2.9 trusted | v2.8 median edge | v2.9 median non-overlap edge |
|---|---:|---:|---:|---:|---:|---:|
| 1D | 106 | 106 | 1 | 0 | +2.8 pp | +2.8 pp |
| 5D | 98 | 19 | 1 | 0 | +4.7 pp | +5.0 pp |
| 10D | 88 | 8 | 0 | 0 | +1.1 pp | 0.0 pp |
| 20D | 68 | 3 | 0 | 0 | -5.9 pp | 0.0 pp |

The key change is not merely the point estimate. Multi-day evidence is much smaller once overlapping forward returns are not treated as independent trials.

## Examples
### USD/JPY — 1D
v2.8 passed the old gate with:
- edge +3.3 pp;
- Brier skill +2.2%;
- ECE 0.040;
- raw OOS N 180.

v2.9 keeps the same point estimates but estimates:
- edge 95% CI: -6.4 ... +12.0 pp;
- Brier-skill 95% CI: -2.3 ... +6.2%.

Because both intervals include zero, the signal is no longer trusted.

### EUR/USD — 5D
v2.8 passed with raw edge +16.9 pp and Brier skill +3.4%.

v2.9 finds:
- raw N 172;
- effective N 34;
- phase-median non-overlap edge +17.6 pp;
- edge 95% CI +2.6 ... +32.6 pp;
- Brier-skill 95% CI -21.8 ... +25.2%;
- non-overlap ECE 0.218.

The directional accuracy signal looks interesting, but probabilistic skill and calibration are not yet credible enough to publish a directional bias.

## Interpretation
This is a good failure. v2.9 shows that the current feature set may contain pockets of directional information, but the probability model is not yet sufficiently stable/calibrated to support strong claims.

The next priority is point-in-time macro data and a longer immutable history, not a more complex neural network.
