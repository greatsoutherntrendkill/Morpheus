# MODEL AUDIT — v4.40 Distributional Forecast & Expected Move

## Цель
Добавить честную оценку диапазона результата и риска вокруг уже существующего directional forecast, не превращая диапазон в новый недоказанный directional signal.

## Target
Основная distribution target — будущая логарифмическая доходность через `h` последующих торговых сессий, в процентах.

Квантили: 10%, 25%, 50%, 75%, 90%.

## Защита от leakage
- feature row использует только информацию, доступную на соответствующую историческую дату;
- последние `h` строк без наблюдаемого future target исключаются;
- train/calibration/evaluation разделены хронологически;
- между train→calibration и calibration→evaluation стоит purge gap длиной `h` сессий;
- median bias и interval correction обучаются только на calibration slice;
- untouched evaluation не используется для refit или tuning;
- current live row не входит ни в один historical target.

## Calibration
После quantile regressors:
1. calibration slice оценивает median bias;
2. 50% и 80% интервалы расширяются split-conformal correction;
3. quantile crossing принудительно исправляется монотонной сортировкой;
4. слабый evaluation skill не может сузить диапазон ниже realised-volatility risk floor.

## Метрики
На untouched evaluation считаются:
- 50% coverage;
- 80% coverage;
- pinball loss по каждому квантилю;
- mean pinball;
- pinball skill против unconditional historical-quantile baseline;
- CRPS-like = 2 × mean pinball;
- median MAE.

В prospective ledger дополнительно считается expected-absolute-move MAE.

## Options benchmark
Options IV читается только из локального нормализованного snapshot, уже полученного data-layer. Forecast module не инициирует внешний options request.

`IV × sqrt(h/252)` отображается как 1-sigma benchmark. Он не используется как скрытая метка и не меняет `p_up`.

## Governance invariant
Для одинакового вызова v4.39 и v4.40 должны совпадать:
- `p_up` / `p_down`;
- `signal_threshold`;
- `abstain`;
- directional component weights.

v4.40 только добавляет `distribution_forecast`.

## Известные ограничения
- при короткой истории distribution output корректно возвращает insufficient sample;
- local options snapshot может не содержать подходящего mapped proxy — тогда benchmark unavailable;
- quantile estimates остаются challenger-quality until накоплена prospective history; development coverage не считается доказательством live coverage.
