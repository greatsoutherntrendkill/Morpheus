from __future__ import annotations
import json
import alternative_data_v40 as AD

if __name__ == '__main__':
    snap=AD.build_snapshot(force=True)
    print(json.dumps({
        'version':snap.get('version'),
        'generated_at':snap.get('generated_at'),
        'crypto':(snap.get('crypto') or {}).get('status'),
        'options':(snap.get('options') or {}).get('status'),
        'energy':(snap.get('energy') or {}).get('status'),
        'cftc':(snap.get('cftc') or {}).get('status'),
        'digest':snap.get('digest') or [],
    },ensure_ascii=False,indent=2))
