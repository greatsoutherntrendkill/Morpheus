
"""Morpheus v3.7 — regime-aware Mixture-of-Experts + OOD guard.

This is a research challenger layered on v3.6's global-time pooled panel.

Architecture:
    global expert
      + asset-class expert
      + risk-regime expert
      -> locked weighted probability
      -> development-only Platt calibration
      -> evidence × OOD familiarity × expert-agreement shrinkage toward 50%

No prospective-holdout outcome is used for fitting, calibration, threshold choice
or expert selection.
"""
from __future__ import annotations

import math
import numpy as np
import pandas as pd

import models as M
import cross_asset_models as X

VERSION="regime-moe-v4.40.10"
FEATURE_VERSION="regime-cross-asset-pit-v3.7.0"
VALIDATION_VERSION="global-time-purged-regime-moe-data-driven-inner-weights-v4.40.10"
PROSPECTIVE_HOLDOUT_START=X.PROSPECTIVE_HOLDOUT_START
HORIZONS=X.HORIZONS
MIN_TRAIN_DATES=180
RETRAIN_EVERY=60

LOCKED_CONFIG={
    "estimator":"SGD logistic experts",
    "global_weight":0.45,
    "class_weight":0.35,
    "regime_weight":0.20,
    "sgd_alpha":0.0008,
    "sgd_max_iter":700,
    "sgd_average":True,
    "min_class_rows":500,
    "min_regime_rows":900,
    "ood_familiarity_floor":0.25,
    "expert_disagreement_scale":0.12,
    "cross_market_lag":"1d inherited from v3.6",
    "prospective_holdout_start":str(PROSPECTIVE_HOLDOUT_START.date()),
}

def coarse_class(cat: str) -> str:
    cat=str(cat or "")
    if cat in ("Крипто",): return "crypto"
    if cat in ("Сырьё",): return "commodities"
    if cat in ("Валюты",): return "fx"
    if cat=="Индексы РФ": return "russia"
    if cat.startswith("Индексы") or cat=="Фьючерсы": return "equities"
    return "other"

def _date_regimes(panel: pd.DataFrame) -> pd.DataFrame:
    """Regimes use only information available at each date.

    Expanding quantile thresholds are shifted by one date, so today's regime does
    not use future distribution information to decide what 'high' or 'low' means.
    """
    cols=[c for c in [
        "x_eq_mom20_l1","x_dxy_mom20_l1","x_eq_vol20_l1",
        "us_ff_chg3m","us_cpi_accel","us_vix","curve_2s10s"
    ] if c in panel]
    d=(panel.groupby("date",sort=True)[cols].first()
       if cols else pd.DataFrame(index=sorted(pd.unique(panel.date))))
    d.index=pd.to_datetime(d.index)

    def hist_quant(s,q,minp=60):
        return s.expanding(min_periods=minp).quantile(q).shift(1)

    eq=d["x_eq_mom20_l1"] if "x_eq_mom20_l1" in d else pd.Series(np.nan,index=d.index)
    dx=d["x_dxy_mom20_l1"] if "x_dxy_mom20_l1" in d else pd.Series(np.nan,index=d.index)
    eq_med=hist_quant(eq,.5); dx_med=hist_quant(dx,.5)
    risk=np.where((eq>eq_med)&(dx<=dx_med),"risk_on",
          np.where((eq<eq_med)&(dx>=dx_med),"risk_off","mixed"))
    d["risk_regime"]=risk

    vol=d["x_eq_vol20_l1"] if "x_eq_vol20_l1" in d else pd.Series(np.nan,index=d.index)
    vlo=hist_quant(vol,.30); vhi=hist_quant(vol,.70)
    d["vol_regime"]=np.where(vol>vhi,"high_vol",np.where(vol<vlo,"low_vol","normal_vol"))

    ff=d["us_ff_chg3m"] if "us_ff_chg3m" in d else pd.Series(np.nan,index=d.index)
    d["policy_regime"]=np.where(ff>.05,"tightening",np.where(ff<-.05,"easing","policy_neutral"))

    cpi=d["us_cpi_accel"] if "us_cpi_accel" in d else pd.Series(np.nan,index=d.index)
    d["inflation_regime"]=np.where(cpi>.05,"inflationary",
                                   np.where(cpi<-.05,"disinflationary","inflation_neutral"))

    # Deterministic continuous regime strength. Only lagged/PIT inputs participate.
    eqz=(eq-eq.expanding(min_periods=60).mean().shift(1)) / (eq.expanding(min_periods=60).std().shift(1)+1e-9)
    dxz=(dx-dx.expanding(min_periods=60).mean().shift(1)) / (dx.expanding(min_periods=60).std().shift(1)+1e-9)
    vz=(vol-vol.expanding(min_periods=60).mean().shift(1)) / (vol.expanding(min_periods=60).std().shift(1)+1e-9)
    d["risk_score"]=np.tanh((eqz-dxz).fillna(0)/2)
    d["vol_score"]=np.tanh(vz.fillna(0)/2)
    return d.reset_index().rename(columns={"index":"date"})

def add_regime_features(panel: pd.DataFrame) -> pd.DataFrame:
    p=panel.copy()
    p["date"]=pd.to_datetime(p["date"])
    regs=_date_regimes(p)
    p=p.merge(regs,on="date",how="left")

    # Coarse class is derived from v3.6 one-hot category columns.
    class_cols=[c for c in p if c.startswith("class__")]
    def infer_class(row):
        active=[c[len("class__"):] for c in class_cols if float(row.get(c,0) or 0)>.5]
        s=active[0] if active else ""
        # slugs from Russian class names are not useful; infer from actual symbol/category map.
        return coarse_class(X.CATS.get(row["symbol"],""))
    p["expert_class"]=p.apply(infer_class,axis=1)

    for col,prefix,values in [
        ("risk_regime","regime_risk__",["risk_on","risk_off","mixed"]),
        ("vol_regime","regime_vol__",["high_vol","low_vol","normal_vol"]),
        ("policy_regime","regime_policy__",["tightening","easing","policy_neutral"]),
        ("inflation_regime","regime_inflation__",["inflationary","disinflationary","inflation_neutral"]),
    ]:
        for v in values:
            p[prefix+v]=(p[col]==v).astype(float)

    # Interactions let the global expert learn different sensitivities by regime.
    for base in [c for c in ["mom20","vol20","x_dxy_mom20_l1","us_real10y","us_vix"] if c in p]:
        p[f"int_{base}_risk_score"]=pd.to_numeric(p[base],errors="coerce")*pd.to_numeric(p["risk_score"],errors="coerce")
        p[f"int_{base}_vol_score"]=pd.to_numeric(p[base],errors="coerce")*pd.to_numeric(p["vol_score"],errors="coerce")
    return p

class _Prep:
    def fit(self,X):
        X=np.asarray(X,float)
        med=np.nanmedian(X,axis=0); med=np.where(np.isfinite(med),med,0.0)
        z=np.where(np.isfinite(X),X,med)
        mu=z.mean(0); sd=z.std(0)+1e-9
        self.med=med; self.mu=mu; self.sd=sd
        return self
    def transform(self,X):
        X=np.asarray(X,float)
        z=np.where(np.isfinite(X),X,self.med)
        return (z-self.mu)/self.sd

class FastExpert:
    def __init__(self,seed=42):
        from sklearn.linear_model import SGDClassifier
        self.prep=_Prep()
        self.m=SGDClassifier(
            loss="log_loss",penalty="l2",alpha=LOCKED_CONFIG["sgd_alpha"],
            max_iter=LOCKED_CONFIG["sgd_max_iter"],tol=1e-4,random_state=seed,
            average=LOCKED_CONFIG["sgd_average"],class_weight=None
        )
    def fit(self,X,y):
        z=self.prep.fit(X).transform(X)
        self.m.fit(z,np.asarray(y,int)); return self
    def proba(self,X):
        return np.asarray(self.m.predict_proba(self.prep.transform(X))[:,1],float)
    def coef_abs(self):
        a=np.abs(np.asarray(self.m.coef_[0],float)); s=float(a.sum()) or 1.
        return a/s

class RegimeMoE:
    def __init__(self, feature_cols):
        self.cols=list(feature_cols)
        self.global_model=None
        self.class_models={}
        self.regime_models={}
        self.ood_cols=[i for i,c in enumerate(self.cols)
                       if not c.startswith(("asset__","class__","region__","regime_"))]
        self.ood_prep=None
        self.ood_ref=None
        self.weights={"global":float(LOCKED_CONFIG["global_weight"]),
                      "class":float(LOCKED_CONFIG["class_weight"]),
                      "regime":float(LOCKED_CONFIG["regime_weight"])}
        self.weight_selection={"version":"regime-moe-weights-v4.40.10","learned":False,
                               "weights":dict(self.weights),"reason":"locked_fallback"}

    @staticmethod
    def _blend_from_components(c, weights):
        vals=[]
        for name,key in (("global","global_p"),("class","class_p"),("regime","regime_p")):
            v=c.get(key); w=float(weights.get(name,0.0))
            if v is not None and np.isfinite(v) and w>0: vals.append((float(v),w))
        sw=sum(w for _,w in vals)
        return float(sum(v*w for v,w in vals)/sw) if sw>0 else float(c.get("global_p",.5))

    def _fit_experts(self,X,y,meta):
        self.global_model=FastExpert(370).fit(X,y)
        self.class_models={}; self.regime_models={}
        cls=np.asarray(meta["expert_class"],object)
        for j,k in enumerate(sorted(set(cls))):
            mask=cls==k
            if mask.sum()>=LOCKED_CONFIG["min_class_rows"] and len(np.unique(y[mask]))>1:
                self.class_models[k]=FastExpert(371+j).fit(X[mask],y[mask])
        rg=np.asarray(meta["risk_regime"],object)
        for j,k in enumerate(sorted(set(rg))):
            mask=rg==k
            if mask.sum()>=LOCKED_CONFIG["min_regime_rows"] and len(np.unique(y[mask]))>1:
                self.regime_models[k]=FastExpert(390+j).fit(X[mask],y[mask])
        if self.ood_cols:
            zraw=X[:,self.ood_cols]
            self.ood_prep=_Prep().fit(zraw)
            z=self.ood_prep.transform(zraw)
            dist=np.mean(np.minimum(np.abs(z),5.0),axis=1)
            self.ood_ref=np.sort(np.asarray(dist,float))

    def _learn_weights(self,X,y,meta,dates,label_ends=None):
        try:
            d=pd.to_datetime(np.asarray(dates),errors="coerce")
            unique=np.array(sorted(pd.unique(d[~pd.isna(d)])),dtype="datetime64[ns]")
            if len(unique)<80:return None,{"reason":"insufficient_unique_dates"}
            val_start=pd.Timestamp(unique[max(55,int(len(unique)*.78))])
            val=np.asarray([pd.Timestamp(x)>=val_start if not pd.isna(x) else False for x in d],bool)
            train=~val
            if label_ends is not None:
                le=pd.to_datetime(np.asarray(label_ends),errors="coerce")
                train &= np.asarray([pd.Timestamp(x)<val_start if not pd.isna(x) else False for x in le],bool)
            if train.sum()<1200 or val.sum()<180 or len(np.unique(y[train]))<2 or len(np.unique(y[val]))<2:
                return None,{"reason":"insufficient_inner_split","fit_n":int(train.sum()),"validation_n":int(val.sum())}
            inner=RegimeMoE(self.cols)
            inner._fit_experts(X[train],y[train],meta.iloc[np.where(train)[0]])
            comps=inner.proba_components(X[val],meta.iloc[np.where(val)[0]],weights={"global":.45,"class":.35,"regime":.20})
            yy=y[val]
            fixed={"global":.45,"class":.35,"regime":.20}
            base=np.asarray([self._blend_from_components(c,fixed) for c in comps],float)
            base_brier=float(np.mean((base-yy)**2))
            best=(base_brier,fixed)
            # Coarse simplex is deliberate: low variance, interpretable, no hyperparameter explosion.
            grid=np.arange(0.0,1.0001,0.10)
            for wg in grid:
                if wg<.20:continue
                for wc in grid:
                    wr=1.0-wg-wc
                    if wr < -1e-9:continue
                    wr=max(0.0,wr)
                    w={"global":float(wg),"class":float(wc),"regime":float(wr)}
                    pp=np.asarray([self._blend_from_components(c,w) for c in comps],float)
                    b=float(np.mean((pp-yy)**2))
                    # Prefer simpler/global-heavier mixture on exact ties.
                    key=(b,-wg,abs(wc-.35)+abs(wr-.20))
                    bestkey=(best[0],-best[1]["global"],abs(best[1]["class"]-.35)+abs(best[1]["regime"]-.20))
                    if key < bestkey:best=(b,w)
            improvement=base_brier-best[0]
            learned=bool(improvement>1e-5)
            return (best[1] if learned else fixed),{
                "version":"regime-moe-weights-v4.40.10","learned":learned,
                "weights":dict(best[1] if learned else fixed),"fit_n":int(train.sum()),"validation_n":int(val.sum()),
                "validation_start":str(val_start.date()),"baseline_brier":round(base_brier,8),
                "selected_brier":round(float(best[0]),8),"brier_improvement":round(float(improvement),8),
                "reason":"chronological_inner_oos" if learned else "locked_weights_not_beaten",
            }
        except Exception as exc:
            return None,{"reason":f"weight_learning_failed:{type(exc).__name__}"}

    def fit(self,X,y,meta,dates=None,label_ends=None,learn_weights=True):
        X=np.asarray(X,float); y=np.asarray(y,float)
        meta=pd.DataFrame(meta).reset_index(drop=True)
        if learn_weights and dates is not None:
            w,diag=self._learn_weights(X,y,meta,dates,label_ends)
            if w is not None:self.weights=dict(w)
            self.weight_selection={"version":"regime-moe-weights-v4.40.10","learned":False,
                                   "weights":dict(self.weights),**diag}
        self._fit_experts(X,y,meta)
        return self

    def _familiarity(self,X):
        if self.ood_prep is None or self.ood_ref is None or len(self.ood_ref)<20:
            return np.full(len(X),50.0)
        z=self.ood_prep.transform(np.asarray(X,float)[:,self.ood_cols])
        dist=np.mean(np.minimum(np.abs(z),5.0),axis=1)
        ranks=np.searchsorted(self.ood_ref,dist,side="right")/len(self.ood_ref)
        return np.clip((1-ranks)*100,0,100)

    def proba_components(self,X,meta,weights=None):
        X=np.asarray(X,float)
        pg=self.global_model.proba(X)
        meta=pd.DataFrame(meta).reset_index(drop=True)
        cls=np.asarray(meta["expert_class"],object)
        rg=np.asarray(meta["risk_regime"],object)
        active_weights=dict(weights or self.weights)
        out=[]; familiar=self._familiarity(X)
        for i in range(len(X)):
            comps=[("global",float(pg[i]),active_weights.get("global",0.45))]
            cm=self.class_models.get(cls[i])
            if cm is not None:
                comps.append(("class",float(cm.proba(X[i:i+1])[0]),active_weights.get("class",0.35)))
            rscore=0.0
            try:
                if "risk_score" in meta:rscore=float(np.asarray(meta["risk_score"],float)[i])
            except Exception:rscore=0.0
            centers={"risk_off":-0.75,"mixed":0.0,"risk_on":0.75}
            routed=[]
            for rk,rm in self.regime_models.items():
                if rm is None:continue
                w=float(np.exp(-((rscore-centers.get(str(rk),0.0))**2)/(2*.42**2)))
                if w>1e-6:routed.append((rk,float(rm.proba(X[i:i+1])[0]),w))
            regime_p=None
            if routed:
                swr=sum(w for _,_,w in routed) or 1.0
                regime_p=sum(v*w for _,v,w in routed)/swr
                comps.append(("regime",float(regime_p),active_weights.get("regime",0.20)))
            sw=sum(w for _,_,w in comps)
            p=sum(v*w for _,v,w in comps)/sw if sw>0 else float(pg[i])
            vals=np.asarray([v for _,v,_ in comps],float)
            disagreement=float(vals.std()) if len(vals)>1 else 0.
            out.append({
                "p":float(p),"global_p":float(pg[i]),
                "class_p":next((v for n,v,_ in comps if n=="class"),None),
                "regime_p":regime_p,
                "expert_disagreement":disagreement,
                "regime_familiarity":float(familiar[i]),
                "expert_class":str(cls[i]),"risk_regime":str(rg[i]),"risk_score":float(rscore),
                "moe_weights":dict(active_weights),
            })
        return out

    def importance(self):
        return self.global_model.coef_abs()

def _feature_cols(df):
    skip={"date","symbol","close","label_end","ret_fwd","y",
          "expert_class","risk_regime","vol_regime","policy_regime","inflation_regime"}
    return [c for c in df if c not in skip]

def _baseline(train,test):
    gp=float(train.y.mean())
    by=train.groupby("symbol").y.mean().to_dict()
    return np.asarray([float(by.get(s,gp)) for s in test.symbol],float)

def walkforward(panel_h,horizon):
    df=panel_h.dropna(subset=["y","label_end","date"]).copy()
    df["date"]=pd.to_datetime(df.date); df["label_end"]=pd.to_datetime(df.label_end)
    df=df[(df.date<PROSPECTIVE_HOLDOUT_START)&(df.label_end<PROSPECTIVE_HOLDOUT_START)].copy()
    dates=np.array(sorted(pd.unique(df.date)),dtype="datetime64[ns]")
    cols=_feature_cols(df)
    if len(dates)<=MIN_TRAIN_DATES+25: return pd.DataFrame(),cols

    rows=[]; model=None; last_fit=-999; base_by={}; global_p=.5
    for i,d64 in enumerate(dates[MIN_TRAIN_DATES:],start=MIN_TRAIN_DATES):
        d=pd.Timestamp(d64); test=df[df.date==d]
        if test.empty: continue
        train=df[(df.date<d)&(df.label_end<d)]
        if len(train)<2500: continue
        if model is None or i-last_fit>=RETRAIN_EVERY:
            model=RegimeMoE(cols).fit(
                train[cols].to_numpy(float),train.y.to_numpy(float),
                train[["expert_class","risk_regime","risk_score"]],
                dates=train["date"].to_numpy(), label_ends=train["label_end"].to_numpy()
            )
            base_by=train.groupby("symbol").y.mean().to_dict()
            global_p=float(train.y.mean())
            last_fit=i
        comps=model.proba_components(test[cols].to_numpy(float),test[["expert_class","risk_regime","risk_score"]])
        bp=np.asarray([float(base_by.get(s,global_p)) for s in test.symbol],float)
        for j,(_,r) in enumerate(test.iterrows()):
            c=comps[j]
            rows.append({
                "date":r.date,"label_end":r.label_end,"feature_available_at":r.date,"symbol":r.symbol,"y":float(r.y),"ret_fwd":float(r.ret_fwd),
                "p":c["p"],"base":float(bp[j]),
                "familiarity":c["regime_familiarity"],"disagreement":c["expert_disagreement"],
                "risk_regime":c["risk_regime"],"expert_class":c["expert_class"],"risk_score":c.get("risk_score")
            })
    return pd.DataFrame(rows),cols

def _regime_metrics(oos):
    if oos.empty: return {}
    out={}
    for rg,g in oos.groupby("risk_regime"):
        if len(g)<50: continue
        out[str(rg)]={"rows":int(len(g)),**X._metric(g.p,g.y,g.base)}
    return out

def _asset_evidence(oos,sym,h):
    return X._asset_evidence(oos,sym,h)

def _evidence_alpha(ev):
    sample=min(1.0,max(0.0,float(ev.get("n_eff",0))/30.0))
    bs=float(ev.get("brier_skill",-999)); ece=float(ev.get("ece",1.0))
    skill=1.0 if bs>0 and ece<=.15 else .5 if bs>-2 and ece<=.20 else .25
    return sample*skill

def _ood_alpha(familiarity):
    # 70+ is fully familiar; very low familiarity never gets more than 25% conviction.
    return float(np.clip(float(familiarity)/70.0,LOCKED_CONFIG["ood_familiarity_floor"],1.0))

def _agreement_alpha(disagreement):
    scale=LOCKED_CONFIG["expert_disagreement_scale"]
    return float(max(.35,1-min(.65,float(disagreement)/scale*.65)))

def run_horizon(panel,targets,horizon):
    ph=X.add_target(panel,targets,horizon)
    oos,cols=walkforward(ph,horizon)
    result={"horizon":int(horizon),"version":VERSION,
            "prospective_holdout_start":str(PROSPECTIVE_HOLDOUT_START.date()),
            "holdout_used_for_tuning":False}
    if oos.empty:
        result["error"]="insufficient development OOS"; return result

    # Strict time-split calibration check.
    ud=np.array(sorted(pd.unique(oos.date)))
    cut=ud[max(1,int(len(ud)*.60))-1]
    early=oos[(oos.date<=cut)&(oos.label_end<=cut)]; late=oos[oos.date>cut].copy()
    cal_check=X._fit_platt(early.p,early.y)
    late_cal=X._apply_platt(cal_check,late.p) if len(late) else np.array([])

    # Live calibrator may use every PRE-HOLDOUT OOS row, never holdout.
    live_cal=X._fit_platt(oos.p,oos.y)

    frozen=ph[(pd.to_datetime(ph.date)<PROSPECTIVE_HOLDOUT_START)&
              (pd.to_datetime(ph.label_end)<PROSPECTIVE_HOLDOUT_START)&ph.y.notna()].copy()
    model=RegimeMoE(cols).fit(
        frozen[cols].to_numpy(float),frozen.y.to_numpy(float),
        frozen[["expert_class","risk_regime","risk_score"]],
        dates=frozen["date"].to_numpy(), label_ends=frozen["label_end"].to_numpy()
    )

    live=[]
    for sym,g in ph.groupby("symbol"):
        r=g.sort_values("date").iloc[-1]
        comp=model.proba_components(
            r[cols].to_numpy(float).reshape(1,-1),
            pd.DataFrame([{"expert_class":r.expert_class,"risk_regime":r.risk_regime,"risk_score":float(r.risk_score)}])
        )[0]
        raw=float(comp["p"])
        cal=float(X._apply_platt(live_cal,np.array([raw]))[0])
        ev=_asset_evidence(oos,sym,horizon)
        ae=_evidence_alpha(ev); ao=_ood_alpha(comp["regime_familiarity"]); aa=_agreement_alpha(comp["expert_disagreement"])
        total=ae*ao*aa
        final=float(np.clip(.5+total*(cal-.5),.05,.95))
        live.append({
            "symbol":sym,"date":str(pd.Timestamp(r.date).date()),
            "raw_moe_p_up":round(raw,4),"calibrated_p_up":round(cal,4),
            "final_research_p_up":round(final,4),
            "total_shrink_alpha":round(total,3),
            "evidence_alpha":round(ae,3),"ood_alpha":round(ao,3),"agreement_alpha":round(aa,3),
            "regime_familiarity":round(comp["regime_familiarity"],1),
            "expert_disagreement":round(comp["expert_disagreement"],4),
            "risk_regime":comp["risk_regime"],"expert_class":comp["expert_class"],"risk_score":round(float(comp.get("risk_score") or 0.0),4),
            "global_p_up":round(comp["global_p"],4),
            "class_p_up":None if comp["class_p"] is None else round(comp["class_p"],4),
            "regime_p_up":None if comp["regime_p"] is None else round(comp["regime_p"],4),
            "development_evidence":ev,
        })

    imp=np.asarray(model.importance(),float)
    order=np.argsort(imp)[::-1][:12]
    top=[{"feature":str(cols[i]),"importance":round(float(imp[i]),6)} for i in order]
    result.update({
        "locked_config":LOCKED_CONFIG,
        "internal_moe_routing":{"version":"regime-moe-weights-v4.40.10","weights":dict(model.weights),"selection":dict(model.weight_selection)},
        "development_rows":int(len(oos)),"development_global_dates":int(oos.date.nunique()),
        "development":X._metric(oos.p,oos.y,oos.base),
        "regime_development":_regime_metrics(oos),
        "cluster_date_bootstrap":X._cluster_block_bootstrap(oos,horizon,n_boot=500,seed=737),
        "calibration_check":{
            "fit_last_date":str(pd.Timestamp(cut).date()),
            "evaluation_first_date":None if late.empty else str(pd.Timestamp(late.date.min()).date()),
            "raw":X._metric(late.p,late.y,late.base) if len(late) else {},
            "platt":X._metric(late_cal,late.y,late.base) if len(late) else {},
        },
        "top_features_frozen":top,
        "frozen_train_rows":int(len(frozen)),
        "frozen_train_max_label_end":str(pd.Timestamp(frozen.label_end.max()).date()),
        "live":live,
    })

    # Prospective holdout evaluation is frozen and automatically activates after new data arrives.
    hold=ph[pd.to_datetime(ph.date)>=PROSPECTIVE_HOLDOUT_START].dropna(subset=["y","label_end"]).copy()
    hi={"status":"awaiting_new_data" if hold.empty else "accumulating_frozen_holdout",
        "n_realized_rows":int(len(hold)),"n_global_dates":int(hold.date.nunique()) if len(hold) else 0,
        "used_for_tuning":False,"frozen_model":True}
    if not hold.empty:
        comps=model.proba_components(hold[cols].to_numpy(float),hold[["expert_class","risk_regime","risk_score"]])
        raw=np.asarray([c["p"] for c in comps],float)
        cal=X._apply_platt(live_cal,raw)
        final=[]
        for pp,c,sym in zip(cal,comps,hold.symbol):
            ev=_asset_evidence(oos,sym,horizon)
            total=_evidence_alpha(ev)*_ood_alpha(c["regime_familiarity"])*_agreement_alpha(c["expert_disagreement"])
            final.append(float(np.clip(.5+total*(float(pp)-.5),.05,.95)))
        base=_baseline(frozen,hold)
        htmp=pd.DataFrame({"date":pd.to_datetime(hold.date),"symbol":hold.symbol.to_numpy(),
                           "y":hold.y.to_numpy(float),"p":np.asarray(final,float),"base":base})
        hi.update({
            "first_date":str(pd.Timestamp(hold.date.min()).date()),
            "last_date":str(pd.Timestamp(hold.date.max()).date()),
            "raw_moe":X._metric(raw,hold.y,base),
            "calibrated":X._metric(cal,hold.y,base),
            "final_research":X._metric(final,hold.y,base),
            "cluster_date_bootstrap":X._cluster_block_bootstrap(htmp,horizon,n_boot=500,seed=973),
        })
    result["prospective_holdout"]=hi
    return result

def run_all(con):
    base,targets,meta=X.build_base_panel(con)
    panel=add_regime_features(base)
    meta=dict(meta)
    meta.update({
        "regime_features_point_in_time":True,
        "regime_thresholds_expanding_and_shifted":True,
        "ood_reference_pre_holdout_only":True,
        "architecture":"global + asset-class + risk-regime logistic experts",
    })
    return {
        "version":"3.7","model_version":VERSION,
        "feature_version":FEATURE_VERSION,"validation_version":VALIDATION_VERSION,
        "prospective_holdout_start":str(PROSPECTIVE_HOLDOUT_START.date()),
        "data_meta":meta,
        "horizons":[run_horizon(panel,targets,h) for h in HORIZONS],
        "decision":{
            "production_champion":"logreg-v3.2.0","action":"retain",
            "reason":"Regime MoE is a new shadow challenger; prospective post-2026-09-08 holdout is required before any promotion."
        }
    }
