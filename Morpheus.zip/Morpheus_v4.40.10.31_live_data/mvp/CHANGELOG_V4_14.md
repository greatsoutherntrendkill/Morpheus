# Morpheus v4.14 — Live 30s + Asset-valid News

- Markets: favourite star is separated from the instrument title; titles are larger and brighter.
- Quotes: visible-tab auto refresh every 30 seconds; backend quote TTL lowered to 30 seconds.
- News: visible-tab auto refresh every 30 seconds; backend news TTL lowered to 30 seconds; manual refresh can force provider refresh.
- Overview / next event: fixed dominant probability card contrast in Signal theme.
- Overview / dynamics: added asset selector directly to the chart; chart and asset-news panel stay synchronized.
- Overview / asset events: strict asset relevance ranking based on direct affected symbols, linked benchmark groups and explicit macro drivers; generic regional news is excluded.
- Overview / dynamics row now spans the full page width and gives the news panel substantially more horizontal space.
- Sidebar: removed the `РАЗДЕЛЫ` label and re-fit the Morpheus brand so it stays inside the Signal glass sidebar.
