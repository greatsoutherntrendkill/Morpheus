"""Explicit daily observation-time contracts; never infer label ends from calendar days.

Date-only prices mean end-of-session decisions, not intraday publication times.
Historical audit windows are development data. The new sealed prospective window
is fixed across assets and runs, and cannot be claimed as completed validation.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import os
import tempfile
import numpy as np
import pandas as pd

VERSION = 'temporal-validation-v4.40.10.12'
SEALED_START = pd.Timestamp('2026-09-18')
META = ['date', 'feature_available_at', 'label_end']


def timeline(index, horizon):
    dates = pd.DatetimeIndex(pd.to_datetime(index))
    if not dates.is_monotonic_increasing or dates.has_duplicates:
        raise ValueError('Observation dates must be unique and increasing')
    h = int(horizon)
    if h < 1: raise ValueError('Horizon must be positive')
    return pd.DataFrame({'date': dates, 'feature_available_at': dates,
                         'label_end': pd.Series(dates, index=dates).shift(-h)}, index=dates)


def attach(frame, index, horizon):
    out = frame.copy()
    clock = timeline(index, horizon).reindex(out.index)
    for col in META: out[col] = clock[col]
    return out


def legal(frame, as_of=None):
    """Fail closed for unknown availability, unresolved targets, or sealed labels."""
    if not all(c in frame for c in META):
        return frame.iloc[:0].copy()
    d = frame.copy()
    d.index=d.index.rename(None)  # Providers often name both index and column "date".
    for c in META: d[c] = pd.to_datetime(d[c], errors='coerce', utc=True).dt.tz_localize(None)
    ok = d[META].notna().all(axis=1)
    ok &= (d.feature_available_at <= d.date) & (d.label_end > d.date)
    ok &= d.label_end < SEALED_START
    if as_of is not None:
        now = pd.Timestamp(as_of)
        if now.tzinfo: now = now.tz_convert('UTC').tz_localize(None)
        ok &= d.label_end < now
    # Revisions of the same origin/asset are not independent samples.
    keys = ['date'] + (['symbol'] if 'symbol' in d else [])
    return d.loc[ok].sort_values(keys, kind='stable').drop_duplicates(keys, keep='first')


def before(frame, boundary):
    b = pd.Timestamp(boundary)
    return frame[(frame.date < b) & (frame.label_end < b)].copy()


def split(frame, fractions=(.6, .8), min_counts=(40, 15, 15)):
    """Date groups stay together across assets. Purge actual outcome intervals."""
    d = legal(frame)
    if d.empty: return None
    dates = pd.DatetimeIndex(d.date.unique()).sort_values()
    cuts = [dates[min(len(dates)-1, max(1, int(len(dates)*f)))] for f in fractions]
    if len(set(cuts)) != len(cuts): return None
    chunks = []
    left = None
    for right in cuts + [None]:
        part = d if left is None else d[d.date >= left]
        if right is not None: part = before(part, right)
        chunks.append(part.copy()); left = right
    if any(len(c) < n for c,n in zip(chunks,min_counts)): return None
    for a,b in zip(chunks,chunks[1:]):
        assert a.label_end.max() < b.date.min()
        assert set(a.date).isdisjoint(set(b.date))
    report = manifest(chunks)
    for c in chunks: c.attrs['temporal_split'] = report
    return tuple(chunks)


def manifest(chunks):
    bounds = [{'rows':len(c), 'origin_start':str(c.date.min()), 'origin_end':str(c.date.max()),
               'feature_available_max':str(c.feature_available_at.max()),
               'target_end_max':str(c.label_end.max()),
               'date_groups':int(c.date.nunique())} for c in chunks]
    assignments=[]
    for i,c in enumerate(chunks):
        cols=META+(['symbol'] if 'symbol' in c else [])
        for row in c[cols].astype(str).to_dict('records'):assignments.append({'partition':i,**row})
    payload={'version':VERSION,'boundaries':bounds,'samples':assignments}
    encoded=json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()
    digest=hashlib.sha256(encoded).hexdigest()
    stored=False
    try:
        from persistent_state_v44010 import data_root
        root=data_root()/'temporal_manifests';root.mkdir(parents=True,exist_ok=True)
        dest=root/(digest+'.json')
        if not dest.exists():
            with tempfile.NamedTemporaryFile(dir=root,delete=False) as f:
                f.write(encoded);tmp=f.name
            os.replace(tmp,dest)
        stored=True
    except OSError:
        pass  # Forecast remains research-only; never fabricate an audit file.
    return {'version':VERSION,'scope':'development_only','boundaries':bounds,
            'strict_label_end_purge':True,'date_grouped':True,'boundary_fingerprint':digest,
            'sample_manifest':digest+'.json','sample_manifest_saved':stored,
            'sealed_start':str(SEALED_START.date()),'final_validation_passed':False}


def records(rows):
    """Legacy OOS records without availability metadata cannot train a router."""
    if not rows: return pd.DataFrame()
    return legal(pd.DataFrame(rows))


def collect_manifests(value):
    out = []
    def visit(x, path='forecast'):
        if isinstance(x,dict):
            m=x.get('temporal_split')
            if isinstance(m,dict):out.append({'component':path,**m})
            for k,v in x.items():
                if k!='temporal_split':visit(v,path+'.'+str(k))
        elif isinstance(x,list):
            for i,v in enumerate(x):visit(v,path+'.'+str(i))
    visit(value)
    return out
