# Model governance v3.2

The registry is immutable: changing code/features means a new model version, never editing an old row.
The prediction ledger records what the model knew and predicted at the data cutoff. Realized outcomes are attached later once and do not rewrite the original forecast.

## Champion/challenger
The current custom Logistic Regression is champion `logreg-v3.2.0`. A challenger may be evaluated but cannot silently replace it. LightGBM/CatBoost belong in the next step.

Promotion requires locked evidence: sufficient effective sample size, positive lower confidence bounds on final-holdout edge and Brier skill, plus economic value after costs/slippage/turnover. Final holdout is not used for tuning.
