
from __future__ import annotations
import csv, json
from datetime import datetime, timezone
from pathlib import Path
import db
import model_registry as MR
import cross_asset_models as X

ROOT=Path(__file__).parent
OUT=ROOT/"site"/"cross_asset_v36.json"
CSV=ROOT/"cross_asset_v36.csv"

def _register(con):
    notes="v3.6 pooled cross-asset research challenger; prospective holdout starts after packaged data cutoff"
    for name,ver in X.MODEL_VERSIONS.items():
        family="pooled_logistic_regression" if name=="pooled_logistic" else "pooled_lightgbm"
        MR.register_challenger(
            con,ver,family,X.FEATURE_VERSION,X.LOCKED_CONFIGS[name],notes,
            validation_version=X.VALIDATION_VERSION
        )

def _merge_site(payload):
    p=ROOT/"site"/"data.json"
    if not p.exists(): return
    data=json.loads(p.read_text(encoding="utf-8"))
    lookup={}
    for hrow in payload["horizons"]:
        h=str(hrow["horizon"])
        for name,m in hrow["models"].items():
            for r in m.get("live") or []:
                lookup.setdefault(r["symbol"],{})[h]={
                    "model":name,"version":m.get("version"),
                    **r,
                    "prospective_holdout":m.get("prospective_holdout"),
                    "cluster_date_bootstrap":m.get("cluster_date_bootstrap"),
                    "calibration_check":m.get("calibration_check"),
                    "top_features_frozen":m.get("top_features_frozen"),
                } if name=="pooled_lightgbm" else lookup.setdefault(r["symbol"],{}).get(h,{})
    # Preserve both research models under each horizon.
    by={}
    for hrow in payload["horizons"]:
        h=str(hrow["horizon"])
        for name,m in hrow["models"].items():
            for r in m.get("live") or []:
                by.setdefault(r["symbol"],{}).setdefault(h,{})[name]={
                    "version":m.get("version"),**r,
                    "prospective_holdout":m.get("prospective_holdout"),
                    "cluster_date_bootstrap":m.get("cluster_date_bootstrap"),
                    "calibration_check":m.get("calibration_check"),
                    "top_features_frozen":m.get("top_features_frozen"),
                    "development":m.get("development"),
                }
    for a in data.get("assets",[]):
        a["cross_asset_v36"]=by.get(a.get("symbol"),{})
    data["cross_asset_version"]="3.6"
    data["cross_asset_prospective_holdout_start"]=payload["prospective_holdout_start"]
    p.write_text(json.dumps(data,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
    (ROOT/"site"/"data.js").write_text("window.FORECASTS = "+json.dumps(data,ensure_ascii=False,separators=(",",":"))+";\n",encoding="utf-8")

def main():
    con=db.connect()
    try:
        _register(con)
        payload=X.run_all(con)
        payload["generated_at"]=datetime.now(timezone.utc).replace(microsecond=0).isoformat()

        # Immutable research predictions for both pooled models.
        macro={"feature_version":X.FEATURE_VERSION,"cross_market_lag":"1d","prospective_holdout_start":payload["prospective_holdout_start"]}
        rows=[]
        for hrow in payload["horizons"]:
            h=hrow["horizon"]
            for name,m in hrow["models"].items():
                ver=m.get("version")
                for r in m.get("live") or []:
                    p=float(r["evidence_shrunk_p_up"])
                    status="pre-holdout/research" if r["date"] < payload["prospective_holdout_start"] else "prospective-holdout/frozen"
                    pid=MR.append_prediction_for_model(
                        con,ver,X.FEATURE_VERSION,r["symbol"],h,r["date"],p,
                        quality={"research":True,"raw_p_up":r["raw_p_up"],
                                 "calibrated_p_up":r["calibrated_p_up"],
                                 "shrink_alpha":r["shrink_alpha"]},
                        macro_provenance=macro,holdout_status=status
                    )
                    rows.append({
                        "model":name,"model_version":ver,"symbol":r["symbol"],"horizon":h,
                        "date":r["date"],"raw_p_up":r["raw_p_up"],
                        "calibrated_p_up":r["calibrated_p_up"],
                        "evidence_shrunk_p_up":r["evidence_shrunk_p_up"],
                        "shrink_alpha":r["shrink_alpha"],
                        "n_eff":r["development_evidence"].get("n_eff"),
                        "prediction_id":pid,
                    })

        OUT.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
        if rows:
            with CSV.open("w",newline="",encoding="utf-8") as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]))
                w.writeheader(); w.writerows(rows)
        _merge_site(payload)
        print(json.dumps({
            "version":"3.6","assets":payload["data_meta"]["symbols"].__len__(),
            "horizons":len(payload["horizons"]),"prediction_rows":len(rows),
            "prospective_holdout_start":payload["prospective_holdout_start"],
            "decision":payload["decision"],
        },ensure_ascii=False,indent=2))
    finally:
        con.close()

if __name__=="__main__":
    main()
