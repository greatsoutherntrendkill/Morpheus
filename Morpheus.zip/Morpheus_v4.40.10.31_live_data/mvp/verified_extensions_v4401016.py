"""Price-feature ablation and point-in-time contracts for research extensions.
Research switches are context-local, only legal inside historical replay. No
source is promoted from this retrospective experiment. Live quantile features
remain own-price-only until independent source-specific evidence is available.
"""
from contextlib import contextmanager
from contextvars import ContextVar
import math
import numpy as np
import pandas as pd
import evaluation_clock_v4401014 as CLOCK
import data_contract_v4401013 as DATA
VERSION='verified-extensions-v4.40.10.16'
GROUPS={'momentum':('r1','mom5','mom20','mom60'),'volatility':('vol20','vol60','vol_ratio'),'trend':('dist_ma50','dist_ma200')}
OWN_DISTRIBUTION={*[f'ret_{n}' for n in (1,3,5,7,20,60)],*[f'vol_{n}' for n in (10,20,60)],'ma20_gap','ma60_gap'}
_VARIANT=ContextVar('feature_experiment',default=None)

@contextmanager
def experiment(variant='baseline',factor=None):
 if not CLOCK.active():raise RuntimeError('Research feature switches require a historical evaluation clock')
 if variant not in ('baseline','without_momentum','without_volatility','without_trend','plus_market'):raise ValueError('unknown experiment')
 token=_VARIANT.set((variant,factor))
 try:yield
 finally:_VARIANT.reset(token)

def core_features(frame):
 state=_VARIANT.get()
 if state is None:return frame
 if not CLOCK.active():raise RuntimeError('research switch leaked into live forecast')
 variant,factor=state;out=frame.copy()
 if variant.startswith('without_'):out=out.drop(columns=list(GROUPS[variant[8:]]),errors='ignore')
 if variant=='plus_market':
  if factor is None:raise ValueError('missing external source; no fabricated zero feature')
  out['research_market_ret20']=factor.reindex(out.index)
 # Keep the same 200-observation warm-up for all variants; removing MA200 must
 # not accidentally give a candidate more training dates than the reference.
 out.iloc[:min(199,len(out))]=np.nan
 out.attrs.update(frame.attrs);out.attrs['research_variant']=variant
 return out

def distribution_features(frame,diag):
 excluded=[c for c in frame if c not in OWN_DISTRIBUTION]
 result=frame[[c for c in frame if c in OWN_DISTRIBUTION]].copy()
 return result,{**diag,'extension_policy':VERSION,'excluded_external_features':excluded,
   'external_features_active':False,'external_reason':'Межрыночные признаки не допущены к рабочему диапазону: отдельное преимущество и архив доступности не подтверждены.'}

def timestamp(value):
 t=pd.Timestamp(value)
 if pd.isna(t):raise ValueError('missing timestamp')
 if t.tzinfo is None:raise ValueError('explicit timezone required')
 return t.tz_convert('UTC')

def align_observations(records,decision_times,max_age_days=7):
 """Use only observations actually available by each decision, never backfill.
 Each record needs observed_at, available_at, value. Corrections need their own
 available_at. Age refers to observation time, not the correction delivery time.
 """
 parsed=[];rejected=0
 for row in records:
  try:
   observed=timestamp(row['observed_at']);available=timestamp(row['available_at']);value=float(row['value'])
   if available<observed or not math.isfinite(value):raise ValueError('invalid availability')
   parsed.append((observed,available,value))
  except (KeyError,ValueError,TypeError):rejected+=1
 # Conflicting values with the same observation and availability timestamp
 # have no defensible ordering. Exclude the entire ambiguous pair.
 values_by_key={}
 for observed,available,value in parsed:values_by_key.setdefault((observed,available),set()).add(value)
 ambiguous={key for key,values in values_by_key.items() if len(values)>1}
 rejected+=sum((o,a) in ambiguous for o,a,v in parsed)
 parsed=[r for r in parsed if r[:2] not in ambiguous]
 values=[]
 for decision in decision_times:
  t=timestamp(decision);known=[r for r in parsed if r[1]<=t and r[0]<=t and (t-r[0]).total_seconds()<=max_age_days*86400]
  # A late revision to an old observation must not replace a newer observation.
  known.sort(key=lambda x:(x[0],x[1]));values.append(known[-1][2] if known else np.nan)
 return pd.Series(values,index=pd.DatetimeIndex(decision_times),dtype=float),{'accepted':len(parsed),'rejected':rejected,'missing':int(pd.isna(values).sum())}

def historical_market_factor(close,source_symbol,target_index,target_symbol):
 """Diagnostic alignment of archived closes, NOT proof of first-seen vintages."""
 c=pd.Series(close,dtype=float).sort_index();ret=np.log(c/c.shift(20));records=[]
 for d,v in ret.dropna().items():
  observed=DATA.session_close(source_symbol,d)
  if pd.isna(observed):continue
  records.append({'observed_at':observed,'available_at':observed+pd.Timedelta(minutes=1),'value':float(v)})
 decisions=[DATA.session_close(target_symbol,d)+pd.Timedelta(minutes=2) for d in target_index]
 aligned,audit=align_observations(records,decisions)
 aligned.index=target_index
 audit.update(source=source_symbol,point_in_time_archive_verified=False,availability='scheduled source close + 1 minute; actual delivery archive absent',use='research_only')
 return aligned,audit

def event_surprise(event,as_of):
 """Raw surprise in the published unit; no sign/size-to-price heuristic."""
 try:
  t=timestamp(as_of);release=timestamp(event['released_at']);seen=timestamp(event['first_available_at']);cons=timestamp(event['consensus_available_at'])
  if cons>=release:return {'available':False,'reason':'Ожидание не зафиксировано до публикации'}
  if seen<release or max(seen,release)>t:return {'available':False,'reason':'Первичная публикация ещё не была доступна'}
  if event.get('is_initial_release') is not True or not event.get('source') or not event.get('unit'):return {'available':False,'reason':'Нет подтверждённой первичной публикации, источника или единицы'}
  actual=float(event['initial_actual']);expected=float(event['consensus'])
  if not math.isfinite(actual) or not math.isfinite(expected):raise ValueError()
  return {'available':True,'surprise':actual-expected,'unit':event['unit'],'direction_adjustment_pp':0,'use':'research_only'}
 except (KeyError,TypeError,ValueError):return {'available':False,'reason':'Нет архива ожиданий и времени первичной публикации'}

def policy():
 return {'version':VERSION,'automatic_promotion':False,'new_sources_active':False,
  'price_groups':list(GROUPS),'sources':[
   {'id':'own_price','name':'Цена самого инструмента','status':'Действующая основа','use':'Направление и масштаб; преимущество всей модели пока не подтверждено'},
   {'id':'cross_market','name':'Другие рынки','status':'Исследование','use':'Сравнение по одному источнику; рабочие диапазоны не используют неподтверждённые внешние признаки'},
   {'id':'macro','name':'Макропубликации и ожидания','status':'Нужен архив','use':'Нужны первичные значения, ожидания до выпуска и время доступности; направление цены не назначается вручную'},
   {'id':'politics','name':'Политические новости','status':'Только риск','use':'Не являются доказанным сигналом роста или падения'},
   {'id':'orderbook','name':'Стакан заявок','status':'Не подключён','use':'Нет согласованного исторического архива по площадкам и инструментам'}],
  'admission_requirements':['Зафиксированный до проверки протокол и неизменная выборка','Парное сравнение с ценовой основой','Улучшение на нескольких непересекающихся периодах','Поправка на несколько проверяемых источников','Архив фактического времени доступности и пересмотров','Будущие выпуски, не использованные при разработке','Отдельное решение о допуске; автоматическое включение запрещено']}
