# v3.1 — Revision-Aware PIT + Frozen Final Holdout

- ALFRED revision-history ingestion (`output_type=3`) with JSON pagination.
- `is_initial` inferred per observation; later events are explicit revisions.
- Macro feature state reconstructed through time instead of back-filling revisions.
- Observation-date YoY and ~3-month change derived from the reconstructed vintage state.
- New SQLite `macro_release` table.
- Publisher-aware release timestamp metadata for major BLS/BEA/Fed releases.
- Fixed final holdout (`FINAL_HOLDOUT_START=2026-04-01`).
- Holdout model and baseline frozen before the holdout boundary.
- Holdout excluded from `quality_gate`.
- Holdout metrics exposed per horizon and in asset Model Quality UI.
- Added regression tests for revision timing, official clock metadata and holdout freezing.
