# Model roadmap after v4.39

Следующий логичный этап — **v4.40 Distributional Forecast & Expected Move**.

План:
- прогноз не только направления, но и распределения доходности;
- quantile forecasts / prediction intervals;
- volatility-conditional expected move;
- asymmetric upside/downside tails;
- options implied move как внешний benchmark там, где он реально доступен;
- calibration coverage для интервалов;
- prospective scoring не только Brier, но и interval coverage / pinball loss / CRPS-подобные метрики;
- никакого автоматического повышения веса без prospective validation.
