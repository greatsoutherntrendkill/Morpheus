# Model audit — v4.40.9

Scope: four known correctness issues identified after v4.40.8. No v4.40.10 solver/regularization or sealed-shadow work is included.

## Closed findings

1. **Soft regime input omission — CLOSED.** `risk_score` is now supplied to `RegimeMoE.proba_components()` in development OOS, frozen live, and holdout paths.
2. **Unqualified distribution veto — CLOSED.** Distribution consistency is diagnostic-only unless distribution quality and effective-N requirements pass.
3. **Zero-weight challenger side effects — CLOSED.** Asset/Event challengers with `weight=0` cannot change any production decision field.
4. **Unlimited forward fill / invisible stale factors — CLOSED.** Market and macro feature carries are bounded and source freshness is explicit and consumed by the live robustness guard.

## Explicitly deferred

- v4.40.10 champion solver / regularization selection;
- data-driven internal RegimeMoE expert weights;
- persistent event/governance store;
- sealed shadow benchmark.
