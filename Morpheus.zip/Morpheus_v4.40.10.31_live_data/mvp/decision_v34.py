
"""Morpheus v3.4 final model-selection decision.

Consumes the locked full-universe benchmark and produces an explicit governance
decision. The script never changes a model because of a single point estimate.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import numpy as np
import db
import model_registry as MR

ROOT=Path(__file__).parent
BENCH=ROOT/"site"/"model_benchmark_v34.json"
OUT_JSON=ROOT/"site"/"model_decision_v34.json"
OUT_MD=ROOT/"MODEL_DECISION_V3_4.md"

MODELS=("logistic_regression","lightgbm","catboost")


def _med(xs):
    xs=[float(x) for x in xs if x is not None and np.isfinite(float(x))]
    return None if not xs else float(np.median(xs))


def summarize(payload):
    rows=payload.get("rows") or []
    assets=sorted({r.get("symbol") for r in rows if r.get("symbol")})
    summary={}
    for model in MODELS:
        hold_brier=[]; hold_ece=[]; cal_brier=[]; cal_ece=[]; net_sharpe=[]
        top_features=Counter(); concentration=[]
        for r in rows:
            m=((r.get("models") or {}).get(model) or {})
            h=m.get("holdout") or {}
            hc=m.get("holdout_calibrated") or {}
            econ=m.get("holdout_economic") or {}
            if h.get("brier") is not None: hold_brier.append(h["brier"])
            if h.get("ece") is not None: hold_ece.append(h["ece"])
            if hc.get("brier") is not None: cal_brier.append(hc["brier"])
            if hc.get("ece") is not None: cal_ece.append(hc["ece"])
            if econ.get("net_sharpe") is not None: net_sharpe.append(econ["net_sharpe"])
            tf=m.get("top_features_frozen") or []
            if tf:
                top_features[tf[0].get("feature")]+=1
                concentration.append(tf[0].get("importance"))
        summary[model]={
            "holdout_tests":len(hold_brier),
            "median_holdout_brier":_med(hold_brier),
            "median_holdout_ece":_med(hold_ece),
            "median_platt_holdout_brier":_med(cal_brier),
            "median_platt_holdout_ece":_med(cal_ece),
            "median_1d_net_sharpe":_med(net_sharpe),
            "top_feature_frequency":top_features.most_common(8),
            "median_top_feature_concentration":_med(concentration),
        }

    promo=(payload.get("promotion") or {}).get("challengers") or {}
    # Manual-review stage: respect the predeclared gate first.
    eligible=[m for m in ("lightgbm","catboost")
              if (promo.get(m) or {}).get("eligible_for_manual_promotion_review")]

    reasons=[]
    decision="retain"
    selected="logistic_regression"
    selected_version=payload.get("champion","logreg-v3.2.0")

    if not eligible:
        reasons.append("No challenger passed the predeclared full-universe promotion-review gate.")
    elif len(eligible)==1:
        c=eligible[0]
        # Extra reviewer checks. Calibration cannot rescue economic-value failure.
        s=summary[c]; cs=summary["logistic_regression"]
        cal_ok=(s["median_platt_holdout_ece"] is not None and
                cs["median_holdout_ece"] is not None and
                s["median_platt_holdout_ece"] <= cs["median_holdout_ece"] + 0.02)
        econ_delta=(None if s["median_1d_net_sharpe"] is None or cs["median_1d_net_sharpe"] is None
                    else s["median_1d_net_sharpe"]-cs["median_1d_net_sharpe"])
        econ_ok=econ_delta is not None and econ_delta>0.10
        if cal_ok and econ_ok:
            decision="promote"
            selected=c
            selected_version=(payload.get("challengers") or {}).get(c)
            reasons.append(f"{c} passed the locked statistical gate, calibration review and economic-value review.")
        else:
            reasons.append(f"{c} reached manual review but failed the final calibration/economic reviewer checks.")
    else:
        # If both pass, choose by median holdout Brier only after both have passed every gate.
        candidates=[]
        cs=summary["logistic_regression"]
        for c in eligible:
            s=summary[c]
            econ_delta=(None if s["median_1d_net_sharpe"] is None or cs["median_1d_net_sharpe"] is None
                        else s["median_1d_net_sharpe"]-cs["median_1d_net_sharpe"])
            cal_ok=(s["median_platt_holdout_ece"] is not None and
                    cs["median_holdout_ece"] is not None and
                    s["median_platt_holdout_ece"] <= cs["median_holdout_ece"] + 0.02)
            if econ_delta is not None and econ_delta>0.10 and cal_ok:
                candidates.append(c)
        if candidates:
            selected=min(candidates,key=lambda c: summary[c]["median_holdout_brier"])
            selected_version=(payload.get("challengers") or {}).get(selected)
            decision="promote"
            reasons.append(f"{selected} won the final reviewer tie-break after both challengers passed the locked gate.")
        else:
            reasons.append("Challengers reached review but none passed the final calibration/economic reviewer checks.")

    # Add evidence-focused explanation.
    for c in ("lightgbm","catboost"):
        pr=promo.get(c) or {}
        reasons.append(
            f"{c}: {pr.get('holm_significant_brier_wins',0)} Holm-significant Brier wins, "
            f"{pr.get('holm_significant_brier_losses',0)} significant losses, "
            f"median Brier improvement={pr.get('median_brier_improvement')}, "
            f"median 1D net-Sharpe delta={pr.get('median_1d_net_sharpe_delta')}."
        )

    return {
        "version":"3.4",
        "decided_at":datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "benchmark_generated_at":payload.get("generated_at"),
        "full_universe_assets":len(assets),
        "benchmark_rows":len(rows),
        "horizons":sorted({int(r["horizon"]) for r in rows if r.get("horizon") is not None}),
        "decision":decision,
        "selected_model":selected,
        "selected_version":selected_version,
        "previous_champion":payload.get("champion"),
        "automatic_promotion":False,
        "reviewer_decision_recorded":True,
        "summary":summary,
        "promotion_gate":promo,
        "reasons":reasons,
    }


def markdown(d):
    name={"logistic_regression":"Logistic Regression","lightgbm":"LightGBM","catboost":"CatBoost"}
    action=("KEEP Logistic Regression as production champion"
            if d["decision"]=="retain"
            else f"PROMOTE {name[d['selected_model']]} to production champion")
    lines=[
        "# Morpheus v3.4 — Final Model Decision","",
        f"## Decision: {action}","",
        f"- Selected version: `{d['selected_version']}`",
        f"- Full-universe assets tested: {d['full_universe_assets']}",
        f"- Asset/horizon benchmark rows: {d['benchmark_rows']}",
        f"- Horizons: {', '.join(map(str,d['horizons']))} trading days",
        "- Final holdout used for tuning: **No**",
        "- Multiple-testing correction: **Holm-Bonferroni**",
        "- Promotion is never automatic: **Yes**","",
        "## Aggregate holdout diagnostics","",
        "| Model | Median Brier | Median ECE | Platt Brier | Platt ECE | Median 1D net Sharpe |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    def f(x):
        return "—" if x is None else f"{x:.4f}"
    for m in MODELS:
        s=d["summary"][m]
        lines.append(f"| {name[m]} | {f(s['median_holdout_brier'])} | {f(s['median_holdout_ece'])} | "
                     f"{f(s['median_platt_holdout_brier'])} | {f(s['median_platt_holdout_ece'])} | "
                     f"{f(s['median_1d_net_sharpe'])} |")
    lines += ["","## Why",""]
    lines += [f"- {x}" for x in d["reasons"]]
    lines += ["","## Governance consequence",""]
    if d["decision"]=="retain":
        lines += [
            "The nonlinear models remain **shadow challengers**. Their live predictions continue to be",
            "logged immutably, but public/production model output remains on the Logistic Regression champion.",
            "A future promotion requires a new locked model version and new evidence; this v3.4 holdout is not",
            "to be recycled as a tuning set."
        ]
    else:
        lines += [
            "The selected challenger may be registered as a new immutable champion version.",
            "The old champion remains in the registry for auditability and rollback comparison."
        ]
    return "\n".join(lines)+"\n"


def main():
    if not BENCH.exists():
        raise SystemExit("Run python benchmark_v34.py first.")
    payload=json.loads(BENCH.read_text(encoding="utf-8"))
    d=summarize(payload)
    OUT_JSON.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding="utf-8")
    OUT_MD.write_text(markdown(d),encoding="utf-8")
    con=db.connect()
    try:
        d["decision_id"]=MR.record_model_decision(
            con,"v3.4-full-universe-manual-review",
            d["previous_champion"],d["selected_version"],d["decision"],
            {"benchmark":payload.get("promotion"),"summary":d["summary"],
             "assets":d["full_universe_assets"],"rows":d["benchmark_rows"]},
            " | ".join(d["reasons"]))
        OUT_JSON.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding="utf-8")
    finally:
        con.close()
    print(json.dumps({
        "decision":d["decision"],"selected_model":d["selected_model"],
        "selected_version":d["selected_version"],
        "assets":d["full_universe_assets"],"rows":d["benchmark_rows"],
    },ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
