"""Morpheus v4.34 — cross-sectional and event-aware feature layer.

This module adds context that the single-series forecast could not see in v4.33:

* relative strength versus an asset-class benchmark;
* cross-sectional market breadth and dispersion;
* correlation regime and asset/benchmark co-movement;
* asset-class-specific context (USD, rates/RGBI, commodity or crypto proxies);
* current event risk from the structured central-bank calendar and the news stream;
* feature-drift diagnostics that reduce confidence when the live feature vector is
  far outside its recent point-in-time distribution.

Important design rule
---------------------
Directional context is deliberately low-weight.  It can refine a forecast, but it
cannot turn an unvalidated 50/50 signal into a high-conviction recommendation.
Event risk mostly raises the no-edge threshold / shrinks confidence unless there
is explicit signed evidence for the selected asset.
"""
from __future__ import annotations
import evaluation_clock_v4401014 as EC14

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import json
import math
import sqlite3
from typing import Iterable

import numpy as np
import pandas as pd

import config as C
import market_universe_v416 as MU
import freshness_contract_v4409 as FRESH4409

VERSION = "context-event-features-v4.34.0"
ROOT = Path(__file__).resolve().parent
NEWS_LASTGOOD = ROOT / "runtime_cache" / "news_last_good_v429.json"


@dataclass(frozen=True)
class AssetProfile:
    asset_class: str
    region: str
    benchmark: str | None
    peers: tuple[str, ...]
    context_symbols: tuple[str, ...]


# A small, stable context universe.  All of these symbols are already maintained
# in market.db, so no extra network request is required on the UI critical path.
_US_PEERS = ("^GSPC", "^NDX", "^DJI", "^RUT", "ES=F", "NQ=F")
_RU_PEERS = ("IMOEX", "RTSI", "MOEXBC", "RGBI", "RUB=X", "CL=F")
_EU_PEERS = ("^GDAXI", "^FTSE", "^FCHI", "^STOXX50E", "EURUSD=X")
_ASIA_PEERS = ("^N225", "^HSI", "CNY=X", "JPY=X")
_CRYPTO_PEERS = ("BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD")
_FX_PEERS = ("EURUSD=X", "GBPUSD=X", "JPY=X", "AUDUSD=X", "USDCAD=X", "RUB=X", "CNY=X", "CNYRUB")
_COMMODITY_PEERS = ("GC=F", "SI=F", "CL=F", "NG=F", "HG=F")


def asset_profile(symbol: str) -> AssetProfile:
    s = str(symbol or "").upper()
    if MU.is_us_equity(s):
        return AssetProfile("equity", "US", "^GSPC", _US_PEERS, ("^NDX", "DX-Y.NYB", "ES=F", "NQ=F", "GC=F"))
    if MU.is_ru_equity(s):
        return AssetProfile("equity", "RU", "IMOEX", _RU_PEERS, ("RTSI", "RGBI", "RUB=X", "CL=F", "GC=F"))
    if s in C.MOEX_INDICES:
        return AssetProfile("index", "RU", "IMOEX" if s != "IMOEX" else "RTSI", _RU_PEERS, ("RGBI", "RUB=X", "CL=F"))
    if s in {"^GSPC", "^NDX", "^DJI", "^RUT", "ES=F", "NQ=F", "DX-Y.NYB"}:
        return AssetProfile("index", "US", "^GSPC" if s != "^GSPC" else "^NDX", _US_PEERS, ("DX-Y.NYB", "GC=F", "CL=F"))
    if s in {"^GDAXI", "^FTSE", "^FCHI", "^STOXX50E"}:
        return AssetProfile("index", "EU", "^STOXX50E" if s != "^STOXX50E" else "^GDAXI", _EU_PEERS, ("EURUSD=X", "DX-Y.NYB"))
    if s in {"^N225", "^HSI"}:
        return AssetProfile("index", "ASIA", "^N225" if s != "^N225" else "^HSI", _ASIA_PEERS, ("CNY=X", "JPY=X", "DX-Y.NYB"))
    if s in _CRYPTO_PEERS:
        return AssetProfile("crypto", "GLOBAL", "BTC-USD" if s != "BTC-USD" else "ETH-USD", _CRYPTO_PEERS, ("DX-Y.NYB", "^GSPC", "GC=F"))
    if s in _FX_PEERS:
        bench = "DX-Y.NYB" if s != "DX-Y.NYB" else "EURUSD=X"
        return AssetProfile("fx", "GLOBAL", bench, _FX_PEERS, ("DX-Y.NYB", "RGBI", "^GSPC", "GC=F"))
    if s in _COMMODITY_PEERS:
        bench = "GC=F" if s not in {"GC=F", "SI=F"} else "SI=F"
        return AssetProfile("commodity", "GLOBAL", bench, _COMMODITY_PEERS, ("DX-Y.NYB", "^GSPC", "CL=F", "GC=F"))
    return AssetProfile("other", "GLOBAL", "^GSPC", _US_PEERS, ("DX-Y.NYB", "GC=F", "CL=F"))


def _db_matrix():
    import data_contract_v4401013 as D
    return _db_matrix_cached(D.dependency_fingerprint())


@lru_cache(maxsize=2)
def _db_matrix_cached(revision) -> pd.DataFrame:
    """Close-price matrix from the local market database.

    The matrix is local and point-in-time; no provider call is made from here.
    """
    if not Path(C.DB_PATH).exists():
        return pd.DataFrame()
    try:
        con = sqlite3.connect(str(C.DB_PATH))
        try:
            d = pd.read_sql_query("SELECT symbol,date,close FROM prices ORDER BY date", con)
        finally:
            con.close()
        if d.empty:
            return pd.DataFrame()
        d["date"] = pd.to_datetime(d["date"], errors="coerce")
        d["close"] = pd.to_numeric(d["close"], errors="coerce")
        d = d.dropna(subset=["symbol", "date", "close"])
        return d.pivot_table(index="date", columns="symbol", values="close", aggfunc="last").sort_index()
    except Exception:
        return pd.DataFrame()


def _series(s: pd.Series | None) -> pd.Series:
    if s is None:
        return pd.Series(dtype=float)
    x = pd.Series(s, dtype=float).dropna().sort_index()
    try:
        x.index = pd.to_datetime(x.index)
    except Exception:
        pass
    return x[~x.index.duplicated(keep="last")]


def _ret(s: pd.Series, n: int) -> float | None:
    x = _series(s)
    if len(x) <= n or not float(x.iloc[-1-n]):
        return None
    return float(x.iloc[-1] / x.iloc[-1-n] - 1.0)


def _ann_vol(s: pd.Series, n: int = 20) -> float | None:
    x = _series(s).pct_change().dropna().tail(n)
    if len(x) < max(8, n // 2):
        return None
    v = float(x.std() * math.sqrt(252))
    return v if math.isfinite(v) else None


def _corr(a: pd.Series, b: pd.Series, n: int = 60) -> float | None:
    z = pd.concat([_series(a).pct_change(), _series(b).pct_change()], axis=1).dropna().tail(n)
    if len(z) < max(12, n // 3):
        return None
    c = float(z.iloc[:, 0].corr(z.iloc[:, 1]))
    return c if math.isfinite(c) else None


def _align_own(matrix: pd.DataFrame, own_close: pd.Series | None, symbol: str, as_of=None) -> pd.Series:
    s = _series(own_close)
    if s.empty and symbol in matrix.columns:
        s = matrix[symbol].dropna()
    if as_of is not None and not s.empty:
        s = s.loc[s.index <= pd.Timestamp(as_of)]
    return s


def _peer_matrix(profile: AssetProfile, as_of=None) -> pd.DataFrame:
    m = _db_matrix()
    if m.empty:
        return m
    cols = [s for s in profile.peers if s in m.columns]
    out = m[cols].copy()
    if as_of is not None:
        out = out.loc[out.index <= pd.Timestamp(as_of)]
    return out


def _fresh_market_sources(matrix: pd.DataFrame, symbols, as_of, *, critical=False):
    out = {}
    for sym in symbols:
        if not sym:
            continue
        ser = matrix[sym] if not matrix.empty and sym in matrix.columns else pd.Series(dtype=float)
        out[str(sym)] = FRESH4409.source_meta(
            str(sym), ser, as_of, warning_days=FRESH4409.MARKET_WARNING_DAYS,
            hard_days=FRESH4409.MARKET_HARD_DAYS, critical=critical)
    return out


def _breadth_series(peers: pd.DataFrame, lookback: int = 20) -> pd.Series:
    if peers.empty or len(peers) <= lookback:
        return pd.Series(dtype=float)
    r = peers / peers.shift(lookback) - 1.0
    return (r > 0).sum(axis=1) / r.notna().sum(axis=1).replace(0, np.nan)


def _dispersion_series(peers: pd.DataFrame, lookback: int = 20) -> pd.Series:
    if peers.empty or len(peers) <= lookback:
        return pd.Series(dtype=float)
    r = peers / peers.shift(lookback) - 1.0
    return r.std(axis=1, skipna=True)


def _avg_corr_series(peers: pd.DataFrame, window: int = 40) -> pd.Series:
    if peers.empty or len(peers.columns) < 2 or len(peers) < window:
        return pd.Series(dtype=float)
    ret = peers.pct_change()
    vals = []
    idx = []
    # Only the last ~280 observations are needed for drift diagnostics.
    start = max(window, len(ret) - 280)
    for i in range(start, len(ret) + 1):
        z = ret.iloc[i-window:i].dropna(axis=1, how="all")
        if len(z.columns) < 2:
            continue
        c = z.corr().to_numpy(float)
        tri = c[np.triu_indices_from(c, k=1)]
        tri = tri[np.isfinite(tri)]
        if len(tri):
            vals.append(float(np.mean(tri)))
            idx.append(ret.index[i-1])
    return pd.Series(vals, index=idx, dtype=float)


def _zscore_now(series: pd.Series) -> float | None:
    s = pd.Series(series, dtype=float).dropna()
    if len(s) < 20:
        return None
    hist = s.iloc[:-1].tail(252) if len(s) > 1 else s
    if len(hist) < 20:
        return None
    sd = float(hist.std())
    if not math.isfinite(sd) or sd <= 1e-12:
        return 0.0
    z = (float(s.iloc[-1]) - float(hist.mean())) / sd
    return float(np.clip(z, -6, 6))


def _correlation_regime(avg_corr: float | None) -> str:
    if avg_corr is None:
        return "не определён"
    if avg_corr >= 0.72:
        return "синхронный рынок"
    if avg_corr <= 0.28:
        return "разрозненный рынок"
    return "нормальная корреляция"


def _coverage(vals: Iterable[object]) -> float:
    vals = list(vals)
    if not vals:
        return 0.0
    ok = 0
    for x in vals:
        try:
            ok += int(x is not None and math.isfinite(float(x)))
        except Exception:
            ok += int(bool(x))
    return float(ok / len(vals))


def cross_sectional_snapshot(symbol: str, own_close: pd.Series | None = None, as_of=None) -> dict:
    """Build a live, point-in-time cross-sectional feature bundle.

    v4.40.9 applies the same freshness contract to every live market source used
    by this context expert. Hard-stale benchmark/peer/context series are excluded
    instead of being silently treated as current observations.
    """
    s = str(symbol or "").upper()
    profile = asset_profile(s)
    matrix = _db_matrix()
    own = _align_own(matrix, own_close, s, as_of)
    ref = pd.Timestamp(as_of) if as_of is not None else (own.index[-1] if not own.empty else (matrix.index[-1] if not matrix.empty else pd.Timestamp.utcnow().tz_localize(None)))
    source_meta = {}
    source_meta["own"] = FRESH4409.source_meta(
        f"own:{s}", own, ref, warning_days=FRESH4409.MARKET_WARNING_DAYS,
        hard_days=FRESH4409.MARKET_HARD_DAYS, critical=True)

    peers = _peer_matrix(profile, ref)
    for ps in list(peers.columns):
        rec = FRESH4409.source_meta(
            f"peer:{ps}", peers[ps], ref, warning_days=FRESH4409.MARKET_WARNING_DAYS,
            hard_days=FRESH4409.MARKET_HARD_DAYS, critical=False)
        source_meta[f"peer:{ps}"] = rec
        if rec.get("hard_stale"):
            peers = peers.drop(columns=[ps])

    bench = pd.Series(dtype=float)
    if profile.benchmark:
        raw_bench = matrix[profile.benchmark].dropna() if profile.benchmark in matrix.columns else pd.Series(dtype=float)
        if not raw_bench.empty:
            raw_bench = raw_bench.loc[raw_bench.index <= ref]
        brec = FRESH4409.source_meta(
            f"benchmark:{profile.benchmark}", raw_bench, ref, warning_days=FRESH4409.MARKET_WARNING_DAYS,
            hard_days=FRESH4409.MARKET_HARD_DAYS, critical=True)
        source_meta[f"benchmark:{profile.benchmark}"] = brec
        if not brec.get("hard_stale") and not brec.get("missing"):
            bench = raw_bench

    rel20 = rel60 = None
    a20, a60 = _ret(own, 20), _ret(own, 60)
    b20, b60 = _ret(bench, 20), _ret(bench, 60)
    if a20 is not None and b20 is not None:
        rel20 = a20 - b20
    if a60 is not None and b60 is not None:
        rel60 = a60 - b60

    breadth_s = _breadth_series(peers, 20)
    dispersion_s = _dispersion_series(peers, 20)
    corr_s = _avg_corr_series(peers, 40)
    breadth = float(breadth_s.dropna().iloc[-1]) if breadth_s.dropna().size else None
    dispersion = float(dispersion_s.dropna().iloc[-1]) if dispersion_s.dropna().size else None
    avg_corr = float(corr_s.dropna().iloc[-1]) if corr_s.dropna().size else None
    corr_bench = _corr(own, bench, 60) if not own.empty and not bench.empty else None
    vol_a, vol_b = _ann_vol(own, 20), _ann_vol(bench, 20)
    vol_ratio = (vol_a / vol_b) if vol_a is not None and vol_b not in (None, 0) else None

    # Asset-class-specific context values. These are raw point-in-time market features.
    context = {}
    for cs in profile.context_symbols:
        x = matrix[cs].dropna() if cs in matrix.columns else pd.Series(dtype=float)
        if not x.empty:
            x = x.loc[x.index <= ref]
        crec = FRESH4409.source_meta(
            f"context:{cs}", x, ref, warning_days=FRESH4409.MARKET_WARNING_DAYS,
            hard_days=FRESH4409.MARKET_HARD_DAYS, critical=False)
        source_meta[f"context:{cs}"] = crec
        if crec.get("hard_stale") or crec.get("missing"):
            continue
        r20 = _ret(x, 20)
        if r20 is not None:
            context[cs] = round(r20, 6)

    # Context score: intentionally conservative and bounded. The score is a feature
    # expert, not a replacement for the validated single-series model.
    parts = []
    if rel20 is not None:
        parts.append(np.clip(rel20 / 0.08, -1, 1) * 0.34)
    if rel60 is not None:
        parts.append(np.clip(rel60 / 0.16, -1, 1) * 0.20)
    if breadth is not None:
        parts.append(np.clip((breadth - 0.5) / 0.35, -1, 1) * 0.22)
    if b20 is not None:
        parts.append(np.clip(b20 / 0.08, -1, 1) * 0.16)
    # Very high dispersion makes relative-strength signals less stable, so it is
    # treated as uncertainty rather than direction.
    context_score = float(np.clip(sum(parts), -1, 1)) if parts else 0.0

    z_breadth, z_disp, z_corr = _zscore_now(breadth_s), _zscore_now(dispersion_s), _zscore_now(corr_s)
    drift_values = [abs(z) for z in (z_breadth, z_disp, z_corr) if z is not None]
    drift_score = float(min(1.0, max(drift_values, default=0.0) / 3.0))
    drift_alerts = []
    if z_breadth is not None and abs(z_breadth) >= 2.5:
        drift_alerts.append("ширина рынка вне обычного диапазона")
    if z_disp is not None and abs(z_disp) >= 2.5:
        drift_alerts.append("дисперсия доходностей необычно высокая/низкая")
    if z_corr is not None and abs(z_corr) >= 2.5:
        drift_alerts.append("структура корреляций заметно изменилась")

    coverage = _coverage([rel20, rel60, breadth, dispersion, avg_corr, corr_bench, vol_ratio])
    return {
        "version": VERSION,
        "symbol": s,
        "asset_class": profile.asset_class,
        "region": profile.region,
        "benchmark": profile.benchmark,
        "relative_strength_20d": None if rel20 is None else round(rel20, 6),
        "relative_strength_60d": None if rel60 is None else round(rel60, 6),
        "benchmark_momentum_20d": None if b20 is None else round(b20, 6),
        "breadth_20d": None if breadth is None else round(breadth, 6),
        "dispersion_20d": None if dispersion is None else round(dispersion, 6),
        "avg_peer_correlation_40d": None if avg_corr is None else round(avg_corr, 6),
        "correlation_regime": _correlation_regime(avg_corr),
        "correlation_to_benchmark_60d": None if corr_bench is None else round(corr_bench, 6),
        "volatility_ratio_20d": None if vol_ratio is None else round(vol_ratio, 6),
        "asset_context_20d": context,
        "context_score": round(context_score, 6),
        "feature_coverage": round(coverage, 4),
        "feature_drift": {
            "score": round(drift_score, 4),
            "breadth_z": None if z_breadth is None else round(z_breadth, 3),
            "dispersion_z": None if z_disp is None else round(z_disp, 3),
            "correlation_z": None if z_corr is None else round(z_corr, 3),
            "alerts": drift_alerts,
        },
        "freshness": FRESH4409.summarize_sources(source_meta),
    }


def _read_seed_news() -> list[dict]:
    rows = []
    try:
        if Path(C.NEWS_SEED).exists():
            d = pd.read_csv(C.NEWS_SEED).fillna("")
            rows.extend(d.to_dict("records"))
    except Exception:
        pass
    try:
        if NEWS_LASTGOOD.exists():
            j = json.loads(NEWS_LASTGOOD.read_text(encoding="utf-8"))
            rows.extend(list(j.get("rows") or []))
    except Exception:
        pass
    return rows


def _read_cb_calendar() -> list[dict]:
    try:
        if Path(C.CB_CALENDAR_SEED).exists():
            return pd.read_csv(C.CB_CALENDAR_SEED).fillna("").to_dict("records")
    except Exception:
        pass
    return []


def _event_type(text: str) -> str | None:
    t = str(text or "").lower().replace("ё", "е")
    if any(x in t for x in ("фрс", "fomc", "fed ", "ецб", "ecb", "банк россии", "цб рф", "ключев")) and any(x in t for x in ("ставк", "rate", "решен", "meeting")):
        return "central_bank"
    if any(x in t for x in ("cpi", "инфляц", "pce", "ипц")):
        return "inflation"
    if any(x in t for x in ("earnings", "отчетност", "результат", "выручк", "прибыл")):
        return "earnings"
    if any(x in t for x in ("дивиденд", "dividend")):
        return "dividend"
    if any(x in t for x in ("m&a", "merger", "acquisition", "поглощен", "слияни", "сделк")):
        return "mna"
    if any(x in t for x in ("санкц", "sanction", "export control", "экспортн")):
        return "sanctions"
    if any(x in t for x in ("войн", "war", "геополит", "эскалац", "конфликт")):
        return "geopolitics"
    return None


def _symbol_relevance(symbol: str, profile: AssetProfile, row: dict) -> float:
    raw = f"{row.get('title','')} {row.get('summary','')} {row.get('event','')} {row.get('cb','')}".lower()
    affected_raw = row.get("affected") or []
    tokens=set()
    if isinstance(affected_raw,list):
        for x in affected_raw:
            if isinstance(x,dict) and x.get("symbol"):tokens.add(str(x.get("symbol")).strip().upper())
            elif isinstance(x,str):tokens.add(x.strip().upper())
    else:
        affected=str(affected_raw)
        tokens={x.strip().upper() for x in affected.replace(",", "|").split("|") if x.strip()}
    score = 0.0
    if symbol in tokens:
        score = 1.0
    base = symbol.replace(".ME", "").split("=")[0].replace("^", "").lower()
    if len(base) >= 3 and base in raw:
        score = max(score, 0.85)
    if profile.region == "US" and any(x in raw for x in ("фрс", "fed", "fomc", "сша", "us ")):
        score = max(score, 0.52)
    if profile.region == "RU" and any(x in raw for x in ("банк россии", "цб рф", "росси", "рубл", "санкц")):
        score = max(score, 0.58)
    if profile.region == "EU" and any(x in raw for x in ("ецб", "ecb", "еврозон", "европ")):
        score = max(score, 0.55)
    if profile.asset_class == "crypto" and any(x in raw for x in ("bitcoin", "ethereum", "крипто", "crypto", "etf")):
        score = max(score, 0.58)
    if profile.asset_class == "commodity" and any(x in raw for x in ("нефт", "gold", "золот", "газ", "opec", "опек", "commodity")):
        score = max(score, 0.58)
    return float(score)


def _signed_dir(row: dict) -> float:
    d = str(row.get("dir") or row.get("direction") or "").lower()
    if d in {"up", "bullish", "positive", "рост"}:
        return 1.0
    if d in {"down", "bearish", "negative", "падение"}:
        return -1.0
    return 0.0


def event_snapshot(symbol: str, as_of=None, news: list[dict] | None = None, events: list[dict] | None = None) -> dict:
    s = str(symbol or "").upper()
    profile = asset_profile(s)
    now = pd.Timestamp(as_of or pd.Timestamp.now()).normalize()
    news_rows = list(news) if news is not None else _read_seed_news()
    cal_rows = list(events) if events is not None else _read_cb_calendar()

    upcoming = []
    for row in cal_rows:
        if not EC14.available(row): continue
        try:
            dt = pd.Timestamp(row.get("date")).normalize()
        except Exception:
            continue
        days = int((dt - now).days)
        if days < -1 or days > 30:
            continue
        rel = _symbol_relevance(s, profile, row)
        if rel <= 0:
            continue
        et = _event_type(f"{row.get('cb','')} {row.get('event','')}") or "central_bank"
        proximity = 1.0 if days <= 1 else 0.80 if days <= 3 else 0.55 if days <= 7 else 0.30
        upcoming.append({"date": str(dt.date()), "days": days, "type": et, "relevance": round(rel, 3), "risk": round(rel * proximity, 3), "label": str(row.get("event") or row.get("cb") or et)})

    recent = []
    directional = []
    for row in news_rows:
        if not EC14.available(row): continue
        raw = f"{row.get('title','')} {row.get('summary','')}"
        et = _event_type(raw)
        if not et:
            continue
        rel = _symbol_relevance(s, profile, row)
        if rel < 0.35:
            continue
        try:
            dt = pd.Timestamp(row.get("published_at") or row.get("published") or row.get("date") or now).normalize()
            age = int((now - dt).days)
        except Exception:
            dt = now; age = 0
        if age < 0 or age > 10:
            continue
        freshness = math.exp(-age / 4.0)
        impact = float(row.get("impact_score") or row.get("relevance_score") or 50) / 100.0
        risk = float(np.clip(rel * freshness * (0.55 + 0.45 * impact), 0, 1))
        sd = _signed_dir(row)
        if sd:
            directional.append(sd * risk)
        recent.append({"date": str(dt.date()), "type": et, "relevance": round(rel, 3), "risk": round(risk, 3), "direction": sd, "title": str(row.get("title") or "")[:180]})

    max_upcoming = max([x["risk"] for x in upcoming], default=0.0)
    max_recent = max([x["risk"] for x in recent], default=0.0)
    risk_score = float(np.clip(max(max_upcoming, max_recent), 0, 1))
    bias = float(np.clip(sum(directional) / max(1.0, sum(abs(x) for x in directional)), -1, 1)) if directional else 0.0
    types = sorted({x["type"] for x in upcoming + recent})
    return {
        "symbol": s,
        "risk_score": round(risk_score, 4),
        "directional_bias": round(bias, 4),
        "event_types": types,
        "nearest_events": sorted(upcoming, key=lambda x: (abs(x["days"]), -x["risk"]))[:4],
        "recent_news": sorted(recent, key=lambda x: (-x["risk"], x["date"]))[:5],
        "as_of": str(now.date()),
    }


def build_context(symbol: str, own_close: pd.Series | None = None, as_of=None,
                  news: list[dict] | None = None, events: list[dict] | None = None) -> dict:
    market = cross_sectional_snapshot(symbol, own_close=own_close, as_of=as_of)
    event = event_snapshot(symbol, as_of=as_of, news=news, events=events)
    coverage = float(market.get("feature_coverage") or 0.0)
    drift = float((market.get("feature_drift") or {}).get("score") or 0.0)
    # Quality of the context expert itself, not of the underlying price model.
    confidence = float(np.clip(coverage * (1.0 - 0.45 * drift), 0, 1))
    return {
        "version": VERSION,
        "symbol": str(symbol or "").upper(),
        "market": market,
        "event": event,
        "context_score": float(market.get("context_score") or 0.0),
        "event_bias": float(event.get("directional_bias") or 0.0),
        "event_risk": float(event.get("risk_score") or 0.0),
        "drift_score": drift,
        "coverage": coverage,
        "context_confidence": round(confidence, 4),
        "freshness": market.get("freshness") or FRESH4409.summarize_sources({}),
    }


def apply_context_probability(base_p: float, context: dict) -> dict:
    """Conservative live refinement of a probability using v4.34 context.

    The maximum directional contribution is intentionally small.  High event risk
    without signed evidence shrinks the signal toward 50%; feature drift also raises
    uncertainty.  This avoids claiming that an unvalidated contextual heuristic is
    stronger than the OOS walk-forward models.
    """
    p = float(np.clip(float(base_p), 0.02, 0.98))
    score = float(context.get("context_score") or 0.0)
    ebias = float(context.get("event_bias") or 0.0)
    erisk = float(context.get("event_risk") or 0.0)
    drift = float(context.get("drift_score") or 0.0)
    coverage = float(context.get("coverage") or 0.0)

    # v4.40.10.16: a hand-labelled news direction cannot move a probability.
    # Political/event metadata may change risk, not assign price direction.
    signed = 0.032 * score * min(1.0, max(0.25, coverage))
    # Unscheduled/high-risk events without a clear signed cue reduce conviction.
    neutral_shrink = min(0.24, 0.14 * erisk + 0.10 * drift)
    adjusted = 0.5 + (p - 0.5) * (1.0 - neutral_shrink) + signed
    adjusted = float(np.clip(adjusted, 0.05, 0.95))
    context_p = float(np.clip(0.5 + 0.10 * score, 0.35, 0.65))
    threshold_delta = float(np.clip(0.020 * erisk + 0.020 * drift - 0.010 * abs(score) * coverage, -0.01, 0.04))
    return {
        "p_up": adjusted,
        "context_p_up": context_p,
        "signed_adjustment": round(adjusted - p, 6),
        "uncertainty_shrink": round(neutral_shrink, 6),
        "threshold_delta": round(threshold_delta, 6),
    }
