
"""Optional v3.7 premium-data slots.

The model runs without these keys. They are intentionally optional because adding
a new vendor changes feature provenance and must be versioned/retested.

Recommended priorities:
1) crypto derivatives -> CoinGlass (funding, OI, liquidations, basis)
2) options/volatility -> Massive/Polygon-compatible options data (IV/skew/OI)
3) energy -> EIA API v2 (already supported in external_apis.py)
4) positioning -> official CFTC public data (no API key)
5) macro/revisions -> FRED/ALFRED (already supported)

This module only centralizes configuration/state. Provider-specific endpoints are
kept out until a concrete account/key is supplied and tested.
"""
from __future__ import annotations
import os
from dotenv import load_dotenv

load_dotenv()

PROVIDERS={
    "coinglass":{
        "env_key":"COINGLASS_API_KEY",
        "features":["funding_rate","open_interest","liquidations","futures_basis"],
        "priority":1,
        "asset_classes":["crypto"],
    },
    "options_provider":{
        "env_key":"OPTIONS_API_KEY",
        "features":["implied_volatility","put_call","skew_25d","options_open_interest"],
        "priority":2,
        "asset_classes":["equities","crypto","commodities"],
    },
    "eia":{
        "env_key":"EIA_API_KEY",
        "features":["crude_inventories","gas_inventories","production"],
        "priority":3,
        "asset_classes":["commodities"],
    },
    "cftc":{
        "env_key":None,
        "features":["managed_money_net","dealer_positioning","commercial_positioning"],
        "priority":4,
        "asset_classes":["fx","commodities","equities"],
    },
    "fred":{
        "env_key":"FRED_API_KEY",
        "features":["yield_curve","credit_spreads","financial_conditions","macro_revisions"],
        "priority":0,
        "asset_classes":["all"],
    },
}

def provider_status():
    out={}
    for name,p in PROVIDERS.items():
        key=p.get("env_key")
        out[name]={**p,"configured":True if key is None else bool(os.getenv(key,"").strip())}
    return out
