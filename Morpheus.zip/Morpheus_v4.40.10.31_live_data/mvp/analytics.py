"""
Аналитика и СЦЕНАРИИ (не предсказания).
Главный принцип: любой прогноз показываем как распределение с интервалом
и всегда сравниваем с наивным ориентиром "завтра = сегодня".
"""
import numpy as np
import pandas as pd


def resample_ohlc(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    """Пересборка дневных свечей в недельные/месячные. rule: 'D','W','ME'."""
    if df.empty or rule == "D":
        return df
    d = df.set_index("date")
    agg = {"open": "first", "high": "max", "low": "min", "close": "last"}
    have = {k: v for k, v in agg.items() if k in d.columns}
    out = d.resample(rule).agg(have).dropna(subset=["close"]).reset_index()
    return out


def log_returns(close: pd.Series) -> pd.Series:
    return np.log(close / close.shift(1)).dropna()


def summary_stats(close: pd.Series) -> dict:
    r = log_returns(close)
    if len(r) < 2:
        return {}
    ann = np.sqrt(252)
    return {
        "Последняя цена": round(float(close.iloc[-1]), 4),
        "Доходность 1д, %": round(float(r.iloc[-1] * 100), 2),
        "Доходность 30д, %": round(float((close.iloc[-1] / close.iloc[-min(len(close), 30)] - 1) * 100), 2),
        "Волат. годовая, %": round(float(r.std() * ann * 100), 1),
        "Средн. дневная, %": round(float(r.mean() * 100), 3),
    }


def moving_averages(df: pd.DataFrame, windows=(20, 50, 200)) -> pd.DataFrame:
    out = df.copy()
    for w in windows:
        out[f"MA{w}"] = out["close"].rolling(w).mean()
    return out


def correlation_matrix(price_wide: pd.DataFrame) -> pd.DataFrame:
    """price_wide: индекс=дата, колонки=символы, значения=цена close."""
    rets = np.log(price_wide / price_wide.shift(1))
    return rets.corr()


def monte_carlo_fan(close: pd.Series, horizon=30, n_sims=2000, seed=42):
    """
    Случайное блуждание с дрейфом по историческим лог-доходностям.
    Возвращает (median, low10, high90) — веер сценариев вперёд на horizon дней.
    Это оценка НЕОПРЕДЕЛЁННОСТИ, а не точечный прогноз.
    """
    r = log_returns(close)
    if len(r) < 30:
        return None
    mu, sigma = r.mean(), r.std()
    last = float(close.iloc[-1])
    rng = np.random.default_rng(seed)
    shocks = rng.normal(mu, sigma, size=(n_sims, horizon))
    paths = last * np.exp(np.cumsum(shocks, axis=1))
    q = np.percentile(paths, [10, 50, 90], axis=0)
    idx = pd.RangeIndex(1, horizon + 1)
    return pd.DataFrame({"step": idx, "low10": q[0], "median": q[1],
                         "high90": q[2]})


def backtest_direction(close: pd.Series, train_min=250) -> dict:
    """
    Честная проверка walk-forward: на каждом шаге предсказываем знак
    завтрашней доходности по знаку дрейфа на обучающем окне и сравниваем
    с наивным ориентиром (всегда предсказывать 'как вчера').
    Возвращает точность направления модели и наива + MAE по цене.
    """
    r = log_returns(close).reset_index(drop=True)
    if len(r) < train_min + 30:
        return {}
    hit_model = hit_naive = ae_model = ae_naive = n = 0
    prices = close.reset_index(drop=True)
    for t in range(train_min, len(r) - 1):
        mu = r.iloc[:t].mean()                       # дрейф на истории
        pred_dir_model = np.sign(mu)
        pred_dir_naive = np.sign(r.iloc[t - 1])      # "как вчера"
        actual_dir = np.sign(r.iloc[t])
        hit_model += int(pred_dir_model == actual_dir and actual_dir != 0)
        hit_naive += int(pred_dir_naive == actual_dir and actual_dir != 0)
        # прогноз цены: модель = last*exp(mu); наив = last
        last_price = prices.iloc[t]                  # смещение из-за dropna
        ae_model += abs(last_price * np.exp(mu) - prices.iloc[t + 1])
        ae_naive += abs(last_price - prices.iloc[t + 1])
        n += 1
    return {
        "Точность направления, модель %": round(100 * hit_model / n, 1),
        "Точность направления, наив %": round(100 * hit_naive / n, 1),
        "MAE цены, модель": round(ae_model / n, 4),
        "MAE цены, наив": round(ae_naive / n, 4),
        "Наблюдений": n,
    }
