# Morpheus v4.19 — MOEX Dual Transport

- Исправлен главный дефект v4.18: живой блок `marketdata` больше не зависит от второго справочного HTTP-запроса.
- TQBR/SNDX получают `securities + marketdata` одним компактным запросом.
- Python сначала обращается к MOEX напрямую (`trust_env=False`), затем пробует системные proxy-переменные; HTTPS дополнен документированным HTTP fallback.
- `/api/moex/status` теперь показывает транспортные попытки и тип сетевой ошибки вместо немого `—`.
- Добавлен независимый browser JSONP fallback к MOEX ISS. Он используется, если локальный Python не может достучаться до `iss.moex.com`.
- Последний успешный MOEX snapshot сохраняется в browser localStorage и на диске backend.
- Для выбранной российской акции/индекса browser может получить свечи MOEX и передать их локальной Morpheus model pipeline через `/api/markets/equity-forecast/from-history`.
