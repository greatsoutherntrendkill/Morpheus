"""Lightweight static-export orchestrator for Morpheus v4.40.8.

Important: this module intentionally imports no numpy/pandas/sklearn project stack.
It starts small, fresh forecast workers, collects their JSON, then launches one
fresh assembler process. This prevents cumulative native-ML worker state from
stalling the startup exporter after dozens of sequential fits.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import config as C

HERE = Path(__file__).resolve().parent
EXPORT = HERE / "export_site.py"
PUBLIC = [s for s in ({**C.YF_PRICES, **C.YF_CROSSES, **C.MOEX_INDICES}) if s != "CNY=X"]


def _run_batch(batch, timeout_s: int) -> list[dict]:
    with tempfile.NamedTemporaryFile(prefix="allanalytics_batch_", suffix=".json", delete=False) as tf:
        out = Path(tf.name)
    try:
        env = os.environ.copy(); env["PYTHONUNBUFFERED"] = "1"
        cmd = [sys.executable, str(EXPORT), "--asset-batch", json.dumps(batch, ensure_ascii=False), "--batch-out", str(out)]
        # Inherit terminal stdout/stderr rather than PIPE. Some optional native
        # backends can leave helper descendants holding pipe descriptors, which
        # would make communicate() wait for EOF even after the worker has exited.
        rc = subprocess.run(cmd, cwd=str(HERE), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout_s).returncode
        if rc != 0:
            raise RuntimeError(f"batch process returned {rc}")
        return json.loads(out.read_text(encoding="utf-8"))
    finally:
        try: out.unlink(missing_ok=True)
        except Exception: pass


def main() -> int:
    batch_size = max(2, min(12, int(os.getenv("EXPORT_ASSET_BATCH_SIZE", "8"))))
    timeout_s = max(30, int(os.getenv("EXPORT_ASSET_BATCH_TIMEOUT_SECONDS", "75")))
    blocks=[]
    for start in range(0, len(PUBLIC), batch_size):
        batch=PUBLIC[start:start+batch_size]
        try:
            rows=_run_batch(batch, timeout_s)
        except Exception as exc:
            print(f"  batch {batch[0]}…{batch[-1]}: ошибка ({type(exc).__name__}: {exc})")
            continue
        by_sym={str(r.get("symbol")):r for r in rows if isinstance(r,dict)}
        for sym in batch:
            row=by_sym.get(sym) or {}; block=row.get("block")
            if block:
                blocks.append(block); print(f"  {sym}: ок")
            else:
                print(f"  {sym}: пропуск ({row.get('error') or 'нет результата'})")

    with tempfile.NamedTemporaryFile(prefix="allanalytics_assets_", suffix=".json", delete=False, mode="w", encoding="utf-8") as tf:
        json.dump(blocks, tf, ensure_ascii=False, separators=(",", ":"))
        assets_path=Path(tf.name)
    try:
        env=os.environ.copy(); env["PYTHONUNBUFFERED"]="1"
        cmd=[sys.executable,str(EXPORT),"--assemble-assets",str(assets_path)]
        return subprocess.run(cmd,cwd=str(HERE),env=env).returncode
    finally:
        try: assets_path.unlink(missing_ok=True)
        except Exception: pass


if __name__ == "__main__":
    raise SystemExit(main())
