
"""Morpheus v4.1 — полное обновление пользовательских данных.

Каскад котировок:
MOEX / Binance / Bybit / Yahoo Chart REST / Stooq / ECB / ЦБ РФ / yfinance.
При временном сбое источник больше не удаляет последний рабочий снимок.
"""
from __future__ import annotations
import subprocess, sys

def run(*args):
    cmd=[sys.executable,*args]
    print("\n>>>"," ".join(cmd))
    subprocess.run(cmd,check=True)

# v4.40.6 integrity: live forecasts come only from model_integrity_v4406 via API.
# unified_forecast_v39.py is retained as a legacy snapshot reader, not a live source.

if __name__=="__main__":
    run("update.py",*sys.argv[1:])
    run("export_site.py")
    run("update_altdata_v40.py")
    print("\nAllAnalytics v4.1: котировки, прогноз, новости и альтернативные данные обновлены.")
