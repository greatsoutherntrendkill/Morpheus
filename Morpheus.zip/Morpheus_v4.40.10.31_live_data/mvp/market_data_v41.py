
"""Morpheus v4.1 — отказоустойчивый слой рыночных цен.

Задача модуля: пользовательский интерфейс не должен зависеть от одного
неофициального клиента Yahoo/yfinance. Для каждого класса активов используется
каскад независимых источников.

Источники:
- MOEX ISS — российские индексы;
- Binance Market Data / Bybit — криптовалюты;
- Yahoo Chart REST (query1 -> query2) — глобальные индексы, фьючерсы, сырьё, FX;
- Stooq CSV — резерв для глобальных рынков;
- Frankfurter/ECB — резерв для основных валютных пар;
- ЦБ РФ — резерв для USD/RUB и CNY/RUB;
- yfinance — последний программный резерв.

Ни один сбой источника не обнуляет уже полученные котировки другого источника.
"""
from __future__ import annotations

import io
import math
import time
import urllib.parse
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
import requests

import data_contract_v4401013 as DATA13
import config as C
import sources as S
import market_universe_v416 as MU416

TIMEOUT = 9
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Morpheus/4.1"
HEADERS = {"User-Agent": UA, "Accept": "application/json,text/plain,*/*"}

_MOEX_FAST_CACHE={}

CRYPTO_MAP = {
    "BTC-USD":"BTCUSDT","ETH-USD":"ETHUSDT","SOL-USD":"SOLUSDT","XRP-USD":"XRPUSDT",
}

STOOQ_MAP = {
    "^GSPC":"^spx","^NDX":"^ndx","^DJI":"^dji","^RUT":"^rut",
    "^GDAXI":"^dax","^FTSE":"^ukx","^FCHI":"^cac","^STOXX50E":"^stoxx50e",
    "^N225":"^nkx","^HSI":"^hsi","DX-Y.NYB":"dx.f",
    "ES=F":"es.f","NQ=F":"nq.f","GC=F":"gc.f","SI=F":"si.f",
    "CL=F":"cl.f","NG=F":"ng.f","HG=F":"hg.f",
    "EURUSD=X":"eurusd","GBPUSD=X":"gbpusd","JPY=X":"usdjpy",
    "AUDUSD=X":"audusd","USDCAD=X":"usdcad","RUB=X":"usdrub","CNY=X":"usdcny",
}

FX_FRANKFURTER = {
    "EURUSD=X":("EUR","USD"),
    "GBPUSD=X":("GBP","USD"),
    "JPY=X":("USD","JPY"),
    "AUDUSD=X":("AUD","USD"),
    "USDCAD=X":("USD","CAD"),
}

PLAUSIBLE = {
    "^GSPC":(1000,20000),"^NDX":(2000,70000),"^DJI":(10000,120000),"^RUT":(500,10000),
    "^GDAXI":(5000,60000),"^FTSE":(3000,25000),"^FCHI":(2500,20000),"^STOXX50E":(1500,15000),
    "^N225":(10000,120000),"^HSI":(5000,100000),"DX-Y.NYB":(40,250),
    "ES=F":(1000,20000),"NQ=F":(2000,70000),
    "GC=F":(300,12000),"SI=F":(3,300),"CL=F":(5,400),"NG=F":(.2,100),"HG=F":(.5,30),
    "BTC-USD":(500,1000000),"ETH-USD":(20,100000),"SOL-USD":(.2,5000),"XRP-USD":(.02,100),
    "EURUSD=X":(.5,2.5),"GBPUSD=X":(.5,3),"JPY=X":(40,300),"AUDUSD=X":(.3,1.5),
    "USDCAD=X":(.7,3),"RUB=X":(20,400),"CNY=X":(3,15),"CNYRUB":(2,80),
    "IMOEX":(300,10000),"RTSI":(200,5000),"MOEXBC":(100,50000),"RGBI":(40,300),
}

@dataclass
class MarketResult:
    symbol: str
    frame: pd.DataFrame
    source: str
    errors: list[str]

def _empty():
    return pd.DataFrame(columns=["date","open","high","low","close"])

def _norm(df):
    if df is None or df.empty:
        return _empty()
    d=df.copy()
    d["date"]=pd.to_datetime(d["date"],errors="coerce",utc=True).dt.tz_convert(None)
    for c in ("open","high","low","close"):
        d[c]=pd.to_numeric(d[c],errors="coerce")
    d=d.dropna(subset=["date","close"]).sort_values("date").drop_duplicates("date",keep="last")
    d["open"]=d["open"].fillna(d["close"])
    d["high"]=d["high"].fillna(d[["open","close"]].max(axis=1))
    d["low"]=d["low"].fillna(d[["open","close"]].min(axis=1))
    d["high"]=d[["high","open","close"]].max(axis=1)
    d["low"]=d[["low","open","close"]].min(axis=1)
    return d[["date","open","high","low","close"]]

def plausible(symbol, value):
    try:
        v=float(value)
        if not math.isfinite(v) or v<=0:
            return False
        lo,hi=PLAUSIBLE.get(symbol,(0,float("inf")))
        return lo <= v <= hi
    except Exception:
        return False

def _validate(symbol, df, min_rows=2, max_stale_days=14):
    d=_norm(df)
    if len(d)<min_rows:
        return _empty()
    if not plausible(symbol,d.iloc[-1]["close"]):
        return _empty()
    try:
        age=(pd.Timestamp.now().normalize()-pd.Timestamp(d.iloc[-1]["date"]).normalize()).days
        if age>max_stale_days:
            return _empty()
    except Exception:
        pass
    return d

def yahoo_chart(symbol, range_="6mo", interval="1d"):
    enc=urllib.parse.quote(symbol,safe="")
    errs=[]
    for host in ("query1.finance.yahoo.com","query2.finance.yahoo.com"):
        url=f"https://{host}/v8/finance/chart/{enc}"
        try:
            r=requests.get(url,params={"range":range_,"interval":interval,"events":"div,splits"},
                           headers=HEADERS,timeout=TIMEOUT)
            if r.status_code!=200:
                errs.append(f"{host}: HTTP {r.status_code}")
                continue
            result=((r.json().get("chart") or {}).get("result") or [None])[0]
            if not result:
                errs.append(f"{host}: пустой ответ")
                continue
            ts=result.get("timestamp") or []
            q=(((result.get("indicators") or {}).get("quote") or [{}])[0])
            n=min(len(ts),*(len(q.get(k) or []) for k in ("open","high","low","close")))
            if n<=0:
                errs.append(f"{host}: нет свечей")
                continue
            df=pd.DataFrame({
                "date":pd.to_datetime(ts[:n],unit="s",utc=True),
                "open":(q.get("open") or [])[:n],"high":(q.get("high") or [])[:n],
                "low":(q.get("low") or [])[:n],"close":(q.get("close") or [])[:n],
            })
            df=_validate(symbol,df)
            df=DATA13.yahoo_price_frame(df,result)
            if not df.empty:
                return df,f"Yahoo Chart ({host.split('.')[0]})",errs
            errs.append(f"{host}: данные не прошли контроль")
        except Exception as e:
            errs.append(f"{host}: {type(e).__name__}")
    return _empty(),"",errs

def stooq_history(symbol, days=2200):
    ss=STOOQ_MAP.get(symbol)
    if not ss and MU416.is_us_equity(symbol):
        ss=str(symbol).lower()+".us"
    if not ss:
        return _empty(),"",["Stooq: нет сопоставления"]
    end=pd.Timestamp.now().normalize()
    start=end-pd.Timedelta(days=days)
    url="https://stooq.com/q/d/l/"
    try:
        r=requests.get(url,params={"s":ss,"i":"d","d1":start.strftime("%Y%m%d"),"d2":end.strftime("%Y%m%d")},
                       headers={"User-Agent":UA,"Accept":"text/csv,*/*"},timeout=TIMEOUT)
        if r.status_code!=200:
            return _empty(),"",[f"Stooq: HTTP {r.status_code}"]
        t=r.text.strip()
        if not t or "No data" in t or "," not in t:
            return _empty(),"",["Stooq: пустой ответ"]
        d=pd.read_csv(io.StringIO(t))
        cols={str(c).lower():c for c in d.columns}
        req=("date","open","high","low","close")
        if not all(k in cols for k in req):
            return _empty(),"",["Stooq: неизвестный формат"]
        out=pd.DataFrame({k:d[cols[k]] for k in req})
        out=_validate(symbol,out)
        return (out,"Stooq",[]) if not out.empty else (_empty(),"",["Stooq: данные не прошли контроль"])
    except Exception as e:
        return _empty(),"",[f"Stooq: {type(e).__name__}"]

def binance_history(symbol, limit=220):
    bs=CRYPTO_MAP.get(symbol)
    if not bs:
        return _empty(),"",["Binance: не криптоактив"]
    url="https://data-api.binance.vision/api/v3/klines"
    try:
        r=requests.get(url,params={"symbol":bs,"interval":"1d","limit":min(1000,max(2,int(limit)))},
                       headers=HEADERS,timeout=TIMEOUT)
        if r.status_code!=200:
            return _empty(),"",[f"Binance: HTTP {r.status_code}"]
        rows=r.json()
        d=pd.DataFrame([{
            "date":pd.to_datetime(int(x[0]),unit="ms",utc=True),
            "open":x[1],"high":x[2],"low":x[3],"close":x[4],
        } for x in rows])
        d=_validate(symbol,d,max_stale_days=3)
        return (d,"Binance Market Data",[]) if not d.empty else (_empty(),"",["Binance: данные не прошли контроль"])
    except Exception as e:
        return _empty(),"",[f"Binance: {type(e).__name__}"]

def bybit_history(symbol, limit=220):
    bs=CRYPTO_MAP.get(symbol)
    if not bs:
        return _empty(),"",["Bybit: не криптоактив"]
    url="https://api.bybit.com/v5/market/kline"
    try:
        r=requests.get(url,params={"category":"spot","symbol":bs,"interval":"D","limit":min(1000,max(2,int(limit)))},
                       headers=HEADERS,timeout=TIMEOUT)
        if r.status_code!=200:
            return _empty(),"",[f"Bybit: HTTP {r.status_code}"]
        j=r.json()
        if int(j.get("retCode",-1))!=0:
            return _empty(),"",[f"Bybit: код {j.get('retCode')}"]
        rows=((j.get("result") or {}).get("list") or [])
        d=pd.DataFrame([{
            "date":pd.to_datetime(int(x[0]),unit="ms",utc=True),
            "open":x[1],"high":x[2],"low":x[3],"close":x[4],
        } for x in rows]).sort_values("date")
        d=_validate(symbol,d,max_stale_days=3)
        return (d,"Bybit public market",[]) if not d.empty else (_empty(),"",["Bybit: данные не прошли контроль"])
    except Exception as e:
        return _empty(),"",[f"Bybit: {type(e).__name__}"]

def frankfurter_history(symbol, days=120):
    pair=FX_FRANKFURTER.get(symbol)
    if not pair:
        return _empty(),"",["Frankfurter: нет пары"]
    base,to=pair
    end=pd.Timestamp.now().date()
    start=end-timedelta(days=days)
    url=f"https://api.frankfurter.app/{start.isoformat()}..{end.isoformat()}"
    try:
        r=requests.get(url,params={"from":base,"to":to},headers=HEADERS,timeout=TIMEOUT)
        if r.status_code!=200:
            return _empty(),"",[f"Frankfurter: HTTP {r.status_code}"]
        rates=(r.json() or {}).get("rates") or {}
        rows=[]
        for d,v in sorted(rates.items()):
            if to not in v: continue
            c=float(v[to])
            rows.append({"date":d,"open":c,"high":c,"low":c,"close":c})
        out=_validate(symbol,pd.DataFrame(rows),max_stale_days=10)
        return (out,"Frankfurter / ECB",[]) if not out.empty else (_empty(),"",["Frankfurter: данные не прошли контроль"])
    except Exception as e:
        return _empty(),"",[f"Frankfurter: {type(e).__name__}"]

def cbr_fx_history(symbol, days=120):
    """Резерв для USD/RUB и CNY/RUB из официального XML ЦБ РФ."""
    if symbol not in ("RUB=X","CNYRUB"):
        return _empty(),"",["ЦБ РФ: пара не поддерживается"]
    codes={"USD":"R01235","CNY":"R01375"}
    start=(pd.Timestamp.now()-pd.Timedelta(days=days)).strftime("%d/%m/%Y")
    end=pd.Timestamp.now().strftime("%d/%m/%Y")
    def one(code):
        r=requests.get("https://www.cbr.ru/scripts/XML_dynamic.asp",
                       params={"date_req1":start,"date_req2":end,"VAL_NM_RQ":code},
                       headers={"User-Agent":UA},timeout=TIMEOUT)
        r.raise_for_status()
        import xml.etree.ElementTree as ET
        root=ET.fromstring(r.content)
        rows={}
        for rec in root.findall("Record"):
            date=rec.attrib.get("Date")
            nom=float((rec.findtext("Nominal") or "1").replace(",","."))
            val=float((rec.findtext("Value") or "").replace(",","."))
            rows[pd.to_datetime(date,dayfirst=True)]=val/nom
        return rows
    try:
        usd=one(codes["USD"])
        if symbol=="RUB=X":
            rows=[{"date":d,"open":v,"high":v,"low":v,"close":v} for d,v in sorted(usd.items())]
        else:
            cny=one(codes["CNY"])
            dates=sorted(set(usd)&set(cny))
            rows=[{"date":d,"open":cny[d],"high":cny[d],"low":cny[d],"close":cny[d]} for d in dates]
        out=_validate(symbol,pd.DataFrame(rows),max_stale_days=10)
        return (out,"ЦБ РФ",[]) if not out.empty else (_empty(),"",["ЦБ РФ: данные не прошли контроль"])
    except Exception as e:
        return _empty(),"",[f"ЦБ РФ: {type(e).__name__}"]


def _cross_ohlc(num_df, den_df, symbol="CNYRUB"):
    """Синхронный OHLC-кросс num/den из реальных рыночных баров обеих ног."""
    a=_norm(num_df).set_index("date")
    b=_norm(den_df).set_index("date")
    if a.empty or b.empty:
        return _empty()
    idx=a.index.intersection(b.index)
    if len(idx)<2:
        return _empty()
    out=pd.DataFrame(index=idx)
    out["open"]=a.loc[idx,"open"]/b.loc[idx,"open"]
    out["close"]=a.loc[idx,"close"]/b.loc[idx,"close"]
    # High/low cross use conservative combinations of the two synchronized bars.
    out["high"]=a.loc[idx,"high"]/b.loc[idx,"low"]
    out["low"]=a.loc[idx,"low"]/b.loc[idx,"high"]
    return _validate(symbol,out.reset_index())


def cnyrub_market_history(long_history=False):
    """Рыночная CNY/RUB история с настоящим диапазоном свечей.

    1) прямой Yahoo CNYRUB=X;
    2) синхронный USD/RUB ÷ USD/CNY;
    3) официальный фиксинг ЦБ РФ остаётся только последним резервом.
    """
    errs=[]
    rng="5y" if long_history else "6mo"

    direct,src,e=yahoo_chart("CNYRUB=X",rng,"1d")
    errs+=e
    if not direct.empty:
        d=_validate("CNYRUB",direct)
        if not d.empty:
            return d,"Yahoo Chart · CNY/RUB",errs

    rub,rs,re=yahoo_chart("RUB=X",rng,"1d")
    cny,cs,ce=yahoo_chart("CNY=X",rng,"1d")
    errs+=re+ce
    d=_cross_ohlc(rub,cny,"CNYRUB")
    if not d.empty:
        return d,"расчёт USD/RUB ÷ USD/CNY",errs

    # Try yfinance legs independently before falling back to the CBR fixing.
    try:
        rub_yf=S.fetch_yf("RUB=X",rng)
        cny_yf=S.fetch_yf("CNY=X",rng)
        d=_cross_ohlc(rub_yf,cny_yf,"CNYRUB")
        if not d.empty:
            return d,"рыночный кросс USD/RUB ÷ USD/CNY",errs
    except Exception as ex:
        errs.append(f"рыночный кросс: {type(ex).__name__}")

    fix,src,e=cbr_fx_history("CNYRUB",730 if long_history else 120)
    errs+=e
    if not fix.empty:
        return fix,"ЦБ РФ · официальный фиксинг (линейный режим)",errs
    return _empty(),"",errs


def yfinance_history(symbol, period="6mo"):
    try:
        d=S.fetch_yf(symbol,period)
        d=_validate(symbol,d)
        return (d,"yfinance",[]) if not d.empty else (_empty(),"",["yfinance: пусто"])
    except Exception as e:
        return _empty(),"",[f"yfinance: {type(e).__name__}"]

def moex_history(symbol, long_history=False):
    try:
        import time as _time
        key=(symbol,bool(long_history)); cached=_MOEX_FAST_CACHE.get(key)
        if cached and _time.time()-cached[0] < 60:
            return cached[1].copy(),"MOEX ISS · быстрый кэш",[]
        # Для обычных экранов не тянем ~6 лет MOEX ISS на каждый запрос.
        # 720 календарных дней достаточно для 1г/6м интерфейса; длинная история
        # запрашивается только для 3y/5y/max.
        days=2400 if long_history else 720
        d=S.fetch_moex_index(symbol,start=str((pd.Timestamp.now()-pd.Timedelta(days=days)).date()))
        d=_validate(symbol,d)
        if not d.empty:_MOEX_FAST_CACHE[key]=(_time.time(),d.copy())
        return (d,"MOEX ISS",[]) if not d.empty else (_empty(),"",["MOEX ISS: пусто"])
    except Exception as e:
        return _empty(),"",[f"MOEX ISS: {type(e).__name__}"]

def moex_security_history(symbol, long_history=False):
    try:
        import time as _time
        secid=MU416.moex_secid(symbol)
        key=("share:"+secid,bool(long_history)); cached=_MOEX_FAST_CACHE.get(key)
        if cached and _time.time()-cached[0] < 60:
            return cached[1].copy(),"MOEX ISS · быстрый кэш",[]
        days=2600 if long_history else 720
        d=S.fetch_moex_security(secid,start=str((pd.Timestamp.now()-pd.Timedelta(days=days)).date()))
        d=_validate(symbol,d,min_rows=2,max_stale_days=14)
        if not d.empty:_MOEX_FAST_CACHE[key]=(_time.time(),d.copy())
        return (d,"MOEX ISS · акции",[]) if not d.empty else (_empty(),"",["MOEX ISS акции: пусто"])
    except Exception as e:
        return _empty(),"",[f"MOEX ISS акции: {type(e).__name__}"]


def _yahoo_live_meta(symbol):
    enc=urllib.parse.quote(symbol,safe="")
    errs=[]
    for host in ("query1.finance.yahoo.com","query2.finance.yahoo.com"):
        try:
            url=f"https://{host}/v8/finance/chart/{enc}"
            r=requests.get(url,params={"range":"1d","interval":"1d","includePrePost":"false","events":"div,splits"},headers=HEADERS,timeout=TIMEOUT)
            if r.status_code!=200:
                errs.append(f"{host}: HTTP {r.status_code}"); continue
            result=(((r.json() or {}).get("chart") or {}).get("result") or [None])[0] or {}
            meta=result.get("meta") or {}
            last=meta.get("regularMarketPrice")
            prev=meta.get("chartPreviousClose") or meta.get("previousClose")
            if last is None:
                closes=((((result.get("indicators") or {}).get("quote") or [{}])[0]).get("close") or [])
                vals=[x for x in closes if x is not None]
                last=vals[-1] if vals else None
            if last is None or not plausible(symbol,last):
                errs.append(f"{host}: нет пригодной цены"); continue
            chg=(float(last)/float(prev)-1)*100 if prev not in (None,0) else None
            ts=meta.get("regularMarketTime")
            asof=pd.to_datetime(ts,unit="s",utc=True).isoformat() if ts else None
            return {"last":float(last),"chg1d":chg,"as_of":asof,"source":f"Yahoo live ({host.split('.')[0]})","errors":errs}
        except Exception as e:
            errs.append(f"{host}: {type(e).__name__}")
    return {"last":None,"chg1d":None,"as_of":None,"source":None,"errors":errs}

def fetch_history(symbol, long_history=False):
    """Получить свечи из первого рабочего источника; ошибки остальных сохраняются."""
    errors=[]
    if symbol in C.MOEX_INDICES:
        d,src,e=moex_history(symbol,long_history=long_history); errors+=e
        return MarketResult(symbol,d,src,errors)

    if MU416.is_ru_equity(symbol):
        d,src,e=moex_security_history(symbol,long_history=long_history); errors+=e
        if not d.empty: return MarketResult(symbol,d,src,errors)

    if symbol in CRYPTO_MAP:
        limit=1000 if long_history else 220
        for fn in (binance_history,bybit_history):
            d,src,e=fn(symbol,limit); errors+=e
            if not d.empty: return MarketResult(symbol,d,src,errors)

    if symbol=="CNYRUB":
        d,src,e=cnyrub_market_history(long_history); errors+=e
        if not d.empty: return MarketResult(symbol,d,src,errors)
        return MarketResult(symbol,_empty(),"",errors)

    # Yahoo Chart REST не требует cookie/crumb для chart endpoint и часто работает,
    # когда bulk yfinance падает.
    d,src,e=yahoo_chart(symbol,"5y" if long_history else "6mo","1d"); errors+=e
    if not d.empty: return MarketResult(symbol,d,src,errors)

    d,src,e=stooq_history(symbol,2200 if long_history else 240); errors+=e
    if not d.empty: return MarketResult(symbol,d,src,errors)

    if symbol in FX_FRANKFURTER:
        d,src,e=frankfurter_history(symbol,730 if long_history else 120); errors+=e
        if not d.empty: return MarketResult(symbol,d,src,errors)

    if symbol=="RUB=X":
        d,src,e=cbr_fx_history(symbol,730 if long_history else 120); errors+=e
        if not d.empty: return MarketResult(symbol,d,src,errors)

    d,src,e=yfinance_history(symbol,"5y" if long_history else "6mo"); errors+=e
    if not d.empty: return MarketResult(symbol,d,src,errors)

    return MarketResult(symbol,_empty(),"",errors)

def quote_from_frame(symbol, frame, source, errors=None, history_points=190):
    d=_norm(frame)
    if d.empty:
        return {"symbol":symbol,"last":None,"chg1d":None,"source":None,"errors":errors or []}
    last=float(d.iloc[-1]["close"])
    prev=float(d.iloc[-2]["close"]) if len(d)>1 else None
    chg=None if not prev or prev<=0 else (last/prev-1)*100
    hist=d.tail(history_points)
    return {
        "symbol":symbol,"last":round(last,6),
        "chg1d":None if chg is None else round(chg,3),
        "as_of":pd.Timestamp(d.iloc[-1]["date"]).isoformat(),
        "source":source,
        "history":[{"t":str(pd.Timestamp(r.date).date()),"o":round(float(r.open),6),
                    "h":round(float(r.high),6),"l":round(float(r.low),6),
                    "c":round(float(r.close),6)} for r in hist.itertuples()],
        "errors":errors or [],
    }

def fetch_quote(symbol):
    # v4.16: 30-секундный контур акций принципиально не тянет многолетнюю
    # историю. История и модели загружаются лениво при открытии сектора/актива.
    if MU416.is_ru_equity(symbol):
        live=S.fetch_moex_security_snapshot(MU416.moex_secid(symbol))
        if live.get("last") is not None and plausible(symbol,live.get("last")):
            return {
                "symbol":symbol,"last":round(float(live["last"]),6),
                "chg1d":None if live.get("chg1d") is None else round(float(live["chg1d"]),3),
                "as_of":str(live.get("time") or ""),"source":"MOEX ISS · marketdata",
                "history":[],"errors":[],
            }
        return {"symbol":symbol,"last":None,"chg1d":None,"as_of":None,"source":None,"history":[],"errors":["MOEX ISS: live price unavailable"]}
    if MU416.is_us_equity(symbol):
        live=_yahoo_live_meta(symbol)
        if live.get("last") is not None:
            return {
                "symbol":symbol,"last":round(float(live["last"]),6),
                "chg1d":None if live.get("chg1d") is None else round(float(live["chg1d"]),3),
                "as_of":live.get("as_of"),"source":live.get("source"),
                "history":[],"errors":live.get("errors") or [],
            }
        # Secondary one-request daily fallback for resilience.
        d,src,e=stooq_history(symbol,days=20)
        if not d.empty:
            return quote_from_frame(symbol,d,src,(live.get("errors") or [])+e,history_points=10)
        return {"symbol":symbol,"last":None,"chg1d":None,"as_of":None,"source":None,"history":[],"errors":live.get("errors") or e}
    # Большая часть глобального universe обновляется из компактного Yahoo meta,
    # а не повторной загрузкой 6 месяцев истории каждые 30 секунд.
    if symbol in STOOQ_MAP and symbol not in CRYPTO_MAP:
        live=_yahoo_live_meta(symbol)
        if live.get("last") is not None:
            return {"symbol":symbol,"last":round(float(live["last"]),6),
                    "chg1d":None if live.get("chg1d") is None else round(float(live["chg1d"]),3),
                    "as_of":live.get("as_of"),"source":live.get("source"),
                    "history":[],"errors":live.get("errors") or []}
    r=fetch_history(symbol,long_history=False)
    return quote_from_frame(symbol,r.frame,r.source,r.errors)

 # Legacy source label retained for regression compatibility: MOEX ISS · пакет TQBR

def _batch_ru_quotes(symbols):
    """Пакетный live-контур MOEX: один запрос на акции + один на индексы."""
    syms=list(dict.fromkeys(symbols or []))
    ru_eq=[s for s in syms if MU416.is_ru_equity(s)]
    ru_idx=[s for s in syms if s in C.MOEX_INDICES]
    out={}
    def _shares():
        secids=[MU416.moex_secid(s) for s in ru_eq]
        return S.fetch_moex_market_snapshot_batch(secids,market='shares',board='TQBR',ttl=10)
    def _indices():
        return S.fetch_moex_market_snapshot_batch(ru_idx,market='index',ttl=10)
    if ru_eq or ru_idx:
        with ThreadPoolExecutor(max_workers=2) as ex:
            jobs=[]
            if ru_eq: jobs.append(('shares',ex.submit(_shares)))
            if ru_idx: jobs.append(('index',ex.submit(_indices)))
            for kind,f in jobs:
                try: data=f.result() or {}
                except Exception: data={}
                if kind=='shares':
                    for sym in ru_eq:
                        x=data.get(MU416.moex_secid(sym)) or {}
                        if x.get('last') is not None:
                            out[sym]={
                                'symbol':sym,'last':round(float(x['last']),6),
                                'chg1d':None if x.get('chg1d') is None else round(float(x['chg1d']),3),
                                'as_of':x.get('time'),'source':x.get('source') or 'MOEX ISS · TQBR',
                                'history':[],'errors':[],
                            }
                else:
                    for sym in ru_idx:
                        x=data.get(sym) or {}
                        if x.get('last') is not None:
                            out[sym]={
                                'symbol':sym,'last':round(float(x['last']),6),
                                'chg1d':None if x.get('chg1d') is None else round(float(x['chg1d']),3),
                                'as_of':x.get('time'),'source':x.get('source') or 'MOEX ISS · SNDX',
                                'history':[],'errors':[],
                            }
    return out

def fetch_all(symbols, workers=8):
    symbols=list(dict.fromkeys(symbols or []))
    by=_batch_ru_quotes(symbols)
    remaining=[s for s in symbols if s not in by]
    rows=[]
    if remaining:
        with ThreadPoolExecutor(max_workers=max(2,min(workers,12))) as ex:
            fut={ex.submit(fetch_quote,s):s for s in remaining}
            for f in as_completed(fut):
                s=fut[f]
                try:
                    rows.append(f.result())
                except Exception as e:
                    rows.append({"symbol":s,"last":None,"chg1d":None,"source":None,
                                 "errors":[f"внутренняя ошибка: {type(e).__name__}"]})
    by.update({r["symbol"]:r for r in rows})
    return [by[s] for s in symbols if s in by]
