# Model roadmap after v4.40.1

v4.40.1 starts the durable prospective evidence clock. Keep the production model running and let the readiness monitor decide when the sample is large/diverse enough for the next statistical review.

## While status is NOT READY / COLLECTING
Do not fit regime-specific interval corrections from the small live sample. Continue other model-core work that does not consume immature v4.40 prospective distribution evidence.

## When `ready_for_v441_regime_review = true`
Proceed to v4.41 Regime-Conditioned Distribution Review:
- evaluate coverage / pinball / median bias by horizon, asset class and regime;
- use only point-in-time context frozen in the ledger;
- introduce correction/tail specialist only for segments with sufficient evidence;
- keep untouched prospective review windows and manual promotion.

## Event-conditioned branch
`ready_for_v441_event_review` is a separate gate because independent FOMC/ECB/CBR/CPI/earnings events accumulate slowly. Regime review may begin before event review is mature.

Historical Analog Engine, Monte Carlo/options fusion and LLM Scenario Intelligence remain later layers per the deferred Scenario Lab roadmap.
