# Morpheus v4.33 — Model Quality Foundation

Первый этап нового плана улучшения прогнозных моделей.

## Что изменено

- Добавлен `model_quality_v433.py` — volatility-aware regime challenger.
- Цель прогноза теперь умеет отделять **значимый рост / нейтральное движение / значимое падение**. Нейтральный порог зависит от исторической волатильности и горизонта.
- Добавлены point-in-time режимы рынка: направление тренда + режим волатильности.
- Добавлен глобальный directional expert и regime-specific expert. Специализированный эксперт используется только при достаточном числе наблюдений.
- Добавлена rolling OOS Platt calibration: калибратор обучается только на предыдущих out-of-sample прогнозах.
- Добавлен `meta_forecast_v433.py`: production walk-forward + regime challenger объединяются консервативным meta-layer.
- При расхождении моделей итоговая вероятность автоматически сжимается к 50%.
- Добавлен dynamic no-edge gate / abstention: модель может явно сказать, что устойчивого преимущества нет.
- Экстремальные вероятности ограничены диапазоном, чтобы исследовательский сигнал не превращался в ложные 0%/100%.
- Старые forecast-cache не используются: v4.33 имеет отдельный namespace кэша.
- Обзор и Technical Lab для дневных горизонтов теперь запрашивают новый `/api/markets/forecast` и получают v4.33 meta forecast для поддерживаемых рыночных инструментов.
- В Technical Lab расширено объяснение прогноза: режим рынка, сила сигнала, нейтральная вероятность и согласие основной/режимной модели.
- Добавлен диагностический endpoint `/api/models/quality-v433`.
- Модели `vol-regime-challenger-v4.33.0` и `meta-quality-v4.33.0` зарегистрированы в immutable model registry как challengers. Автоматическая промоция отключена.

## Что сознательно НЕ сделано

- Champion `logreg-v3.2.0` не заменён автоматически.
- Historical Analog / Scenario roadmap не смешивался с этой версией.
- Intraday 30m–4h модель не переписана в этом этапе; v4.33 касается прежде всего дневного forecast pipeline.

## Проверки

- Новые v4.33 regression tests: 7/7 passed.
- Критический набор forecasting / UI / governance тестов: 20/20 passed.
- Python syntax: passed.
- Frontend JavaScript syntax: passed.
- Полный исторический suite: 60 тестов проходят; 1 старый v3.4 benchmark fixture остаётся несовместим с текущим `model_benchmark_v34.json` и не относится к изменениям v4.33.
