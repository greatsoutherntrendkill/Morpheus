"""Morpheus v4.40.9 — Model Correctness release wrapper.

v4.40.9 deliberately changes no target semantics and introduces no new expert.
It hardens four correctness invariants around the v4.40.8 routing stack:
- real point-in-time risk_score is used by soft regime routing;
- the directional/distribution consistency gate can act only on a qualified
  distribution model with sufficient effective sample;
- unapproved challengers have literally zero production influence;
- every live context feature follows the v4.40.9 freshness/staleness contract.
"""
from __future__ import annotations

import data_driven_routing_v4408 as BASE
import forecast_contract_v4406 as CONTRACT
import freshness_contract_v4409 as FRESH4409

VERSION = "model-correctness-v4.40.9"
MODEL_GENERATION = CONTRACT.MODEL_GENERATION
TARGET4405 = BASE.TARGET4405


def forecast_horizon(close, symbol: str, horizon: int = 10, fast: bool = True, context: dict | None = None) -> dict:
    out = BASE.forecast_horizon(close, symbol=symbol, horizon=int(horizon), fast=fast, context=context)
    if not out:
        return {}
    out = dict(out)
    out["base_model_version"] = out.get("version")
    out["version"] = VERSION
    out["model_version"] = VERSION
    out["model_generation"] = MODEL_GENERATION
    out["correctness_release"] = {
        "version": VERSION,
        "real_soft_regime_routing": True,
        "quality_aware_distribution_gate": True,
        "unapproved_challenger_zero_influence": True,
        "feature_freshness_contract": FRESH4409.VERSION,
    }
    val = dict(out.get("validation") or {})
    val.update({
        "model_correctness_release": VERSION,
        "real_soft_regime_routing": True,
        "distribution_gate_requires_quality_and_effective_n": True,
        "unapproved_challenger_zero_influence": True,
        "feature_freshness_contract": FRESH4409.VERSION,
    })
    out["validation"] = val
    return out
