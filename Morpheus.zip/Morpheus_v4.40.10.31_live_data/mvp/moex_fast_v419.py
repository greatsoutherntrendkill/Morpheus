"""Morpheus v4.20 — MOEX ISS VPN-resilient transport layer.

Why this exists:
* all Russian instruments were failing together, which means the transport to ISS
  was the weak point, not individual SECID mappings;
* v4.18 made a successful marketdata request depend on a second metadata request;
  if that second request failed, the whole board was discarded;
* requests.Session respected proxy variables inherited from the shell, which can
  break localhost Python access even when the browser itself can reach MOEX.

v4.19 fixes this by:
1) one compact ISS request per board containing BOTH securities + marketdata;
2) direct transport with trust_env=False first, then normal env/proxy transport;
3) HTTPS first and documented HTTP fallback;
4) partial block parsing — marketdata is never discarded because metadata failed;
5) persistent last-good cache and diagnostics.

The browser adds an independent JSONP fallback in site/index.html, so prices have
both a backend path and a browser path to MOEX.
"""
from __future__ import annotations

import json
import os
import time
import socket
import ssl
import http.client
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

ROOT = Path(__file__).resolve().parent
CACHE_DIR = ROOT / "runtime_cache" / "moex_v420"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
LIVE_CACHE_FILE = CACHE_DIR / "live.json"
HISTORY_DIR = CACHE_DIR / "history"
HISTORY_DIR.mkdir(parents=True, exist_ok=True)
FAST_HISTORY_DIR = CACHE_DIR / "history_fast"
FAST_HISTORY_DIR.mkdir(parents=True, exist_ok=True)

CONNECT_TIMEOUT = float(os.getenv("MOEX_CONNECT_TIMEOUT", "2.5"))
READ_TIMEOUT = float(os.getenv("MOEX_READ_TIMEOUT", "5.5"))
LIVE_TTL = max(3, int(os.getenv("MOEX_LIVE_CACHE_SECONDS", "10")))
HISTORY_TTL = max(600, int(os.getenv("MOEX_HISTORY_CACHE_SECONDS", str(6 * 3600))))
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Morpheus/4.20"

_LOCK = Lock()
_FETCH_LOCK = Lock()
_MEM = {"ts": 0.0, "shares": {}, "indices": {}, "errors": [], "transport": None}
_LAST_ATTEMPTS: list[dict] = []
_DOH_CACHE = {"ts":0.0,"ips":[]}
_PREFERRED_TRANSPORT = None


def _resolve_iss_doh() -> list[str]:
    """Resolve iss.moex.com without depending on the VPN DNS resolver.

    This does not bypass a provider that blocks the destination IP itself, but it
    fixes the common case where a VPN DNS/SmartDNS route cannot resolve MOEX.
    """
    now=time.time()
    if _DOH_CACHE.get("ips") and now-float(_DOH_CACHE.get("ts") or 0)<3600:
        return list(_DOH_CACHE["ips"])
    ips=[]
    resolvers=[
        ("cloudflare","https://cloudflare-dns.com/dns-query",{"name":"iss.moex.com","type":"A"},{"accept":"application/dns-json"}),
        ("google","https://dns.google/resolve",{"name":"iss.moex.com","type":"A"},{}),
    ]
    for _,url,params,headers in resolvers:
        try:
            r=_DIRECT.get(url,params=params,headers={**_DIRECT.headers,**headers},timeout=(2.0,3.5))
            if r.status_code!=200: continue
            j=r.json()
            for a in j.get("Answer") or []:
                v=str(a.get("data") or "")
                try:
                    socket.inet_aton(v)
                    if v not in ips: ips.append(v)
                except OSError:
                    pass
            if ips: break
        except Exception:
            continue
    if ips:
        _DOH_CACHE.update(ts=now,ips=ips[:4])
    return ips[:4]


class _FixedIPHTTPS(http.client.HTTPSConnection):
    def __init__(self, ip: str, hostname: str, timeout: float):
        self._fixed_ip=ip; self._hostname=hostname
        super().__init__(hostname,443,timeout=timeout,context=ssl.create_default_context())
    def connect(self):
        raw=socket.create_connection((self._fixed_ip,self.port),self.timeout)
        self.sock=self._context.wrap_socket(raw,server_hostname=self._hostname)


def _request_json_doh(path: str, params: dict) -> tuple[dict,str]:
    query=urllib.parse.urlencode(params,doseq=True,safe=",")
    target=path+("?"+query if query else "")
    last=None
    attempts=[]
    for ip in _resolve_iss_doh():
        t0=time.perf_counter(); conn=None
        try:
            conn=_FixedIPHTTPS(ip,"iss.moex.com",CONNECT_TIMEOUT+READ_TIMEOUT)
            conn.request("GET",target,headers={"Host":"iss.moex.com","User-Agent":UA,"Accept":"application/json"})
            r=conn.getresponse(); body=r.read()
            ms=round((time.perf_counter()-t0)*1000)
            attempts.append({"transport":"https-doh-ip","ip":ip,"status":r.status,"ms":ms})
            if r.status!=200: continue
            j=json.loads(body.decode("utf-8"))
            if isinstance(j,dict):
                global _LAST_ATTEMPTS
                _LAST_ATTEMPTS=(_LAST_ATTEMPTS+attempts)[-10:]
                return j,"https-doh-ip"
        except Exception as exc:
            ms=round((time.perf_counter()-t0)*1000)
            attempts.append({"transport":"https-doh-ip","ip":ip,"error":f"{type(exc).__name__}: {str(exc)[:100]}","ms":ms})
            last=exc
        finally:
            try:
                if conn: conn.close()
            except Exception:
                pass
    if attempts:
        _LAST_ATTEMPTS=(_LAST_ATTEMPTS+attempts)[-10:]
    raise last or RuntimeError("MOEX DoH transport failed")


def _make_session(trust_env: bool) -> requests.Session:
    s = requests.Session()
    s.trust_env = trust_env
    retry = Retry(total=1, connect=1, read=1, status=1, backoff_factor=.12,
                  status_forcelist=(429, 500, 502, 503, 504),
                  allowed_methods=frozenset(["GET"]), raise_on_status=False)
    s.mount("https://", HTTPAdapter(max_retries=retry, pool_connections=4, pool_maxsize=8))
    s.mount("http://", HTTPAdapter(max_retries=retry, pool_connections=4, pool_maxsize=8))
    s.headers.update({"User-Agent": UA, "Accept": "application/json,text/plain,*/*", "Connection": "keep-alive"})
    return s

_DIRECT = _make_session(False)
_ENV = _make_session(True)


def _request_json(path: str, params: dict) -> tuple[dict, str]:
    """Transport ladder. Returns (json, transport_label).

    Once a VPN-compatible route succeeds it is tried first on later candle pages,
    which prevents a 5-year history request from repeating several timeouts per page.
    """
    global _LAST_ATTEMPTS, _PREFERRED_TRANSPORT
    attempts = []
    if _PREFERRED_TRANSPORT == "public-relay":
        try:return _request_json_relay(path,params)
        except Exception: _PREFERRED_TRANSPORT=None
    elif _PREFERRED_TRANSPORT == "https-doh-ip":
        try:return _request_json_doh(path,params)
        except Exception: _PREFERRED_TRANSPORT=None
    ladders = [
        ("https-direct", _DIRECT, "https://iss.moex.com"),
        ("http-direct", _DIRECT, "http://iss.moex.com"),
        ("https-env", _ENV, "https://iss.moex.com"),
        ("http-env", _ENV, "http://iss.moex.com"),
    ]
    # Reuse the transport that already succeeded for live MOEX prices.  In v4.22
    # every history request restarted the full ladder from https-direct, so a VPN
    # could spend several seconds on known-bad routes before reaching the working
    # route.  Forecast history is latency-sensitive, therefore the known-good
    # transport is tried first.
    if _PREFERRED_TRANSPORT in {x[0] for x in ladders}:
        ladders.sort(key=lambda x: 0 if x[0] == _PREFERRED_TRANSPORT else 1)
    last_exc = None
    for label, sess, base in ladders:
        t0 = time.perf_counter()
        try:
            r = sess.get(base + path, params=params, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), allow_redirects=True)
            elapsed = round((time.perf_counter() - t0) * 1000)
            attempts.append({"transport": label, "status": r.status_code, "ms": elapsed, "url": str(r.url)[:220]})
            if r.status_code != 200:
                last_exc = RuntimeError(f"HTTP {r.status_code}")
                continue
            obj = r.json()
            if not isinstance(obj, dict):
                last_exc = ValueError("non-object JSON")
                continue
            _LAST_ATTEMPTS = attempts[-8:]
            _PREFERRED_TRANSPORT = label
            return obj, label
        except Exception as exc:
            elapsed = round((time.perf_counter() - t0) * 1000)
            attempts.append({"transport": label, "error": f"{type(exc).__name__}: {str(exc)[:120]}", "ms": elapsed})
            last_exc = exc
    _LAST_ATTEMPTS = attempts[-8:]
    try:
        obj,label=_request_json_doh(path,params);_PREFERRED_TRANSPORT=label;return obj,label
    except Exception as exc:
        last_exc=exc
    try:
        obj,label=_request_json_relay(path,params);_PREFERRED_TRANSPORT=label;return obj,label
    except Exception as exc:
        last_exc=exc
    raise last_exc or RuntimeError("MOEX transport failed")


def _request_json_relay(path: str, params: dict) -> tuple[dict,str]:
    """Emergency relay for public MOEX JSON when a VPN blocks MOEX itself.

    Only public market-data URLs are sent through the relay; no cookies, API keys or
    user data are included. This is deliberately last in the ladder.
    """
    if str(os.getenv("MOEX_PUBLIC_RELAY_ENABLED","1")).lower() not in {"1","true","yes","on"}:
        raise RuntimeError("public relay disabled")
    upstream="https://iss.moex.com"+path
    q=urllib.parse.urlencode(params,doseq=True,safe=",")
    if q: upstream+="?"+q
    relay="https://api.allorigins.win/raw"
    t0=time.perf_counter()
    r=_DIRECT.get(relay,params={"url":upstream},headers={"User-Agent":UA,"Accept":"application/json,text/plain,*/*"},timeout=(3.0,8.0))
    ms=round((time.perf_counter()-t0)*1000)
    global _LAST_ATTEMPTS
    _LAST_ATTEMPTS=(_LAST_ATTEMPTS+[{"transport":"public-relay","status":r.status_code,"ms":ms}])[-10:]
    if r.status_code!=200: raise RuntimeError(f"relay HTTP {r.status_code}")
    j=r.json()
    if not isinstance(j,dict): raise ValueError("relay returned non-object JSON")
    return j,"public-relay"


def _rows(block: dict | None) -> list[dict]:
    cols = (block or {}).get("columns") or []
    data = (block or {}).get("data") or []
    return [{c: row[i] if i < len(row) else None for i, c in enumerate(cols)} for row in data]


def _num(v):
    try:
        x = float(v)
        return x if x > 0 else None
    except Exception:
        return None


def _read_cache() -> dict:
    try:
        return json.loads(LIVE_CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"saved_at": None, "shares": {}, "indices": {}}


def _save_cache(shares: dict, indices: dict):
    old = _read_cache()
    merged_shares = {**(old.get("shares") or {}), **(shares or {})}
    merged_indices = {**(old.get("indices") or {}), **(indices or {})}
    if not merged_shares and not merged_indices:
        return
    tmp = LIVE_CACHE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps({"saved_at": datetime.now().isoformat(timespec="seconds"),
                               "shares": merged_shares, "indices": merged_indices},
                              ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    tmp.replace(LIVE_CACHE_FILE)


def _board_snapshot(market: str, board: str) -> tuple[dict, str]:
    path = f"/iss/engines/stock/markets/{market}/boards/{board}/securities.json"
    if market == "shares":
        params = {
            "iss.meta": "off", "iss.only": "securities,marketdata",
            "securities.columns": "SECID,SHORTNAME,PREVPRICE,PREVLEGALCLOSEPRICE",
            "marketdata.columns": "SECID,LAST,LASTCHANGEPRCNT,LASTTOPREVPRICE,UPDATETIME,SYSTIME",
        }
        live_keys = ("LAST",)
        prev_keys = ("PREVPRICE", "PREVLEGALCLOSEPRICE")
        change_keys = ("LASTCHANGEPRCNT", "LASTTOPREVPRICE")
    else:
        params = {
            "iss.meta": "off", "iss.only": "securities,marketdata",
            "securities.columns": "SECID,SHORTNAME",
            "marketdata.columns": "SECID,CURRENTVALUE,LASTVALUE,LASTCHANGEPRCNT,CHANGE,UPDATETIME,SYSTIME",
        }
        live_keys = ("CURRENTVALUE",)
        prev_keys = ("LASTVALUE",)
        change_keys = ("LASTCHANGEPRCNT", "CHANGE")

    j, transport = _request_json(path, params)
    sec_rows = _rows(j.get("securities"))
    mkt_rows = _rows(j.get("marketdata"))
    sec = {str(r.get("SECID") or "").upper(): r for r in sec_rows if r.get("SECID")}
    mkt = {str(r.get("SECID") or "").upper(): r for r in mkt_rows if r.get("SECID")}
    keys = set(sec) | set(mkt)
    out = {}
    for secid in keys:
        s, m = sec.get(secid, {}), mkt.get(secid, {})
        live = next((_num(m.get(k)) for k in live_keys if _num(m.get(k)) is not None), None)
        prev = next((_num(m.get(k)) for k in prev_keys if _num(m.get(k)) is not None), None)
        if prev is None:
            prev = next((_num(s.get(k)) for k in prev_keys if _num(s.get(k)) is not None), None)
        last = live or prev
        if last is None:
            continue
        chg = None
        for k in change_keys:
            try:
                if m.get(k) is not None:
                    chg = float(m.get(k)); break
            except Exception:
                pass
        if chg is None and live is not None and prev:
            chg = (live / prev - 1) * 100
        out[secid] = {
            "secid": secid, "last": round(float(last), 8),
            "chg1d": None if chg is None else round(float(chg), 4),
            "time": m.get("UPDATETIME") or m.get("SYSTIME"),
            "name": s.get("SHORTNAME") or secid,
            "prev": prev, "board": board,
            "source": f"MOEX ISS · {board} · {transport}" if live is not None else f"MOEX ISS · previous close · {transport}",
            "stale": live is None,
        }
    if not out:
        raise RuntimeError(f"MOEX {board}: response contained no usable prices")
    return out, transport


def refresh_live(force: bool = False) -> dict:
    now = time.time()
    with _LOCK:
        if not force and _MEM.get("shares") and now - float(_MEM.get("ts") or 0) < LIVE_TTL:
            return dict(_MEM)
    with _FETCH_LOCK:
        now = time.time()
        with _LOCK:
            if not force and _MEM.get("shares") and now - float(_MEM.get("ts") or 0) < LIVE_TTL:
                return dict(_MEM)
        errors, transports = [], []
        shares, indices = {}, {}
        try:
            shares, tr = _board_snapshot("shares", "TQBR"); transports.append(tr)
        except Exception as exc:
            errors.append(f"TQBR: {type(exc).__name__}: {str(exc)[:180]}")
        try:
            indices, tr = _board_snapshot("index", "SNDX"); transports.append(tr)
        except Exception as exc:
            errors.append(f"SNDX: {type(exc).__name__}: {str(exc)[:180]}")
        if shares or indices:
            try: _save_cache(shares, indices)
            except Exception as exc: errors.append(f"cache-write: {type(exc).__name__}")
        persisted = _read_cache()
        if not shares:
            shares = persisted.get("shares") or {}
            for row in shares.values(): row.update(source="MOEX ISS · last-good disk cache", stale=True)
        if not indices:
            indices = persisted.get("indices") or {}
            for row in indices.values(): row.update(source="MOEX ISS · last-good disk cache", stale=True)
        result = {"ts": now, "shares": shares, "indices": indices, "errors": errors,
                  "transport": ",".join(dict.fromkeys(transports)) or None,
                  "saved_at": persisted.get("saved_at"), "attempts": list(_LAST_ATTEMPTS)}
        with _LOCK:
            _MEM.clear(); _MEM.update(result)
        return result


def status() -> dict:
    d = refresh_live(False)
    return {"version": "4.20", "shares": len(d.get("shares") or {}), "indices": len(d.get("indices") or {}),
            "errors": d.get("errors") or [], "transport": d.get("transport"),
            "attempts": d.get("attempts") or [], "cache_file": LIVE_CACHE_FILE.name,
            "saved_at": d.get("saved_at")}


def get_snapshot(secids, market: str = "shares", force: bool = False) -> dict:
    wanted = {str(x or "").upper().replace(".ME", "") for x in secids or [] if x}
    d = refresh_live(force)
    src = d.get("shares") if market == "shares" else d.get("indices")
    return {s: dict(src[s]) for s in wanted if s in (src or {})}


def _history_path(market: str, board: str, secid: str) -> Path:
    safe = "".join(c for c in str(secid).upper() if c.isalnum() or c in "-_")
    return HISTORY_DIR / f"{market}_{board}_{safe}.json"


def _load_history(path: Path) -> pd.DataFrame:
    try:
        obj = json.loads(path.read_text(encoding="utf-8")); rows = obj.get("rows") or []
        d = pd.DataFrame(rows)
        if d.empty: return pd.DataFrame(columns=["date","open","high","low","close"])
        d["date"] = pd.to_datetime(d["date"], errors="coerce")
        for c in ("open","high","low","close"): d[c] = pd.to_numeric(d[c], errors="coerce")
        return d.dropna(subset=["date","close"]).sort_values("date")
    except Exception:
        return pd.DataFrame(columns=["date","open","high","low","close"])


def history_recent(secid: str, market: str = "shares", board: str = "TQBR",
                   calendar_days: int = 132, force: bool = False) -> tuple[pd.DataFrame, dict]:
    """Recent *daily closing history* using the MOEX history endpoint.

    This is the correct source for the market-card directional forecast.  The
    previous implementation used /candles even though the model only consumes
    daily closes.  apimoex documents get_board_history specifically for this use
    case.  A ~132 calendar-day window normally contains 85-95 trading sessions,
    fits in one ISS page, and gives the bootstrap model >60 returns.

    Returns (frame, diagnostics).  OHLC fields are intentionally set to CLOSE: the
    forecast model only consumes CLOSE and the UI already has a separate chart
    history pipeline.
    """
    secid = str(secid or "").upper().replace(".ME", "")
    safe = "".join(c for c in f"boardhist_{market}_{board}_{secid}" if c.isalnum() or c in "-_")
    cache = FAST_HISTORY_DIR / f"{safe}.json"
    now = time.time()
    diag = {"source": None, "transport": None, "observations": 0, "attempts": [], "errors": []}

    if cache.exists() and not force and now - cache.stat().st_mtime < HISTORY_TTL:
        d = _load_history(cache)
        if len(d) >= 61:
            diag.update(source="MOEX ISS board history · disk cache", observations=int(len(d)))
            return d, diag

    end = datetime.now().date()
    start = end - timedelta(days=max(118, min(int(calendar_days), 145)))
    path = f"/iss/history/engines/stock/markets/{market}/boards/{board}/securities/{secid}.json"
    params = {
        "iss.meta": "off", "iss.only": "history",
        "from": start.isoformat(), "till": end.isoformat(),
        "history.columns": "TRADEDATE,CLOSE",
    }
    rows = []
    try:
        j, transport = _request_json(path, params)
        diag["transport"] = transport
        for r in _rows(j.get("history")):
            dt, cl = r.get("TRADEDATE"), _num(r.get("CLOSE"))
            if dt and cl is not None:
                rows.append({"date": dt, "open": cl, "high": cl, "low": cl, "close": cl})
    except Exception as exc:
        diag["errors"].append(f"board history: {type(exc).__name__}: {str(exc)[:140]}")

    d = pd.DataFrame(rows)
    if not d.empty:
        d["date"] = pd.to_datetime(d["date"], errors="coerce")
        d["close"] = pd.to_numeric(d["close"], errors="coerce")
        d = d.dropna(subset=["date", "close"]).sort_values("date").drop_duplicates("date", keep="last")
        for c in ("open", "high", "low"):
            d[c] = d["close"]

    # Board history can be short when an instrument recently moved boards.  In
    # that case use market history (all boards) for the same SECID.  This is the
    # documented apimoex get_market_history fallback and avoids hard-coding TQBR
    # continuity as an assumption.
    if len(d) < 61:
        market_path = f"/iss/history/engines/stock/markets/{market}/securities/{secid}.json"
        try:
            j2, transport2 = _request_json(market_path, {
                "iss.meta": "off", "iss.only": "history",
                "from": start.isoformat(), "till": end.isoformat(),
                "history.columns": "BOARDID,TRADEDATE,CLOSE",
            })
            diag["transport"] = transport2
            extra = []
            for r in _rows(j2.get("history")):
                dt, cl = r.get("TRADEDATE"), _num(r.get("CLOSE"))
                if dt and cl is not None:
                    extra.append({"date": dt, "open": cl, "high": cl, "low": cl, "close": cl})
            if extra:
                d2 = pd.DataFrame(extra)
                d2["date"] = pd.to_datetime(d2["date"], errors="coerce")
                d2["close"] = pd.to_numeric(d2["close"], errors="coerce")
                d2 = d2.dropna(subset=["date", "close"]).sort_values("date").drop_duplicates("date", keep="last")
                for c in ("open", "high", "low"):
                    d2[c] = d2["close"]
                if len(d2) > len(d):
                    d = d2
                    diag["source"] = "MOEX ISS market history"
        except Exception as exc:
            diag["errors"].append(f"market history: {type(exc).__name__}: {str(exc)[:140]}")

    if len(d) >= 61:
        if not diag.get("source"):
            diag["source"] = "MOEX ISS board history"
        try:
            cache.write_text(json.dumps({
                "saved_at": datetime.now().isoformat(),
                "rows": [{"date": str(pd.Timestamp(r.date).date()), "open": float(r.close),
                          "high": float(r.close), "low": float(r.close), "close": float(r.close)}
                         for r in d.itertuples()]
            }, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        diag["observations"] = int(len(d))
        diag["attempts"] = list(_LAST_ATTEMPTS)[-6:]
        return d, diag

    cached = _load_history(cache)
    if len(cached) >= 61:
        diag.update(source="MOEX ISS board history · stale disk cache", observations=int(len(cached)))
        diag["attempts"] = list(_LAST_ATTEMPTS)[-6:]
        return cached, diag
    diag["observations"] = int(len(d))
    diag["attempts"] = list(_LAST_ATTEMPTS)[-6:]
    return d, diag



def candles_recent(secid: str, market: str = "shares", board: str = "TQBR",
                   calendar_days: int = 135, force: bool = False) -> pd.DataFrame:
    """Single-request recent history for instant UI forecasts.

    The live-price transport already proves that MOEX is reachable.  For a card
    probability we do not need years of candles: ~3-5 months (>60 sessions) is
    enough for the existing historical block-bootstrap direction model.  Keeping
    the window under the ISS page size avoids pagination, parallel fan-out and
    VPN/relay timeout cascades.  This function is forecast-only and does not alter
    the live quote pipeline.
    """
    secid = str(secid or "").upper().replace(".ME", "")
    safe = "".join(c for c in f"recent_{market}_{board}_{secid}" if c.isalnum() or c in "-_")
    cache = FAST_HISTORY_DIR / f"{safe}.json"
    now = time.time()
    if cache.exists() and not force and now - cache.stat().st_mtime < HISTORY_TTL:
        d = _load_history(cache)
        if len(d) >= 60:
            return d

    end = datetime.now().date()
    start = end - timedelta(days=max(110, min(int(calendar_days), 155)))
    path = f"/iss/engines/stock/markets/{market}/boards/{board}/securities/{secid}/candles.json"
    try:
        j, _ = _request_json(path, {
            "iss.meta": "off", "iss.only": "candles",
            "from": start.isoformat(), "till": end.isoformat(), "interval": 24,
            "candles.columns": "begin,open,high,low,close",
        })
        rows = []
        for r in _rows(j.get("candles")):
            rows.append({"date": r.get("begin"), "open": r.get("open"), "high": r.get("high"),
                         "low": r.get("low"), "close": r.get("close")})
        d = pd.DataFrame(rows)
        if not d.empty:
            d["date"] = pd.to_datetime(d["date"], errors="coerce")
            for c in ("open", "high", "low", "close"):
                d[c] = pd.to_numeric(d[c], errors="coerce")
            d = d.dropna(subset=["date", "close"]).sort_values("date").drop_duplicates("date", keep="last")
            if len(d) >= 60:
                try:
                    cache.write_text(json.dumps({
                        "saved_at": datetime.now().isoformat(),
                        "rows": [{"date": str(pd.Timestamp(r.date).date()), "open": float(r.open),
                                  "high": float(r.high), "low": float(r.low), "close": float(r.close)}
                                 for r in d.itertuples()]
                    }, ensure_ascii=False), encoding="utf-8")
                except Exception:
                    pass
                return d
    except Exception:
        pass
    return _load_history(cache)


def candles_fast(secid: str, market: str = "shares", board: str = "TQBR",
                 calendar_days: int = 720, force: bool = False) -> pd.DataFrame:
    """Fast daily history for UI forecasts.

    MOEX ISS gives candle data in small pages. v4.20 downloaded those pages
    sequentially, so one stock could block the forecast endpoint for tens of
    seconds behind a VPN. Here the requested window is split into date chunks
    small enough to fit into one ISS response and all chunks are fetched in
    parallel. The result is cached on disk for six hours.
    """
    secid = str(secid or "").upper().replace(".ME", "")
    safe = "".join(c for c in f"{market}_{board}_{secid}" if c.isalnum() or c in "-_")
    cache = FAST_HISTORY_DIR / f"{safe}.json"
    now = time.time()
    if cache.exists() and not force and now - cache.stat().st_mtime < HISTORY_TTL:
        d = _load_history(cache)
        if len(d) >= 250:
            return d

    end = datetime.now().date()
    start = end - timedelta(days=max(420, int(calendar_days)))
    # ~100 calendar-day chunks normally contain 65-75 trading sessions and
    # therefore stay safely below the ISS 100-row page size.
    chunks=[]; cur=start
    while cur <= end:
        till=min(end,cur+timedelta(days=99))
        chunks.append((cur.isoformat(),till.isoformat()))
        cur=till+timedelta(days=1)

    path = f"/iss/engines/stock/markets/{market}/boards/{board}/securities/{secid}/candles.json"
    def one(bounds):
        frm,till=bounds
        j,_=_request_json(path,{"iss.meta":"off","iss.only":"candles","from":frm,"till":till,
                              "interval":24,"candles.columns":"begin,open,high,low,close"})
        return _rows(j.get("candles"))

    rows=[]
    # 7-ish requests complete in roughly one network round-trip instead of 7
    # serial round-trips. Keep the pool bounded to avoid hammering ISS/relay.
    with ThreadPoolExecutor(max_workers=min(6,max(1,len(chunks)))) as ex:
        fut=[ex.submit(one,c) for c in chunks]
        for f in as_completed(fut):
            try:
                for r in f.result() or []:
                    rows.append({"date":r.get("begin"),"open":r.get("open"),"high":r.get("high"),
                                 "low":r.get("low"),"close":r.get("close")})
            except Exception:
                continue

    d=pd.DataFrame(rows)
    if not d.empty:
        d["date"]=pd.to_datetime(d["date"],errors="coerce")
        for c in ("open","high","low","close"): d[c]=pd.to_numeric(d[c],errors="coerce")
        d=d.dropna(subset=["date","close"]).sort_values("date").drop_duplicates("date",keep="last")
        if len(d)>=60:
            try:
                cache.write_text(json.dumps({"saved_at":datetime.now().isoformat(),
                    "rows":[{"date":str(pd.Timestamp(r.date).date()),"open":float(r.open),"high":float(r.high),
                             "low":float(r.low),"close":float(r.close)} for r in d.itertuples()]},
                    ensure_ascii=False),encoding="utf-8")
            except Exception:
                pass
            return d
    return _load_history(cache)


def candles(secid: str, market: str = "shares", board: str = "TQBR", years: int = 5, force: bool = False) -> pd.DataFrame:
    secid = str(secid or "").upper().replace(".ME", "")
    cache = _history_path(market, board, secid); now = time.time()
    if cache.exists() and not force and now - cache.stat().st_mtime < HISTORY_TTL:
        d = _load_history(cache)
        if not d.empty: return d
    start_date = (datetime.now() - timedelta(days=max(2, years) * 366)).date().isoformat()
    path = f"/iss/engines/stock/markets/{market}/boards/{board}/securities/{secid}/candles.json"
    rows, offset = [], 0
    try:
        for _ in range(16):
            j, _ = _request_json(path, {"iss.meta":"off", "iss.only":"candles", "from":start_date,
                                        "interval":24, "start":offset,
                                        "candles.columns":"begin,open,high,low,close"})
            page = _rows(j.get("candles"))
            if not page: break
            for r in page:
                rows.append({"date":r.get("begin"),"open":r.get("open"),"high":r.get("high"),
                             "low":r.get("low"),"close":r.get("close")})
            offset += len(page)
            if len(page) < 100: break
        d = pd.DataFrame(rows)
        if not d.empty:
            d["date"] = pd.to_datetime(d["date"], errors="coerce")
            for c in ("open","high","low","close"): d[c] = pd.to_numeric(d[c], errors="coerce")
            d = d.dropna(subset=["date","close"]).sort_values("date")
            if not d.empty:
                cache.write_text(json.dumps({"saved_at":datetime.now().isoformat(),
                                             "rows":[{"date":str(pd.Timestamp(r.date).date()),
                                                      "open":float(r.open),"high":float(r.high),
                                                      "low":float(r.low),"close":float(r.close)}
                                                     for r in d.itertuples()]}, ensure_ascii=False), encoding="utf-8")
                return d
    except Exception:
        pass
    return _load_history(cache)
