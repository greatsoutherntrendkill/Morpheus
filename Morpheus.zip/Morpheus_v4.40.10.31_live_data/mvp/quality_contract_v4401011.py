"""Publication contract: evidence about an intermediate model is not final validation."""
from copy import deepcopy
import math

VERSION = 'published-quality-v4.40.10.16'
UNCONFIRMED = 'Надёжность не подтверждена'

def probability(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) and 0 <= value <= 1 else None

def distribution(result):
    out = deepcopy(result or {})
    if out.get('status') != 'ok':
        return out
    # Current audits precede deployment postprocessing; preserve them as diagnostics.
    evaluation = out.get('evaluation') or {}
    final = (evaluation.get('scope') == 'final_published_pipeline'
             and evaluation.get('contract_version') == VERSION
             and evaluation.get('temporal_validation_passed') is True)
    if not final:
        if evaluation and evaluation.get('scope') != 'not_validated':
            out['development_evaluation'] = evaluation
        out['evaluation'] = {'scope': 'not_validated', 'contract_version': VERSION,
                             'reason': 'Окончательный диапазон требует отдельной проверки на истории.'}
        out['quality_ok'] = False
    out['quality_contract_version'] = VERSION
    out['validation_status'] = 'validated' if final else 'unconfirmed'
    return out

def forecast(result):
    out = deepcopy(result or {})
    rel = out.get('reliability') if isinstance(out.get('reliability'), dict) else {}
    out['reliability'] = rel
    final = out.get('final_evaluation') or {}
    validated = (final.get('contract_version') == VERSION
                 and final.get('scope') == 'final_published_pipeline'
                 and final.get('passed') is True)
    confidence = probability(rel.get('probability'))
    valid_rel = (validated and rel.get('trained') is True
                 and rel.get('validated_on_untouched_eval') is True and confidence is not None)
    out['confidence_score'] = confidence if valid_rel else None
    out['confidence_status'] = 'validated' if valid_rel else 'unconfirmed'
    out['confidence'] = (f'{confidence:.0%}' if valid_rel else 'не подтверждена')
    out['confidence_note'] = ('Проверена на независимых прогнозах.' if valid_rel else
                              'Недостаточно независимых проверок окончательного прогноза.')
    if rel and not valid_rel:
        rel['probability'] = None
        rel['publication_status'] = 'unconfirmed'
        out['reliability'] = rel
    p = probability(out.get('p_up'))
    threshold = probability(out.get('signal_threshold'))
    reasons = []
    if p is None:
        reasons.append('Нет расчёта направления.')
    elif threshold is not None and max(p, 1-p) < threshold:
        reasons.append('Окончательный перевес ниже порога публикации.')
    if out.get('event_signal_guard') or (out.get('macro_events') or {}).get('signal_guard'):
        reasons.append('Повышен событийный риск.')
    if out.get('abstain') and not reasons:
        reasons.append('Модель воздерживается от направленного сигнала.')
    out['abstain'] = bool(reasons)
    q = dict(out.get('quality') or {})
    q.update(trusted=bool(validated and not reasons),
             confidence=out['confidence'],
             bias='neutral' if reasons else ('bullish' if p >= .5 else 'bearish'),
             reason=' '.join(reasons) if reasons else ('Проверка пройдена.' if validated else UNCONFIRMED))
    out['quality'] = q
    if not validated:
        out['status_text'] = UNCONFIRMED
    out['forecast_status'] = ('нет данных' if p is None else 'нет преимущества' if reasons else
                     'подтверждён' if validated else 'исследовательская оценка')
    if out.get('status') not in ('ok', 'unavailable', 'insufficient_history'):
        out['status'] = out['forecast_status']
    if reasons:
        out['signal_strength'] = 'нет преимущества'
        if p is not None and 'summary' in out:
            classes = out.get('class_probabilities') or {}
            values = [probability(classes.get(k)) for k in ('up','neutral','down')]
            lead = (f'Значимый рост: {values[0]:.0%}, нейтральное движение: {values[1]:.0%}, снижение: {values[2]:.0%}. '
                    if all(v is not None for v in values) else '')
            out['summary'] = lead + 'Направленный сигнал не публикуется. ' + ' '.join(reasons[:2])
    elif threshold is not None:
        strength = max(p, 1-p)
        out['signal_strength'] = 'выраженный' if strength >= .72 else 'умеренный' if strength >= max(.64, threshold) else 'слабый'
    if out.get('distribution_forecast'):
        out['distribution_forecast'] = distribution(out['distribution_forecast'])
    guidance = out.get('movement_guidance') or {}
    if guidance and not (out.get('distribution_forecast') or {}).get('quality_ok'):
        guidance.update(distribution_quality_ok=False, range_status='unconfirmed',
                        directional_scenario_range=None, reason='Окончательный диапазон ещё не прошёл независимую проверку.')
        out['movement_guidance'] = guidance
    explanation = out.get('ensemble_explanation') or {}
    if explanation:
        out['ensemble_explanation'] = {'publication_note': q['reason']}
    out['quality_contract_version'] = VERSION
    return out

def snapshot(data):
    out = deepcopy(data)
    for asset in out.get('assets', []):
        for field in ('unified_forecast_v39', 'forecasts', 'live_market_forecasts', 'model_horizons'):
            if isinstance(asset.get(field), dict):
                def current(f):
                    if not isinstance(f,dict):return f
                    from forecast_contract_v4406 import MODEL_GENERATION
                    if f.get('model_generation') != MODEL_GENERATION:
                        return forecast({'p_up':None,'status':'unavailable','requires_recalculation':True,
                                         'summary':'Обновляем расчёт после изменения проверки истории.'})
                    return forecast(f)
                asset[field] = {h: current(f) for h, f in asset[field].items()}
    out['quality_contract_version'] = VERSION
    return out
