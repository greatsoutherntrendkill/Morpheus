import unittest,time,tempfile
from threading import Event
from pathlib import Path
from live_quotes_v31 import QuoteService,utc,single_quote
from unittest.mock import patch

class QuotesTest(unittest.TestCase):
 def setUp(self):
  self.now=[1793444400.0];self.s=QuoteService(clock=lambda:self.now[0]);self.s.register([{'symbol':'BTC-USD'},{'symbol':'AAPL'}])
 def tearDown(self):self.s.close()
 def test_cross_rate_uses_older_input_timestamp(self):
  def provider(url,params=None):
   rub='RUB%3DX' in url
   return {'chart':{'result':[{'meta':{'regularMarketPrice':80 if rub else 8,'regularMarketTime':self.now[0]-(100 if rub else 0)}}]}}
  with patch('live_quotes_v31.get_json',provider):q=single_quote('CNYRUB')
  self.assertEqual(q['last'],10);self.assertEqual(q['as_of'],utc(self.now[0]-100))
 def test_no_snapshot_as_live(self):
  self.s.register([{'symbol':'AAPL','last':99,'as_of':'2026-09-04'}]);self.assertIsNone(self.s.snapshot()['quotes'][1]['last'])
 def test_old_and_future_prices_rejected(self):
  for ts in [self.now[0]-60*86400,self.now[0]+3600]:
   self.s._store('AAPL',{'last':100,'as_of':utc(ts)});self.assertIsNone(self.s.snapshot(['AAPL'])['quotes'][0]['last'])
 def test_crypto_expiry_and_market_close(self):
  self.s._store('BTC-USD',{'last':100,'as_of':utc(self.now[0])});self.now[0]+=181
  self.assertIsNone(self.s.snapshot(['BTC-USD'])['quotes'][0]['last'])
  self.s._store('AAPL',{'last':100,'as_of':utc(self.now[0]-86400)})
  q=self.s.snapshot(['AAPL'])['quotes'][0];self.assertEqual(q['status'],'latest_trade');self.assertFalse(q['stale'])
 def test_failure_preserves_value_but_not_freshness(self):
  self.s._store('AAPL',{'last':100,'as_of':utc(self.now[0])});self.s._store('AAPL',None,'HTTP 429')
  q=self.s.snapshot(['AAPL'])['quotes'][0];self.assertEqual(q['last'],100);self.assertTrue(q['stale']);self.assertEqual(q['error'],'HTTP 429')
 def test_no_time_renewal_on_read(self):
  self.s._store('AAPL',{'last':100,'as_of':utc(self.now[0])});before=self.s.snapshot(['AAPL'])['quotes'][0]['fetched_at'];self.now[0]+=100
  q=self.s.snapshot(['AAPL'])['quotes'][0];self.assertTrue(q['stale']);self.assertEqual(q['fetched_at'],before)
 def test_out_of_order(self):
  self.s._store('AAPL',{'last':101,'as_of':utc(self.now[0])});self.s._store('AAPL',{'last':99,'as_of':utc(self.now[0]-100)})
  self.assertEqual(self.s.snapshot(['AAPL'])['quotes'][0]['last'],101)
 def test_slow_provider_does_not_block_fast(self):
  gate=Event();fast=Event()
  def fetch(sym):
   if sym=='AAPL':gate.wait(2)
   else:fast.set()
   return {'last':100,'as_of':utc(self.now[0])}
  self.s.fetch=fetch;start=time.monotonic();self.s.refresh();self.assertLess(time.monotonic()-start,.2);fast.wait(1)
  for _ in range(100):
   if self.s.snapshot(['BTC-USD'])['quotes'][0]['last'] is not None:break
   time.sleep(.005)
  self.assertEqual(self.s.snapshot(['BTC-USD'])['quotes'][0]['last'],100);self.assertTrue(self.s.snapshot(['AAPL'])['refreshing']);gate.set()
 def test_one_minute_and_no_duplicate_requests(self):
  calls=[];done=Event()
  def fetch(sym):calls.append(sym);done.set();return {'last':100,'as_of':utc(self.now[0])}
  self.s.fetch=fetch;self.s.refresh(only=['AAPL']);done.wait(1);time.sleep(.02)
  self.s.refresh(only=['AAPL']);self.assertEqual(len(calls),1)
  self.now[0]+=60;self.s.refresh(only=['AAPL']);time.sleep(.02);self.assertEqual(len(calls),2)
 def test_restart_cache_not_fresh_forever(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'quotes.json';s=QuoteService(clock=lambda:self.now[0],cache_path=p);s.register([{'symbol':'AAPL'}]);s._store('AAPL',{'last':100,'as_of':utc(self.now[0])});s.close()
   self.now[0]+=120;r=QuoteService(clock=lambda:self.now[0],cache_path=p);r.register([{'symbol':'AAPL'}]);self.assertTrue(r.snapshot()['quotes'][0]['stale']);r.close()
if __name__=='__main__':unittest.main()
