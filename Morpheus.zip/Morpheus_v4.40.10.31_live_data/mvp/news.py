"""Morpheus news intelligence layer.

Server-side only:
- News API retrieves fresh market/macro headlines.
- A deterministic finance filter removes noise, deduplicates and ranks stories.
- Each story is tagged with event class, affected assets, financial sentiment,
  transmission channels and an impact score.
- Pexels is used only as a labelled illustration fallback when the publisher did
  not provide an image. API keys never reach the public site payload.

This is intentionally an interpretable filter rather than an LLM-generated
trading signal. News context does not override the model quality gate.
"""
from __future__ import annotations

import os
import hashlib
from functools import lru_cache
import re
import math
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from urllib.parse import urlparse
from pathlib import Path

import pandas as pd
import requests
from PIL import Image

try:
    from deep_translator import GoogleTranslator
except Exception:
    GoogleTranslator = None

import config as C
from dotenv import load_dotenv

load_dotenv()

TIMEOUT = 20
DEFAULT_MAX_AGE_HOURS = 120
DEFAULT_MIN_SCORE = 30
MAX_LIVE_RAW = 80
MAX_OUTPUT = 14

# Asset/entity resolver. Values refer only to symbols already supported by Morpheus.
INSTR_KW = {
    "bitcoin": ["BTC-USD"], "btc": ["BTC-USD"], "биткоин": ["BTC-USD"],
    "ethereum": ["ETH-USD"], "ether": ["ETH-USD"], "эфир": ["ETH-USD"],
    "solana": ["SOL-USD"], "xrp": ["XRP-USD"], "crypto": ["BTC-USD", "ETH-USD"],
    "крипто": ["BTC-USD", "ETH-USD"],
    "gold": ["GC=F"], "золот": ["GC=F"], "silver": ["SI=F"], "сереб": ["SI=F"],
    "oil": ["CL=F"], "crude": ["CL=F"], "нефть": ["CL=F"], "opec": ["CL=F"], "опек": ["CL=F"],
    "natural gas": ["NG=F"], "природн": ["NG=F"], "copper": ["HG=F"], "медь": ["HG=F"],
    "s&p": ["^GSPC", "ES=F"], "sp500": ["^GSPC", "ES=F"], "s&p 500": ["^GSPC", "ES=F"],
    "russell 2000": ["^RUT"], "small cap": ["^RUT"], "small-cap": ["^RUT"],
    "nasdaq": ["^NDX", "NQ=F"], "dow jones": ["^DJI"], "wall street": ["^GSPC", "^NDX", "^DJI"],
    "stocks": ["^GSPC", "^NDX"], "equities": ["^GSPC", "^NDX"], "акции": ["^GSPC", "^NDX"],
    "dax": ["^GDAXI"], "ftse": ["^FTSE"], "cac 40": ["^FCHI"], "stoxx": ["^STOXX50E"], "nikkei": ["^N225"],
    "hang seng": ["^HSI"],
    "dollar": ["DX-Y.NYB"], "доллар": ["DX-Y.NYB"], "dxy": ["DX-Y.NYB"],
    "euro": ["EURUSD=X"], "евро": ["EURUSD=X"], "pound": ["GBPUSD=X"], "фунт": ["GBPUSD=X"],
    "yen": ["JPY=X"], "иена": ["JPY=X"], "yuan": ["CNYRUB"], "юан": ["CNYRUB"],
    "ruble": ["RUB=X", "IMOEX", "RGBI"], "rouble": ["RUB=X", "IMOEX", "RGBI"],
    "рубл": ["RUB=X", "IMOEX", "RGBI"], "moscow exchange": ["IMOEX", "RGBI"], "мосбирж": ["IMOEX", "RGBI"],
    "fed": ["^GSPC", "^NDX", "^DJI", "^RUT", "ES=F", "NQ=F", "DX-Y.NYB", "GC=F"], "federal reserve": ["^GSPC", "^NDX", "^DJI", "^RUT", "ES=F", "NQ=F", "DX-Y.NYB", "GC=F"],
    "фрс": ["^GSPC", "^NDX", "^DJI", "^RUT", "ES=F", "NQ=F", "DX-Y.NYB", "GC=F"], "ecb": ["EURUSD=X", "^STOXX50E", "^GDAXI", "^FCHI"], "ецб": ["EURUSD=X", "^STOXX50E", "^GDAXI", "^FCHI"],
    "bank of england": ["^FTSE", "GBPUSD=X"], "boe": ["^FTSE", "GBPUSD=X"], "банк англии": ["^FTSE", "GBPUSD=X"],
    "bank of japan": ["^N225", "JPY=X"], "boj": ["^N225", "JPY=X"], "банк японии": ["^N225", "JPY=X"],
    "people’s bank of china": ["^HSI", "CNYRUB"], "peoples bank of china": ["^HSI", "CNYRUB"], "pboc": ["^HSI", "CNYRUB"], "народн банк кит": ["^HSI", "CNYRUB"],
    "bank of russia": ["RUB=X", "IMOEX", "RTSI", "MOEXBC", "RGBI"], "банк россии": ["RUB=X", "IMOEX", "RTSI", "MOEXBC", "RGBI"], "цб рф": ["RUB=X", "IMOEX", "RTSI", "MOEXBC", "RGBI"],
    "treasury": ["^GSPC", "DX-Y.NYB", "GC=F"], "bond yields": ["^GSPC", "DX-Y.NYB", "GC=F"],
    "доходност": ["^GSPC", "DX-Y.NYB", "GC=F"], "облигац": ["RGBI", "^GSPC"],
    "sanction": ["RUB=X", "IMOEX", "CL=F"], "санкц": ["RUB=X", "IMOEX", "CL=F"],
}

CAT_KW = {
    "war": ["war", "conflict", "military", "missile", "attack", "ceasefire", "война", "конфликт", "удар", "перемир"],
    "sanctions": ["sanction", "embargo", "restriction", "санкц", "эмбарго", "ограничен"],
    "trade": ["tariff", "trade war", "export control", "import duty", "тариф", "торгов", "экспортн", "пошлин"],
    "crypto": ["bitcoin", "btc", "ethereum", "ether", "crypto", "stablecoin", "биткоин", "эфир", "крипт"],
    "energy": ["oil", "crude", "opec", "natural gas", "lng", "refinery", "нефть", "газ", "опек", "энерг"],
    "macro": ["inflation", "cpi", "pce", "gdp", "payroll", "jobs report", "unemployment", "pmi", "recession",
              "fed", "federal reserve", "ecb", "central bank", "rate cut", "rate hike", "yield",
              "инфляц", "ввп", "занятост", "безработ", "фрс", "ецб", "центробанк", "ставк", "доходност", "pmi"],
    "corporate": ["earnings", "revenue", "profit", "guidance", "shares", "stock", "ipo", "merger", "acquisition",
                  "отчёт", "выручк", "прибыл", "акци", "ipo", "слиян", "поглощ"],
}
CAT_RU = {
    "war": "геополитика", "sanctions": "санкции", "trade": "торговля",
    "crypto": "крипто", "energy": "энергия", "macro": "макро и ставки",
    "corporate": "рынки и компании", "other": "рынки",
}
CAT_EMOJI = {"war": "◆", "sanctions": "◆", "trade": "◆", "crypto": "₿", "energy": "●", "macro": "◆", "corporate": "■", "other": "·"}

FINANCE_ANCHORS = [
    "market", "markets", "stock", "stocks", "equities", "bond", "yield", "treasury", "futures", "currency", "forex",
    "inflation", "cpi", "pce", "gdp", "fed", "federal reserve", "ecb", "central bank", "rate", "recession", "payroll",
    "bitcoin", "crypto", "oil", "crude", "gold", "opec", "tariff", "sanction", "earnings", "revenue", "profit",
    "рынок", "акци", "облигац", "доходност", "валют", "инфляц", "ставк", "фрс", "ецб", "ввп", "нефть", "золот",
    "биткоин", "крипт", "санкц", "тариф", "прибыл", "выручк",
]
ERROR_PAGE_KW = [
    "server error", "that's an error", "that’s an error", "there was an error",
    "please try again later", "that's all we know", "that’s all we know",
    "bad gateway", "service unavailable", "access denied", "page not found",
    "internal server error", "temporarily unavailable", "ошибка сервера",
]
ERROR_CODE_RE = re.compile(r"(?:^|\D)(?:4\d\d|5\d\d)(?:\D|$)", re.I)
BLOCKED_SOURCE_TOKENS = ["biztoc"]
FORCE_PEXELS_SOURCE_TOKENS = ["mail.ru", "mail ru", "news.mail.ru"]

NOISE_KW = [
    "football", "soccer", "nba", "nfl", "tennis", "celebrity", "movie", "recipe", "gaming review", "fashion",
    "футбол", "хоккей", "теннис", "кино", "рецепт", "мода", "звезд", "гороскоп",
]
POSITIVE = ["rally", "surge", "gain", "rise", "record high", "beats estimates", "cooling inflation", "rate cut", "dovish", "ceasefire",
            "рост", "вырос", "ралли", "рекорд", "выше ожиданий", "замедлен инфляц", "снижен ставк", "перемир"]
NEGATIVE = ["selloff", "slump", "drop", "fall", "crash", "misses estimates", "hot inflation", "rate hike", "hawkish", "recession",
            "war escalat", "sanctions tighten", "default", "crisis", "распродаж", "обвал", "паден", "ниже ожиданий", "ускорен инфляц",
            "повышен ставк", "эскалац", "ужесточен санкц", "дефолт", "кризис"]

TRUSTED_SOURCE_TOKENS = [
    "reuters", "associated press", "ap news", "financial times", "bloomberg", "cnbc", "wall street journal", "wsj",
    "bbc", "the economist", "marketwatch", "barron's", "fortune", "forbes", "business insider", "coindesk",
    "рбк", "коммерсант", "интерфакс", "ведомости", "тасс",
]

CHANNELS = {
    "macro": "ставки, доходности и ожидания по ликвидности",
    "energy": "предложение, запасы и инфляционный канал сырья",
    "crypto": "риск-аппетит, ликвидность и крипто-потоки",
    "war": "геополитическая премия, сырьё и risk-off",
    "sanctions": "торговые ограничения, валютные потоки и риск-премия",
    "trade": "тарифы, цепочки поставок и маржинальность компаний",
    "corporate": "прибыли, guidance и переоценка equity risk premium",
    "other": "общий рыночный риск-аппетит",
}

PEXELS_QUERY = {
    "macro": "financial markets trading screens",
    "energy": "oil refinery energy market",
    "crypto": "bitcoin cryptocurrency finance",
    "war": "global geopolitics city",
    "sanctions": "global trade cargo containers",
    "trade": "shipping containers global trade",
    "corporate": "stock market business finance",
    "other": "financial markets city trading",
}


def _low(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "").lower()).strip()


def is_error_payload(*parts) -> bool:
    """Catch error-page garbage before and after translation."""
    t = _low(" ".join(str(x or "") for x in parts))
    t = t.replace("’", "'").replace("!!1", " ").replace("!1", " ")
    if any(k.replace("’", "'") in t for k in ERROR_PAGE_KW):
        return True
    if ERROR_CODE_RE.search(t) and any(w in t for w in ("error", "ошиб", "server", "gateway")):
        return True
    return False


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.getenv(name, "1" if default else "0").strip().lower()
    return v in {"1", "true", "yes", "on"}


def categorize(text: str) -> str:
    t = _low(text)
    scores = {cat: sum(1 for k in kws if k in t) for cat, kws in CAT_KW.items()}
    cat, score = max(scores.items(), key=lambda kv: kv[1])
    return cat if score else "other"


def affected(text: str) -> list[str]:
    t = _low(text)
    syms: list[str] = []
    for kw, ss in INSTR_KW.items():
        if kw in t:
            for s in ss:
                if s not in syms:
                    syms.append(s)
    return syms


def financial_sentiment(text: str, cat: str) -> tuple[float, str]:
    """Interpretable market-context sentiment in [-1, 1], not price prediction."""
    t = _low(text)
    pos = sum(1 for w in POSITIVE if w in t)
    neg = sum(1 for w in NEGATIVE if w in t)
    # Event priors are deliberately small; explicit language dominates.
    prior = {"war": -0.22, "sanctions": -0.18, "trade": -0.10, "macro": 0.0,
             "energy": 0.0, "crypto": 0.0, "corporate": 0.0, "other": 0.0}.get(cat, 0.0)
    raw = (pos - neg) * 0.34 + prior
    score = max(-1.0, min(1.0, raw))
    label = "risk-on" if score >= 0.20 else "risk-off" if score <= -0.20 else "mixed"
    return round(score, 2), label


def direction(text: str, cat: str) -> int:
    score, _ = financial_sentiment(text, cat)
    return 1 if score >= 0.20 else -1 if score <= -0.20 else 0


def transmission_channels(text: str, cat: str) -> list[str]:
    t = _low(text)
    out = [CHANNELS.get(cat, CHANNELS["other"])]
    if any(k in t for k in ("inflation", "cpi", "pce", "инфляц")):
        out.append("инфляционные ожидания → ставки → мультипликаторы")
    if any(k in t for k in ("dollar", "dxy", "доллар", "currency", "валют")):
        out.append("валютный канал и стоимость фондирования")
    if any(k in t for k in ("treasury", "yield", "bond", "доходност", "облигац")):
        out.append("доходности облигаций и discount rate")
    if any(k in t for k in ("oil", "crude", "opec", "нефть", "опек")) and cat != "energy":
        out.append("нефтяная риск-премия и инфляционный канал")
    # preserve order, max 3
    return list(dict.fromkeys(out))[:3]


def _parse_published(v: str):
    s = str(v or "").strip()
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception:
        try:
            return pd.to_datetime(s, utc=True).to_pydatetime()
        except Exception:
            return None


def _freshness(published: str, max_age_hours: int = DEFAULT_MAX_AGE_HOURS) -> tuple[float, float | None]:
    dt = _parse_published(published)
    if not dt:
        return 0.25, None
    age = max(0.0, (datetime.now(timezone.utc) - dt).total_seconds() / 3600.0)
    # 1 now, ~0.5 at half-window, low at the edge.
    freshness = max(0.0, 1.0 - age / max_age_hours)
    return freshness, round(age, 1)


def _source_bonus(source: str) -> int:
    s = _low(source)
    return 9 if any(tok in s for tok in TRUSTED_SOURCE_TOKENS) else 0


def _canonical_title(title: str) -> str:
    t = _low(title)
    t = re.sub(r"\s*[-–—|:]\s*(reuters|bloomberg|cnbc|bbc|rbc|рбк|тасс|коммерсант).*$", "", t)
    t = re.sub(r"[^a-zа-яё0-9 ]+", " ", t)
    t = re.sub(r"\b(the|a|an|and|or|of|to|in|on|for|с|и|в|на|о|об|про)\b", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def _is_duplicate(title: str, seen: list[str]) -> bool:
    can = _canonical_title(title)
    if not can:
        return True
    for old in seen:
        if can == old or SequenceMatcher(None, can, old).ratio() >= 0.82:
            return True
    seen.append(can)
    return False


def _relevance(text: str, cat: str, syms: list[str], source: str, published: str, max_age_hours: int) -> tuple[int, float | None]:
    t = _low(text)
    if any(k in t for k in NOISE_KW):
        return 0, None
    anchor_hits = sum(1 for k in FINANCE_ANCHORS if k in t)
    cat_hits = sum(1 for k in CAT_KW.get(cat, []) if k in t)
    freshness, age = _freshness(published, max_age_hours)
    if age is not None and age > max_age_hours:
        return 0, age
    score = min(34, anchor_hits * 5) + min(20, cat_hits * 5) + min(22, len(syms) * 6)
    score += 12 if cat != "other" else 0
    score += _source_bonus(source)
    score += round(freshness * 16)
    return int(min(100, score)), age


def _newsapi_request(api_key: str, language: str, q: str) -> list[dict]:
    since = (datetime.now(timezone.utc) - timedelta(days=3)).strftime("%Y-%m-%dT%H:%M:%S")
    try:
        r = requests.get(
            "https://newsapi.org/v2/everything",
            timeout=TIMEOUT,
            headers={"X-Api-Key": api_key},
            params={
                "q": q,
                "searchIn": "title,description",
                "language": language,
                "from": since,
                "sortBy": "publishedAt",
                "pageSize": 50,
            },
        )
        data = r.json()
        if r.status_code != 200 or data.get("status") != "ok":
            print(f"  [news] newsapi/{language}: HTTP {r.status_code} {data.get('code','')} {data.get('message','')[:120]}")
            return []
        return [{
            "title": a.get("title", ""),
            "summary": a.get("description", "") or "",
            "image": a.get("urlToImage", "") or "",
            "url": a.get("url", "") or "",
            "source": (a.get("source") or {}).get("name", "") or "",
            "published": a.get("publishedAt", "") or "",
            "provider": "newsapi",
        } for a in data.get("articles", [])]
    except Exception as e:
        print(f"  [news] newsapi/{language}: ошибка {type(e).__name__}: {str(e)[:120]}")
        return []


def fetch_live(api_key: str, provider: str = "newsapi") -> list[dict]:
    """Fetch Russian finance news by default. English is optional and fail-closed."""
    if provider != "newsapi":
        try:
            r = requests.get("https://gnews.io/api/v4/top-headlines", timeout=TIMEOUT,
                             params={"category": "business", "lang": "ru", "max": 30, "apikey": api_key})
            arts = r.json().get("articles", [])
            return [{"title": a.get("title", ""), "summary": a.get("description", "") or "",
                     "image": a.get("image", "") or "", "url": a.get("url", "") or "",
                     "source": (a.get("source") or {}).get("name", "") or "",
                     "published": a.get("publishedAt", "") or "", "provider": "gnews"} for a in arts]
        except Exception as e:
            print(f"  [news] gnews: ошибка {type(e).__name__}: {str(e)[:120]}")
            return []

    q_ru = '(рынок OR акции OR облигации OR инфляция OR ФРС OR ЕЦБ OR ставка OR биткоин OR крипто OR нефть OR ОПЕК OR золото OR тарифы OR санкции OR рубль OR Мосбиржа OR доллар)'
    rows = _newsapi_request(api_key, "ru", q_ru)
    if _bool_env("NEWS_INCLUDE_ENGLISH", False):
        q_en = '(markets OR stocks OR bonds OR inflation OR CPI OR "Federal Reserve" OR ECB OR "rate cut" OR "rate hike" OR bitcoin OR ethereum OR oil OR OPEC OR gold OR tariffs OR sanctions OR recession)'
        rows += _newsapi_request(api_key, "en", q_en)
    return rows[:MAX_LIVE_RAW]


def _seed_dir(v):
    m = {"up": 1, "рост": 1, "down": -1, "падение": -1, "neutral": 0, "нейтрально": 0}
    return m.get(str(v).strip().lower()) if pd.notna(v) and str(v).strip() else None


def load_seed() -> list[dict]:
    try:
        df = pd.read_csv(C.NEWS_SEED)
        out = []
        for _, r in df.iterrows():
            item = {"title": r["title"], "summary": r.get("summary", "") or "",
                    "image": r.get("image", "") if isinstance(r.get("image", ""), str) else "",
                    "url": r.get("url", "") if isinstance(r.get("url", ""), str) else "",
                    "source": r.get("source", "") if isinstance(r.get("source", ""), str) else "",
                    "published": str(r.get("date", "")), "provider": "seed",
                    "category": r.get("category", "") if isinstance(r.get("category", ""), str) else "",
                    "affected": [s for s in str(r.get("affected", "")).split("|") if s] if pd.notna(r.get("affected", "")) else []}
            if "dir" in df.columns:
                dv = _seed_dir(r.get("dir"))
                if dv is not None:
                    item["dir"] = dv
            out.append(item)
        return out
    except Exception:
        return []


def filter_and_rank(items: list[dict], assets: list[dict], min_score: int = DEFAULT_MIN_SCORE,
                    max_age_hours: int = DEFAULT_MAX_AGE_HOURS) -> list[dict]:
    name_by_sym = {a["symbol"]: a["name"] for a in assets}
    candidates = []
    for it in items:
        title = str(it.get("title", "") or "").strip()
        summary = str(it.get("summary", "") or "").strip()
        if not title or title == "[Removed]" or len(title) < 12:
            continue
        text = title + " " + summary
        low_text = _low(text)
        low_source = _low(it.get("source", ""))
        if is_error_payload(title, summary):
            continue
        if any(k in low_source for k in BLOCKED_SOURCE_TOKENS):
            continue
        cat = it.get("category") or categorize(text)
        syms = it.get("affected") or affected(text)
        syms = [s for s in syms if s in name_by_sym][:6]
        rel, age = _relevance(text, cat, syms, it.get("source", ""), it.get("published", ""), max_age_hours)
        # Seed rows are manually curated and may not have a precise publication timestamp.
        if it.get("provider") == "seed":
            rel = max(rel, 45)
        if rel < min_score:
            continue
        sent_score, sent_label = financial_sentiment(text, cat)
        d = it["dir"] if it.get("dir") is not None else (1 if sent_score >= .2 else -1 if sent_score <= -.2 else 0)
        impact = int(min(100, round(rel * .72 + abs(sent_score) * 18 + min(10, len(syms) * 2))))
        candidates.append({
            "title": title,
            "summary": summary[:230],
            "image": it.get("image", "") or "",
            "image_source": "publisher" if it.get("image") else "none",
            "source": it.get("source", "") or "",
            "url": it.get("url", "") or "",
            "published": str(it.get("published", "") or ""),
            "age_hours": age,
            "category": cat,
            "cat_ru": CAT_RU.get(cat, cat),
            "emoji": CAT_EMOJI.get(cat, "·"),
            "dir": d,
            "sentiment_score": sent_score,
            "sentiment_label": sent_label,
            "impact_label": "risk-on" if d > 0 else "risk-off" if d < 0 else "mixed",
            "relevance_score": rel,
            "impact_score": impact,
            "channels": transmission_channels(text, cat),
            "affected": [{"symbol": s, "name": name_by_sym[s]} for s in syms],
            "provider": it.get("provider", ""),
        })

    candidates.sort(key=lambda x: (x["impact_score"], x["relevance_score"], -(x.get("age_hours") or 0)), reverse=True)
    seen: list[str] = []
    out = []
    for row in candidates:
        if _is_duplicate(row["title"], seen):
            continue
        out.append(row)
        if len(out) >= MAX_OUTPUT:
            break
    return out


def _pexels_search(api_key: str, query: str, per_page: int = 6) -> list[dict]:
    try:
        r = requests.get(
            "https://api.pexels.com/v1/search",
            timeout=TIMEOUT,
            headers={"Authorization": api_key},
            params={"query": query, "orientation": "landscape", "color": "green", "per_page": per_page},
        )
        data = r.json()
        if r.status_code != 200:
            print(f"  [news] pexels: HTTP {r.status_code} {str(data)[:120]}")
            return []
        out = []
        for p in data.get("photos", []):
            src = p.get("src") or {}
            out.append({
                "image": src.get("landscape") or src.get("large") or src.get("medium") or "",
                "photographer": p.get("photographer", ""),
                "photographer_url": p.get("photographer_url", ""),
                "page_url": p.get("url", ""),
                "alt": p.get("alt", ""),
            })
        return [x for x in out if x["image"]]
    except Exception as e:
        print(f"  [news] pexels: ошибка {type(e).__name__}: {str(e)[:120]}")
        return []


def enrich_images(items: list[dict], pexels_key: str) -> list[dict]:
    if not pexels_key:
        return items
    # One request per visual category, not per article, to stay well within Pexels limits.
    pools: dict[str, list[dict]] = {}
    used: dict[str, int] = {}
    for item in items:
        if item.get("image"):
            continue
        q = PEXELS_QUERY.get(item.get("category"), PEXELS_QUERY["other"])
        if q not in pools:
            pools[q] = _pexels_search(pexels_key, q)
            used[q] = 0
        pool = pools[q]
        if not pool:
            continue
        idx = used[q] % len(pool)
        used[q] += 1
        p = pool[idx]
        item.update({
            "image": p["image"],
            "image_source": "pexels",
            "image_is_illustration": True,
            "image_credit_name": p.get("photographer", ""),
            "image_credit_url": p.get("photographer_url", ""),
            "image_page_url": p.get("page_url", ""),
            "image_alt": p.get("alt", ""),
        })
    return items





def _looks_russian(text: str) -> bool:
    text = str(text or "")
    return bool(re.search(r"[А-Яа-яЁё]", text))


@lru_cache(maxsize=1024)
def translate_to_ru(text: str) -> str:
    text = str(text or "").strip()
    if not text or _looks_russian(text):
        return text
    if not _bool_env("NEWS_TRANSLATE_ENGLISH", False) or GoogleTranslator is None:
        return ""
    try:
        out = str(GoogleTranslator(source="auto", target="ru").translate(text) or "").strip()
        if not out or not _looks_russian(out) or is_error_payload(out):
            return ""
        return out
    except Exception:
        return ""


def localize_rows_ru(rows: list[dict]) -> list[dict]:
    out = []
    for row in rows or []:
        item = dict(row)
        title = str(item.get("title", "") or "").strip()
        summary = str(item.get("summary", "") or "").strip()
        if is_error_payload(title, summary):
            continue
        if title and not _looks_russian(title):
            item["title_original"] = title
            title = translate_to_ru(title)
            if not title:
                continue
            item["title"] = title
        if summary and not _looks_russian(summary):
            item["summary_original"] = summary
            item["summary"] = translate_to_ru(summary)
        if is_error_payload(item.get("title", ""), item.get("summary", "")):
            continue
        if not _looks_russian(item.get("title", "")):
            continue
        out.append(item)
    return out


def _img_ext(url: str, content_type: str = "") -> str:
    path = urlparse(str(url or "")).path.lower()
    for ext in (".jpg", ".jpeg", ".png", ".webp"):
        if path.endswith(ext):
            return ext
    ct = (content_type or "").lower()
    if "png" in ct:
        return ".png"
    if "webp" in ct:
        return ".webp"
    return ".jpg"


def _photo_like(path: Path) -> bool:
    try:
        with Image.open(path) as im:
            w, h = im.size
            if w < 560 or h < 280:
                return False
            g = im.convert("L").resize((160, 90))
            return g.entropy() >= 4.1
    except Exception:
        return False


def _download_image(url: str, path_base: Path, require_photo: bool = True) -> Path | None:
    try:
        r = requests.get(url, timeout=TIMEOUT, stream=True, headers={"User-Agent": "Mozilla/5.0"})
        ct = (r.headers.get("Content-Type") or "").lower()
        if r.status_code != 200 or (ct and "image" not in ct):
            return None
        ext = _img_ext(url, ct)
        path = path_base.with_suffix(ext)
        with open(path, "wb") as fh:
            total = 0
            for chunk in r.iter_content(16384):
                if chunk:
                    fh.write(chunk); total += len(chunk)
                if total > 8_000_000:
                    break
        if not path.exists() or path.stat().st_size < 4096:
            path.unlink(missing_ok=True); return None
        if require_photo and not _photo_like(path):
            path.unlink(missing_ok=True); return None
        return path
    except Exception:
        return None


def _pexels_query_for_story(item: dict) -> str:
    t = _low((item.get("title", "") or "") + " " + (item.get("summary", "") or ""))
    cat = item.get("category") or "other"
    if any(k in t for k in ("пик", "недвиж", "девелоп")):
        return "Moscow modern apartment buildings real estate business"
    if any(k in t for k in ("мосбирж", "рубл", "акции рф", "российск")):
        return "Moscow business skyline finance"
    if any(k in t for k in ("bitcoin", "биткоин", "ethereum", "крипт")):
        return "bitcoin cryptocurrency finance"
    if any(k in t for k in ("нефть", "oil", "opec", "газ", "energy")):
        return "oil refinery energy market"
    if any(k in t for k in ("банк", "citigroup", "bank")):
        return "bank finance city skyscraper"
    if any(k in t for k in ("фрс", "ецб", "ставк", "инфляц", "центробанк")):
        return "central bank finance interest rates"
    if cat in {"sanctions", "trade"}:
        return "shipping containers global trade"
    if cat == "war":
        return "geopolitics diplomacy city"
    return PEXELS_QUERY.get(cat, PEXELS_QUERY["other"])


def prepare_media(rows: list[dict], site_dir, pexels_key: str | None = None) -> list[dict]:
    """Only clean stories survive; every visual is a verified local photograph."""
    root = Path(site_dir)
    media_dir = root / "news_media"
    media_dir.mkdir(parents=True, exist_ok=True)
    key = (pexels_key or os.getenv("PEXELS_API_KEY", "")).strip()
    image_mode = os.getenv("NEWS_IMAGE_MODE", "smart").strip().lower()
    require_image = _bool_env("NEWS_REQUIRE_IMAGE", True)
    pools, used, out = {}, {}, []

    for row in rows or []:
        item = dict(row)
        if is_error_payload(item.get("title", ""), item.get("summary", "")):
            continue
        source_low = _low(item.get("source", ""))
        cached = None
        remote = str(item.get("image", "") or "").strip()
        force_fallback = any(tok in source_low for tok in FORCE_PEXELS_SOURCE_TOKENS)

        if image_mode != "pexels" and not force_fallback and remote.startswith(("http://", "https://")):
            seed = (item.get("published", "") or "") + "|publisher|" + remote
            digest = hashlib.md5(seed.encode("utf-8")).hexdigest()[:20]
            cached = _download_image(remote, media_dir / digest, True)
            if cached is not None: item["image_source"] = "publisher"

        if cached is None and key:
            q = _pexels_query_for_story(item)
            if q not in pools:
                pools[q] = _pexels_search(key, q, per_page=8); used[q] = 0
            pool = pools[q]
            if not pool:
                generic = PEXELS_QUERY.get(item.get("category"), PEXELS_QUERY["other"])
                if generic not in pools:
                    pools[generic] = _pexels_search(key, generic, per_page=8); used[generic] = 0
                q = generic; pool = pools[q]
            if pool:
                for _ in range(len(pool)):
                    ph = pool[used[q] % len(pool)]; used[q] += 1
                    remote = ph.get("image", "")
                    digest = hashlib.md5((q + "|" + remote).encode("utf-8")).hexdigest()[:20]
                    cached = _download_image(remote, media_dir / digest, True)
                    if cached is not None:
                        item.update({"image_source":"pexels","image_is_illustration":True,
                                     "image_credit_name":ph.get("photographer",""),
                                     "image_credit_url":ph.get("photographer_url",""),
                                     "image_page_url":ph.get("page_url",""),
                                     "image_alt":ph.get("alt","")})
                        break
        if cached is not None:
            item["image"] = "/news_media/" + cached.name
        else:
            item["image"] = ""; item["image_source"] = "none"
        if require_image and not item["image"]:
            continue
        out.append(item)
    return out


def build(assets: list[dict], *, allow_live: bool = True) -> list[dict]:
    key = os.getenv("NEWS_API_KEY", "").strip()
    provider = os.getenv("NEWS_PROVIDER", "newsapi").strip().lower() or "newsapi"
    pexels_key = os.getenv("PEXELS_API_KEY", "").strip()
    try:
        min_score = int(os.getenv("NEWS_FILTER_MIN_SCORE", str(DEFAULT_MIN_SCORE)))
    except ValueError:
        min_score = DEFAULT_MIN_SCORE
    try:
        max_age = int(os.getenv("NEWS_MAX_AGE_HOURS", str(DEFAULT_MAX_AGE_HOURS)))
    except ValueError:
        max_age = DEFAULT_MAX_AGE_HOURS

    raw = fetch_live(key, provider) if key and allow_live else []
    filtered = filter_and_rank(raw, assets, min_score=min_score, max_age_hours=max_age) if raw else []
    if not filtered:
        filtered = filter_and_rank(load_seed(), assets, min_score=min(30, min_score), max_age_hours=10**9)
    filtered = localize_rows_ru(filtered)
    return [x for x in filtered if not is_error_payload(x.get("title", ""), x.get("summary", ""))]


def sentiment(assets, vix):
    """Индекс настроений 0..100 (страх↔жадность) из рыночных данных, не из headline tone."""
    n = max(1, len(assets))
    breadth = sum(1 for a in assets if (a.get("chg1d") or 0) > 0) / n
    moms = [a["regime"]["mom"] for a in assets
            if a.get("regime") and a["regime"].get("mom") is not None]
    mom = (sum(1 for m in moms if m > 0) / len(moms)) if moms else 0.5
    vixc = 0.5
    if vix is not None:
        vixc = max(0.0, min(1.0, (30 - vix) / (30 - 12)))
    val = round(100 * (0.4 * breadth + 0.3 * mom + 0.3 * vixc))
    label = "жадность" if val >= 60 else "страх" if val <= 40 else "нейтрально"
    return {"value": val, "label": label, "breadth": round(breadth * 100),
            "vix": vix if vix is not None else None}
