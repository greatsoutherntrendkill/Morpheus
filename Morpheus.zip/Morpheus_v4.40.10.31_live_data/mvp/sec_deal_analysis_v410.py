
"""Morpheus v4.10 — deep SEC corporate-finance enrichment.

Goals:
- Russian explanations, company names unchanged.
- SEC remains the source of truth for the transaction.
- SEC submissions/companyfacts enrich financial context.
- Existing Massive/OPTIONS_API_KEY is used for historical market reaction.
- Missing values are never fabricated.

This module is intentionally lazy: deep analysis is generated only when a user
opens a deal card.
"""
from __future__ import annotations

import datetime as dt
import json
import math
import os
import re
import time
from pathlib import Path
from typing import Any

import requests
from dotenv import load_dotenv

import sec_edgar_deals_v49 as SEC49

ROOT=Path(__file__).parent
CACHE_DIR=ROOT/"runtime_cache"/"sec_deal_analysis_v410"
CACHE_DIR.mkdir(parents=True,exist_ok=True)
load_dotenv(ROOT/".env")

CACHE_TTL=max(3600,int(os.getenv("SEC_DEAL_ANALYSIS_TTL_SECONDS","21600")))
SESSION=requests.Session()

CORP_SUFFIX=r"(?:Inc\.?|Incorporated|Corporation|Corp\.?|Company|Co\.?|LLC|L\.L\.C\.|Ltd\.?|Limited|PLC|plc|Holdings(?:,\s*Inc\.?)?|Group(?:,\s*Inc\.?)?|N\.V\.|S\.A\.|AG|SE)"
COMPANY_RE=re.compile(rf"\b([A-Z][A-Za-z0-9&'’.\-/]*(?:[\s,]+[A-Z][A-Za-z0-9&'’.\-/]*){{0,8}}[\s,]+{CORP_SUFFIX})\b")
BAD_ENTITY_WORDS={
    "service providers","stock exchange","exchange agent","transfer agent",
    "merger consideration","public company accounting","due to forfeiture",
    "the company","our company","parent company","target company",
}
MONTHS={
    "january":1,"february":2,"march":3,"april":4,"may":5,"june":6,
    "july":7,"august":8,"september":9,"october":10,"november":11,"december":12,
}

FACT_TAGS={
    "revenue":["RevenueFromContractWithCustomerExcludingAssessedTax","Revenues","SalesRevenueNet"],
    "operating_income":["OperatingIncomeLoss"],
    "net_income":["NetIncomeLoss","ProfitLoss"],
    "da":["DepreciationDepletionAndAmortization","DepreciationDepletionAndAmortizationPropertyPlantAndEquipment"],
    "cash":["CashAndCashEquivalentsAtCarryingValue","CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"],
    "goodwill":["Goodwill"],
    "assets":["Assets"],
    "liabilities":["Liabilities"],
    "debt":["LongTermDebtAndFinanceLeaseObligationsCurrent","LongTermDebtCurrent","LongTermDebtNoncurrent",
            "ShortTermBorrowings","LongTermDebt"],
}

def _cache_path(accession:str)->Path:
    safe=re.sub(r"[^0-9A-Za-z_-]","",accession)
    return CACHE_DIR/f"{safe}.json"

def _load_cache(accession:str):
    p=_cache_path(accession)
    try:
        d=json.loads(p.read_text(encoding="utf-8"))
        if time.time()-float(d.get("_cached_at",0))<CACHE_TTL:
            d.pop("_cached_at",None)
            return d
    except Exception:
        pass
    return None

def _save_cache(accession:str,d:dict[str,Any]):
    try:
        payload={**d,"_cached_at":time.time()}
        _cache_path(accession).write_text(json.dumps(payload,ensure_ascii=False),encoding="utf-8")
    except Exception:
        pass

def _sec_json(url:str)->dict[str,Any]:
    raw=SEC49._get_bytes(url,35)
    return json.loads(raw.decode("utf-8","ignore"))

def _norm_company(s:str|None)->str|None:
    if not s:return None
    s=re.sub(r"\s+"," ",s).strip(" ,.;:-")
    if len(s)<3 or len(s)>120:return None
    low=s.lower()
    if any(x in low for x in BAD_ENTITY_WORDS):return None
    if low.startswith(("and ","or ","the ")):s=re.sub(r"^(?:and|or|the)\s+","",s,flags=re.I)
    return s.strip()

def _company_entities_near_deal(text:str,issuer:str)->list[str]:
    hits=[]
    issuer_key=re.sub(r"[^a-z0-9]","",str(issuer).lower())
    anchors=list(re.finditer(r"agreement and plan of merger|business combination agreement|merger agreement|tender offer|proposed merger|proposed acquisition",text,re.I))
    windows=[]
    for a in anchors[:12]:
        windows.append(text[max(0,a.start()-700):min(len(text),a.end()+2200)])
    if not windows:
        windows=[text[:5000]]
    for w in windows:
        for m in COMPANY_RE.finditer(w):
            x=_norm_company(m.group(1))
            if not x:continue
            key=re.sub(r"[^a-z0-9]","",x.lower())
            if key==issuer_key:continue
            if "mergersub" in key or "acquisitionsub" in key:continue
            # Reject accidental concatenation containing the issuer plus another entity.
            if issuer_key and issuer_key in key:continue
            if x not in hits:hits.append(x)
    return hits[:8]

def _better_counterparty(text:str,issuer:str,current:str|None)->tuple[str|None,list[str]]:
    candidates=_company_entities_near_deal(text,issuer)
    cur=_norm_company(current)
    if cur and not any(b in cur.lower() for b in BAD_ENTITY_WORDS):
        # Keep existing extraction only if it actually looks like a legal entity.
        if re.search(CORP_SUFFIX+r"$",cur,re.I):
            if cur not in candidates:candidates.insert(0,cur)
    return (candidates[0] if candidates else None),candidates

def _date_from_match(mon:str,day:str,year:str)->str|None:
    try:
        return dt.date(int(year),MONTHS[mon.lower()],int(day)).isoformat()
    except Exception:return None

def _extract_announcement_date(text:str, fallback:str)->str:
    patterns=[
      re.compile(r"On\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s+(\d{4})[\s\S]{0,260}?(?:entered into|executed|announced)",re.I),
      re.compile(r"(?:Agreement and Plan of Merger|Business Combination Agreement)[^.]{0,120}dated\s+(?:as of\s+)?(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s+(\d{4})",re.I),
    ]
    for p in patterns:
        m=p.search(text)
        if m:
            d=_date_from_match(m.group(1),m.group(2),m.group(3))
            if d:return d
    return fallback

def _extract_expected_close(text:str)->str|None:
    pats=[
      re.compile(r"expected to (?:close|be completed|consummate)[^.]{0,100}(?:in|during)\s+(?:the\s+)?(first|second|third|fourth)\s+quarter(?:\s+of)?\s+(\d{4})",re.I),
      re.compile(r"expected to (?:close|be completed|consummate)[^.]{0,100}(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})",re.I),
    ]
    m=pats[0].search(text)
    if m:return {"first":"1 кв.","second":"2 кв.","third":"3 кв.","fourth":"4 кв."}[m.group(1).lower()]+" "+m.group(2)
    m=pats[1].search(text)
    if m:return m.group(1)+" "+m.group(2)
    return None

def _transaction_status_ru(form:str,text:str)->str:
    low=text.lower()
    if re.search(r"(?:merger|acquisition|transaction)\s+(?:was|has been)\s+(?:completed|consummated|closed)",low):
        return "Сделка закрыта"
    if form=="DEFM14A":return "Сделка вынесена на голосование"
    if form=="PREM14A":return "Предварительные материалы к голосованию"
    if form.startswith(("SC TO","SC 14D9")):return "Тендерное предложение"
    if form.startswith(("S-4","F-4")):return "Регистрация сделки / объединения"
    return "Сделка раскрыта в SEC"

def _consideration(text:str)->dict[str,Any]:
    low=text.lower()
    methods=[]
    if re.search(r"cash consideration|in cash|cash payment|cash merger consideration",low):methods.append("денежные средства")
    if re.search(r"stock consideration|share consideration|shares of (?:common|ordinary)|stock-for-stock|exchange ratio",low):methods.append("акции")
    if re.search(r"debt financing|debt commitment|term loan|bridge facility|credit facility",low):methods.append("долговое финансирование")
    if re.search(r"equity financing|equity commitment",low):methods.append("акционерное финансирование")
    ratio=None
    m=re.search(r"(?:exchange ratio|receive)\s+(?:of\s+)?([\d.]+)\s+(?:shares?|ordinary shares|common shares)",text,re.I)
    if m:
        try:ratio=float(m.group(1))
        except Exception:pass
    cash_per_share=SEC49._extract_per_share(text)
    return {"methods":methods,"cash_per_share":cash_per_share,"exchange_ratio":ratio}

def _terms_summary(detail:dict,text:str,counterparty:str|None,status_ru:str,close:str|None,cons:dict)->str:
    issuer=detail.get("issuer") or detail.get("company") or "Компания"
    if counterparty:
        lead=f"{issuer} раскрыла документы SEC по сделке с {counterparty}."
    else:
        lead=f"{issuer} раскрыла в SEC документы по сделке M&A."
    bits=[]
    if detail.get("headline_value"):
        bits.append("стоимость сделки раскрыта в документе")
    if cons.get("methods"):
        bits.append("форма оплаты: "+", ".join(cons["methods"]))
    if close:
        bits.append("ожидаемое закрытие: "+close)
    tail=(" "+". ".join(x[:1].upper()+x[1:] for x in bits)+".") if bits else ""
    return lead+" Текущий статус: "+status_ru.lower()+"."+tail

def _submissions(cik:str)->dict[str,Any]:
    return _sec_json(f"https://data.sec.gov/submissions/CIK{int(cik):010d}.json")

def _companyfacts(cik:str)->dict[str,Any]:
    return _sec_json(f"https://data.sec.gov/api/xbrl/companyfacts/CIK{int(cik):010d}.json")

def _ticker_exchange(sub:dict)->tuple[str|None,str|None]:
    tickers=sub.get("tickers") or []; exchanges=sub.get("exchanges") or []
    ticker=tickers[0] if tickers else None
    ex=exchanges[0] if exchanges else None
    return ticker,ex

def _event_date(detail:dict)->dt.date:
    for k in ("announcement_date","date"):
        try:return dt.date.fromisoformat(str(detail.get(k)))
        except Exception:pass
    return dt.date.today()

def _fact_entries(cf:dict,tag:str)->list[dict]:
    us=(cf.get("facts") or {}).get("us-gaap") or {}
    node=us.get(tag) or {}
    units=node.get("units") or {}
    out=[]
    for unit,rows in units.items():
        if unit not in {"USD","USD/shares","shares","pure"}:continue
        for x in rows or []:
            if isinstance(x,dict):out.append({**x,"unit":unit})
    return out

def _best_duration_fact(cf:dict,tags:list[str],event:dt.date,annual=True)->float|None:
    candidates=[]
    for tag in tags:
        for x in _fact_entries(cf,tag):
            try:
                filed=dt.date.fromisoformat(x.get("filed"))
                start=dt.date.fromisoformat(x.get("start")) if x.get("start") else None
                end=dt.date.fromisoformat(x.get("end")) if x.get("end") else None
                val=float(x.get("val"))
            except Exception:continue
            if filed>event or end is None:continue
            dur=(end-start).days if start else None
            if annual and (dur is None or not 280<=dur<=390):continue
            form=str(x.get("form") or "")
            if annual and form not in {"10-K","20-F","40-F","10-K/A","20-F/A"}:continue
            score=(end,filed)
            candidates.append((score,val,tag))
    if not candidates:return None
    candidates.sort(key=lambda z:z[0],reverse=True)
    return candidates[0][1]

def _best_instant_fact(cf:dict,tags:list[str],event:dt.date)->float|None:
    candidates=[]
    for tag in tags:
        for x in _fact_entries(cf,tag):
            try:
                filed=dt.date.fromisoformat(x.get("filed"))
                end=dt.date.fromisoformat(x.get("end"))
                val=float(x.get("val"))
            except Exception:continue
            if filed>event or end>event:continue
            candidates.append(((end,filed),val,tag))
    if not candidates:return None
    candidates.sort(key=lambda z:z[0],reverse=True)
    return candidates[0][1]

def _fundamentals(cik:str,event:dt.date)->dict[str,Any]:
    try:cf=_companyfacts(cik)
    except Exception:return {}
    revenue=_best_duration_fact(cf,FACT_TAGS["revenue"],event,True)
    op=_best_duration_fact(cf,FACT_TAGS["operating_income"],event,True)
    ni=_best_duration_fact(cf,FACT_TAGS["net_income"],event,True)
    da=_best_duration_fact(cf,FACT_TAGS["da"],event,True)
    cash=_best_instant_fact(cf,FACT_TAGS["cash"],event)
    debt_parts=[]
    for tag in FACT_TAGS["debt"]:
        v=_best_instant_fact(cf,[tag],event)
        if v is not None:debt_parts.append(v)
    debt=max(debt_parts) if debt_parts else None
    ebitda=(op+da) if op is not None and da is not None else None
    return {
      "revenue":revenue,"operating_income":op,"net_income":ni,"da":da,
      "ebitda_proxy":ebitda,"cash":cash,"debt":debt,
      "source":"SEC XBRL companyfacts",
    }

def _multiples(value:float|None,f:dict)->dict[str,Any]:
    out={"deal_value_to_revenue":None,"deal_value_to_ebitda":None}
    if value and f.get("revenue") and f["revenue"]>0:
        out["deal_value_to_revenue"]=value/f["revenue"]
    if value and f.get("ebitda_proxy") and f["ebitda_proxy"]>0:
        out["deal_value_to_ebitda"]=value/f["ebitda_proxy"]
    return out

def _massive_key()->str:
    return os.getenv("MASSIVE_API_KEY") or os.getenv("OPTIONS_API_KEY") or ""

def _massive_bars(ticker:str,start:dt.date,end:dt.date)->list[dict]:
    key=_massive_key()
    if not key:return []
    url=f"https://api.massive.com/v2/aggs/ticker/{ticker}/range/1/day/{start.isoformat()}/{end.isoformat()}"
    r=SESSION.get(url,params={"adjusted":"true","sort":"asc","limit":5000,"apiKey":key},timeout=12)
    if r.status_code!=200:return []
    return r.json().get("results") or []

def _yf_bars(ticker:str,start:dt.date,end:dt.date)->list[dict]:
    try:
        import yfinance as yf
        df=yf.download(ticker,start=start.isoformat(),end=(end+dt.timedelta(days=1)).isoformat(),auto_adjust=True,progress=False,threads=False)
        if df is None or df.empty:return []
        out=[]
        for idx,row in df.iterrows():
            c=row["Close"]
            try:
                if hasattr(c,"iloc"):c=c.iloc[0]
                out.append({"date":idx.date().isoformat(),"c":float(c)})
            except Exception:pass
        return out
    except Exception:return []

def _market_reaction(ticker:str|None,event:dt.date)->dict[str,Any]:
    if not ticker:return {}
    start=event-dt.timedelta(days=8);end=event+dt.timedelta(days=14)
    bars=_massive_bars(ticker,start,end);source="Massive"
    norm=[]
    for x in bars:
        try:
            d=dt.datetime.fromtimestamp(float(x["t"])/1000,dt.timezone.utc).date()
            norm.append((d,float(x["c"])))
        except Exception:pass
    if not norm:
        source="yfinance fallback"
        norm=[(dt.date.fromisoformat(x["date"]),x["c"]) for x in _yf_bars(ticker,start,end)]
    if len(norm)<2:return {"ticker":ticker,"source":source}
    norm.sort()
    prev=[x for x in norm if x[0]<event]
    post=[x for x in norm if x[0]>=event]
    if not prev or not post:return {"ticker":ticker,"source":source}
    p0=prev[-1][1];p1=post[0][1]
    p5=post[min(4,len(post)-1)][1]
    return {
      "ticker":ticker,"source":source,
      "reference_date":event.isoformat(),
      "previous_close":p0,"first_close":p1,"fifth_close":p5,
      "day1_pct":(p1/p0-1)*100 if p0 else None,
      "day5_pct":(p5/p0-1)*100 if p0 else None,
    }


def _ipo_market_reaction(ticker:str|None,event:dt.date,offer_price:float|None)->dict[str,Any]:
    if not ticker:return {}
    start=event-dt.timedelta(days=1);end=event+dt.timedelta(days=14)
    bars=_massive_bars(ticker,start,end);source="Massive"
    norm=[]
    for x in bars:
        try:
            d=dt.datetime.fromtimestamp(float(x["t"])/1000,dt.timezone.utc).date()
            norm.append((d,float(x["c"])))
        except Exception:pass
    if not norm:
        source="yfinance fallback"
        norm=[(dt.date.fromisoformat(x["date"]),x["c"]) for x in _yf_bars(ticker,start,end)]
    norm=sorted([x for x in norm if x[0]>=event])
    if not norm:return {"ticker":ticker,"source":source}
    p1=norm[0][1];p5=norm[min(4,len(norm)-1)][1]
    ref=float(offer_price) if offer_price and float(offer_price)>0 else None
    return {
      "ticker":ticker,"source":source,"reference_date":event.isoformat(),
      "offer_price":ref,"first_close":p1,"fifth_close":p5,
      "day1_pct":(p1/ref-1)*100 if ref else None,
      "day5_pct":(p5/ref-1)*100 if ref else None,
    }

def _post_close_goodwill(cik:str,target:str|None,event:dt.date)->dict[str,Any]:
    """Conservative search: only report goodwill if target name and goodwill occur nearby
    in a later 10-Q/10-K. This avoids using the issuer's total balance-sheet goodwill."""
    if not target:return {"value":None,"status":"not_found"}
    try:sub=_submissions(cik)
    except Exception:return {"value":None,"status":"unavailable"}
    recent=(sub.get("filings") or {}).get("recent") or {}
    forms=recent.get("form") or []; accs=recent.get("accessionNumber") or []; filed=recent.get("filingDate") or []; docs=recent.get("primaryDocument") or []
    target_key=re.sub(r"[^a-z0-9 ]","",target.lower())[:28].strip()
    if len(target_key)<5:return {"value":None,"status":"not_found"}
    candidates=[]
    for i,form in enumerate(forms):
        if form not in {"10-Q","10-K","10-Q/A","10-K/A"}:continue
        try:fd=dt.date.fromisoformat(filed[i])
        except Exception:continue
        if fd<=event or fd>event+dt.timedelta(days=600):continue
        candidates.append((fd,accs[i],docs[i],form))
    for fd,acc,doc,form in candidates[:6]:
        acc_clean=acc.replace("-","")
        url=f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc_clean}/{doc}"
        try:text=SEC49._strip_sec_text(SEC49._get_text(url,35))
        except Exception:continue
        low=re.sub(r"[^a-z0-9 ]","",text.lower())
        pos=low.find(target_key)
        if pos<0:continue
        # Search around the matched acquisition discussion.
        segment=text[max(0,pos-2500):min(len(text),pos+7000)]
        pats=[
          re.compile(r"goodwill[^$]{0,100}\$\s*([\d,.]+)\s*(billion|million|thousand)?",re.I),
          re.compile(r"\$\s*([\d,.]+)\s*(billion|million|thousand)?[^.]{0,100}goodwill",re.I),
        ]
        for p in pats:
            m=p.search(segment)
            if not m:continue
            v=SEC49._money_value(m.group(1),m.group(2))
            if m.group(2) and m.group(2).lower()=="thousand" and v is not None:v*=1000
            if v and v>0:
                return {"value":v,"status":"reported","filed":fd.isoformat(),"form":form,"url":url}
    return {"value":None,"status":"not_found"}


def _strict_deal_value(text:str)->float|None:
    pats=[
      re.compile(r"(?:transaction|deal)\s+(?:is\s+)?valued at[^$]{0,80}\$\s*([\d,.]+)\s*(billion|million|bn|mm)?",re.I),
      re.compile(r"(?:enterprise|equity)\s+value[^$]{0,80}\$\s*([\d,.]+)\s*(billion|million|bn|mm)?",re.I),
      re.compile(r"(?:aggregate\s+)?purchase price[^$]{0,80}\$\s*([\d,.]+)\s*(billion|million|bn|mm)?",re.I),
      re.compile(r"(?:total|aggregate)\s+consideration[^$]{0,80}\$\s*([\d,.]+)\s*(billion|million|bn|mm)?",re.I),
    ]
    for p in pats:
        m=p.search(text)
        if m:
            v=SEC49._money_value(m.group(1),m.group(2))
            if v and v>0:return v
    return None

def _roles(form:str,issuer:str|None,counterparty:str|None,text:str)->dict[str,Any]:
    if not issuer:
        return {"buyer":None,"target":None,"structure":"сделка M&A","confidence":"низкая"}
    low=text.lower()
    spac=bool(re.search(r"\bspac\b|special purpose acquisition|blank check company|business combination agreement",low))
    if spac:
        return {"buyer":issuer,"target":counterparty,"structure":"объединение / business combination","confidence":"средняя"}
    if form in {"DEFM14A","PREM14A","SC 14D9","SC 14D9/A"}:
        return {"buyer":counterparty,"target":issuer,"structure":"поглощение / слияние","confidence":"средняя"}
    if form.startswith(("S-4","F-4","SC TO-T")):
        return {"buyer":issuer,"target":counterparty,"structure":"поглощение / объединение","confidence":"средняя"}
    return {"buyer":None,"target":None,"structure":"сделка M&A","confidence":"низкая"}

def _mna_analysis(detail:dict,text:str)->dict[str,Any]:
    issuer=detail.get("issuer") or detail.get("company")
    counterparty,candidates=_better_counterparty(text,issuer or "",detail.get("counterparty"))
    announcement=_extract_announcement_date(text,detail.get("date"))
    close=_extract_expected_close(text)
    status_ru=_transaction_status_ru(detail.get("form") or "",text)
    cons=_consideration(text)
    try:event=dt.date.fromisoformat(announcement)
    except Exception:event=_event_date(detail)
    sub={}
    try:sub=_submissions(str(detail.get("cik")))
    except Exception:pass
    ticker,exchange=_ticker_exchange(sub)
    f=_fundamentals(str(detail.get("cik")),event)
    value=_strict_deal_value(text)
    # For proxy/tender documents the older extractor is usually reliable enough;
    # for S-4/F-4 avoid using filing-fee "transaction valuation" as deal value.
    if value is None and not str(detail.get("form") or "").startswith(("S-4","F-4")):
        value=detail.get("headline_value")
    mult=_multiples(value,f)
    market=_market_reaction(ticker,event)
    role=_roles(str(detail.get("form") or ""),issuer,counterparty,text)
    goodwill_target=role.get("target") if role.get("buyer")==issuer else None
    goodwill=_post_close_goodwill(str(detail.get("cik")),goodwill_target,event)
    return {
      **detail,
      "counterparty":counterparty,
      "participants":[x for x in [issuer,counterparty] if x],
      "party_candidates":candidates,
      "roles":role,
      "announcement_date":announcement,
      "expected_close":close,
      "status_ru":status_ru,
      "consideration":cons,
      "ticker":ticker,
      "exchange":exchange,
      "headline_value":value,
      "fundamentals":f,
      "multiples":mult,
      "goodwill":goodwill,
      "market_reaction":market,
      "summary_ru":_terms_summary(detail,text,counterparty,status_ru,close,cons),
      "analysis_ru":{
        "valuation":(
          "Стоимость сделки сопоставлена с последней доступной годовой отчётностью SEC filer до даты события. "
          "EV/EBITDA показывается как расчётный ориентир на базе Operating Income + D&A и не подменяет раскрытый компанией adjusted EBITDA."
        ),
        "goodwill":(
          "Goodwill достоверно показывается только если после закрытия сделки в 10-Q/10-K найдено раскрытие purchase price allocation по этой покупке."
          if goodwill.get("value") is None else
          "Goodwill взят из последующего 10-Q/10-K, где приобретение и распределение покупной цены раскрыты вместе."
        ),
        "market":(
          f"Реакция рассчитана по акции {ticker} относительно последнего закрытия перед датой события."
          if ticker else "Для SEC filer не удалось однозначно определить торгуемый тикер."
        ),
      },
      "data_quality":{
        "transaction":"SEC filing",
        "financials":"SEC XBRL" if f else "недостаточно данных",
        "market":market.get("source") if market else "недостаточно данных",
        "goodwill":"SEC 10-Q/10-K" if goodwill.get("value") else "ещё не раскрыт / не найден",
      },
    }

def _ipo_analysis(detail:dict,text:str)->dict[str,Any]:
    try:event=dt.date.fromisoformat(detail.get("date"))
    except Exception:event=dt.date.today()
    sub={}
    try:sub=_submissions(str(detail.get("cik")))
    except Exception:pass
    ticker,exchange=_ticker_exchange(sub)
    ticker=detail.get("ticker") or ticker
    exchange=detail.get("exchange") or exchange
    f=_fundamentals(str(detail.get("cik")),event)
    market=_ipo_market_reaction(ticker,event,detail.get("offer_price"))
    proceeds=detail.get("gross_proceeds")
    return {
      **detail,
      "ticker":ticker,"exchange":exchange,
      "fundamentals":f,"market_reaction":market,
      "proceeds_to_revenue":(proceeds/f["revenue"]) if proceeds and f.get("revenue") else None,
      "status_ru":"IPO завершено / финальный проспект",
      "summary_ru":(
        f"{detail.get('company')} разместила финальный проспект IPO в SEC."
        +(f" Цена предложения — ${detail.get('offer_price'):.2f} за акцию." if detail.get("offer_price") is not None else "")
        +(f" Объём размещения — около ${proceeds/1e6:.1f} млн." if proceeds else "")
      ),
      "analysis_ru":{
        "valuation":"Для IPO показываем отношение объёма размещения к последней годовой выручке, если она доступна в SEC XBRL.",
        "market":f"Первичная реакция рассчитана по {ticker} после даты финального prospectus." if ticker else "Тикер не определён.",
      },
      "data_quality":{
        "transaction":"SEC 424B4",
        "financials":"SEC XBRL" if f else "недостаточно данных",
        "market":market.get("source") if market else "недостаточно данных",
      },
    }

def analyze(detail:dict[str,Any],force:bool=False)->dict[str,Any]:
    accession=str(detail.get("accession") or "")
    if accession and not force:
        hit=_load_cache(accession)
        if hit:return hit
    raw=SEC49._get_text(detail["sec_url"],45)
    text=SEC49._strip_sec_text(raw)
    out=_mna_analysis(detail,text) if detail.get("kind")=="mna" else _ipo_analysis(detail,text)
    out["analysis_version"]="4.10"
    out["source_policy"]="SEC EDGAR is source of truth; SEC XBRL and existing market-data providers only enrich the filing."
    if accession:_save_cache(accession,out)
    return out
