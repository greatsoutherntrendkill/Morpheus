# Morpheus v4.34 — Feature & Event Layer

Второй этап roadmap улучшения прогнозных моделей после v4.33 Model Quality Foundation.

## Что добавлено

- `feature_event_v434.py` — новый контекстный feature layer.
- Cross-sectional relative strength против подходящего benchmark на 20 и 60 сессиях.
- Market breadth: доля инструментов сопоставимой группы с положительной 20-дневной динамикой.
- Dispersion: разброс доходностей между инструментами группы.
- Correlation regime: синхронный / нормальный / разрозненный рынок.
- Correlation-to-benchmark и relative volatility.
- Asset-class-specific контекст:
  - акции США — S&P 500 / Nasdaq / DXY / фьючерсы;
  - акции РФ — IMOEX / RTSI / RGBI / RUB / нефть;
  - крипто — BTC / ETH / SOL / XRP + risk assets;
  - FX — DXY, валютный cross-section, ставки/облигационные прокси;
  - сырьё — DXY, широкий risk context и связанные товары.
- Event-aware слой:
  - заседания ФРС / ЕЦБ / Банка России;
  - инфляция;
  - earnings;
  - дивиденды;
  - M&A;
  - санкции;
  - геополитика.
- События и новости не получают высокий направленный вес автоматически: без подписанного факта они прежде всего повышают uncertainty / no-edge threshold.
- Feature drift diagnostics: ширина рынка, dispersion и correlation structure сравниваются со своим недавним диапазоном.
- `meta_forecast_v434.py` — v4.33 statistical core + low-weight cross-sectional/event context expert.
- При высоком event risk или сильном feature drift вероятность консервативно сжимается к 50%, а порог публикации сигнала повышается.
- Cross-sectional context не может сам по себе создать экстремальный прогноз.
- Новый endpoint: `/api/models/features-v434?symbol=...`.
- Новый endpoint диагностики: `/api/models/quality-v434?symbol=...&horizon=...`.
- Старый `/api/models/quality-v433` сохранён как compatibility alias.
- Overview теперь показывает рыночный контекст и событийные риски нового слоя.
- Technical Lab объясняет relative strength, breadth, correlation regime, event risk и feature drift на русском языке.

## Governance

Зарегистрированы frozen challengers:

- `context-feature-expert-v4.34.0`
- `meta-context-v4.34.0`

Автоматическая промоция отключена. Champion `logreg-v3.2.0` не заменён.

## Проверки

- Новый набор v4.34: 7/7.
- Полный regression suite: 70/70.
- Python syntax: passed.
- Frontend JavaScript syntax: passed.
