# Model Audit — v4.40.6

This release focuses on consistency rather than adding another high-capacity forecaster.

## Closed issues

1. **Stale forecast cache after ZIP extraction** — cache is invalid unless its own `as_of`, target and model generation are current.
2. **Training/settlement target mismatch** — one shared target contract is now used by both.
3. **Binary scoring of a three-state system** — current prospective evidence reports multiclass, move/no-move and conditional-direction metrics separately.
4. **Cross-generation evidence contamination** — promotion/reporting is isolated to the current generation; legacy evidence remains audit-only.
5. **Historical P(neutral) prior** — replaced in the normal production path by learned Move/No-Move models in champion, regime challenger and asset specialists.
6. **Conditional vs neutral-aware scale mixing** — current blends and prospective context comparison now stay on the conditional-direction scale before neutral mass is reapplied.

## Deliberate fallbacks

For very short/legacy histories where a Move/No-Move model cannot be trained, a historical movement prior can still be used as an explicitly labelled fallback. Such a fallback is not presented as a learned current-state probability and specialist fallback neutral mass cannot receive live influence.

## Still intentionally unchanged

- v4.41 regime/event-conditioned distribution review remains gated by prospective evidence.
- Monthly Fed/CBR research weights remain scenario weights until enough point-in-time meeting evidence exists for a genuinely trained meeting model.
- Intraday 30m–4h output remains an uncalibrated technical score, not a calibrated probability.
