# Model Quality roadmap после v4.35

## v4.36 — Prospective Feedback Loop

- immutable prediction ledger для каждого нового прогноза;
- фиксация model version, component weights, probability, threshold, regime, features и event state на момент прогноза;
- автоматический settlement после истечения 30м / 1ч / 1д / 5д / 10д / 20д / 30д / 60д;
- error attribution по активу, asset class, горизонту, regime, event type, feature drift и provider state;
- rolling leaderboard champion / regime challenger / dynamic meta / context expert;
- learned prospective weight для v4.34 context/event expert только после достаточного количества settled forecasts;
- promotion review с minimum sample, calibration, edge, drawdown of accuracy и stability constraints;
- никакой автоматической замены champion без governance decision.

После v4.36 Model Quality roadmap соединяется с отложенным Scenario Intelligence roadmap: Historical Analog Engine → Quant Scenario Model → LLM interpretation layer.
