"""
export_site.py — выгружает результаты движка в статический data.js для публичного сайта.
Запуск:  python export_site.py   (после python update.py / --demo)
Пишет site/data.js как window.FORECASTS = {...}. Сайт статический: грузится с любого
бесплатного хостинга (GitHub Pages, Netlify, Vercel) без бэкенда.
"""
import os
# Static startup export performs many small numerical fits. Keep BLAS/OpenMP
# single-threaded so repeated fits cannot create/oversubscribe worker pools and
# make the bulk exporter progressively slower on laptops. Must be set before
# NumPy/sklearn/pandas are imported, including through project modules.
for _k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(_k, "1")

import json
import re
import sys
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

import research_forecast_v46 as RF46
import research_monthly_v4403 as RM4403
import config as C
import db
import models as M
import macro_features as MF
import techa as T
import indicators as IND
import political as P
import news as NEWS
import model_registry as MR

HORIZON = 10
HORIZONS = (1, 5, 10, 20)
HIST = 320



CRYPTO_SYMS = {"BTC-USD","ETH-USD","SOL-USD","XRP-USD"}
FX_SYMS = {"EURUSD=X","GBPUSD=X","JPY=X","AUDUSD=X","USDCAD=X","RUB=X","CNY=X","CNYRUB","DX-Y.NYB"}


def _local_threshold(symbol: str, chart: bool = False) -> float:
    if symbol in CRYPTO_SYMS:
        return 0.24 if chart else 0.34
    if symbol in FX_SYMS:
        return 0.035 if chart else 0.08
    if symbol.startswith("^") or symbol in C.MOEX_INDICES:
        return 0.055 if chart else 0.12
    if symbol in {"ES=F","NQ=F"}:
        return 0.065 if chart else 0.13
    if symbol == "NG=F":
        return 0.18 if chart else 0.28
    return 0.11 if chart else 0.22


def sanitize_price_df(df: pd.DataFrame, symbol: str = "") -> pd.DataFrame:
    """Model-safe cleaner: remove only obvious local feed glitches, never smooth normal trends."""
    if df is None or df.empty:
        return df
    out=df.copy()
    for c in ("open","high","low","close"):
        out[c]=pd.to_numeric(out[c],errors="coerce")
    out=(out.dropna(subset=["date","open","high","low","close"])
            .sort_values("date").drop_duplicates("date",keep="last"))
    out=out[(out[["open","high","low","close"]]>0).all(axis=1)].copy()
    if len(out)<7:
        return out.reset_index(drop=True)

    med=out["close"].rolling(9,center=True,min_periods=5).median()
    th=_local_threshold(symbol, chart=False)
    dev=(out["close"]/med-1).abs()
    body_dev=(out["open"]/med-1).abs()
    # Only replace bars that are far from a local window; this catches stale/demo contamination.
    bad=(dev>th)|(body_dev>th)
    repl=out["close"].mask(bad).interpolate(limit_direction="both")
    out.loc[bad,"close"]=repl[bad]
    out.loc[bad,"open"]=repl[bad]

    body_hi=out[["open","close"]].max(axis=1)
    body_lo=out[["open","close"]].min(axis=1)
    wick=0.18 if symbol in CRYPTO_SYMS else 0.10 if symbol=="NG=F" else 0.07
    out["high"]=np.minimum(out["high"].astype(float),body_hi*(1+wick))
    out["low"]=np.maximum(out["low"].astype(float),body_lo*(1-wick))
    out["high"]=out[["high","open","close"]].max(axis=1)
    out["low"]=out[["low","open","close"]].min(axis=1)
    return out.reset_index(drop=True)


def chart_safe_df(df: pd.DataFrame, symbol: str = "") -> pd.DataFrame:
    """Aggressive DISPLAY-ONLY cleaner. It cannot alter the model inputs."""
    if df is None or df.empty:
        return df
    out=df.copy().sort_values("date").drop_duplicates("date",keep="last").reset_index(drop=True)
    c=out["close"].astype(float)
    med=c.rolling(11,center=True,min_periods=5).median()
    th=_local_threshold(symbol, chart=True)
    bad=(c/med-1).abs()>th
    # opening gaps that do not exist in the local close series are also display glitches
    bad |= (out["open"].astype(float)/med-1).abs()>(th*1.15)
    clean_close=c.mask(bad).interpolate(limit_direction="both")
    out.loc[bad,"close"]=clean_close[bad]
    out.loc[bad,"open"]=clean_close[bad]

    # Limit visual wicks by asset class. This only affects chart_history.
    if symbol in CRYPTO_SYMS: wick=0.12
    elif symbol in FX_SYMS: wick=0.025
    elif symbol.startswith("^") or symbol in C.MOEX_INDICES or symbol in {"ES=F","NQ=F"}: wick=0.035
    elif symbol=="NG=F": wick=0.12
    else: wick=0.065
    body_hi=out[["open","close"]].max(axis=1)
    body_lo=out[["open","close"]].min(axis=1)
    out["high"]=np.minimum(out["high"].astype(float),body_hi*(1+wick))
    out["low"]=np.maximum(out["low"].astype(float),body_lo*(1-wick))
    out["high"]=out[["high","open","close"]].max(axis=1)
    out["low"]=out[["low","open","close"]].min(axis=1)
    return out.reset_index(drop=True)




SITE = Path(__file__).parent / "site"

NAMES = {**{k: v[0] for k, v in C.YF_PRICES.items()},
         **{k: v[2] for k, v in C.YF_CROSSES.items()},
         **{k: v[0] for k, v in C.MOEX_INDICES.items()}}
CATS = {**{k: v[1] for k, v in C.YF_PRICES.items()},
        **{k: v[3] for k, v in C.YF_CROSSES.items()},
        **{k: v[1] for k, v in C.MOEX_INDICES.items()}}
PUBLIC = [s for s in NAMES if s != "CNY=X"]

CB_NAME_BY_COUNTRY = {"США": "ФРС", "Еврозона": "ЕЦБ", "Россия": "Банк России"}



def rate_decision_probabilities(expected_bp, factors):
    """Простая сценарная оценка заседания для UI.

    Это не CME/биржевая implied probability. Она строится из текущего ожидаемого
    шага в seed/calendar и текстовых факторов ЦБ, чтобы интерфейс мог показать
    три понятных сценария: повышение, снижение, сохранение.
    """
    try:
        bp = int(expected_bp) if expected_bp is not None else 0
    except Exception:
        bp = 0

    if bp >= 25:
        probs = {"hike": 66.0, "cut": 9.0, "hold": 25.0}
    elif bp <= -25:
        probs = {"hike": 9.0, "cut": 66.0, "hold": 25.0}
    else:
        probs = {"hike": 15.0, "cut": 15.0, "hold": 70.0}

    dovish = re.compile(
        r"слаб|замедл|охлажд|сниж.*инфляц|сниж.*ожидан|безработ|рецесс|"
        r"слаб.*рост|спад|дезинфляц",
        re.I,
    )
    hawkish = re.compile(
        r"проинфляц|выше цели|ж[её]стк|дефицит кадров|сильн.*рынок труда|"
        r"энергетическ.*риск|пошлин|бюджет.*риск|ускор.*инфляц",
        re.I,
    )
    neutral = re.compile(r"у цели|сбаланс|стабил|без изменений", re.I)

    for f in factors or []:
        t = str((f or {}).get("text", ""))
        if dovish.search(t):
            probs["cut"] += 5
            probs["hold"] -= 2
            probs["hike"] -= 3
        elif hawkish.search(t):
            probs["hike"] += 5
            probs["hold"] -= 2
            probs["cut"] -= 3
        elif neutral.search(t):
            probs["hold"] += 4
            probs["hike"] -= 2
            probs["cut"] -= 2

    for k in probs:
        probs[k] = max(1.0, probs[k])
    s = sum(probs.values())
    out = {k: int(round(v / s * 100)) for k, v in probs.items()}
    # Preserve exact 100% after rounding.
    diff = 100 - sum(out.values())
    winner = max(out, key=out.get)
    out[winner] += diff
    return out


def rate_forecast(country, trend, events, rate=None):
    """Численный прогноз на ближайшее заседание: ±б.п. и ориентир уровня."""
    bp = None
    cb = CB_NAME_BY_COUNTRY.get(country)
    if cb:
        ev = [e for e in events if e["cb"] == cb]
        if ev and ev[0]["expected_bp"] is not None:
            bp = int(ev[0]["expected_bp"])
    if bp is None:
        t = (trend or "").lower()
        if "пауз" in t or "удерж" in t:
            bp = 0
        elif "сниж" in t:
            bp = -25
        elif "повыш" in t:
            bp = 0            # после повышения обычно пауза
        else:
            bp = 0
    if rate is None:
        return f"{bp:+d} б.п."
    lvl = round(rate + bp / 100.0, 2)
    return (f"0 б.п. → сохранение {lvl:.2f}%" if bp == 0
            else f"{bp:+d} б.п. → ~{lvl:.2f}%")


def load_cb_factors():
    try:
        df = pd.read_csv(C.CB_FACTORS_SEED)
        out = {}
        for _, r in df.iterrows():
            out.setdefault(r["cb"], []).append({"text": r["factor"], "dir": int(r["dir"])})
        return out
    except Exception:
        return {}


IDX_DEF = [
    ("VIXCLS", "Индекс страха VIX", "рост → давление на акции, спрос на золото и доллар"),
    ("T10Y2Y", "Наклон кривой 2–10 лет", "инверсия → сигнал риска рецессии; крутизна → проциклично"),
    ("UMCSENT", "Потреб. настроения (UMich)", "рост → поддержка потребления и акций"),
    ("INDPRO", "Промпроизводство", "рост → проциклично для индексов и сырья"),
    ("PAYEMS", "Занятость вне с/х", "сильные данные → ястребиный уклон ФРС, давление на облигации"),
]


def build_indices(con):
    out = []
    for sid, name, infl in IDX_DEF:
        m = db.read_macro(con, sid)
        if m.empty:
            continue
        s = m.set_index("date")["value"]
        last = float(s.iloc[-1])
        prev = float(s.iloc[-4]) if len(s) > 4 else float(s.iloc[0])
        chg = last - prev
        trend = "рост" if chg > 1e-9 else "снижение" if chg < -1e-9 else "без изменений"
        out.append({"name": name, "value": round(last, 2), "trend": trend,
                    "forecast": ("вероятно продолжение: " + trend) if trend != "без изменений"
                    else "вероятно без изменений", "influence": infl,
                    "dir": 1 if chg > 0 else -1 if chg < 0 else 0})
    return out


def load_macro_stats():
    try:
        df = pd.read_csv(C.MACRO_STATS_SEED)
        rows = []
        for _, r in df.iterrows():
            rows.append({"country": r["country"], "indicator": r["indicator"],
                         "value": r["value"], "forecast": r["forecast"],
                         "factors": r["factors"], "dir": int(r["dir"])})
        return rows
    except Exception:
        return []


def build_forecast_text(b):
    """Публичное резюме без BUY/SELL: ML bias проходит quality gate отдельно от контекста."""
    v = b.get("verdict") or {}
    ta = b.get("ta") or {}
    ind = b.get("indicators")
    drv = b.get("drivers") or []
    reg = b.get("regime") or {}
    q = b.get("model_quality") or {"bias": "neutral", "label": "нейтрально",
                                    "confidence": "низкая", "trusted": False,
                                    "reason": "недостаточно данных"}
    primary = (b.get("model_horizons") or {}).get(str(HORIZON), {})
    rating = q.get("bias", "neutral")

    tech = []
    st = ta.get("structure", {})
    bmap = {"bull": ("восходящая", 1), "bear": ("нисходящая", -1), "range": ("диапазон", 0)}
    bru, bdir = bmap.get(st.get("bias"), ("—", 0))
    tech.append({"text": f"структура — {bru}", "dir": bdir})
    pdz = ta.get("premium_discount")
    if pdz:
        prem = pdz["state"] == "premium"
        tech.append({"text": "зона премиум, дорого" if prem else "зона дискаунт, дёшево",
                     "dir": -1 if prem else 1})
    if ind:
        il = ind["signals"]["ind"]["label"]
        tech.append({"text": f"индикаторы (MACD/RSI): {il}",
                     "dir": {"бычий": 1, "медвежий": -1}.get(il, 0)})
        rsi = ind["last"].get("rsi")
        if rsi is not None and rsi > 70:
            tech.append({"text": f"RSI {rsi:.0f} — перекупленность", "dir": -1})
        elif rsi is not None and rsi < 30:
            tech.append({"text": f"RSI {rsi:.0f} — перепроданность", "dir": 1})
    mom = reg.get("mom")
    if mom is not None:
        tech.append({"text": f"моментум 20д {mom:+}%", "dir": 1 if mom > 0 else -1 if mom < 0 else 0})

    macro = [{"text": d["label"], "dir": 1 if d["contribution"] > 0 else -1} for d in drv]
    if not macro:
        macro = [{"text": "макро-факторы нейтральны", "dir": 0}]

    def concl(items):
        total = sum(x["dir"] for x in items)
        return {"dir": 1 if total > 0 else -1 if total < 0 else 0,
                "label": "за рост" if total > 0 else "за падение" if total < 0 else "смешанно"}

    p = primary.get("p_up")
    ptxt = f"{round(p * 100)}%" if p is not None else "—"
    if q.get("trusted"):
        summary = (f"ML на горизонте {HORIZON}д: {q.get('label')}, confidence {q.get('confidence')}, "
                   f"P(рост) {ptxt}. Эвристический тех/макро/политический контекст показывается отдельно "
                   "и не повышает качество ML автоматически.")
    else:
        summary = (f"Устойчивого ML-сигнала на {HORIZON}д нет: P(рост) {ptxt}, "
                   f"confidence {q.get('confidence')}. Причина: {q.get('reason')}. "
                   "Технический и макро-контекст ниже — описательный, а не рекомендация.")
    return {"rating": rating, "summary": summary, "tech": tech[:6], "macro": macro[:6],
            "tech_concl": concl(tech), "macro_concl": concl(macro),
            "confidence": q.get("confidence"), "trusted": bool(q.get("trusted")),
            "reason": q.get("reason", "")}



def public_model_view(ff, live_track=None):
    """Separate raw model opinion from publication/validation status.

    The raw probability is always visible. A directional signal is only
    'validated' when the existing strict quality gate passes.
    """
    ff = ff or {}
    p = ff.get("p_up")
    q = ff.get("quality") or {}
    sc = ff.get("scorecard") or {}
    if p is None:
        raw = {"direction":"unavailable","label":"Нет расчёта","p_up":None,"strength":"—"}
    else:
        p=float(p)
        if p >= 0.5:
            direction="up"; label="Рост ↑"; strength=abs(p-0.5)*2
        else:
            direction="down"; label="Снижение ↓"; strength=abs(p-0.5)*2
        raw={"direction":direction,"label":label,"p_up":round(p,4),
             "strength":round(strength,3)}
    n_eff=int(sc.get("n_eff",0) or 0)
    target_n=30
    ci_edge=sc.get("edge_ci")
    ci_brier=sc.get("brier_skill_ci")
    evidence={
        "effective_n":n_eff,
        "target_effective_n":target_n,
        "n_progress_pct":min(100,round(n_eff/target_n*100)) if target_n else 100,
        "edge_ci_excludes_zero":bool(isinstance(ci_edge,list) and len(ci_edge)==2 and ci_edge[0]>0),
        "brier_skill_ci_excludes_zero":bool(isinstance(ci_brier,list) and len(ci_brier)==2 and ci_brier[0]>0),
        "ece_ok":bool(sc.get("ece") is not None and float(sc.get("ece"))<=0.15),
        "quality_gate_passed":bool(q.get("trusted")),
        "live_track_record":live_track or {},
    }
    status = {
        "validated": bool(q.get("trusted")),
        "label": q.get("label") if q.get("trusted") else "Нет подтверждённого сигнала",
        "confidence": q.get("confidence","низкая"),
        "reason": q.get("reason","недостаточно доказательств"),
    }
    return {"raw":raw,"status":status,"evidence":evidence}

def asset_block(con, sym):
    df = sanitize_price_df(db.read_prices(con, sym), sym)
    if df.empty or len(df) < 60:
        return None
    close = df.set_index("date")["close"]
    chart_df = chart_safe_df(df, sym)
    dxy_df = sanitize_price_df(db.read_prices(con, "DX-Y.NYB"), "DX-Y.NYB")
    dxy = dxy_df.set_index("date")["close"] if sym != "DX-Y.NYB" and not dxy_df.empty else None
    macro = MF.macro_features_for(con, sym, close.index)
    macro_audit = MF.macro_data_audit(con)
    macro_audit["features_used"] = int(len(macro.columns))

    last = float(close.iloc[-1])
    chg1d = float((close.iloc[-1] / close.iloc[-2] - 1) * 100) if len(close) > 1 else 0.0

    reg = M.regime(close)
    fan, summ = M.scenario_paths(close, horizon=HORIZON)
    forecasts = M.multi_horizon_forecasts(close, dxy, macro, HORIZONS)
    primary_model = forecasts.get(str(HORIZON), {})
    exp = M.explain_latest(close, dxy, macro, horizon=HORIZON)

    hist = [{"t": r["date"].strftime("%Y-%m-%d"),
             "o": round(float(r["open"]), 4), "h": round(float(r["high"]), 4),
             "l": round(float(r["low"]), 4), "c": round(float(r["close"]), 4)}
            for _, r in df.iloc[-HIST:].iterrows()]
    chart_hist = [{"t": r["date"].strftime("%Y-%m-%d"),
                   "o": round(float(r["open"]), 4), "h": round(float(r["high"]), 4),
                   "l": round(float(r["low"]), 4), "c": round(float(r["close"]), 4)}
                  for _, r in chart_df.iloc[-HIST:].iterrows()]

    # TA/indicators use chart-safe data so display overlays cannot be driven by feed glitches.
    taildf = chart_df[["date", "open", "high", "low", "close"]].tail(250).reset_index(drop=True)
    ta = T.analyze(taildf)
    if ta:
        dts = taildf["date"].dt.strftime("%Y-%m-%d").tolist()
        for tl in ta.get("trendlines", []):          # индексы -> даты для отрисовки
            if 0 <= tl["x1"] < len(dts) and 0 <= tl["x2"] < len(dts):
                tl["d1"], tl["d2"] = dts[tl["x1"]], dts[tl["x2"]]

    last_date = df["date"].iloc[-1]
    future = [d.strftime("%Y-%m-%d")
              for d in pd.bdate_range(last_date, periods=HORIZON + 1)[1:]]

    block = {
        "symbol": sym, "name": NAMES.get(sym, sym), "category": CATS.get(sym, ""),
        "last": round(last, 4), "chg1d": round(chg1d, 2),
        "regime": {"trend": reg.get("Тренд (MA200)", "—"),
                   "vol": reg.get("Волатильность", "—"),
                   "mom": reg.get("Моментум 20д, %", None)} if reg else None,
        "history": hist, "chart_history": chart_hist, "ta": ta,
        "data_source": db.get_meta(con, f"price_source:{sym}", "snapshot"),
        "macro_data": macro_audit,
    }
    if fan is not None:
        block["scenario"] = {
            "p_up": round(summ["p_up"], 3),
            "method": summ.get("method", "historical_block_bootstrap"),
            "exp_move_pct": round(summ["exp_move_pct"], 2),
            "lo_pct": round(summ["lo_pct"], 2), "hi_pct": round(summ["hi_pct"], 2),
            "horizon": HORIZON, "future": future,
            "band": {k: [round(float(x), 4) for x in fan[k]]
                     for k in ("p05", "p25", "p50", "p75", "p95")},
        }
    block["model_horizons"] = forecasts
    # v3.2+: append-only prediction ledger. A rerun on the same data cutoff is idempotent.
    data_cutoff = str(pd.Timestamp(close.index[-1]).date())
    ledger_ids = {}
    for hh, ff in forecasts.items():
        ledger_ids[hh] = MR.append_prediction(
            con, sym, int(hh), data_cutoff, ff.get("p_up"), ff.get("quality"),
            macro_audit, ff.get("holdout") or {})
    block["prediction_ledger_ids"] = ledger_ids
    # v3.5: expose raw probability from day one, but keep validation status separate.
    model_views = {}
    for hh, ff in forecasts.items():
        tr = MR.live_track_record(con, MR.MODEL_VERSION, sym, int(hh))
        model_views[hh] = public_model_view(ff, tr)
    block["model_views"] = model_views
    block["model_version"] = MR.MODEL_VERSION
    block["feature_version"] = MR.FEATURE_VERSION
    block["model_quality"] = primary_model.get("quality", {
        "trusted": False, "confidence": "низкая", "bias": "neutral",
        "label": "нет подтвержденного сигнала", "reason": "недостаточно данных"})
    block["p_up_model"] = primary_model.get("p_up")
    if exp is not None:
        block["drivers"] = [
            {"label": r["label"], "value": round(float(r["value"]), 4),
             "contribution": round(float(r["contribution"]), 3)}
            for _, r in exp["drivers"].head(7).iterrows()]
    if primary_model:
        block["scorecard"] = primary_model.get("scorecard", {})

    # --- индикаторные стратегии + наложения на график (последние 90 дат) ---
    ind = IND.analyze(taildf)
    if ind:
        ser = ind["series"]
        dts = ser["dates"]
        keep = set(p["t"] for p in hist)
        def align(key):
            return [{"t": t, "v": v} for t, v in zip(dts, ser[key])
                    if t in keep and v is not None]
        block["indicators"] = {
            "last": ind["last"],
            "ma20": align("ma20"), "ma50": align("ma50"), "ma200": align("ma200"),
            "boll_up": align("boll_up"), "boll_mid": align("boll_mid"),
            "boll_dn": align("boll_dn"),
            "signals": ind["signals"],
        }

    # --- список стратегий (для переключателя) ---
    smc_bias = (ta or {}).get("structure", {}).get("bias", "range")
    smc_label = {"bull": "бычий", "bear": "медвежий", "range": "нейтральный"}[smc_bias]
    block["strategies"] = [
        {"id": "smc", "name": "Smart Money (ICT)", "signal": smc_label,
         "summary": "Структура, FVG, order blocks, ликвидность, уровни."},
    ]
    if ind:
        block["strategies"] += [
            {"id": "ind", "name": "Индикаторы (тренд)", "signal": ind["signals"]["ind"]["label"],
             "summary": "MA 20/50/200, MACD, RSI."},
            {"id": "boll", "name": "Боллинджер (возврат)", "signal": ind["signals"]["boll"]["label"],
             "summary": "Полосы Боллинджера + RSI, возврат к среднему."},
        ]

    # --- политические/геополитические риски по активу (независимая оценка 1..5) ---
    pol_events = P.load_events()
    cat_asset = CATS.get(sym, "")
    block["political"] = P.impact_for(cat_asset, pol_events)
    pol_score = P.score(cat_asset, pol_events)

    # --- итоговый вывод: симбиоз тех-анализа, макро и политики ---
    macro_net = sum(d["contribution"] for d in block.get("drivers", []))
    ind_sig = ind["signals"]["ind"]["label"] if ind else "нейтральный"
    if fan is not None:
        block["verdict"] = IND.combined_verdict(
            smc_bias, ind_sig, macro_net,
            round(summ["p_up"], 3), round(summ["exp_move_pct"], 2),
            round(summ["lo_pct"], 2), round(summ["hi_pct"], 2),
            political_score=pol_score)
    block["forecast_text"] = build_forecast_text(block)
    return block



def _asset_batch_worker(symbols, out_path):
    """Compute a small export batch in a fresh process.

    Some optional numerical backends used by the forecasting stack retain native
    worker state across many sequential fits.  A bounded child process makes the
    static exporter deterministic on macOS/Linux without changing any prediction
    mathematics.  The child exits explicitly after writing JSON, so native worker
    state can never accumulate across the whole public universe.
    """
    con = db.connect()
    rows=[]
    try:
        for sym in symbols:
            try:
                block=asset_block(con, sym)
                rows.append({"symbol":sym,"block":block,"error":None})
            except Exception as exc:
                rows.append({"symbol":sym,"block":None,"error":f"{type(exc).__name__}: {exc}"})
    finally:
        try: con.close()
        except Exception: pass
    Path(out_path).write_text(json.dumps(rows,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(0)


def _build_assets_for_export():
    """Build public assets through bounded subprocess batches.

    Set EXPORT_ASSET_ISOLATION=0 only for debugging.  Production/static startup
    defaults to isolation because it prevents cumulative native-ML worker hangs.
    """
    isolate=str(os.getenv("EXPORT_ASSET_ISOLATION","1")).strip().lower() not in {"0","false","no","off"}
    if not isolate:
        con=db.connect(); assets=[]
        try:
            for sym in PUBLIC:
                try:
                    b=asset_block(con,sym)
                    if b: assets.append(b); print(f"  {sym}: ок")
                except Exception as exc:
                    print(f"  {sym}: пропуск ({exc})")
        finally:
            con.close()
        return assets

    batch_size=max(2,min(12,int(os.getenv("EXPORT_ASSET_BATCH_SIZE","8"))))
    timeout_s=max(30,int(os.getenv("EXPORT_ASSET_BATCH_TIMEOUT_SECONDS","75")))
    assets=[]
    script=Path(__file__).resolve()
    for start in range(0,len(PUBLIC),batch_size):
        batch=PUBLIC[start:start+batch_size]
        with tempfile.NamedTemporaryFile(prefix="allanalytics_export_",suffix=".json",delete=False) as tf:
            out_path=Path(tf.name)
        try:
            env=os.environ.copy(); env["PYTHONUNBUFFERED"]="1"
            cmd=[sys.executable,str(script),"--asset-batch",json.dumps(batch,ensure_ascii=False),"--batch-out",str(out_path)]
            # Do not PIPE child stdout/stderr here.  Some optional native ML backends
            # can leave helper descendants holding inherited pipe descriptors even
            # after the batch process exits, which makes communicate()/PIPE wait for
            # EOF forever.  DEVNULL makes completion depend only on the batch process.
            proc=subprocess.run(cmd,cwd=str(script.parent),env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=timeout_s)
            if proc.returncode!=0:
                raise RuntimeError(f"asset batch failed rc={proc.returncode}")
            rows=json.loads(out_path.read_text(encoding="utf-8")) if out_path.exists() else []
            by_sym={str(r.get("symbol")):r for r in rows if isinstance(r,dict)}
            for sym in batch:
                row=by_sym.get(sym) or {}
                b=row.get("block")
                if b:
                    assets.append(b); print(f"  {sym}: ок")
                else:
                    print(f"  {sym}: пропуск ({row.get('error') or 'нет результата'})")
        except subprocess.TimeoutExpired:
            print(f"  batch {batch[0]}…{batch[-1]}: timeout; активы пропущены")
        except Exception as exc:
            print(f"  batch {batch[0]}…{batch[-1]}: ошибка ({exc})")
        finally:
            try: out_path.unlink(missing_ok=True)
            except Exception: pass
    return assets


def build_data():
    # A lightweight launcher normally precomputes forecast blocks in isolated
    # workers.  Assembly then starts in a fresh process with no accumulated native
    # ML state.  Direct in-process fallback is retained for tests/debugging.
    prebuilt=os.getenv("EXPORT_PREBUILT_ASSETS_FILE","").strip()
    if prebuilt and Path(prebuilt).exists():
        assets=json.loads(Path(prebuilt).read_text(encoding="utf-8"))
    else:
        assets = _build_assets_for_export()
    con = db.connect()
    # v3.5: settle legacy track-record entries only in the parent DB session.
    MR.settle_predictions(con)

    outc = MF.meeting_outcomes(con)
    today = pd.Timestamp.today().normalize()
    cbf = load_cb_factors()
    events = []
    for _, e in outc.iterrows():
        if e["date"] < today:
            continue
        expected = None if pd.isna(e["expected_bp"]) else int(e["expected_bp"])
        factors = cbf.get(e["cb"], [])
        events.append({
            "date": e["date"].strftime("%Y-%m-%d"),
            "cb": e["cb"],
            "event": e["event"],
            "expected_bp": expected,
            "factors": factors,
            "rate_probabilities": rate_decision_probabilities(expected, factors),
            "probability_note": "сценарная оценка Morpheus, не биржевая implied probability",
        })
    events = events[::-1]

    rates = db.read_cb_rates(con)
    rate_rows = [{"country": r["country"], "rate_name": r["rate_name"],
                  "rate": r["rate"], "trend": r["trend"], "as_of": r["as_of"],
                  "forecast": rate_forecast(r["country"], r["trend"], events, r["rate"])}
                 for _, r in rates.iterrows()]

    macro_stats = load_macro_stats()

    pol = P.load_events()
    pol_rows = [{"title": e["title"], "cat_key": e["category"],
                 "category": P.CAT_RU.get(e["category"], e["category"]),
                 "severity": int(e["severity"]),
                 "note": e["note"] if isinstance(e["note"], str) else "",
                 "date": str(e["date"])} for _, e in pol.iterrows()]

    # --- новостной слой + индекс настроений ---
    # Startup/static export must be deterministic and bounded. Live news is served
    # by the API after startup, so the exporter uses the local seed/last-good layer
    # by default and never blocks the whole site on an external news/translation call.
    # Offline publishers can opt back into live export explicitly.
    allow_live_news = str(os.getenv("NEWS_FETCH_DURING_EXPORT", "0")).strip().lower() in {"1","true","yes","on"}
    news_items = NEWS.build([{"symbol": a["symbol"], "name": a["name"]} for a in assets], allow_live=allow_live_news)
    vm = db.read_macro(con, "VIXCLS")
    vix_last = float(vm["value"].iloc[-1]) if not vm.empty else None
    senti = NEWS.sentiment(assets, vix_last)
    # стопка новостей под каждым политическим риском (по категории)
    for pr in pol_rows:
        pr["news"] = [{"title": n["title"], "source": n["source"], "url": n["url"]}
                      for n in news_items if n["category"] == pr["cat_key"]][:4]

    data = {"version":"3.8", "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "assets": assets, "events": events, "rates": rate_rows,
            "political": pol_rows, "news": news_items, "sentiment": senti,
            "macro_stats": macro_stats}

    # Research forecasts are served exclusively by the release-aware trained engine.
    # Do not republish the retired hand-weighted forecasts in offline snapshots.
    retired={"version":"4.40.10.19","macro":[],"rates":[],"months":[],"status":"replaced_by_macro_policy_v19","endpoint":"/api/macro-policy/v19"}
    data["research_outlook_v46"]=retired
    data["research_monthly_v4403"]=retired
    data["ui_version"] = "4.40.9"
    data["scenario_core_version"] = "4.7"
    data["corporate_finance_version"] = "4.8"

    con.close()
    return data


def build():
    data = build_data()
    SITE.mkdir(exist_ok=True)
    # v4.40.3: the live UI already renders provider images lazily and applies the
    # Morpheus green monochrome treatment in-browser. Downloading every news
    # image during startup made export needlessly slow and duplicated that work.
    # Local static media remains opt-in for offline publishing.
    if str(os.getenv("NEWS_PREPARE_STATIC_MEDIA", "0")).strip().lower() in {"1","true","yes","on"}:
        try:
            data["news"] = NEWS.prepare_media(data.get("news", []), SITE)
        except Exception:
            pass
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    payload = "window.FORECASTS = " + raw + ";\n"
    import quality_contract_v4401011 as QUALITY
    data = QUALITY.snapshot(data)
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    payload = "window.FORECASTS = " + raw + ";"
    (SITE / "data.js").write_text(payload, encoding="utf-8")
    (SITE / "data.json").write_text(raw + "\n", encoding="utf-8")
    print(f"\nГотово: {len(data['assets'])} активов -> site/data.js + site/data.json "
          f"({len(payload)//1024} КБ). Открой site/index.html.")
    return data


if __name__ == "__main__":
    # Internal bounded worker mode used by the lightweight launcher.
    if "--asset-batch" in sys.argv:
        try:
            i=sys.argv.index("--asset-batch"); symbols=json.loads(sys.argv[i+1])
            j=sys.argv.index("--batch-out"); out_path=sys.argv[j+1]
            _asset_batch_worker([str(x) for x in symbols],out_path)
        except Exception as exc:
            print(f"asset batch bootstrap failed: {type(exc).__name__}: {exc}",file=sys.stderr)
            sys.stderr.flush(); os._exit(2)
    if "--assemble-assets" in sys.argv:
        j=sys.argv.index("--assemble-assets")
        os.environ["EXPORT_PREBUILT_ASSETS_FILE"]=sys.argv[j+1]
        build(); sys.stdout.flush(); sys.stderr.flush(); os._exit(0)
    # Replace this already-imported heavy process with the stdlib-only launcher
    # before performing any model fits.  The launcher owns all batch workers.
    launcher=Path(__file__).with_name("export_launcher_v4408.py")
    os.execv(sys.executable,[sys.executable,str(launcher)])
