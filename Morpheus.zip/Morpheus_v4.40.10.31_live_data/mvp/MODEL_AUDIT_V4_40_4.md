# Model Audit — v4.40.4 Model Integrity

## Purpose

v4.40.4 is an integrity release. It deliberately avoids adding another expert model and instead fixes semantic and validation inconsistencies found in the existing forecasting stack.

## Live directional contract

The production-facing forecast now distinguishes:

- `P(significant UP)`;
- `P(NEUTRAL)`;
- `P(significant DOWN)`.

The significance band is volatility-adjusted. A tiny positive return is therefore not automatically treated as a fully correct bullish forecast.

For backward compatibility, older `p_up/p_down` fields are retained as directional scores. New code that needs a true three-state probability distribution must use `class_probabilities`.

## Leakage controls

The integrity contract requires chronological separation between model fitting, calibration, threshold tuning and final evaluation. Unknown future outcomes are excluded rather than converted to negative labels.

The distribution layer keeps its untouched audit and only then performs a production refit. Overlapping forecast horizons are treated as dependent observations in uncertainty diagnostics.

## Research-only outputs

The v4.40.3 monthly rate/macroeconomic block remains a scenario engine until enough point-in-time meeting evidence exists for a properly trained meeting model. UI semantics explicitly state this limitation.

Intraday technical outputs are also marked as uncalibrated technical direction scores.

## Prospective evidence

Do not delete `~/AllAnalytics_Data/`. Directional/distribution evidence from earlier releases remains valuable, but v4.40.4 is tagged with a new model generation because the target/probability semantics changed. Cross-generation performance should be compared explicitly rather than pooled as if the forecasts were identical.

## Release status

All 133 project tests passed in the final release tree. Static export and smoke checks also passed.
