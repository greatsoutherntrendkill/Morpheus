# Scenario Lab roadmap

## v4.7 — AI Scenario Core
- стабильный ScenarioIntent JSON-контракт;
- provider interface под будущий AI;
- локальный parser без внешнего API;
- существующий rule engine остаётся числовым ядром;
- новый понятный пользовательский ответ: что вероятнее, почему, что изменит прогноз, связанные активы;
- UI не показывает внутреннюю сложность.

## v4.8 — Historical Analog Engine + OpenAI
- подключить OpenAI API;
- заменить LocalScenarioParser на LLM provider через тот же контракт;
- event database;
- поиск похожих исторических эпизодов;
- блок «Найдено N похожих ситуаций».

## v4.9 — Quant Scenario Model
- Monte Carlo;
- volatility regime;
- correlation shocks;
- options implied move;
- shock sensitivities;
- статистические диапазоны и confidence.

## v5.0 — Scenario Intelligence
- LLM + historical analogs + current news + macro + derivatives + quant;
- timeline;
- related assets;
- «что изменит прогноз»;
- объяснение с progressive disclosure.

## v5.1 — Model Competition
- Terra champion;
- Claude Sonnet shadow challenger;
- Sol escalation model;
- сравнение качества на накопленных сценариях.
