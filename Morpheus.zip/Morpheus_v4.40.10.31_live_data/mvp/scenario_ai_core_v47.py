
"""Morpheus v4.7 — AI Scenario Core без внешнего API.

Архитектура:
1. ParserProvider — превращает вопрос в ScenarioIntent.
2. EvidenceBuilder — связывает intent с текущими данными Morpheus.
3. Quant/Rule Engine — существующий scenario_engine_v46.
4. Presenter — превращает расчёт в простой пользовательский ответ.

В v4.7 используется LocalScenarioParser.
В v4.8 в ParserProvider можно подключить OpenAI без изменения UI/quant-слоя.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Protocol, Any

import scenario_engine_v46 as RULES
from scenario_contract_v47 import ScenarioIntent, ScenarioCondition, normalize_intent


ASSET_WORDS = {
    "золот": "GC=F", "нефт": "CL=F", "газ": "NG=F",
    "битко": "BTC-USD", "bitcoin": "BTC-USD", "btc": "BTC-USD",
    "ethereum": "ETH-USD", "эфир": "ETH-USD",
    "nasdaq": "^NDX", "s&p": "^GSPC", "sp500": "^GSPC",
    "рубл": "RUB=X", "мосбир": "IMOEX", "доллар": "DX-Y.NYB",
}
REGIONS = [
    ("Ормуз", r"ормуз"),
    ("Иран", r"\bиран"),
    ("Россия", r"росси|\bрф\b"),
    ("Украина", r"украин"),
    ("США", r"\bсша\b|америк|вашингтон|трамп"),
    ("Китай", r"китай|пекин"),
    ("Тайвань", r"тайван"),
    ("Европа", r"\bес\b|европ|брюссел"),
    ("Ближний Восток", r"ближн.*восток|израил|сауд"),
]
EVENTS = [
    ("военная эскалация", r"войн|вторг|удар|атак|эскалац|блокад"),
    ("санкции / активы", r"санкц|замороженн.*актив|конфиск|резерв.*передад|резерв.*отдад"),
    ("денежная политика", r"ставк|фрс|ецб|центробанк|банк росс"),
    ("крипто-событие", r"сатош|биткоин.*прод|кошел.*btc|взлом.*бирж"),
    ("энергетический шок", r"нефт|газ|опек|opec|пролив"),
    ("макро-шок", r"инфляц|рецесс|безработ|ввп|кризис"),
]
CHANNELS = [
    ("поставки сырья", r"нефт|газ|пролив|экспорт|постав"),
    ("потоки капитала", r"резерв|актив|санкц|капитал|валют"),
    ("стоимость денег", r"ставк|доходност|фрс|ецб|центробанк"),
    ("ликвидность", r"битко|крипто|ликвид|продаст|кошел"),
    ("аппетит к риску", r"войн|эскалац|санкц|кризис|атак"),
]


class ParserProvider(Protocol):
    name: str
    def parse(self, question: str, previous_question: str | None = None) -> dict[str, Any]: ...


class LocalScenarioParser:
    name = "local-v4.7"

    def parse(self, question: str, previous_question: str | None = None) -> dict[str, Any]:
        combined = " ".join(x for x in [previous_question, question] if x).strip()
        low = combined.lower()
        assets = []
        for word, sym in ASSET_WORDS.items():
            if word in low and sym not in assets:
                assets.append(sym)
        region = next((name for name, pat in REGIONS if re.search(pat, combined, re.I)), "")
        event_type = next((name for name, pat in EVENTS if re.search(pat, combined, re.I)), "рыночный шок")
        channels = [name for name, pat in CHANNELS if re.search(pat, combined, re.I)]
        if not channels:
            channels = ["ожидания участников рынка", "риск-премия"]
        severity = "высокая" if re.search(r"полност|войн|вторг|конфиск|блокир|массов|резк",low) else "средняя"
        timing = "завтра" if "завтра" in low else "ближайшее время"
        duration = ""
        m = re.search(r"(\d+)\s*(дн|дня|дней|недел|месяц)",low)
        if m:
            duration = m.group(0)
        cond = ScenarioCondition(
            event_type=event_type,
            subject=question.strip(),
            region=region,
            timing=timing,
            duration=duration,
            severity=severity,
            assets=assets,
            channels=channels,
        )
        return ScenarioIntent(
            question=combined,
            conditions=[cond],
            requested_asset=assets[0] if assets else None,
            parser=self.name,
        ).to_dict()


@dataclass
class ScenarioCore:
    parser: ParserProvider

    def capabilities(self) -> dict[str, Any]:
        return {
            "version": "4.7",
            "mode": "local",
            "external_ai_connected": False,
            "parser": self.parser.name,
            "pipeline": [
                {"id":"understand","label":"Понимаем событие","ready":True},
                {"id":"evidence","label":"Связываем с рынком","ready":True},
                {"id":"calculate","label":"Считаем реакцию","ready":True},
                {"id":"explain","label":"Объясняем простыми словами","ready":True},
                {"id":"historical","label":"Исторические аналоги","ready":False,"planned":"v4.8"},
                {"id":"quant","label":"Статистическая оценка","ready":False,"planned":"v4.9"},
            ],
            "provider_slot": {
                "interface": "ParserProvider",
                "active": "LocalScenarioParser",
                "future": "external-llm-provider",
                "planned_version": "4.8",
            },
        }

    def analyze(self, payload: dict[str, Any], question: str, previous_question: str | None = None) -> dict[str, Any]:
        intent = normalize_intent(self.parser.parse(question, previous_question))
        raw = RULES.analyze(payload, question, previous_question)
        result = enrich_for_user(raw, intent)
        result["scenario_intent"] = intent
        result["core"] = {
            "version":"4.7",
            "mode":"local",
            "external_ai_connected":False,
            "parser":self.parser.name,
        }
        return result


def _main_impact(raw: dict[str, Any], intent: dict[str, Any]) -> dict[str, Any] | None:
    impacts = raw.get("impacts") or []
    requested = intent.get("requested_asset")
    if requested:
        hit = next((x for x in impacts if x.get("symbol")==requested),None)
        if hit:
            return hit
    if not impacts:
        return None
    return max(impacts,key=lambda x:max(abs(float((x.get("range_pct") or [0,0])[0])),
                                         abs(float((x.get("range_pct") or [0,0])[1]))))


def _plain_direction(impact: dict[str, Any] | None) -> str:
    if not impact:
        return "Реакция пока неясна"
    lo,hi=(impact.get("range_pct") or [0,0])[:2]
    mid=(float(lo)+float(hi))/2
    if mid>=2:
        return "Скорее рост"
    if mid<=-2:
        return "Скорее падение"
    return "Скорее высокая волатильность"


def _what_changes(raw: dict[str, Any], intent: dict[str, Any]) -> list[str]:
    cond=(intent.get("conditions") or [{}])[0]
    event=cond.get("event_type","")
    if "военн" in event or "энергет" in event:
        return [
            "Станет ли событие реально влиять на физические поставки",
            "Как долго сохранится ограничение или угроза",
            "Будут ли ответные меры других стран",
        ]
    if "санкц" in event:
        return [
            "Юридическая реализуемость решения",
            "Ответные меры и ограничения расчётов",
            "Фактическое изменение потоков капитала",
        ]
    if "крипто" in event:
        return [
            "Появятся ли реальные переводы крупных объёмов на биржи",
            "Глубина ликвидности и размер ликвидаций",
            "Скорость восстановления спроса после первого шока",
        ]
    if "денежн" in event:
        return [
            "Новые данные по инфляции и рынку труда",
            "Риторика центрального банка",
            "Изменение ожиданий по следующему заседанию",
        ]
    return [
        "Подтвердится ли само событие",
        "Насколько сильно изменятся реальные денежные или товарные потоки",
        "Как отреагируют связанные рынки в первые часы",
    ]


def enrich_for_user(raw: dict[str, Any], intent: dict[str, Any]) -> dict[str, Any]:
    out=dict(raw)
    main=_main_impact(raw,intent)
    out["headline"] = {
        "label": _plain_direction(main),
        "asset": (main or {}).get("name") or (main or {}).get("symbol") or "рынок",
        "range_pct": (main or {}).get("range_pct") or [0,0],
        "reason": (raw.get("summary") or "").split(".")[0].strip() + ".",
    }
    out["simple_answer"] = {
        "what_likely": raw.get("summary") or "Рынок сначала переоценит риск, затем движение будет зависеть от реального масштаба события.",
        "why": (raw.get("transmission") or [])[:4],
        "what_changes_forecast": _what_changes(raw,intent),
        "related_assets": [
            {
                "symbol":x.get("symbol"),
                "name":x.get("name"),
                "direction":x.get("direction"),
                "range_pct":x.get("range_pct"),
            } for x in (raw.get("impacts") or [])[:6]
        ],
    }
    out["answer_style"]="simple-analytical-v4.7"
    return out


CORE = ScenarioCore(LocalScenarioParser())
