"""
techa.py — технический анализ и разметка Smart Money (ICT), считается из OHLC.
Никаких внешних данных не нужно: свинги, структура (BOS/CHoCH), FVG-имбалансы,
order blocks, ликвидность (equal highs/lows), premium/discount, уровни S/R,
тренд-линии и ЦЕНОВЫЕ ЦЕЛИ по сценариям (уровни + проекция ATR/замер структуры).

Честность: уровни точны (это факт из графика). Достижение уровня — вероятностно,
поэтому к каждой цели считается ЭМПИРИЧЕСКАЯ частота достижения за горизонт.
"""
import numpy as np
import pandas as pd

H = 10          # горизонт целей, дней
K = 3           # окно для свингов


def atr(df, n=14):
    h, l, c = df["high"], df["low"], df["close"]
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()],
                   axis=1).max(axis=1)
    return float(tr.rolling(n).mean().iloc[-1])


def swings(df, k=K):
    h, l = df["high"].values, df["low"].values
    n = len(df)
    sh, sl = [], []
    for i in range(k, n - k):
        if h[i] == max(h[i - k:i + k + 1]):
            sh.append((i, float(h[i])))
        if l[i] == min(l[i - k:i + k + 1]):
            sl.append((i, float(l[i])))
    return sh, sl


def structure(sh, sl, price):
    """Био­рыночная структура: тренд, инвалидация, замер последней ноги."""
    out = {"bias": "range", "invalidation": None, "leg": None,
           "bos": None, "choch": None}
    if len(sh) >= 2 and len(sl) >= 2:
        hh = sh[-1][1] > sh[-2][1]
        hl = sl[-1][1] > sl[-2][1]
        lh = sh[-1][1] < sh[-2][1]
        ll = sl[-1][1] < sl[-2][1]
        if hh and hl:
            out["bias"] = "bull"
            out["invalidation"] = sl[-1][1]
            out["bos"] = sh[-2][1]
        elif lh and ll:
            out["bias"] = "bear"
            out["invalidation"] = sh[-1][1]
            out["bos"] = sl[-2][1]
        else:
            out["bias"] = "range"
            out["choch"] = sl[-1][1] if price > sl[-1][1] else sh[-1][1]
    if sh and sl:
        out["leg"] = abs(sh[-1][1] - sl[-1][1])
    return out


def levels(sh, sl, price, a):
    """Кластеризованные уровни S/R около цены с числом касаний."""
    pts = sorted([p for _, p in sh] + [p for _, p in sl])
    tol = 0.6 * a if a else 0
    clusters = []
    for p in pts:
        if clusters and abs(p - clusters[-1]["m"]) <= tol:
            c = clusters[-1]
            c["s"] += p
            c["n"] += 1
            c["m"] = c["s"] / c["n"]
        else:
            clusters.append({"s": p, "n": 1, "m": p})
    lv = [{"price": round(c["m"], 4), "touches": c["n"]} for c in clusters]
    res = sorted([x for x in lv if x["price"] > price], key=lambda x: x["price"])
    sup = sorted([x for x in lv if x["price"] < price], key=lambda x: -x["price"])
    return res, sup


def fvgs(df, price, a, keep=4):
    """Fair Value Gaps (3-свечной имбаланс), только незакрытые, около цены."""
    h, l = df["high"].values, df["low"].values
    n = len(df)
    dates = df["date"].values
    out = []
    for i in range(2, n):
        if l[i] > h[i - 2]:                       # бычий гэп
            top, bot = float(l[i]), float(h[i - 2])
            filled = (l[i + 1:] <= bot).any() if i + 1 < n else False
            if not filled:
                out.append({"type": "bull", "top": round(top, 4),
                            "bottom": round(bot, 4), "date": str(pd.Timestamp(dates[i - 1]).date())})
        if h[i] < l[i - 2]:                        # медвежий гэп
            top, bot = float(l[i - 2]), float(h[i])
            filled = (h[i + 1:] >= top).any() if i + 1 < n else False
            if not filled:
                out.append({"type": "bear", "top": round(top, 4),
                            "bottom": round(bot, 4), "date": str(pd.Timestamp(dates[i - 1]).date())})
    out.sort(key=lambda z: abs((z["top"] + z["bottom"]) / 2 - price))
    return out[:keep]


def order_blocks(df, sh, sl, keep=2):
    """Order block: последняя противоположная свеча перед импульсом к BOS."""
    o, c = df["open"].values, df["close"].values
    h, l = df["high"].values, df["low"].values
    dates = df["date"].values
    obs = []
    if sh:
        j = sh[-1][0]                              # последний swing high
        for i in range(j, max(j - 12, 0), -1):     # ищем последнюю медвежью свечу до него
            if c[i] < o[i]:
                obs.append({"type": "bull", "top": round(float(max(o[i], c[i])), 4),
                            "bottom": round(float(l[i]), 4),
                            "date": str(pd.Timestamp(dates[i]).date())})
                break
    if sl:
        j = sl[-1][0]
        for i in range(j, max(j - 12, 0), -1):
            if c[i] > o[i]:
                obs.append({"type": "bear", "top": round(float(h[i]), 4),
                            "bottom": round(float(min(o[i], c[i])), 4),
                            "date": str(pd.Timestamp(dates[i]).date())})
                break
    return obs[:keep]


def liquidity(sh, sl, a):
    """Equal highs/lows — зоны ликвидности (buyside сверху, sellside снизу)."""
    tol = 0.3 * a if a else 0
    out = []
    for arr, kind in ((sh, "buyside"), (sl, "sellside")):
        prices = [p for _, p in arr][-6:]
        for i in range(len(prices)):
            for j in range(i + 1, len(prices)):
                if abs(prices[i] - prices[j]) <= tol:
                    out.append({"price": round((prices[i] + prices[j]) / 2, 4),
                                "kind": kind})
    # уникальные
    seen, uniq = set(), []
    for x in out:
        key = (x["kind"], round(x["price"], 2))
        if key not in seen:
            seen.add(key)
            uniq.append(x)
    return uniq[:4]


def premium_discount(df, price, lookback=60):
    d = df.tail(lookback)
    hi, lo = float(d["high"].max()), float(d["low"].min())
    eq = (hi + lo) / 2
    return {"high": round(hi, 4), "low": round(lo, 4), "eq": round(eq, 4),
            "state": "premium" if price > eq else "discount"}


def trendlines(sh, sl):
    """Линии по последним свингам: поддержка по лоу, сопротивление по хай."""
    lines = []
    if len(sl) >= 2:
        (i1, p1), (i2, p2) = sl[-2], sl[-1]
        lines.append({"kind": "support", "x1": i1, "y1": round(p1, 4),
                      "x2": i2, "y2": round(p2, 4)})
    if len(sh) >= 2:
        (i1, p1), (i2, p2) = sh[-2], sh[-1]
        lines.append({"kind": "resistance", "x1": i1, "y1": round(p1, 4),
                      "x2": i2, "y2": round(p2, 4)})
    return lines


def _reach_prob(close, dist_pct, up=True, horizon=H):
    """Эмпирическая частота: как часто за horizon дней цена доходила до дистанции."""
    c = close.values
    n = len(c)
    hits = tot = 0
    for t in range(n - horizon):
        window = c[t + 1:t + 1 + horizon]
        if up:
            move = window.max() / c[t] - 1
            if move >= dist_pct:
                hits += 1
        else:
            move = window.min() / c[t] - 1
            if move <= -dist_pct:
                hits += 1
        tot += 1
    return round(hits / tot, 2) if tot else None


def targets(df, price, res, sup, fvg, a, struct):
    close = df["close"]
    bull, bear = [], []

    def add(lst, price_t, label, up):
        if price_t is None or price_t <= 0:
            return
        dist = abs(price_t / price - 1)
        lst.append({"label": label, "price": round(float(price_t), 4),
                    "dist_pct": round(dist * 100, 2),
                    "prob": _reach_prob(close, dist, up=up)})

    # уровни
    for r in res[:2]:
        add(bull, r["price"], f"сопротивление ({r['touches']} кас.)", True)
    for s in sup[:2]:
        add(bear, s["price"], f"поддержка ({s['touches']} кас.)", False)
    # ближайший FVG как магнит
    for f in fvg:
        mid = (f["top"] + f["bottom"]) / 2
        if mid > price:
            add(bull, f["top"], "верх FVG", True)
        else:
            add(bear, f["bottom"], "низ FVG", False)
    # проекции
    if a:
        add(bull, price + 1.5 * a, "проекция +1.5·ATR", True)
        add(bear, price - 1.5 * a, "проекция −1.5·ATR", False)
    if struct.get("leg"):
        add(bull, price + struct["leg"], "замер структуры вверх", True)
        add(bear, price - struct["leg"], "замер структуры вниз", False)

    # сорт по близости, дедуп, топ-3
    def dedup(lst):
        lst.sort(key=lambda z: z["dist_pct"])
        out, seen = [], []
        for z in lst:
            if all(abs(z["price"] - s) > 0.4 * (a or 1) for s in seen):
                out.append(z)
                seen.append(z["price"])
            if len(out) >= 3:
                break
        return out
    return {"bull": dedup(bull), "bear": dedup(bear)}


def analyze(df):
    """Полный слой SMC/ICT + цели. df: date, open, high, low, close (по возрастанию дат)."""
    if df.empty or len(df) < 40:
        return None
    df = df.reset_index(drop=True)
    price = float(df["close"].iloc[-1])
    a = atr(df)
    sh, sl = swings(df)
    struct = structure(sh, sl, price)
    res, sup = levels(sh, sl, price, a)
    fvg = fvgs(df, price, a)
    obs = order_blocks(df, sh, sl)
    liq = liquidity(sh, sl, a)
    pd_zone = premium_discount(df, price)
    tls = trendlines(sh, sl)
    tgt = targets(df, price, res, sup, fvg, a, struct)
    return {
        "atr": round(a, 4), "price": round(price, 4),
        "structure": struct, "resistance": res[:3], "support": sup[:3],
        "fvg": fvg, "order_blocks": obs, "liquidity": liq,
        "premium_discount": pd_zone, "trendlines": tls, "targets": tgt,
        "swings_high": [{"i": i, "p": round(p, 4)} for i, p in sh[-6:]],
        "swings_low": [{"i": i, "p": round(p, 4)} for i, p in sl[-6:]],
    }
