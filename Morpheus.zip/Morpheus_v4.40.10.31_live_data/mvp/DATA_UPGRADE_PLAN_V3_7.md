# What to add next — external data priority for Morpheus

## 1. CoinGlass API — highest incremental priority

Add to `.env`:

```text
COINGLASS_API_KEY=...
```

Why:
- funding rates;
- aggregated open interest;
- liquidations;
- futures basis / positioning proxies.

Best fit:
- BTC, ETH, SOL, XRP.

The code already includes CoinGlass V4 generic and convenience clients in
`external_apis.py`. Do not paste the key into source code.

## 2. Massive Options API — highest priority for US equities

Add:

```text
OPTIONS_PROVIDER=massive
OPTIONS_API_KEY=...
```

Useful features:
- implied volatility;
- Greeks;
- options open interest;
- derived 25-delta skew;
- put/call and term structure constructed from the option chain.

A chain-snapshot client is already included. Historical feature engineering must
be versioned separately before it enters a backtest.

## 3. EIA API — free and useful for oil / gas

Add:

```text
EIA_API_KEY=...
```

`external_apis.py` already has the EIA v2 client.

Priority features:
- weekly crude inventories;
- gasoline/distillate inventories;
- natural-gas storage;
- US production.

## 4. CFTC COT — no key required

The project already has a CFTC Public Reporting client.

Useful:
- leveraged money;
- asset manager;
- managed money;
- producer/merchant positioning.

Best for:
- FX;
- commodities;
- index futures.

## 5. FRED/ALFRED — keep this configured

```text
FRED_API_KEY=...
```

v3.7 adds Treasury curve, credit spread and NFCI series automatically on the next
`update.py` / `refresh_v36.py` run.

## Recommended order

If spending money on only one provider:
**CoinGlass first** if crypto is strategically important.

If US indices are the main product:
**Massive Options first**.

If you want maximum improvement per zero/low cost:
**FRED + CFTC + EIA** before buying another general price API.
