"""Local maintenance command; secrets are read only from the user's .env."""
import argparse,json
import macro_policy_service_v19 as S

def main():
 p=argparse.ArgumentParser(description='Обновить историю и обучить модели ставок/макро')
 p.add_argument('--offline',action='store_true',help='обучение на сохранённой истории без запросов к FRED')
 args=p.parse_args();S.job(not args.offline)
 print(json.dumps(S.STATE,ensure_ascii=False,indent=2))
 return 1 if S.STATE.get('error') else 0
if __name__=='__main__':raise SystemExit(main())
