#!/bin/zsh
# Compatibility entry point for earlier macOS instructions.
exec zsh "$(dirname "$0")/../START_MORPHEUS.command"
