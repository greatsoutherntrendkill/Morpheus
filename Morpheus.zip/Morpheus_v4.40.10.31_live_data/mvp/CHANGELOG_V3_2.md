# Morpheus v3.2 — Model Governance

## Added
- Immutable `model_registry`: every production model is frozen by version, feature version, validation version and code hash.
- Append-only `prediction_ledger`: each live probability is persisted with symbol, horizon, prediction/data-cutoff timestamps, quality gate, macro provenance and holdout status.
- Ledger writes are idempotent for the same `(model_version, symbol, horizon, data_cutoff)`.
- SQLite triggers reject deletion and mutation of historical predictions. Only the first realized outcome may be attached later.
- `challenger_runs` and `promotion_history` tables establish the champion/challenger governance layer without introducing a new ML model yet.
- Conservative promotion rule: challenger needs effective N >= 30, positive lower 95% holdout CI for edge and Brier skill, and better net economic value. Promotion remains explicit/manual.
- API: `/api/model-registry` and `/api/prediction-ledger`.

## Champion
`logreg-v3.2.0` remains the frozen champion. v3.2 intentionally does **not** add LightGBM/CatBoost: the next version can now compare them against the same immutable ledger and locked holdout without moving the goalposts.
