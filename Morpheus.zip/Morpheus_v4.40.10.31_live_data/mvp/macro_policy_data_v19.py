"""Release-time aware inputs for macro/policy learning. No scenario anchors."""
from __future__ import annotations
from contextlib import closing
import hashlib,json,os,sqlite3
from datetime import datetime,timezone,timedelta
from pathlib import Path
import requests

REGISTRY={
 'UNRATE':dict(name='Безработица',country='US',kind='macro',unit='%',freq='M',transform='level'),
 'CPIAUCSL':dict(name='Инфляция CPI · сезонно скорректированная',country='US',kind='macro',unit='% г/г',freq='M',transform='yoy'),
 'PCEPILFE':dict(name='Базовая инфляция PCE',country='US',kind='macro',unit='% г/г',freq='M',transform='yoy'),
 'GDPC1':dict(name='Рост реального ВВП',country='US',kind='macro',unit='% кв/кв, годовой темп',freq='Q',transform='annualized'),
 'PAYEMS':dict(name='Занятость вне сельского хозяйства',country='US',kind='macro',unit='тыс. за месяц',freq='M',transform='change'),
 'DFEDTARL':dict(name='FFR · нижняя граница',country='US',kind='rate',unit='%',freq='M',transform='level'),
 'DFEDTARU':dict(name='FFR · верхняя граница',country='US',kind='rate',unit='%',freq='M',transform='level'),
 'INDPRO':dict(name='Промышленное производство',country='US',kind='feature',unit='% г/г',freq='M',transform='yoy'),
 'RSAFS':dict(name='Розничные продажи',country='US',kind='feature',unit='% г/г',freq='M',transform='yoy'),
 'T10Y2Y':dict(name='Наклон кривой доходности',country='US',kind='feature',unit='п.п.',freq='M',transform='level'),
}
COUNTRIES={'US':'США','RU':'Россия','EA':'Еврозона','GB':'Великобритания','JP':'Япония','CA':'Канада','AU':'Австралия','CH':'Швейцария','CN':'Китай','IN':'Индия','BR':'Бразилия','ZA':'ЮАР','MX':'Мексика','KR':'Южная Корея','TR':'Турция','KZ':'Казахстан','BY':'Беларусь','AM':'Армения'}

def data_dir():
 p=Path(os.environ.get('ALLANALYTICS_DATA_DIR',Path(__file__).parent/'AllAnalytics_Data'))/'macro_policy_v19';p.mkdir(parents=True,exist_ok=True);return p

def connect(path=None):
 c=sqlite3.connect(str(path or data_dir()/'ledger.sqlite'),timeout=30);c.row_factory=sqlite3.Row
 c.executescript('''
 PRAGMA journal_mode=WAL;
 CREATE TABLE IF NOT EXISTS observations(series TEXT, period TEXT, available TEXT, value REAL, source TEXT, PRIMARY KEY(series,period,available));
 CREATE TABLE IF NOT EXISTS imports(id INTEGER PRIMARY KEY, recorded TEXT, series TEXT, rows INTEGER, digest TEXT);
 CREATE TABLE IF NOT EXISTS forecasts(id TEXT PRIMARY KEY, issued TEXT, series TEXT, period TEXT, horizon INTEGER, model TEXT, value REAL, lower REAL, upper REAL, baseline REAL, snapshot TEXT, metadata TEXT);
 CREATE TABLE IF NOT EXISTS outcomes(forecast_id TEXT PRIMARY KEY, recorded TEXT, available TEXT, value REAL, source TEXT);
 CREATE TABLE IF NOT EXISTS revisions(id INTEGER PRIMARY KEY, forecast_id TEXT, recorded TEXT, available TEXT, value REAL, UNIQUE(forecast_id,available));
 ''');return c

def ingest(c,series,rows,source='FRED/ALFRED'):
 if series not in REGISTRY:raise ValueError('unknown_series')
 cleaned=[]
 for r in rows:
  try:
   period=datetime.strptime(str(r['date']), '%Y-%m-%d').date().isoformat()
   # FRED gives a date, not an exact publication time: available only next UTC day.
   available=(datetime.strptime(str(r['realtime_start']), '%Y-%m-%d').replace(tzinfo=timezone.utc)+timedelta(days=1)).isoformat()
   value=None if r['value'] in ('.',None,'') else float(r['value'])
   if value is not None and not __import__('math').isfinite(value):continue
  except (ValueError,KeyError,TypeError):continue
  if available[:10]<period:raise ValueError('release_before_observation')
  cleaned.append((series,period,available,value,source))
 with c:
  for row in cleaned:
   old=c.execute('SELECT value FROM observations WHERE series=? AND period=? AND available=?',row[:3]).fetchone()
   if old and old[0]!=row[3]:raise ValueError('conflicting_vintage')
   c.execute('INSERT OR IGNORE INTO observations VALUES (?,?,?,?,?)',row)
  digest=hashlib.sha256(json.dumps(cleaned,sort_keys=True).encode()).hexdigest()
  c.execute('INSERT INTO imports(recorded,series,rows,digest) VALUES(?,?,?,?)',(datetime.now(timezone.utc).isoformat(),series,len(cleaned),digest))
 return len(cleaned)

def fetch_series(series,key,start='1995-01-01',session=None,realtime_start=None,realtime_end=None):
 if not key:raise ValueError('FRED_API_KEY_required')
 if session is None:
  with requests.Session() as owned:
   return fetch_series(series,key,start,owned,realtime_start,realtime_end)
 client=session;rows=[];offset=0
 if series in ('DFEDTARL','DFEDTARU','T10Y2Y') and realtime_start is None:
  for year in range(1995,datetime.now(timezone.utc).year+1,4):
   rows.extend(fetch_series(series,key,start,client,f'{year}-01-01',f'{year+3}-12-31' if year+3<datetime.now(timezone.utc).year else '9999-12-31'))
  return rows
 while True:
  params=dict(series_id=series,api_key=key,file_type='json',observation_start=start,realtime_start=realtime_start or '1776-07-04',output_type=1 if series in ('DFEDTARL','DFEDTARU','T10Y2Y') else 3,limit=10000,offset=offset,sort_order='asc')
  if realtime_end:params['realtime_end']=realtime_end
  try:
   for attempt in range(3):
    try:
     response=client.get('https://api.stlouisfed.org/fred/series/observations',params=params,timeout=(10,90));break
    except requests.RequestException:
     if attempt==2:raise
   if response.status_code!=200:
    message=str(response.json().get('error_message',''))
    if realtime_start and 'series does not exist in ALFRED' in message:return []
    raise RuntimeError('FRED_HTTP_'+str(response.status_code))
   body=response.json()
  except requests.RequestException:raise RuntimeError('FRED_connection_failed') from None
  page=body.get('observations',[])
  if not isinstance(page,list):raise RuntimeError('FRED_invalid_response')
  for item in page:
   if 'value' in item and 'realtime_start' in item:rows.append(item)
   else:
    for column,value in item.items():
     if column.startswith(series+'_'):
      try:stamp=datetime.strptime(column[len(series)+1:],'%Y%m%d').date().isoformat()
      except ValueError:continue
      rows.append(dict(date=item['date'],realtime_start=stamp,value=value))
  offset+=len(page)
  if offset>=int(body.get('count',offset)) or not page:break
  if offset>1000000:raise RuntimeError('FRED_dataset_limit')
 return rows

def refresh(key,series=None,path=None):
 result=[]
 with closing(connect(path)) as c, c:
  for sid in series or REGISTRY:
   try:result.append(dict(series=sid,rows=ingest(c,sid,fetch_series(sid,key)),status='ok'))
   except Exception as exc:result.append(dict(series=sid,status='error',error=type(exc).__name__,reason=str(exc) if isinstance(exc,(ValueError,RuntimeError)) else 'provider_error'))
 return result

def rows(c):return [dict(r) for r in c.execute('SELECT * FROM observations ORDER BY series,period,available')]
