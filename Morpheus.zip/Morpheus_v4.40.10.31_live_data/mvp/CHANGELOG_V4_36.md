# Morpheus v4.36 — Prospective Feedback Loop

## Главная идея

v4.36 впервые отделяет **реальное качество новых live-прогнозов** от исторического backtest/OOS. Активная модель v4.35 не меняет свои веса на основании этих данных автоматически: новая версия сначала создаёт честный prospective ledger, ждёт фактического исхода и только после этого считает качество.

## Что добавлено

- `prospective_feedback_v436.py` — независимый append-only журнал live-прогнозов и их последующей проверки.
- Каждый дневной прогноз сохраняет point-in-time snapshot: тикер, горизонт, дата данных, цена входа, вероятность, порог сигнала, abstention, reliability, режим рынка, компоненты ансамбля и контекст.
- Повторный запрос неизменившегося прогноза не создаёт дубликат: используется стабильный forecast key.
- После появления достаточного количества будущих торговых сессий прогноз автоматически settlement-ится по фактической цене.
- Малые движения отделяются от значимых через volatility-adjusted neutral band.
- Отдельно оцениваются опубликованные сигналы и случаи `NO EDGE`/abstention.
- Сохраняются Brier score, calibration error, directional hit и significant hit.
- Добавлена error attribution: context disagreement, event risk, feature drift, component disagreement, overconfidence, missed move, market noise и др.
- Добавлен rolling leaderboard ансамбля и его компонентов на **одних и тех же prospective наблюдениях**.
- Никакой model promotion не выполняется автоматически. Leaderboard только сообщает готовность к ручному review.

## Автоматический settlement

Forecast API записывает новый прогноз и запускает settlement в отдельном background worker. Сетевые/исторические ошибки мониторинга не способны сломать ответ основного forecast endpoint.

Settlement использует только свечи, находящиеся **строго после** `data_as_of`, и ждёт именно нужное количество будущих торговых наблюдений.

## API

- `/api/models/quality-v436?symbol=SBER.ME&horizon=10`
- `/api/models/prospective-v436/status`
- `/api/models/prospective-v436/ledger?symbol=SBER.ME&horizon=10&settled_only=1`
- `/api/models/prospective-v436/leaderboard?window_days=180&symbol=SBER.ME&horizon=10`
- `/api/models/prospective-v436/errors?symbol=SBER.ME&horizon=10`
- `POST /api/models/prospective-v436/settle`

Старые quality endpoints v4.35/v4.34/v4.33 сохранены как compatibility aliases.

## UI

В Technical Lab в блоке «На чём основан прогноз» появился раздел **«Проспективная проверка v4.36»**. После накопления фактических исходов он показывает число проверенных прогнозов, значимую accuracy и долю опубликованных сигналов. До накопления статистики честно отображается статус набора истории.

## Governance

- active forecast weights всё ещё задаются v4.35 Dynamic Ensemble;
- prospective ledger **не участвует** в обучении текущего прогноза;
- automatic promotion = false;
- prospective результаты предназначены для следующего этапа: доказательного отбора challenger-моделей и validation event/context слоя.

## Проверка

Полный проектный test suite после изменений: **83/83 passed**.
