"""Morpheus v4.40.5 — shared directional target contract.

One source of truth for what counts as a material market move.  Training,
backtests, prospective settlement and model governance must use this exact
contract so that a forecast is never trained on one target and scored on another.
"""
from __future__ import annotations

import math
import numpy as np
import pandas as pd

VERSION = "target-contract-v4.40.5"
TARGET_VERSION = "volatility-adjusted-3state-v4.40.5"
NEUTRAL_SIGMA = 0.35
MIN_ABS_MOVE = 0.0020
MAX_ABS_MOVE = 0.12
VOL_WINDOW = 20
VOL_MIN_PERIODS = 15


def _series(close) -> pd.Series:
    if isinstance(close, pd.Series):
        s = pd.Series(close, dtype=float).copy()
    elif isinstance(close, pd.DataFrame):
        col = "close" if "close" in close.columns else "Close" if "Close" in close.columns else None
        if col is None:
            return pd.Series(dtype=float)
        s = pd.Series(close[col], dtype=float).copy()
        if "date" in close.columns:
            s.index = pd.to_datetime(close["date"], errors="coerce")
    else:
        s = pd.Series(close, dtype=float)
    try:
        s.index = pd.to_datetime(s.index, errors="coerce")
    except Exception:
        pass
    return s.replace([np.inf, -np.inf], np.nan).dropna().sort_index()


def threshold_series(close, horizon: int, neutral_sigma: float = NEUTRAL_SIGMA) -> pd.Series:
    """Material-move threshold in log-return units, known at each forecast date."""
    c = _series(close)
    if c.empty:
        return pd.Series(dtype=float)
    h = max(1, int(horizon))
    lr = np.log(c / c.shift(1))
    vol = lr.rolling(VOL_WINDOW, min_periods=VOL_MIN_PERIODS).std()
    return (float(neutral_sigma) * vol * math.sqrt(h)).clip(lower=MIN_ABS_MOVE, upper=MAX_ABS_MOVE)


def target_frame(close, horizon: int, neutral_sigma: float = NEUTRAL_SIGMA) -> pd.DataFrame:
    """Return point-in-time UP / NEUTRAL / DOWN labels.

    state: +1 significant up, 0 neutral/noise, -1 significant down, NaN unknown.
    y: 1/0 only for significant moves; neutral and not-yet-known labels remain NaN.
    """
    c = _series(close)
    h = max(1, int(horizon))
    threshold = threshold_series(c, h, neutral_sigma=neutral_sigma)
    ret_fwd = np.log(c.shift(-h) / c)
    state = pd.Series(np.nan, index=c.index, dtype=float)
    known = ret_fwd.notna() & threshold.notna()
    state.loc[known] = 0.0
    state.loc[known & (ret_fwd > threshold)] = 1.0
    state.loc[known & (ret_fwd < -threshold)] = -1.0
    y = pd.Series(np.nan, index=c.index, dtype=float)
    y.loc[state > 0] = 1.0
    y.loc[state < 0] = 0.0
    neutral = pd.Series(np.nan, index=c.index, dtype=float)
    neutral.loc[known] = (state.loc[known] == 0).astype(float)
    label_end = pd.Series(c.index, index=c.index).shift(-h)
    return pd.DataFrame(
        {
            "ret_fwd": ret_fwd,
            "threshold": threshold,
            "state": state,
            "y": y,
            "neutral": neutral,
            "label_end": label_end,
        },
        index=c.index,
    )


def band_for_asof(close, horizon: int, as_of=None, neutral_sigma: float = NEUTRAL_SIGMA) -> float | None:
    """Return the exact material-move band in log-return fractions (not simple returns)."""
    c = _series(close)
    if c.empty:
        return None
    if as_of is not None:
        try:
            cutoff = pd.Timestamp(as_of).tz_localize(None) if pd.Timestamp(as_of).tzinfo else pd.Timestamp(as_of)
            c = c[c.index <= cutoff]
        except Exception:
            pass
    if c.empty:
        return None
    th = threshold_series(c, horizon, neutral_sigma=neutral_sigma).dropna()
    if th.empty:
        return None
    v = float(th.iloc[-1])
    return v if math.isfinite(v) else None


def band_pct_for_asof(close, horizon: int, as_of=None, neutral_sigma: float = NEUTRAL_SIGMA) -> float | None:
    x = band_for_asof(close, horizon, as_of=as_of, neutral_sigma=neutral_sigma)
    return None if x is None else float(x * 100.0)


def classify_return(realized_return_decimal: float, band_decimal: float) -> str:
    r = float(realized_return_decimal)
    b = abs(float(band_decimal))
    if r > b:
        return "up"
    if r < -b:
        return "down"
    return "neutral"


def one_hot(outcome: str) -> dict[str, float]:
    o = str(outcome or "").lower()
    return {"up": 1.0 if o == "up" else 0.0,
            "neutral": 1.0 if o == "neutral" else 0.0,
            "down": 1.0 if o == "down" else 0.0}


def normalize_class_probabilities(value: dict | None, *, p_neutral=None, conditional_p_up=None) -> dict[str, float] | None:
    """Normalize P(up), P(neutral), P(down), with a safe compatibility fallback."""
    if isinstance(value, dict):
        try:
            vals = {k: max(0.0, float(value.get(k, 0.0))) for k in ("up", "neutral", "down")}
            total = sum(vals.values())
            if total > 1e-12 and all(math.isfinite(v) for v in vals.values()):
                return {k: vals[k] / total for k in vals}
        except Exception:
            pass
    try:
        pn = float(p_neutral)
        pc = float(conditional_p_up)
        if math.isfinite(pn) and math.isfinite(pc):
            pn = min(.98, max(.0, pn)); pc = min(1.0, max(.0, pc)); pm = 1.0 - pn
            return {"up": pm * pc, "neutral": pn, "down": pm * (1.0 - pc)}
    except Exception:
        pass
    return None
