"""Official event dates, with retrieval timestamps. No inferred release dates or consensus.
Historical rows describe realized calendars, not point-in-time schedule vintages.
Refresh is explicit/off the forecast path; a failed provider retains its last snapshot.
"""
from pathlib import Path
from datetime import datetime, timezone
import json, re, calendar, os
from urllib.parse import urlparse
import pandas as pd
import requests
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parent
BUNDLED=ROOT/'macro_calendar_v440109.json'
SOURCES={
 'fed':'https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm',
 'bls':'https://www.bls.gov/schedule/{year}/home.htm',
 'bea':'https://www.bea.gov/news/schedule/full',
 'bea2025':'https://www.bea.gov/news/schedule/full-2025',
 'ecb':'https://www.ecb.europa.eu/press/calendars/mgcgc/html/index.en.html',
 'cbr':'https://www.cbr.ru/dkp/cal_mp/',
 'boj':'https://www.boj.or.jp/en/mopo/mpmsche_minu/',
 'boe':'https://www.bankofengland.co.uk/news/2025/september/monetary-policy-committee-dates-for-2026'}
BLS_TYPES={'Employment Situation':'employment_us','Consumer Price Index':'cpi_us','Producer Price Index':'ppi_us','Job Openings and Labor Turnover Survey':'jolts_us','Employment Cost Index':'eci_us'}
LABELS={'fed_rate':'ФРС: решение по ставке','ecb_rate':'ЕЦБ: решение по ставке','cbr_rate':'Банк России: ключевая ставка','boe_rate':'Банк Англии: ставка','boj_rate':'Банк Японии: ставка','employment_us':'США: занятость, безработица и зарплаты','cpi_us':'США: потребительская инфляция CPI','ppi_us':'США: цены производителей PPI','jolts_us':'США: вакансии JOLTS','eci_us':'США: стоимость труда','pce_us':'США: расходы, доходы и инфляция PCE','gdp_us':'США: ВВП'}
RU_MONTHS={v:i+1 for i,v in enumerate('января февраля марта апреля мая июня июля августа сентября октября ноября декабря'.split())}

def cache_path():
 import persistent_state_v44010 as P
 return Path(P.event_db_path()).parent/'macro_calendar_v440109.json'

def load():
 for p in (cache_path(),BUNDLED):
  try:
   d=json.loads(p.read_text());assert isinstance(d['events'],list);return d
  except Exception:pass
 return {'events':[],'sources':{},'retrieved_at':None}

def row(kind,date,source,seen,time=None,tz='UTC'):
 d=str(pd.Timestamp(date).date()); ts=None
 if time:ts=pd.Timestamp(d+' '+time,tz=tz).tz_convert('UTC').isoformat()
 return {'id':kind+':'+d,'type':kind,'label':LABELS[kind],'date':d,'scheduled_at':ts,'timezone':tz,'time_precision':'minute' if ts else 'date','source_url':source,'first_seen_at':seen,'last_checked_at':seen,'historical_schedule_vintage':False}

def parse(source,html,seen,url=None,year=None):
 url=url or SOURCES.get(source,'');s=BeautifulSoup(html,'html.parser');out=[]
 def add(k,d,t=None,z='UTC'):out.append(row(k,d,url,seen,t,z))
 if source=='fed':
  for block in s.select('.fomc-meeting'):
   heading=block.parent.find(class_='panel-heading')
   match=re.search(r'20\d{2}',heading.get_text() if heading else '')
   if not match:continue
   yr=int(match[0]);m=block.select_one('.fomc-meeting__month');d=block.select_one('.fomc-meeting__date')
   if not m or not d or 'notation' in d.get_text():continue
   month=m.get_text(strip=True).split('/')[-1][:3];day=re.findall(r'\d+',d.get_text())
   try:add('fed_rate',datetime.strptime(f'{yr} {month} {day[-1]}','%Y %b %d'),'14:00','America/New_York')
   except (ValueError,IndexError):continue
 elif source=='bls':
  text=s.get_text(' ',strip=True) if '<tr' in html else html
  pattern=r'(?:Monday|Tuesday|Wednesday|Thursday|Friday),\s+([A-Z][a-z]+ \d{1,2}, 20\d{2})\s+(\d{1,2}:\d{2} [AP]M)\s+([^\n]+)'
  # HTML tables are parsed separately to avoid a greedy capture across releases.
  chunks=[tr.get_text(' ',strip=True) for tr in s.select('tr')] if '<tr' in html else text.splitlines()
  for chunk in chunks:
   m=re.search(pattern,chunk)
   if not m:continue
   for name,k in BLS_TYPES.items():
    if m[3].startswith(name+' for'):
     add(k,datetime.strptime(m[1],'%B %d, %Y'),datetime.strptime(m[2],'%I:%M %p').strftime('%H:%M'),'America/New_York');break
 elif source.startswith('bea'):
  yr=year or (2025 if source=='bea2025' else pd.Timestamp(seen).year)
  for tr in s.select('tr'):
   date=tr.select_one('.release-date');title=tr.select_one('.release-title')
   if not date or not title:continue
   t=title.get_text(' ',strip=True);k='pce_us' if t.startswith('Personal Income and Outlays') else 'gdp_us' if (t.startswith('GDP (') or t.startswith('Gross Domestic Product')) else None
   if not k:continue
   try:add(k,datetime.strptime(f'{date.get_text(strip=True)} {yr}','%B %d %Y'),'08:30','America/New_York')
   except ValueError:continue
 elif source=='ecb_history':
  for a in s.select('a[href]'):
   m=re.search(r'ecb\.mp(\d{6})',a.get('href',''))
   if m and 'Monetary policy decisions' in a.get_text():
    add('ecb_rate',datetime.strptime(m[1],'%y%m%d'),'14:15','Europe/Berlin')
 elif source=='ecb':
  for dt in s.select('dt'):
   dd=dt.find_next_sibling('dd');text=dd.get_text(' ',strip=True) if dd else ''
   if 'monetary policy meeting' in text and 'non-monetary' not in text and 'Day 2' in text:
    add('ecb_rate',datetime.strptime(dt.get_text(strip=True),'%d/%m/%Y'),'14:15','Europe/Berlin')
 elif source=='cbr':
  for block in s.select('.main-events_day'):
   title=block.select_one('.title');date=block.select_one('.date')
   if not title or not date or 'Заседание' not in title.get_text():continue
   m=re.search(r'(\d+)\s+(\w+)\s+(20\d{2})',date.get_text(' ',strip=True))
   if m and m[2] in RU_MONTHS:add('cbr_rate',f'{m[3]}-{RU_MONTHS[m[2]]:02}-{int(m[1]):02}','13:30','Europe/Moscow')
  # Older years use a tabular layout. Respect its year label, never infer by row order.
  for tab in s.select('[role="tabpanel"]'):
   label=s.find(id=tab.get('aria-labelledby'));ym=re.search(r'20\d{2}',label.get_text() if label else '')
   if not ym:continue
   for tr in tab.select('tr'):
    cells=tr.find_all('td');text=tr.get_text(' ',strip=True)
    if len(cells)<2 or 'Заседание Совета директоров' not in text or 'Внеочередное' in text:continue
    m=re.search(r'(\d+)\s+(\w+)',cells[0].get_text(' ',strip=True))
    if m and m[2] in RU_MONTHS:add('cbr_rate',f'{ym[0]}-{RU_MONTHS[m[2]]:02}-{int(m[1]):02}','13:30','Europe/Moscow')
 elif source=='boe':
  for tr in s.select('tr'):
   m=re.search(r'(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(20\d{2})',tr.get_text(' ',strip=True))
   if m:add('boe_rate',datetime.strptime(m[0],'%d %B %Y'),'12:00','Europe/London')
 elif source=='boj':
  for tr in s.select('tr'):
   cells=tr.find_all('td')
   if not cells:continue
   text=cells[0].get_text(' ',strip=True)
   m=re.search(r'([A-Z][a-z]+)\.?\s+(\d{1,2}).*?(?:and|&|,)\s*(\d{1,2})',text)
   if not m:continue
   header=tr.find_previous(['h2','h3']);ym=re.search(r'20\d{2}',header.get_text() if header else '')
   if ym:
    try:add('boj_rate',datetime.strptime(f'{ym[0]} {m[1][:3]} {m[3]}','%Y %b %d'),None,'Asia/Tokyo')
    except ValueError:pass
 return list({r['id']:r for r in out}.values())

def refresh():
 from concurrent.futures import ThreadPoolExecutor
 old=load();seen=datetime.now(timezone.utc).isoformat();yr=pd.Timestamp(seen).year
 jobs=[(k,u,None) for k,u in SOURCES.items() if k!='bls']+ [('bls',SOURCES['bls'].format(year=y),y) for y in range(yr-3,yr+1)]
 jobs += [('ecb_history',f'https://www.ecb.europa.eu/press/govcdec/mopo/{y}/html/index_include.en.html',y) for y in range(yr-3,yr+1)]
 events={r['id']:r for r in old['events']};statuses=dict(old.get('sources') or {})
 def fetch(job):
  k,u,y=job
  try:
   r=requests.get(u,timeout=15,headers={'User-Agent':'Morpheus/4.40.10.9 calendar reader'});r.raise_for_status();rows=parse(k,r.text,seen,u,y)
   if not rows:raise ValueError('empty parsed calendar')
   return u,rows,None
  except Exception as e:return u,[],type(e).__name__
 for u,rows,err in ThreadPoolExecutor(6).map(fetch,jobs):
  statuses[u]={'checked_at':seen,'status':'retained_snapshot' if err else 'ok','error':err,'count':len(rows)}
  if rows:
   incoming={r['id'] for r in rows}
   # Delete removed future appointments from this source (rescheduling/cancellation).
   events={k:v for k,v in events.items() if not(v.get('source_url')==u and v.get('date','')>=seen[:10] and k not in incoming)}
   for r in rows:
    previous=events.get(r['id'],{})
    r['first_seen_at']=previous.get('first_seen_at',seen) if previous.get('scheduled_at')==r.get('scheduled_at') else seen
    events[r['id']]=r
 data={'version':'4.40.10.9','retrieved_at':seen,'events':sorted(events.values(),key=lambda r:(r['date'],r['type'])),'sources':statuses}
 path=cache_path();path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2));tmp.replace(path)
 return {'events':len(events),'sources':statuses}

if __name__=='__main__':print(json.dumps(refresh(),ensure_ascii=False,indent=2))
