"""Morpheus v4.8 — lazy company preset builder for Valuation Sandbox.

US equities: yfinance public data fallback (live-ish price + latest annual statements).
MOEX equities: MOEX ISS price + conservative editable preset when standardized
fundamentals are not available from the current provider set.

A licensed fundamentals provider can replace this layer later without changing UI.
"""
from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import json, math, time, requests

import corporate_finance_v471 as BASE

ROOT=Path(__file__).parent
CACHE_DIR=ROOT/"runtime_cache";CACHE_DIR.mkdir(exist_ok=True)
CACHE=CACHE_DIR/"valuation_company_v48.json"
TTL=6*3600


def _finite(v):
    try:return math.isfinite(float(v))
    except Exception:return False

def _read_cache():
    try:return json.loads(CACHE.read_text(encoding="utf-8"))
    except Exception:return {}

def _save_cache(d):
    try:CACHE.write_text(json.dumps(d,ensure_ascii=False),encoding="utf-8")
    except Exception:pass

def _series_value(frame,names):
    if frame is None or getattr(frame,"empty",True):return None
    for n in names:
        try:
            if n in frame.index:
                s=frame.loc[n].dropna()
                if len(s):return float(s.iloc[0])
        except Exception:pass
    return None

def _annual_values(frame,names):
    if frame is None or getattr(frame,"empty",True):return []
    for n in names:
        try:
            if n in frame.index:
                return [float(x) for x in frame.loc[n].dropna().tolist() if _finite(x)]
        except Exception:pass
    return []

def _moex_price(ticker):
    try:
        url=f"https://iss.moex.com/iss/engines/stock/markets/shares/securities/{ticker}.json"
        params={"iss.meta":"off","iss.only":"marketdata,securities","marketdata.columns":"LAST,MARKETPRICE,LCURRENTPRICE","securities.columns":"SECID,SHORTNAME,ISIN,LOTSIZE,DECIMALS"}
        r=requests.get(url,params=params,timeout=4);r.raise_for_status();j=r.json()
        md=j.get("marketdata") or {};cols=md.get("columns") or [];rows=md.get("data") or []
        price=None
        for row in rows:
            x=dict(zip(cols,row))
            for k in ("LAST","MARKETPRICE","LCURRENTPRICE"):
                if _finite(x.get(k)) and float(x[k])>0:price=float(x[k]);break
            if price:break
        sec=j.get("securities") or {};sc=sec.get("columns") or [];sd=sec.get("data") or []
        meta=dict(zip(sc,sd[0])) if sd else {}
        return price,meta
    except Exception:return None,{}

def _generic_ru(ticker,name=None):
    price,meta=_moex_price(ticker)
    p=float(price or 100.0)
    return {
      "ticker":ticker,"name":name or meta.get("SHORTNAME") or ticker,"sector":"MOEX","currency":"RUB",
      "model":"DCF","price":p,"price_snapshot":p,"price_source":"MOEX ISS" if price else "резервный preset",
      "as_of":datetime.now(timezone.utc).isoformat(timespec="seconds"),
      "revenue":100.0,"ebit_margin":20.0,"tax_rate":20.0,"da_pct":5.0,"capex_pct":6.0,"nwc_pct":5.0,
      "dso":45.0,"dio":45.0,"dpo":45.0,"cogs_pct":70.0,"base_growth":5.0,"wacc":15.0,
      "terminal_growth":4.0,"net_debt":20.0,"shares":1.0,"dividend":0.0,"dividend_growth":4.0,
      "cost_equity":16.0,"baseline_policy_rate":14.0,"baseline_inflation":5.0,
      "note":"MOEX: цена обновлена автоматически. Финансовые допущения — редактируемый стартовый preset, пока не подключён стандартизированный fundamentals provider.",
      "preset_quality":"price-only",
    }

def _yf_snapshot(ticker,name=None):
    import yfinance as yf
    q=yf.Ticker(ticker)
    hist=q.history(period="5d",interval="1d",auto_adjust=False)
    if hist is None or hist.empty:raise RuntimeError("price unavailable")
    price=float(hist["Close"].dropna().iloc[-1])
    fin=q.financials;cf=q.cashflow;bs=q.balance_sheet
    rev=_series_value(fin,["Total Revenue","Operating Revenue"])
    op=_series_value(fin,["Operating Income","EBIT"])
    pretax=_series_value(fin,["Pretax Income"]);tax=_series_value(fin,["Tax Provision"])
    da=_series_value(cf,["Depreciation And Amortization","Depreciation"])
    capex=_series_value(cf,["Capital Expenditure"])
    debt=_series_value(bs,["Total Debt"])
    cash=_series_value(bs,["Cash Cash Equivalents And Short Term Investments","Cash And Cash Equivalents"])
    shares=None
    try:
        fi=q.fast_info
        shares=float(fi.get("shares") or 0) if hasattr(fi,"get") else None
    except Exception:shares=None
    if not shares:
        shares=_series_value(bs,["Ordinary Shares Number","Share Issued"])
    revenue_b=(rev or 1e9)/1e9
    margin=(op/rev*100) if rev and op else 15.0
    tax_rate=(tax/pretax*100) if pretax and tax and pretax else 21.0
    da_pct=abs(da/rev*100) if rev and da else 4.0
    capex_pct=abs(capex/rev*100) if rev and capex else 5.0
    net_debt=((debt or 0)-(cash or 0))/1e9
    shares_b=(shares or 1e9)/1e9
    revs=_annual_values(fin,["Total Revenue","Operating Revenue"])
    growth=5.0
    if len(revs)>=2 and revs[1]>0:
        growth=max(-20,min(35,(revs[0]/revs[1]-1)*100))
    dividend=0.0
    try:
        info=q.info or {};dividend=float(info.get("dividendRate") or 0);sector=info.get("sector") or "Акции США";name=name or info.get("shortName") or info.get("longName") or ticker
    except Exception:sector="Акции США"
    return {
      "ticker":ticker,"name":name or ticker,"sector":sector,"currency":"USD","model":"DCF",
      "price":price,"price_snapshot":price,"price_source":"yfinance","as_of":datetime.now(timezone.utc).isoformat(timespec="seconds"),
      "revenue":round(revenue_b,4),"ebit_margin":round(margin,2),"tax_rate":round(max(0,min(45,tax_rate)),2),
      "da_pct":round(da_pct,2),"capex_pct":round(capex_pct,2),"nwc_pct":0.0,
      "dso":45.0,"dio":45.0,"dpo":45.0,"cogs_pct":max(0,100-round(margin,2)),
      "base_growth":round(growth,2),"wacc":8.5,"terminal_growth":2.5,"net_debt":round(net_debt,4),
      "shares":round(max(.0001,shares_b),6),"dividend":round(dividend,4),"dividend_growth":4.0,"cost_equity":8.8,
      "baseline_policy_rate":3.75,"baseline_inflation":2.5,
      "note":"Автоматический preset из последней доступной публичной отчётности. Перед использованием модельные допущения следует проверить.",
      "preset_quality":"auto-fundamentals",
    }

def company_snapshot(ticker,market="US",name=None,force=False):
    t=str(ticker or "").upper().strip();market=str(market or "US").upper()
    if t in BASE.COMPANIES and market!="RU":return BASE.company_snapshot(t)
    cache=_read_cache();key=f"{market}:{t}";row=cache.get(key)
    if not force and row and time.time()-float(row.get("_ts",0))<TTL:
        return {k:v for k,v in row.items() if k!="_ts"}
    try:
        out=_generic_ru(t,name) if market=="RU" else _yf_snapshot(t,name)
    except Exception:
        if market=="RU":out=_generic_ru(t,name)
        else:
            # keep UI usable even if yfinance is temporarily unavailable
            out={"ticker":t,"name":name or t,"sector":"NYSE","currency":"USD","model":"DCF","price":100.0,"price_snapshot":100.0,"price_source":"резервный preset","as_of":"нет live-данных","revenue":10.0,"ebit_margin":15.0,"tax_rate":21.0,"da_pct":4.0,"capex_pct":5.0,"nwc_pct":5.0,"dso":45.0,"dio":45.0,"dpo":45.0,"cogs_pct":70.0,"base_growth":5.0,"wacc":8.5,"terminal_growth":2.5,"net_debt":1.0,"shares":1.0,"dividend":0.0,"dividend_growth":4.0,"cost_equity":8.8,"baseline_policy_rate":3.75,"baseline_inflation":2.5,"note":"Live fundamentals временно недоступны; показан редактируемый стартовый preset.","preset_quality":"fallback"}
    cache[key]={**out,"_ts":time.time()};_save_cache(cache)
    return out
