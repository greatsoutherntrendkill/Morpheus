# Model roadmap after v4.38

## v4.39 — Event Response Models
- отдельные модели реакции на FOMC / ECB / ЦБ РФ / CPI / earnings;
- surprise factor: фактическое значение относительно consensus / базового ожидания;
- historical sensitivity profile по инструменту и классу активов;
- event-specific calibration и abstention;
- отдельная скорость реакции 1d / 3d / 5d;
- event expert остаётся challenger до prospective validation + human approval.

## v4.40 — Specialist Allocation Review
После накопления достаточной prospective history:
- сравнивать general ensemble и specialist по классам активов;
- проверять устойчивость specialist edge по режимам;
- разрешать ограниченный satellite weight только там, где доказан paired prospective edge;
- automatic champion promotion по-прежнему запрещён.

## Отложенный Scenario Lab roadmap
Historical Analog Engine, Quant Scenario Model, Monte Carlo и LLM Scenario Intelligence сохраняются отдельно и будут подключаться поверх более надёжного forecasting core.
