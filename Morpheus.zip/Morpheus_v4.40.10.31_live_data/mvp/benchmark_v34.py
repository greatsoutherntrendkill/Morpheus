"""Morpheus v3.4 full-universe locked model decision benchmark."""
from __future__ import annotations
import argparse, json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np, pandas as pd
import db, export_site as ES, macro_features as MF, model_registry as MR, challenger_models as CM

ROOT=Path(__file__).parent
JSON_OUT=ROOT/'site'/'model_benchmark_v34.json'
CSV_OUT=ROOT/'model_benchmark_v34.csv'


def _symbols(con):
    available=set(db.symbols(con))
    return [s for s in ES.PUBLIC if s in available]


def _aggregate_bins(rows, model, field):
    agg={}
    for r in rows:
        for b in ((r.get('models') or {}).get(model) or {}).get(field) or []:
            k=(float(b['lo']),float(b['hi'])); n=int(b['n'])
            a=agg.setdefault(k,{'n':0,'p':0.0,'y':0.0})
            a['n']+=n; a['p']+=n*float(b['mean_p']); a['y']+=n*float(b['actual_up_rate'])
    out=[]
    for (lo,hi),a in sorted(agg.items()):
        n=a['n']; mp=a['p']/n; ay=a['y']/n
        out.append({'lo':lo,'hi':hi,'n':n,'mean_p':round(mp,4),'actual_up_rate':round(ay,4),'gap':round(mp-ay,4)})
    return out


def aggregate_diagnostics(rows):
    out={}
    for model in ('logistic_regression','lightgbm','catboost'):
        sums={}; counts={}; deltas=[]
        for r in rows:
            mm=(r.get('models') or {}).get(model) or {}
            if mm.get('calibration_brier_delta') is not None:
                deltas.append(float(mm['calibration_brier_delta']))
            for x in mm.get('top_features_frozen') or []:
                f=x['feature']; sums[f]=sums.get(f,0.0)+float(x['importance']); counts[f]=counts.get(f,0)+1
        ranked=sorted(sums,key=lambda f:sums[f]/counts[f],reverse=True)
        out[model]={
            'aggregate_reliability':_aggregate_bins(rows,model,'holdout_reliability'),
            'aggregate_calibrated_reliability':_aggregate_bins(rows,model,'holdout_calibrated_reliability'),
            'median_calibration_brier_improvement':None if not deltas else float(np.median(deltas)),
            'aggregate_feature_importance':[{'feature':f,'mean_normalized_importance':round(sums[f]/counts[f],6),'models_present':counts[f]} for f in ranked[:15]],
        }
    return out


def aggregate_decision(rows,promotion):
    aggregate={}
    for m in ('logistic_regression','lightgbm','catboost'):
        hb=[]; he=[]; edge=[]; nsh=[]; cb=[]; ce=[]
        for r in rows:
            mm=(r.get('models') or {}).get(m) or {}; ho=mm.get('holdout') or {}; cal=mm.get('holdout_calibrated') or {}
            if ho.get('brier') is not None: hb.append(float(ho['brier']))
            if ho.get('ece') is not None: he.append(float(ho['ece']))
            if ho.get('edge_pp') is not None: edge.append(float(ho['edge_pp']))
            if cal.get('brier') is not None: cb.append(float(cal['brier']))
            if cal.get('ece') is not None: ce.append(float(cal['ece']))
            ec=mm.get('holdout_economic') or {}
            if ec.get('net_sharpe') is not None: nsh.append(float(ec['net_sharpe']))
        med=lambda x: None if not x else float(np.median(x))
        aggregate[m]={'holdout_tests':len(hb),'median_holdout_brier':med(hb),'median_holdout_ece':med(he),
                      'median_holdout_edge_pp':med(edge),'median_1d_net_sharpe':med(nsh),
                      'median_calibrated_holdout_brier':med(cb),'median_calibrated_holdout_ece':med(ce)}
    eligible=[c for c,d in (promotion.get('challengers') or {}).items() if d.get('eligible_for_manual_promotion_review')]
    if eligible:
        chosen=max(eligible,key=lambda c:float(promotion['challengers'][c].get('median_brier_improvement') or -1e9))
        action='PROMOTE_AFTER_MANUAL_REGISTRY_EVENT'
        rationale=f'{chosen} passes the locked v3.4 review gate; register a new immutable champion version before production use.'
    else:
        chosen='logistic_regression'; action='KEEP_CHAMPION'
        rationale='No challenger passes the multiplicity-controlled paired frozen-holdout + economic-value gate. Keep logreg-v3.2.0 as production champion; calibration remains research-only.'
    return {'decision':action,'selected_model':chosen,
            'selected_version':CM.CHAMPION_VERSION if chosen=='logistic_regression' else CM.CHALLENGER_VERSIONS[chosen],
            'production_champion_before':CM.CHAMPION_VERSION,'automatic_promotion':False,
            'aggregate':aggregate,'rationale':rationale}


def run(symbols=None,horizons=(1,5,10,20),cost_bps=2.0):
    con=db.connect()
    try:
        MR.register_champion(con)
        for name,fam in (('lightgbm','lightgbm'),('catboost','catboost')):
            MR.register_challenger(con,CM.CHALLENGER_VERSIONS[name],fam,CM.FEATURE_VERSION,CM.LOCKED_CONFIGS[name],
                                   'locked challenger; v3.4 full-universe audit',validation_version=CM.VALIDATION_VERSION)
        deps=CM.dependency_status()
        missing=[k for k,v in deps.items() if not v.get('available')]
        if missing: raise RuntimeError('Missing challenger dependencies: '+', '.join(missing))
        syms=symbols or _symbols(con); rows=[]; errors=[]
        dxy_df=ES.sanitize_price_df(db.read_prices(con,'DX-Y.NYB'),'DX-Y.NYB')
        dxy_all=dxy_df.set_index('date')['close'] if not dxy_df.empty else None
        for sym in syms:
            try:
                df=ES.sanitize_price_df(db.read_prices(con,sym),sym)
                if df.empty or len(df)<300: continue
                close=df.set_index('date')['close']; dxy=None if sym=='DX-Y.NYB' else dxy_all
                macro=MF.macro_features_for(con,sym,close.index); audit=MF.macro_data_audit(con)
                cutoff=str(pd.Timestamp(close.index[-1]).date())
                for h in horizons:
                    try:
                        r=CM.compare_asset(close,dxy,macro,horizon=int(h),cost_bps=cost_bps)
                        if not r: continue
                        r.pop('_arrays',None); r['symbol']=sym; r['name']=ES.NAMES.get(sym,sym); rows.append(r)
                        for name in ('lightgbm','catboost'):
                            mm=r['models'][name]
                            MR.append_prediction_for_model(con,mm['version'],CM.FEATURE_VERSION,sym,int(h),cutoff,mm.get('live_p_up'),
                              {'research_challenger':True,'v34_full_universe':True,'promotion_status':'not_promoted'},audit,'research_challenger')
                        print(f'{sym} {h}D: ok')
                    except Exception as exc:
                        errors.append({'symbol':sym,'horizon':int(h),'error':repr(exc)}); print(f'{sym} {h}D: ERROR {exc}')
            except Exception as exc:
                errors.append({'symbol':sym,'error':repr(exc)}); print(f'{sym}: ERROR {exc}')
        rows=sorted(rows,key=lambda r:(r['symbol'],int(r['horizon'])))
        promotion=CM.promotion_summary(rows); adj=promotion.get('holm_adjusted_p',{})
        for r in rows:
            for c in ('lightgbm','catboost'):
                ph=(r.get('paired_holdout') or {}).get(c)
                if ph is not None:
                    ph['p_holm_brier']=adj.get(f"{c}|{r['symbol']}|{r['horizon']}")
                    ph['multiplicity_pass']=bool(ph['p_holm_brier'] is not None and ph['p_holm_brier']<0.05)
        decision=aggregate_decision(rows,promotion); diagnostics=aggregate_diagnostics(rows)
        payload={'version':'3.4','generated_at':datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
                 'scope':{'symbols':syms,'assets':len(set(r['symbol'] for r in rows)),'horizons':[int(x) for x in horizons],
                          'comparisons':len(rows),'cost_bps':float(cost_bps)},
                 'champion':CM.CHAMPION_VERSION,'challengers':CM.CHALLENGER_VERSIONS,'feature_version':CM.FEATURE_VERSION,
                 'validation_version':CM.VALIDATION_VERSION,'holdout_used_for_tuning':False,
                 'hyperparameters_locked_before_holdout':True,'automatic_promotion':False,'dependency_status':deps,
                 'promotion':promotion,'decision':decision,'diagnostics':diagnostics,'rows':rows,'errors':errors}
        JSON_OUT.parent.mkdir(parents=True,exist_ok=True); JSON_OUT.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
        flat=[]
        for r in rows:
            for name,m in r['models'].items():
                flat.append({'symbol':r['symbol'],'name':r['name'],'horizon':r['horizon'],'model':name,'model_version':m['version'],
                    **{f'holdout_{k}':v for k,v in (m.get('holdout') or {}).items() if not isinstance(v,(list,dict))},
                    **{f'cal_holdout_{k}':v for k,v in (m.get('holdout_calibrated') or {}).items() if not isinstance(v,(list,dict))},
                    **{f'econ_{k}':v for k,v in (m.get('holdout_economic') or {}).items() if not isinstance(v,(list,dict))}})
        pd.DataFrame(flat).to_csv(CSV_OUT,index=False)
        ev={'scope':payload['scope'],'promotion':promotion['challengers'],'aggregate':decision['aggregate']}
        did=MR.record_model_decision(con,'v3.4-full-universe-paired-holm-economic',CM.CHAMPION_VERSION,decision['selected_version'],decision['decision'],ev,decision['rationale'])
        dp={'version':'3.4','decision_id':did,**decision,'scope':payload['scope'],'promotion':promotion['challengers']}
        (ROOT/'site'/'model_decision_v34.json').write_text(json.dumps(dp,ensure_ascii=False,indent=2),encoding='utf-8')
        return payload
    finally:
        con.close()


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--symbols',default=''); ap.add_argument('--horizons',default='1,5,10,20'); ap.add_argument('--cost-bps',type=float,default=2.0)
    a=ap.parse_args(); syms=[x.strip() for x in a.symbols.split(',') if x.strip()] or None; hs=tuple(int(x) for x in a.horizons.split(',') if x.strip())
    p=run(syms,hs,a.cost_bps)
    print(json.dumps({'rows':len(p['rows']),'errors':len(p['errors']),'decision':p['decision'],'promotion':p['promotion']['challengers'],'json':str(JSON_OUT),'csv':str(CSV_OUT)},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
