"""
Обновление данных. Запуск:
    python update.py            # тянуть реальные данные (нужен интернет; FRED — ключ)
    python update.py --demo     # синтетика, работает офлайн, чтобы сразу увидеть дашборд
Флаги: --no-fred, --no-moex, --no-prices, --no-cbr
"""
import argparse
import os
import pandas as pd
from dotenv import load_dotenv

import config as C
import db
import sources as S
import external_apis as EA
import macro_features as MF
import release_times as RT
import market_data_v41 as MD41

load_dotenv()


def load_cb_rates(con):
    df = pd.read_csv(C.CB_RATES_SEED)
    # попытка автообновить строку "Россия" реальной ключевой ставкой с ЦБ РФ
    if not args.no_cbr and not args.demo:
        kr = S.fetch_cbr_key_rate()
        if kr is not None:
            df.loc[df["country"] == "Россия", "rate"] = kr
            df.loc[df["country"] == "Россия", "as_of"] = str(pd.Timestamp.today().date())
            print(f"  [cbr] ключевая ставка обновлена: {kr}%")
    n = db.upsert_cb_rates(con, df)
    print(f"Ставки ЦБ: {n} строк")


def run():
    con = db.connect()

    # 1) цены — v4.1: каскад источников, без удаления последнего снимка при сетевом сбое.
    if not args.no_prices:
        prices_cache={}
        for sym,(name,_) in C.YF_PRICES.items():
            if args.demo:
                df=S.demo_price(sym)
                src="demo"
                errors=[]
            else:
                rr=MD41.fetch_history(sym,long_history=True)
                df=rr.frame
                src=rr.source or ""
                errors=rr.errors
            prices_cache[sym]=df
            source_key=f"price_source:{sym}"
            if not df.empty:
                n=db.replace_prices(con,sym,df)
                db.set_meta(con,source_key,src or ("demo" if args.demo else "live"))
                db.set_meta(con,f"price_error:{sym}","")
                print(f"Цена {sym} ({name}): {n} точек · {src or 'источник не указан'}")
            else:
                # Критическое изменение v4.1: не удаляем последнюю историю только
                # потому, что один интернет-запрос сегодня не прошёл.
                prev=db.read_prices(con,sym)
                msg="; ".join(errors[-4:]) if errors else "источники не ответили"
                db.set_meta(con,f"price_error:{sym}",msg)
                print(f"  [prices] {sym}: обновление не удалось; сохранено {len(prev)} старых точек · {msg}")

        for cross,(num,den,name,_) in C.YF_CROSSES.items():
            # сначала пробуем отдельный официальный/резервный источник;
            # если его нет — рассчитываем кросс из обновлённых ног.
            if args.demo:
                df=S.compute_cross(prices_cache.get(num,pd.DataFrame()),prices_cache.get(den,pd.DataFrame()))
                src="demo-derived"
            else:
                rr=MD41.fetch_history(cross,long_history=True)
                df=rr.frame
                src=rr.source
                if df.empty:
                    df=S.compute_cross(prices_cache.get(num,pd.DataFrame()),prices_cache.get(den,pd.DataFrame()))
                    src="derived-live" if not df.empty else ""
            if not df.empty:
                print(f"Кросс {cross} ({name}): {db.replace_prices(con,cross,df)} точек · {src}")
                db.set_meta(con,f"price_source:{cross}",src)
            else:
                print(f"  [prices] {cross}: обновление не удалось; предыдущая история сохранена")
        db.stamp(con,"prices_updated")

    # 2) индексы РФ (MOEX)
    if not args.no_moex:
        for sec, (name, _) in C.MOEX_INDICES.items():
            df = S.demo_price(sec) if args.demo else S.fetch_moex_index(sec)
            if not df.empty:
                print(f"MOEX {sec} ({name}): {db.replace_prices(con, sec, df)} точек")
                db.set_meta(con, f"price_source:{sec}", "demo" if args.demo else "moex-live")
            elif not args.demo:
                prev_df=db.read_prices(con,sec)
                print(f"  [moex] {sec}: live-fetch не удался; сохранено {len(prev_df)} предыдущих точек")
        db.stamp(con, "moex_updated")

    # 3) макро: current FRED snapshot for UI + ALFRED initial-release PIT for models
    if not args.no_fred:
        key = os.getenv("FRED_API_KEY", "")
        if not key and not args.demo:
            print("  [fred] нет FRED_API_KEY в .env — current/PIT макро пропущено")
        for sid, (name, _) in {**C.FRED_US, **C.FRED_RU, **C.FRED_RATES}.items():
            # Current/revised history is retained for current-state UI and event analysis,
            # but v3.0 predictive features do NOT use it in strict mode.
            df = S.demo_macro(sid) if args.demo else S.fetch_fred(sid, key, C.FRED_START)
            if not df.empty:
                print(f"Макро current {sid} ({name}): {db.replace_macro(con, sid, df)} точек")

            # Point-in-time history: initial release value + the day it first became known.
            if args.demo:
                pit = df.copy()
                if not pit.empty:
                    lag = MF.LAG_DAYS.get(sid, MF.DEFAULT_LAG)
                    pit = pit.rename(columns={"date": "observation_date"})
                    pit["available_date"] = pd.to_datetime(pit["observation_date"]) + pd.to_timedelta(lag, unit="D")
                    pit["vintage_date"] = pit["available_date"]
                    pit["realtime_end"] = ""
                    pit["source"] = "demo_pit"
                    pit["is_initial"] = 1
            else:
                try:
                    pit = EA.fred_revision_history(sid, key, C.FRED_START) if key else pd.DataFrame()
                except Exception as e:
                    print(f"  [alfred] {sid}: ошибка {type(e).__name__}: {e}")
                    pit = pd.DataFrame()

            if not pit.empty:
                n_pit = db.replace_macro_pit(con, sid, pit)
                db.set_meta(con, f"macro_pit_source:{sid}",
                            "demo_pit" if args.demo else "alfred_revision_history")
                print(f"  [pit] {sid}: {n_pit} revision-aware rows")
                rel = RT.build_release_rows(sid, pit)
                if not rel.empty:
                    db.replace_macro_releases(con, sid, rel)
                    exact_n = int((rel["precision"] == "scheduled_time").sum())
                    print(f"  [release] {sid}: {exact_n}/{len(rel)} rows with scheduled intraday time")
            elif not args.demo:
                prev_pit = db.get_meta(con, f"macro_pit_source:{sid}", "unknown")
                if prev_pit not in {"alfred_revision_history", "cbr_official"}:
                    db.delete_macro_pit(con, sid)
                    print(f"  [pit] {sid}: live PIT не получен; demo/unknown PIT удалён")
                else:
                    print(f"  [pit] {sid}: новые PIT-данные не получены; последний подтверждённый PIT сохранён")
        db.set_meta(con, "macro_model_mode", "point_in_time_revision_aware")
        db.stamp(con, "macro_updated")
        db.stamp(con, "macro_pit_updated")

    # 3b) CBR key-rate history. Official dates are treated as day-level availability.
    if not args.no_cbr:
        kr = (S.demo_macro(C.CBR_KEYRATE_SERIES) if args.demo
              else S.fetch_cbr_key_rate_series(C.FRED_START))
        if not kr.empty:
            print(f"Ряд {C.CBR_KEYRATE_SERIES} (ключевая ставка ЦБ РФ): "
                  f"{db.replace_macro(con, C.CBR_KEYRATE_SERIES, kr)} точек")
            pit_kr = kr.rename(columns={"date": "observation_date"}).copy()
            pit_kr["available_date"] = pd.to_datetime(pit_kr["observation_date"])
            pit_kr["vintage_date"] = pit_kr["available_date"]
            pit_kr["realtime_end"] = ""
            pit_kr["source"] = "demo_pit" if args.demo else "cbr_official"
            pit_kr["is_initial"] = 1
            print(f"  [pit] {C.CBR_KEYRATE_SERIES}: "
                  f"{db.replace_macro_pit(con, C.CBR_KEYRATE_SERIES, pit_kr)} rows")
            rel_kr = RT.build_release_rows(C.CBR_KEYRATE_SERIES, pit_kr)
            if not rel_kr.empty:
                db.replace_macro_releases(con, C.CBR_KEYRATE_SERIES, rel_kr)

    # 4) ставки ЦБ
    load_cb_rates(con)

    print("\nГотово. Запусти дашборд:  streamlit run app.py")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--demo", action="store_true")
    p.add_argument("--no-fred", action="store_true")
    p.add_argument("--no-moex", action="store_true")
    p.add_argument("--no-prices", action="store_true")
    p.add_argument("--no-cbr", action="store_true")
    args = p.parse_args()
    run()
