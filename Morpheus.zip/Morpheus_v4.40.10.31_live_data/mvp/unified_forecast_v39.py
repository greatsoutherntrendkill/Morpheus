"""Morpheus v3.9 — legacy offline snapshot only.

Since v4.40.6 this file is not part of the live forecast refresh path.
The single live source of truth is model_integrity_v4406 via FastAPI.

Previously: единый пользовательский прогноз.

Это не новая скрытая модель и не механизм автоматической промоции. Модуль сводит
уже рассчитанные прогнозы в одно консервативное представление для интерфейса:
production-оценка получает больший вес, research-модели — меньший. Неподтверждённые
production-вероятности предварительно сжимаются к 50% по накопленному evidence.
"""
from __future__ import annotations

import json, math, statistics
from pathlib import Path

ROOT=Path(__file__).parent
DATA=ROOT/'site'/'data.json'
HORIZONS=('1','5','10','20')
LEGACY_ONLY=True
LIVE_SOURCE_OF_TRUTH='model_integrity_v4406'


WEIGHTS={
    'production':0.50,
    'pooled_logistic':0.15,
    'pooled_lightgbm':0.20,
    'regime':0.15,
}


def _num(x):
    try:
        x=float(x)
        return x if math.isfinite(x) else None
    except Exception:
        return None


def _production_component(a,h):
    v=((a.get('model_views') or {}).get(h) or {})
    raw=_num(((v.get('raw') or {}).get('p_up')))
    if raw is None: return None
    status=v.get('status') or {}; ev=v.get('evidence') or {}
    n=_num(ev.get('effective_n')) or 0.0
    target=_num(ev.get('target_effective_n')) or 30.0
    sample=min(1.0,max(0.0,n/target))
    # Непрошедший quality gate не должен доминировать над сводкой только из-за
    # экстремального raw score.
    quality=1.0 if status.get('validated') else 0.35
    alpha=sample*quality
    adj=0.5+alpha*(raw-0.5)
    return {'p':adj,'raw':raw,'weight':WEIGHTS['production'],'reliability':alpha,
            'validated':bool(status.get('validated'))}


def _research_component(a,h,key,field):
    if key=='regime':
        z=((a.get('regime_moe_v37') or {}).get(h) or {})
        p=_num(z.get(field)); alpha=_num(z.get('total_shrink_alpha'))
    else:
        z=(((a.get('cross_asset_v36') or {}).get(h) or {}).get(key) or {})
        p=_num(z.get(field)); alpha=_num(z.get('shrink_alpha'))
    if p is None: return None
    return {'p':p,'raw':p,'weight':WEIGHTS[key],
            'reliability':max(0.0,min(1.0,alpha if alpha is not None else 0.5)),
            'validated':False}


def _label(p,confidence):
    if p is None: return 'Нет расчёта','Нет достаточных данных'
    edge=p-0.5
    if abs(edge)<0.025:
        return ('Вероятность роста' if p>=0.5 else 'Вероятность падения'),'Модели не дают заметного преимущества ни одной стороне'
    direction='роста' if edge>0 else 'снижения'
    if confidence>=0.58 and abs(edge)>=0.08:
        return ('Выраженное преимущество '+direction,
                'Несколько независимых оценок сходятся в одном направлении')
    if confidence>=0.35 or abs(edge)>=0.055:
        return ('Умеренное преимущество '+direction,
                'Направление заметно, но запас статистической уверенности ограничен')
    return ('Слабое преимущество '+direction,
            'Направление есть, но подтверждение пока недостаточно сильное')


def build_horizon(a,h):
    comps=[]
    c=_production_component(a,h)
    if c: comps.append(c)
    for key,field in [('pooled_logistic','evidence_shrunk_p_up'),
                      ('pooled_lightgbm','evidence_shrunk_p_up'),
                      ('regime','final_research_p_up')]:
        z=_research_component(a,h,key,field)
        if z: comps.append(z)
    if not comps:
        return {'p_up':None,'label':'Нет расчёта','confidence':'нет данных','agreement':0,
                'summary':'Для этого горизонта пока нет доступного расчёта.','model_count':0}

    sw=sum(c['weight'] for c in comps)
    p=sum(c['p']*c['weight'] for c in comps)/sw
    vals=[c['p'] for c in comps]
    disp=statistics.pstdev(vals) if len(vals)>1 else 0.0
    agreement=max(0.0,min(1.0,1.0-disp/0.12))
    rel=sum(c['reliability']*c['weight'] for c in comps)/sw
    directional=min(1.0,abs(p-0.5)/0.12)
    confidence=max(0.0,min(1.0,agreement*rel*directional))
    if confidence>=0.60: conf='высокая'
    elif confidence>=0.35: conf='средняя'
    else: conf='низкая'
    label,why=_label(p,confidence)
    direction_label='Вероятность роста' if p>=0.5 else 'Вероятность падения'
    up=sum(1 for c in comps if c['p']>=0.5)
    down=len(comps)-up
    side='рост' if p>=0.5 else 'снижение'
    verified=any(c['validated'] for c in comps) and agreement>=0.65
    if verified:
        status='подтверждён'
        status_text='Текущий сигнал прошёл production-проверку и поддерживается сводной оценкой.'
    else:
        status='исследовательский'
        status_text='Это сводная оценка моделей; статистическое подтверждение production-уровня пока ограничено.'
    return {
        'p_up':round(p,4),'p_down':round(1-p,4),'label':direction_label,'strength_label':label,'direction':side,
        'confidence':conf,'confidence_score':round(confidence,3),
        'agreement':round(agreement,3),'reliability':round(rel,3),
        'model_count':len(comps),'models_up':up,'models_down':down,
        'status':status,'status_text':status_text,
        'summary':f"{why}. {up} из {len(comps)} оценок склоняются к росту; согласованность — {round(agreement*100)}%.",
    }


def enrich(data):
    import quality_contract_v4401011 as QUALITY
    for a in data.get('assets',[]):
        a['unified_forecast_v39']={h:QUALITY.forecast(build_horizon(a,h)) for h in HORIZONS}
    data['unified_forecast_version']='3.9'
    data['version']='3.9'
    return data


def main():
    data=json.loads(DATA.read_text(encoding='utf-8'))
    enrich(data)
    DATA.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    (ROOT/'site'/'data.js').write_text('window.FORECASTS = '+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
    print(f"OK: единый прогноз добавлен для {len(data.get('assets',[]))} активов")

if __name__=='__main__':
    main()
