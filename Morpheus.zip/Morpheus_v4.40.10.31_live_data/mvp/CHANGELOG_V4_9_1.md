# Morpheus v4.9.1 — SEC connectivity fix

Исправлена причина, из-за которой SEC EDGAR мог оставаться с `0 кв. в локальном индексе`
даже при корректно указанном e-mail.

## Что изменено

- SEC_USER_AGENT остаётся:
  `Morpheus Research crazycrazydancer27@gmail.com`
- клиент SEC переведён с urllib на `requests.Session`;
- gzip/deflate теперь декодируются автоматически;
- убран ручной `Host` header;
- добавлены retry/backoff для 403/429/5xx;
- частота снижена до 4 req/s;
- при ошибке `master.zip` используется fallback на `master.idx`;
- добавлен `/api/corpfin/sec-diagnostic`;
- UI теперь показывает реальную ошибку SEC вместо молчаливого `0`;
- при сетевой ошибке интерфейс прямо сообщает, что проблема не в e-mail.

SEC API key по-прежнему не требуется.
