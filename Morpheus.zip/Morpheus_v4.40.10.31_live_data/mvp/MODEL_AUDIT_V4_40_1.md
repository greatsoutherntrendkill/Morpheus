# MODEL AUDIT — v4.40.1 Persistent Evidence Store + Readiness Monitor

## Scope
Infrastructure/governance release. Directional probabilities, confidence thresholds, abstention logic and v4.40 quantile mathematics are intentionally unchanged.

## Persistent store
Default root: `~/AllAnalytics_Data/evidence/`.

- `directional_feedback.sqlite3`
- `distribution_feedback.sqlite3`

Overrides: `ALLANALYTICS_EVIDENCE_DIR`, `ALLANALYTICS_DATA_DIR`, plus backwards-compatible exact SQLite path variables.

The default path is outside the unpacked release directory, therefore a new Morpheus code version does not reset prospective evidence.

## Legacy migration
On startup, bounded discovery checks the current/sibling Morpheus release folders and optional `ALLANALYTICS_LEGACY_EVIDENCE_DIRS`.

Migration invariants:
- `forecast_key` uniqueness makes import idempotent;
- settlements are remapped by immutable forecast key, never by copying release-local integer ids;
- source fingerprint is persisted so unchanged legacy databases are not rescanned on every start;
- migration errors are diagnostic and cannot break live forecast serving.

## Distribution ledger schema v2
New point-in-time context columns:
- `asset_class`
- `regime`
- `event_active`
- `event_type`
- `event_actor`

These are frozen at forecast time. Future review must not reconstruct them from later/current market state.

## Readiness gates
Readiness measures evidence sufficiency, not whether the model is good.

Base minimum:
- >= 300 settled distribution forecasts;
- >= 40 unique forecast dates.

Mature horizon:
- >= 100 settled observations;
- >= 25 unique forecast dates.

Mature regime segment:
- >= 75 observations;
- >= 15 unique forecast dates;
- at least two mature non-unknown regimes for regime review.

Event review is independent:
- >= 30 event-window observations;
- >= 5 unique event forecast dates for at least one event type.

Bad interval coverage does not block review. It is surfaced as a quality flag because poor coverage is itself evidence that v4.41 should investigate calibration/tails.

## Governance invariant
The readiness monitor:
- does not fit a model;
- does not alter `p_up` / `p_down`;
- does not alter quantiles;
- does not change confidence thresholds;
- does not promote challengers;
- does not automatically trigger v4.41.
