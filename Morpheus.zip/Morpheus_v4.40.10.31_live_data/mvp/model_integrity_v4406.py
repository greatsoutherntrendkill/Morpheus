"""Morpheus v4.40.6 — Evidence Consistency + learned Move/No-Move integrity wrapper.

This is the single live source of truth for directional forecasts.  v4.40.6 keeps
the v4.40.4 statistical integrity fixes and adds:
* one shared target contract for training and prospective settlement;
* generation-isolated prospective evidence;
* explicit multiclass / move / conditional-direction scoring;
* learned P(material move | current features), replacing the historical neutral share;
* cache-generation metadata for stale-result invalidation.
"""
from __future__ import annotations

import distributional_forecast_v440 as BASE440
import target_contract_v4405 as TARGET4405
import forecast_contract_v4406 as CONTRACT4406

VERSION = "model-integrity-v4.40.6"
MODEL_GENERATION = CONTRACT4406.MODEL_GENERATION
VALIDATION_VERSION = "evidence-consistency-move-model-v4.40.6"
PROBABILITY_SEMANTICS_VERSION = CONTRACT4406.PROBABILITY_SEMANTICS_VERSION


def _ensemble_explanation(out: dict) -> dict:
    components=[]
    for row in out.get("components") or []:
        if not isinstance(row,dict):
            continue
        components.append({
            "name":row.get("name"),
            "p_up":row.get("p_up"),
            "conditional_p_up":row.get("conditional_p_up"),
            "p_move":row.get("p_move"),
            "p_neutral":row.get("p_neutral"),
            "weight":row.get("weight"),
            "validated":row.get("validated"),
        })
    return {
        "scope":"final_ensemble_component_decomposition",
        "directional_score_up":out.get("directional_score_up",out.get("p_up")),
        "conditional_p_up":out.get("conditional_p_up"),
        "p_move":out.get("p_move"),
        "class_probabilities":out.get("class_probabilities") or {},
        "p_neutral":out.get("p_neutral"),
        "abstain":bool(out.get("abstain")),
        "components":components,
        "feature_driver_scope":"direction and move/no-move are separate probability tasks; component decomposition explains the final ensemble",
    }


def forecast_horizon(close, symbol: str, horizon: int = 10, fast: bool = True, context: dict | None = None) -> dict:
    out=BASE440.forecast_horizon(close,symbol=symbol,horizon=int(horizon),fast=fast,context=context)
    if not out:
        return {}
    out=dict(out)
    lower=out.get("version")
    out["base_model_version"]=lower
    out["version"]=VERSION
    out["integrity_version"]=VERSION
    out["model_generation"]=MODEL_GENERATION
    out["target_version"]=TARGET4405.TARGET_VERSION
    out["probability_semantics_version"]=PROBABILITY_SEMANTICS_VERSION

    p_move=out.get("p_move")
    p_cond=out.get("conditional_p_up")
    try:
        p_move=max(.0,min(1.0,float(p_move)))
        p_cond=max(.0,min(1.0,float(p_cond)))
        classes={"up":p_move*p_cond,"neutral":1.0-p_move,"down":p_move*(1.0-p_cond)}
        total=sum(classes.values()) or 1.0
        classes={k:round(float(v/total),6) for k,v in classes.items()}
        out["class_probabilities"]=classes
        out["p_move"]=round(float(classes["up"]+classes["down"]),6)
        out["p_neutral"]=round(float(classes["neutral"]),6)
    except Exception:
        classes=out.get("class_probabilities") or {}

    # p_up / p_down stay as compatibility directional scores for old UI gates.
    out["directional_score_up"]=out.get("p_up")
    out["directional_score_down"]=out.get("p_down")
    out["probability_semantics"]=(
        "class_probabilities are normalized P(significant up / neutral / significant down); "
        "P(neutral)=1-P(material move) from a learned Move/No-Move model; conditional_p_up is P(up | material move); "
        "p_up/p_down remain backward-compatible neutral-aware directional scores"
    )
    out["calibrated_probability_scope"]="factorized: P(material move) × conditional P(direction | material move)"
    out["ensemble_explanation"]=_ensemble_explanation(out)
    validation=dict(out.get("validation") or {})
    validation.update({
        "integrity_version":VALIDATION_VERSION,
        "shared_target_contract":TARGET4405.VERSION,
        "shared_three_state_target":True,
        "normalized_three_state_probabilities":True,
        "legacy_directional_score_explicit":True,
        "neutral_never_coerced_to_down":True,
        "move_probability_modelled_from_current_features":True,
        "historical_neutral_share_not_primary_probability":True,
        "prospective_target_contract_matches_training":True,
        "prospective_multiclass_scoring":True,
        "prospective_conditional_direction_scoring":True,
        "prospective_generation_isolation":True,
        "cache_generation_validation":True,
        "meta_calibration_threshold_eval_separated":True,
        "deployment_calibration_matches_refit":True,
        "distribution_refit_after_untouched_audit":True,
        "dependence_aware_oos":True,
        "event_response_timestamp_aware":True,
        "single_live_source_of_truth":True,
    })
    out["validation"]=validation
    return out
