"""Morpheus v4.34 — context/event-aware meta forecast.

The v4.33 forecast remains the statistical core. v4.34 adds a low-weight
cross-sectional/event expert and a drift-aware confidence gate. Context cannot
promote itself to champion and cannot produce an extreme probability on its own.
"""
from __future__ import annotations

import math
import numpy as np
import pandas as pd

import meta_forecast_v433 as META433
import feature_event_v434 as FE434

VERSION = "meta-context-v4.34.0"
FEATURE_VERSION = FE434.VERSION


def _finite(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def forecast_horizon(close: pd.Series, symbol: str, horizon: int=10, fast: bool=True,
                     context: dict | None=None) -> dict:
    h=int(horizon)
    base=META433.forecast_horizon(close,horizon=h,fast=fast)
    p0=_finite((base or {}).get("p_up"))
    if p0 is None:
        return {}
    ctx=context or FE434.build_context(symbol,own_close=close,as_of=pd.Timestamp(close.index[-1]) if len(close) else None)
    adj=FE434.apply_context_probability(p0,ctx)
    p=float(adj["p_up"])

    base_threshold=_finite((base or {}).get("signal_threshold")) or .58
    threshold=float(np.clip(base_threshold+float(adj.get("threshold_delta") or 0.0),.54,.70))
    dir_prob=max(p,1-p)

    # Cross-sectional disagreement is informative, but it is never allowed to
    # overpower the validated v4.33 core.
    context_p=_finite(adj.get("context_p_up"))
    context_disagreement=bool(context_p is not None and (context_p>=.5)!=(p0>=.5) and abs(context_p-.5)>=.035)
    base_abstain=bool((base or {}).get("abstain"))
    evidence_ok=not base_abstain or dir_prob>=max(.70,threshold+.05)
    if context_disagreement and dir_prob < .72:
        evidence_ok=False
    abstain=bool(dir_prob<threshold or not evidence_ok)

    if dir_prob>=.72:strength="выраженный"
    elif dir_prob>=max(.64,threshold):strength="умеренный"
    elif dir_prob>=threshold:strength="слабый"
    else:strength="нет преимущества"
    if abstain:strength="нет преимущества"

    base_quality=(base or {}).get("quality") or {}
    trusted=bool(not abstain and base_quality.get("trusted") and float(ctx.get("drift_score") or 0)<.85 and not context_disagreement)
    market=ctx.get("market") or {}; event=ctx.get("event") or {}
    comps=list((base or {}).get("components") or [])
    comps.append({
        "name":"cross_sectional_context",
        "p_up":round(float(context_p if context_p is not None else .5),6),
        "weight":round(0.10+0.08*float(ctx.get("context_confidence") or 0),4),
        "trusted":False,
    })

    return {
        "version":VERSION,"feature_version":FEATURE_VERSION,"horizon":h,
        "p_up":round(p,6),"p_down":round(1-p,6),
        "abstain":abstain,"signal_strength":strength,"signal_threshold":round(threshold,3),
        "regime":(base or {}).get("regime"),
        "disagreement":bool((base or {}).get("disagreement")),
        "context_disagreement":context_disagreement,
        "quality":{
            "trusted":trusted,
            "confidence":"средняя" if trusted else "низкая",
            "bias":"neutral" if abstain else ("bullish" if p>=.5 else "bearish"),
            "reason":"нет достаточного преимущества" if abstain else ("контекст расходится с базовой моделью" if context_disagreement else "сигнал подтверждён базовой моделью и контекстом"),
        },
        "components":comps,
        "base_meta":base,
        "context_features":market,
        "event_context":event,
        "context_freshness":ctx.get("freshness") or (market.get("freshness") if isinstance(market,dict) else None) or {},
        "context_score":round(float(ctx.get("context_score") or 0),6),
        "context_p_up":round(float(context_p if context_p is not None else .5),6),
        "context_adjustment_pp":round(float(adj.get("signed_adjustment") or 0)*100,3),
        "event_risk":round(float(ctx.get("event_risk") or 0),4),
        "event_bias":round(float(ctx.get("event_bias") or 0),4),
        "feature_drift":market.get("feature_drift") or {},
        "scorecard":{
            **((base or {}).get("scorecard") or {}),
            "context_coverage":round(float(ctx.get("coverage") or 0),4),
            "context_confidence":round(float(ctx.get("context_confidence") or 0),4),
            "context_score":round(float(ctx.get("context_score") or 0),4),
            "event_risk":round(float(ctx.get("event_risk") or 0),4),
            "drift_score":round(float(ctx.get("drift_score") or 0),4),
        },
        "validation":{
            **((base or {}).get("validation") or {}),
            "context_layer":"research challenger",
            "cross_sectional_point_in_time":True,
            "event_layer_point_in_time":True,
            "feature_drift_gate":True,
            "automatic_promotion":False,
        },
    }
