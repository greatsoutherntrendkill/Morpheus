"""Morpheus v4.39 — event response models.

A conservative challenger for scheduled / just-released macro and corporate
catalysts.  It deliberately separates *event detection* from *directional
forecasting*:

* upcoming events raise risk but do not create a directional probability while
  the surprise is unknown;
* a directional event forecast is emitted only when the event surprise can be
  measured from structured values or explicit outcome wording;
* historical sensitivity is estimated only from events strictly before the
  forecast date and prices observed after those past events;
* the event expert receives zero production weight until paired prospective
  evidence passes the v4.39 guard and a human explicitly approves it.

The local event archive is cumulative: live/seed news and the calendar are
merged into a small JSON ledger so an event does not disappear when the news
cache rolls over.  No synthetic historical event dates are invented.
"""
from __future__ import annotations
from contextlib import closing
import data_contract_v4401013 as DATA13

import json
import math
import os
import re
import time
import sqlite3
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

import config as C
import feature_event_v434 as FE434
import asset_specialists_v438 as BASE438
import prospective_selection_v439 as SEL439
import persistent_state_v44010 as PSTATE44010

VERSION = "event-response-models-v4.40.10"
VALIDATION_VERSION = "timestamp-aware-event-sensitivity+persistent-archive+prospective-human-review-v4.40.10"
ROOT = Path(__file__).resolve().parent
ARCHIVE_PATH = ROOT / "runtime_cache" / "event_archive_v439.json"  # legacy migration source only
EVENT_DB_PATH = PSTATE44010.event_db_path()
CACHE_SECONDS = 120
_FORECAST_CACHE: dict[tuple, tuple[float, dict]] = {}


def _finite(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _clip_p(x, lo=.08, hi=.92):
    return float(np.clip(float(x), lo, hi))


def _norm_text(v):
    return str(v or "").lower().replace("ё","е")


def _event_date(row: dict) -> str:
    raw=row.get("published_at") or row.get("published") or row.get("date") or row.get("time") or ""
    try:
        return str(pd.Timestamp(raw).date())
    except Exception:
        return ""


def _event_timing(row: dict, meta: dict | None = None) -> dict:
    """Return timestamp/session timing without pretending daily bars are intraday.

    Explicit structured timing wins.  Otherwise family defaults are conservative:
    scheduled macro/CB releases use the previous close as the pre-event anchor;
    earnings default to after-close only when wording says so, else unknown.
    """
    meta=meta or classify_event(row)
    explicit=str(row.get("session_timing") or "").strip().lower()
    if explicit in {"pre_open","during_session","after_close","unknown"}:
        timing=explicit;source="structured"
    else:
        text=_norm_text(f"{row.get('title','')} {row.get('summary','')} {row.get('event','')}")
        if re.search(r"after[- ]?hours|after market|после закрытия",text):timing="after_close"
        elif re.search(r"pre[- ]?market|до открытия",text):timing="pre_open"
        elif meta.get("family") in {"central_bank","inflation"}:timing="during_session"
        else:timing="unknown"
        source="family_default" if timing!="unknown" else "unknown"
    raw_ts=row.get("event_time") or row.get("scheduled_at") or row.get("datetime") or row.get("time") or row.get("published_at") or row.get("published")
    ts=None
    if raw_ts:
        try:
            t=pd.Timestamp(raw_ts)
            if pd.notna(t):ts=t.isoformat()
        except Exception:pass
    return {"event_timestamp":ts,"session_timing":timing,"timing_source":source,
            "timezone":str(row.get("timezone") or "") or None}


def _actor(text: str) -> str | None:
    t=_norm_text(text)
    if re.search(r"\bфрс\b|\bfed\b|fomc|federal reserve",t): return "fed"
    if re.search(r"\bецб\b|\becb\b|european central bank|европейск.{0,20}централ",t): return "ecb"
    if re.search(r"банк россии|\bцб рф\b|ключев.{0,12}ставк",t): return "cbr"
    return None


def classify_event(row: dict, symbol: str | None=None) -> dict:
    """Return a stable event family without inferring an event that is not present."""
    raw=f"{row.get('title','')} {row.get('summary','')} {row.get('event','')} {row.get('cb','')}"
    t=_norm_text(raw)
    actor=_actor(raw)
    if actor and re.search(r"ставк|rate|meeting|решен|federal funds|deposit rate|ключев",t):
        return {"family":"central_bank","type":f"{actor}_rate","actor":actor}
    if re.search(r"\bcpi\b|инфляц|\bипц\b|consumer price|pce",t):
        region="us" if re.search(r"сша|\bus\b|america|cpi",t) else "eu" if re.search(r"еврозон|euro|ecb",t) else "ru" if re.search(r"росси|рубл",t) else "global"
        return {"family":"inflation","type":f"inflation_{region}","actor":region}
    if re.search(r"earnings|отчетност|результат.{0,18}(кварт|год)|выручк|прибыл",t):
        return {"family":"earnings","type":"earnings","actor":str(symbol or "").upper() or None}
    return {"family":None,"type":None,"actor":actor}


def _percent_values(text: str) -> list[float]:
    vals=[]
    for m in re.finditer(r"(?<!\d)(-?\d{1,3}(?:[\.,]\d+)?)\s*%",str(text or "")):
        try: vals.append(float(m.group(1).replace(',','.')))
        except Exception: pass
    return vals


def _bp_value(text: str) -> float | None:
    t=_norm_text(text)
    m=re.search(r"(?:на\s*)?(\d+(?:[\.,]\d+)?)\s*(?:б\.?\s*п\.?|bp|bps|basis point)",t)
    if not m:return None
    try:return float(m.group(1).replace(',','.'))
    except Exception:return None


def _expected_bp_from_calendar(date: str, actor: str | None, calendar: Iterable[dict] | None=None):
    if not date or not actor:return None
    rows=list(calendar) if calendar is not None else FE434._read_cb_calendar()
    for r in rows:
        if _event_date(r)!=date:continue
        meta=classify_event(r)
        if meta.get("actor")!=actor:continue
        v=_finite(r.get("expected_bp"))
        if v is not None:return v
    return None


def surprise_from_event(row: dict, *, calendar: Iterable[dict] | None=None) -> dict:
    """Parse event surprise using only explicit numbers / wording.

    score is standardized, not a market-direction prior:
      * central bank: (actual bp move - expected bp move) / 25;
      * inflation: (actual - forecast) / 0.20 percentage points;
      * earnings: explicit beat/miss wording or supplied surprise_pct.
    """
    meta=classify_event(row)
    family=meta.get("family");actor=meta.get("actor")
    text=f"{row.get('title','')} {row.get('summary','')} {row.get('event','')}"
    t=_norm_text(text); date=_event_date(row)
    if family=="central_bank":
        exp=_finite(row.get("expected_bp"))
        if exp is None: exp=_expected_bp_from_calendar(date,actor,calendar)
        actual=_finite(row.get("actual_bp"))
        if actual is None:
            bp=_bp_value(text)
            if re.search(r"сниз|пониз|опуст|cut|lowered|reduced",t): actual=-abs(bp) if bp is not None else None
            elif re.search(r"повыс|поднял|увелич|hike|raised|increased",t): actual=abs(bp) if bp is not None else None
            elif re.search(r"без измен|сохран|остав|unchanged|held|left",t): actual=0.0
        if actual is None or exp is None:
            return {"known":False,"family":family,"type":meta.get("type"),"actual":actual,"expected":exp,"score":None,"basis":"нет измеримого сюрприза"}
        score=float(np.clip((actual-exp)/25.0,-4,4))
        return {"known":True,"family":family,"type":meta.get("type"),"actual":actual,"expected":exp,"score":round(score,4),"basis":"изменение ставки против ожидания"}
    if family=="inflation":
        actual=_finite(row.get("actual")); forecast=_finite(row.get("forecast"))
        if actual is None or forecast is None:
            vals=_percent_values(text)
            # Only use text numbers if wording explicitly identifies forecast/expectation.
            if len(vals)>=2 and re.search(r"прогноз|ожидан|forecast|expected|consensus",t):
                actual,forecast=vals[0],vals[1]
        if actual is None or forecast is None:
            return {"known":False,"family":family,"type":meta.get("type"),"actual":actual,"expected":forecast,"score":None,"basis":"нет пары факт/прогноз"}
        score=float(np.clip((actual-forecast)/.20,-4,4))
        return {"known":True,"family":family,"type":meta.get("type"),"actual":actual,"expected":forecast,"score":round(score,4),"basis":"инфляция факт минус консенсус"}
    if family=="earnings":
        sp=_finite(row.get("surprise_pct"))
        if sp is not None:
            score=float(np.clip(sp/5.0,-4,4));known=True;basis="earnings surprise %"
        elif re.search(r"выше ожид|лучше ожид|beat(?:s| expectations)?|above consensus",t):
            score=1.0;known=True;basis="явный earnings beat"
        elif re.search(r"ниже ожид|хуже ожид|miss(?:ed|es)?|below consensus",t):
            score=-1.0;known=True;basis="явный earnings miss"
        else:
            score=None;known=False;basis="нет измеримого earnings surprise"
        return {"known":known,"family":family,"type":meta.get("type"),"actual":sp,"expected":None,"score":score,"basis":basis}
    return {"known":False,"family":family,"type":meta.get("type"),"actual":None,"expected":None,"score":None,"basis":"тип события не поддержан"}


def _source_rows() -> list[dict]:
    rows=[]
    try: rows.extend(FE434._read_seed_news())
    except Exception: pass
    try: rows.extend(FE434._read_cb_calendar())
    except Exception: pass
    return rows


def _event_connect():
    EVENT_DB_PATH.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(EVENT_DB_PATH,timeout=6)
    con.row_factory=sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("CREATE TABLE IF NOT EXISTS events (event_key TEXT PRIMARY KEY, event_date TEXT, event_type TEXT, actor TEXT, payload_json TEXT NOT NULL, updated_at TEXT NOT NULL)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_events_date_type ON events(event_date,event_type)")
    return con

def _migrate_legacy_archive_once():
    try:
        with closing(_event_connect()) as con, con:
            n=int(con.execute("SELECT COUNT(*) FROM events").fetchone()[0])
            if n>0 or not ARCHIVE_PATH.exists():return 0
            j=json.loads(ARCHIVE_PATH.read_text(encoding="utf-8")); rows=list(j.get("events") or [])
            c=0
            for row in rows:
                key=_event_key(row)
                con.execute("INSERT OR IGNORE INTO events(event_key,event_date,event_type,actor,payload_json,updated_at) VALUES(?,?,?,?,?,?)",
                            (key,str(row.get("date") or ""),str(row.get("type") or ""),str(row.get("actor") or ""),json.dumps(row,ensure_ascii=False,sort_keys=True),pd.Timestamp.utcnow().isoformat()))
                c+=1
            con.commit();return c
    except Exception:return 0

def _load_archive() -> list[dict]:
    _migrate_legacy_archive_once()
    try:
        with closing(_event_connect()) as con, con:
            out=[]
            for r in con.execute("SELECT payload_json FROM events ORDER BY event_date,event_type").fetchall():
                try:out.append(json.loads(r[0]))
                except Exception:pass
            return out
    except Exception:
        return []


def _event_key(row: dict) -> str:
    return "|".join([str(row.get("date") or ""),str(row.get("type") or ""),str(row.get("actor") or ""),str(row.get("title") or row.get("event") or "")[:90]])


def sync_event_archive(extra_rows: Iterable[dict] | None=None, *, persist: bool=True) -> list[dict]:
    """Merge only observed local event rows; never fabricate past event dates."""
    old=_load_archive(); merged={_event_key(x):dict(x) for x in old if x.get("date") and x.get("type")}
    all_rows=_source_rows()+list(extra_rows or [])
    calendar=[]
    try:calendar=FE434._read_cb_calendar()
    except Exception:pass
    for raw in all_rows:
        meta=classify_event(raw)
        if not meta.get("family"):continue
        date=_event_date(raw)
        if not date:continue
        sp=surprise_from_event(raw,calendar=calendar)
        timing=_event_timing(raw,meta)
        row={
            "date":date,"family":meta.get("family"),"type":meta.get("type"),"actor":meta.get("actor"),
            "title":str(raw.get("title") or raw.get("event") or raw.get("cb") or meta.get("type"))[:220],
            "source":str(raw.get("source") or raw.get("provider") or "local structured source")[:120],
            "surprise_known":bool(sp.get("known")),"surprise_score":sp.get("score"),"surprise_basis":sp.get("basis"),
            "actual":sp.get("actual"),"expected":sp.get("expected"),
            "affected":raw.get("affected") or [],**timing,
        }
        key=_event_key(row);prev=merged.get(key)
        # Later explicit outcome can enrich an event that was initially only scheduled.
        if prev:
            if row.get("surprise_known") and not prev.get("surprise_known"):prev.update(row)
            elif not prev.get("title") and row.get("title"):prev.update(row)
        else:merged[key]=row
    events=sorted(merged.values(),key=lambda x:(x.get("date") or "",x.get("type") or ""))
    if persist and not os.getenv("PYTEST_CURRENT_TEST"):
        try:
            with closing(_event_connect()) as con, con:
                now=pd.Timestamp.utcnow().isoformat()
                for row in events:
                    key=_event_key(row)
                    con.execute("INSERT INTO events(event_key,event_date,event_type,actor,payload_json,updated_at) VALUES(?,?,?,?,?,?) "
                                "ON CONFLICT(event_key) DO UPDATE SET event_date=excluded.event_date,event_type=excluded.event_type,actor=excluded.actor,payload_json=excluded.payload_json,updated_at=excluded.updated_at",
                                (key,str(row.get("date") or ""),str(row.get("type") or ""),str(row.get("actor") or ""),json.dumps(row,ensure_ascii=False,sort_keys=True),now))
                con.commit()
        except Exception:pass
    return events


def _series(close) -> pd.Series:
    x=pd.Series(close,dtype=float).dropna().sort_index()
    try:x.index=pd.to_datetime(x.index).tz_localize(None)
    except Exception:
        try:x.index=pd.to_datetime(x.index)
        except Exception:pass
    return x[~x.index.duplicated(keep="last")]


def _response_after(close: pd.Series, event, horizon: int):
    """Daily-bar event response with an explicit pre-event anchor policy.

    For pre-open/during-session events, entry is the previous trading close and
    h=1 targets the event-day close.  For after-close events, entry is the event
    day's close and h=1 targets the next trading close.  Unknown legacy strings
    keep the old same-day-close behavior for backward compatibility.
    """
    x=_series(close)
    if x.empty:return None
    if isinstance(event,dict):
        date=str(event.get("date") or "");timing=str(event.get("session_timing") or "unknown")
    else:
        date=str(event or "");timing="legacy_unknown"
    try:d=pd.Timestamp(date).normalize()
    except Exception:return None
    h=max(1,int(horizon))
    if timing in {"pre_open","during_session"}:
        before=x[x.index<d];post=x[x.index>=d]
        if before.empty or len(post)<h:return None
        entry=float(before.iloc[-1]);target=float(post.iloc[h-1]);entry_date=before.index[-1];target_date=post.index[h-1]
        anchor="previous_close_pre_event"
    else:
        before=x[x.index<=d];after=x[x.index>d]
        if before.empty or len(after)<h:return None
        entry=float(before.iloc[-1]);target=float(after.iloc[h-1]);entry_date=before.index[-1];target_date=after.index[h-1]
        anchor="event_day_close_before_after_close_release" if timing=="after_close" else "legacy_same_day_close"
    if not entry:return None
    return {"entry_date":str(entry_date.date()),"target_date":str(target_date.date()),"return_pct":(target/entry-1)*100.0,
            "session_timing":timing,"entry_anchor":anchor}


def _relevant_to_symbol(event: dict, symbol: str, profile: FE434.AssetProfile) -> float:
    # Preserve direct affected-symbol links before falling back to the shared regional rules.
    s=str(symbol).upper(); affected=event.get("affected") or []
    if isinstance(affected,list):
        for x in affected:
            if isinstance(x,dict) and str(x.get("symbol") or "").upper()==s:return 1.0
            if isinstance(x,str) and x.upper()==s:return 1.0
    elif isinstance(affected,str):
        if s in {z.strip().upper() for z in affected.replace(",","|").split("|") if z.strip()}:return 1.0
    # Reuse the existing point-in-time relevance rules with a normalized event row.
    row={"title":event.get("title"),"summary":"","event":event.get("title"),"cb":event.get("actor"),"affected":affected}
    try:return float(FE434._symbol_relevance(s,profile,row))
    except Exception:return 0.0


def historical_event_responses(close: pd.Series, symbol: str, event_type: str, horizon: int, *, as_of=None, events: Iterable[dict] | None=None) -> dict:
    x=_series(close); profile=FE434.asset_profile(symbol)
    if x.empty:return {"n":0,"rows":[],"event_type":event_type,"horizon":int(horizon)}
    cutoff=pd.Timestamp(as_of or x.index[-1]).normalize()
    x=x[x.index<cutoff]  # exclude unfinished/current and future target prices
    rows=[]
    for e in list(events) if events is not None else sync_event_archive(persist=False):
        if e.get("type")!=event_type or not e.get("surprise_known"):continue
        try:dt=pd.Timestamp(e.get("date")).normalize()
        except Exception:continue
        if dt>=cutoff:continue  # strict point-in-time: current/future event never trains itself
        rel=_relevant_to_symbol(e,symbol,profile)
        if rel<.35:continue
        sp=_finite(e.get("surprise_score"))
        if sp is None or abs(sp)<1e-9:continue
        resp=_response_after(x,e,int(horizon))
        if not resp:continue
        rows.append({**resp,"date":str(dt.date()),"surprise":sp,"relevance":round(rel,3),"signed_response":float(resp["return_pct"])*float(sp)})
    if not rows:return {"n":0,"rows":[],"event_type":event_type,"horizon":int(horizon)}
    a=np.asarray([r["surprise"] for r in rows],float); y=np.asarray([r["return_pct"] for r in rows],float)
    denom=float(np.sum(a*a)); slope=float(np.sum(a*y)/denom) if denom>1e-9 else 0.0
    aligned=np.sign(a*y);wins=int(np.sum(aligned>0));losses=int(np.sum(aligned<0));n=len(rows)
    consistency=(wins+2)/(wins+losses+4) if wins+losses else .5
    med=float(np.median(np.abs(y))) if len(y) else 0.0
    return {"n":n,"rows":rows[-30:],"event_type":event_type,"horizon":int(horizon),"sensitivity_pct_per_surprise":round(slope,4),
            "directional_consistency":round(float(consistency),4),"wins":wins,"losses":losses,"median_abs_move_pct":round(med,4)}


def _current_event(symbol: str, as_of, events: list[dict]) -> dict | None:
    profile=FE434.asset_profile(symbol); now=pd.Timestamp(as_of).normalize()
    candidates=[]
    for e in events:
        try:dt=pd.Timestamp(e.get("date")).normalize()
        except Exception:continue
        days=int((dt-now).days)
        if days < -2 or days > 7:continue
        rel=_relevant_to_symbol(e,symbol,profile)
        if rel<.35:continue
        # Resolved event in the last two sessions is more informative than a future event.
        resolved=bool(e.get("surprise_known")) and days<=0
        proximity=1.0 if abs(days)<=1 else .78 if abs(days)<=3 else .50
        score=rel*proximity+(0.45 if resolved else 0)
        candidates.append((score,{**e,"days":days,"relevance":round(rel,3)}))
    return max(candidates,key=lambda z:z[0])[1] if candidates else None


def event_response_forecast(close: pd.Series, symbol: str, horizon: int, *, as_of=None, events: Iterable[dict] | None=None) -> dict:
    x=_series(close);h=int(horizon)
    if x.empty:return {"version":VERSION,"status":"no_history","symbol":str(symbol).upper(),"horizon":h,"p_up":None}
    now=pd.Timestamp(as_of or x.index[-1]).normalize()
    archive=sync_event_archive(events,persist=events is None)
    current=_current_event(str(symbol).upper(),now,archive)
    if not current:
        return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"no_near_event","symbol":str(symbol).upper(),"horizon":h,
                "p_up":None,"reason":"рядом с датой прогноза нет поддерживаемого события ФРС/ЕЦБ/ЦБ РФ, инфляции или earnings"}
    if not current.get("surprise_known"):
        return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"awaiting_surprise","symbol":str(symbol).upper(),"horizon":h,
                "event":current,"p_up":None,"event_risk":min(1.0,.55+.06*max(0,7-abs(int(current.get('days') or 0)))),
                "reason":"событие близко, но фактический сюрприз ещё неизвестен; модель не придумывает направление заранее"}
    hist=historical_event_responses(x,str(symbol).upper(),str(current.get("type")),h,as_of=now,events=archive)
    n=int(hist.get("n") or 0); sp=float(current.get("surprise_score") or 0)
    if abs(sp)<1e-9:
        return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"neutral_surprise","symbol":str(symbol).upper(),"horizon":h,"event":current,
                "historical_sensitivity":hist,"p_up":.5,"quality_ok":False,"reason":"факт совпал с ожиданием; отдельного направленного event-edge нет"}
    if n<6:
        return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"insufficient_event_history","symbol":str(symbol).upper(),"horizon":h,"event":current,
                "historical_sensitivity":hist,"p_up":None,"quality_ok":False,"reason":"для этого типа события пока недостаточно прошлых наблюдений; нужно минимум 6"}
    slope=float(hist.get("sensitivity_pct_per_surprise") or 0);cons=float(hist.get("directional_consistency") or .5)
    expected=slope*sp; direction=1 if expected>=0 else -1
    sample_factor=float(np.clip((n-4)/16,0.12,1.0));cons_edge=max(0.0,abs(cons-.5)*2)
    magnitude_factor=float(np.clip(abs(expected)/(max(.25,float(hist.get('median_abs_move_pct') or .6))),0,1))
    confidence=float(np.clip(.18+.50*cons_edge+.20*sample_factor+.12*magnitude_factor,.18,.82))*sample_factor
    p_correct=.5+(.5*max(0,cons-.5)*2)*confidence
    p_correct=float(np.clip(p_correct,.51,.78))
    p_up=p_correct if direction>0 else 1-p_correct
    p_up=_clip_p(.5+(p_up-.5)*min(1.0,.45+.55*sample_factor),.18,.82)
    quality_ok=bool(n>=8 and cons>=.56 and abs(expected)>=.10)
    return {"version":VERSION,"validation_version":VALIDATION_VERSION,"status":"ok","symbol":str(symbol).upper(),"horizon":h,
            "event":current,"p_up":round(p_up,6),"p_down":round(1-p_up,6),"expected_event_move_pct":round(expected,4),
            "historical_sensitivity":hist,"event_sample_n":n,"quality_ok":quality_ok,"max_live_weight":.10,
            "confidence":round(confidence,4),"reason":"empirical response to the same measured event type; no hand-coded market-direction prior",
            "automatic_promotion":False}


def forecast_horizon(close: pd.Series, symbol: str, horizon: int=10, fast: bool=True, context: dict | None=None) -> dict:
    base=BASE438.forecast_horizon(close,symbol=symbol,horizon=int(horizon),fast=fast,context=context)
    if not base or base.get("p_up") is None:return base or {}
    h=int(horizon); x=_series(close)
    cache_key=(str(symbol).upper(),h,DATA13.series_hash(x),DATA13.dependency_fingerprint())
    cached=_FORECAST_CACHE.get(cache_key)
    if cached and time.time()-cached[0]<CACHE_SECONDS:
        event=dict(cached[1])
    else:
        event=event_response_forecast(x,str(symbol).upper(),h,as_of=x.index[-1] if len(x) else None)
        _FORECAST_CACHE[cache_key]=(time.time(),dict(event))
    ep=_finite(event.get("p_up"));components=list(base.get("components") or [])
    # Event-response estimates direction conditional on the event move.  Blend it
    # with the core on the same conditional scale, then re-apply the core neutral
    # mass; never mix a conditional event probability with a neutral-aware score.
    base_neutral=_finite(base.get("p_neutral"));base_neutral=float(np.clip(base_neutral if base_neutral is not None else .20,.02,.85))
    base_move=max(1e-6,1.0-base_neutral)
    base_cond=_finite(base.get("conditional_p_up"))
    if base_cond is None:
        base_cond=_clip_p(.5+(float(base.get("p_up"))-.5)/base_move,.02,.98)
    components.append({"name":"event_response","p_up":None if ep is None else round(.5+base_move*(ep-.5),6),
                       "conditional_p_up":None if ep is None else round(ep,6),"p_move":round(base_move,6),"p_neutral":round(base_neutral,6),
                       "weight":0.0,"validated":False,
                       "event_type":((event.get("event") or {}).get("type")),"sample_n":event.get("event_sample_n"),"quality_ok":bool(event.get("quality_ok"))})
    try:
        gate=SEL439.event_gate(str(symbol).upper(),h,max_live_weight=float(event.get("max_live_weight") or .10))
    except Exception as exc:
        gate={"version":SEL439.VERSION,"eligible":False,"human_approved":False,"active":False,"weight":0.0,"reason":f"event guard unavailable: {type(exc).__name__}"}
    weight=float(gate.get("weight") or 0.0) if event.get("quality_ok") and ep is not None else 0.0
    p_base=float(base["p_up"]);p_cond_final=float(base_cond);event_disagreement=abs(ep-p_cond_final) if ep is not None else 0.0
    threshold=float(base.get("signal_threshold") or .58)
    if weight>0 and ep is not None:
        p_cond_final=_clip_p((1-weight)*p_cond_final+weight*ep,.02,.98)
        if event_disagreement>=.16:
            p_cond_final=.5+.84*(p_cond_final-.5)
            threshold=min(.78,threshold+.01)
        p_final=float(np.clip(.5+base_move*(p_cond_final-.5),.02,.98))
        dir_prob=max(p_final,1-p_final);abstain=bool(dir_prob<threshold)
        strength="нет преимущества" if abstain else "выраженный" if dir_prob>=.72 else "умеренный" if dir_prob>=max(.64,threshold) else "слабый"
    else:
        # Absolute diagnostic-only invariant: unresolved/unapproved event models
        # cannot change probability, threshold, abstention or signal strength.
        p_final=p_base
        p_cond_final=float(base_cond)
        threshold=float(base.get("signal_threshold") or threshold)
        abstain=bool(base.get("abstain"))
        strength=str(base.get("signal_strength") or ("нет преимущества" if abstain else "слабый"))
    components[-1]["weight"]=round(weight,4);components[-1]["validated"]=bool(gate.get("active"))

    out=dict(base)
    out.update({"version":VERSION if weight>0 else (base.get("version") or VERSION),"model_version":VERSION if weight>0 else (base.get("model_version") or base.get("version") or VERSION),
                "event_response_version":VERSION,"p_up":round(p_final,6),"p_down":round(1-p_final,6),
                "conditional_p_up":round(p_cond_final,6),"p_neutral":round(base_neutral,6),"p_move":round(base_move,6),
                "class_probabilities":(dict(base.get("class_probabilities") or {}) if weight<=0 else {"up":round(base_move*p_cond_final,6),"neutral":round(base_neutral,6),"down":round(base_move*(1-p_cond_final),6)}),
                "components":components,"abstain":abstain,
                "signal_strength":strength,"signal_threshold":round(threshold,3),"event_response":event,"event_gate":gate,
                "event_weight_status":"prospective_validated_human_approved" if gate.get("active") else "challenger_only_pending_guard",
                "validation":{**(base.get("validation") or {}),"event_response_model":True,"event_response_point_in_time":True,"event_response_timestamp_aware":True,"event_response_pre_event_anchor":True,
                              "event_response_prospective_validated":bool(gate.get("eligible")),"event_response_human_approved":bool(gate.get("human_approved")),
                              "automatic_promotion":False,"event_response_validation_version":VALIDATION_VERSION}})
    score=dict(out.get("scorecard") or {})
    score.update({"event_response_type":((event.get("event") or {}).get("type")),"event_response_sample_n":event.get("event_sample_n"),
                  "event_response_expected_move_pct":event.get("expected_event_move_pct"),"event_response_live_weight":round(weight,4)})
    out["scorecard"]=score
    return out
