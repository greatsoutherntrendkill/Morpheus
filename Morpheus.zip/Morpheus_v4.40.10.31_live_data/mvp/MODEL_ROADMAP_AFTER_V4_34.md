# Model Quality roadmap после v4.34

## v4.35 — Dynamic Ensemble & Meta-Learning

- OOS-performance-weighted веса моделей по regime / asset class / horizon;
- reliability meta-model: отдельная модель предсказывает, насколько текущему прогнозу можно доверять;
- signal threshold определяется из development OOS, а не статическими числами;
- calibration отдельно по горизонту и режиму;
- context-feature expert получает вес только там, где его исторический / prospective результат это подтверждает;
- disagreement-aware routing между champion, regime model, cross-sectional context и event model.

## v4.36 — Prospective Feedback Loop

- immutable prediction ledger для всех новых forecast layers;
- автоматическое settlement прогнозов после истечения горизонта;
- error attribution по активу, горизонту, режиму, event type и feature drift;
- rolling model leaderboard;
- controlled promotion review без автоматической замены champion.

После v4.36 Model Quality roadmap можно соединить с Scenario Intelligence roadmap: Historical Analog Engine, Quant Scenario Model и LLM interpretation layer.
