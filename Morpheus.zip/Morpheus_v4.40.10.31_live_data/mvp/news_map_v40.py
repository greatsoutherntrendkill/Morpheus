"""Morpheus v4.0 — география новостей с разнесением точек внутри региона.

Каждая новость получает собственную координату. Новости из одной страны/региона
раскладываются по небольшой детерминированной спирали вокруг базовой точки,
поэтому маркеры остаются рядом географически, но не перекрывают друг друга.
"""
from __future__ import annotations
import math, re, hashlib


COUNTRY_RULES=[
    (r'герман|берлин|germany', 'Germany'),
    (r'франц|париж|france', 'France'),
    (r'великобрит|британ|лондон|bank of england|united kingdom|\\buk\\b', 'United Kingdom'),
    (r'итал|рим|italy', 'Italy'),
    (r'испан|мадрид|spain', 'Spain'),
    (r'нидерланд|амстердам|netherlands', 'Netherlands'),
    (r'бельги|брюссел|belgium', 'Belgium'),
    (r'польш|варшав|poland', 'Poland'),
    (r'украин|киев|kyiv|ukraine', 'Ukraine'),
    (r'росси|\\bрф\\b|москв|russia', 'Russia'),
    (r'сша|америк|вашингтон|united states|\\busa\\b', 'United States of America'),
    (r'китай|пекин|china', 'China'),
    (r'япони|токио|japan', 'Japan'),
    (r'индия|дели|india', 'India'),
    (r'сауд|riyadh|saudi', 'Saudi Arabia'),
    (r'иран|тегеран|iran', 'Iran'),
    (r'израил|тель-авив|israel', 'Israel'),
    (r'турц|анкар|turkey', 'Turkey'),
    (r'бразил|brazil', 'Brazil'),
    (r'австрал|australia', 'Australia'),
    (r'канад|canada', 'Canada'),
]

REGION_HIGHLIGHT={
    'США':['United States of America'],
    'Россия':['Russia'],
    'Китай':['China'],
    'Япония':['Japan'],
    'Индия':['India'],
    'Великобритания':['United Kingdom'],
    'Ближний Восток':['Saudi Arabia','Iran','Israel'],
    'Бразилия':['Brazil'],
    'Австралия':['Australia'],
    'Канада':['Canada'],
    'Европа':['Germany','France','Italy','Spain','Belgium','Netherlands','Poland','Austria'],
}

RULES=[
    (r'фрс|fomc|сша|америк|вашингтон|treasury|доллар|nasdaq|s&p|wall street', 'США', -98.5, 38.5),
    (r'евросоюз|\bес\b|европа|ецб|герман|франц|брюссел|санкц|eurozone', 'Европа', 10.5, 50.5),
    (r'росси|\bрф\b|цб рф|москв|рубл|мосбирж|офз', 'Россия', 37.6, 55.8),
    (r'китай|пекин|народн.*банк кит|юан|china', 'Китай', 116.4, 39.9),
    (r'япони|токио|банк японии|иен|japan', 'Япония', 139.7, 35.7),
    (r'индия|дели|рупи|india', 'Индия', 77.2, 28.6),
    (r'великобрит|лондон|банк англии|фунт|britain|uk ', 'Великобритания', -0.1, 51.5),
    (r'опек|сауд|ближн|ирак|иран|нефт|brent|wti|middle east', 'Ближний Восток', 46.7, 24.7),
    (r'бразил|бразилиа|реал|brazil', 'Бразилия', -47.9, -15.8),
    (r'австрал|сидней|резервн.*банк австрал|australia', 'Австралия', 151.2, -33.9),
    (r'канада|оттава|канад|canada', 'Канада', -106.3, 56.1),
]

def _cyryl(s):
    return bool(re.search(r'[А-Яа-яЁё]', str(s or '')))

def locate(row:dict)->dict:
    text=' '.join(str(row.get(k,'') or '') for k in ('title','summary','source')).lower()
    region='Глобально'; lon=0.0; lat=12.0
    for pat,name,x,y in RULES:
        if re.search(pat,text,re.I): region=name; lon=x; lat=y; break
    if region=='Глобально':
        aff=' '.join(str(x.get('symbol','')) for x in (row.get('affected') or []))
        if any(s in aff for s in ('IMOEX','RGBI','RUB=X')): region,lon,lat='Россия',37.6,55.8
        elif any(s in aff for s in ('^GSPC','^NDX','^DJI','DX-Y.NYB')): region,lon,lat='США',-98.5,38.5
        elif any(s in aff for s in ('CL=F','BZ=F')): region,lon,lat='Ближний Восток',46.7,24.7
    country=None
    for pat,name in COUNTRY_RULES:
        if re.search(pat,text,re.I):
            country=name
            break
    highlight=[country] if country else list(REGION_HIGHLIGHT.get(region,[]))
    impact=int(row.get('impact_score') or row.get('relevance_score') or 0)
    return {**row,'map_region':region,'map_country':country,'map_highlight':highlight,
            'map_base_lon':lon,'map_base_lat':lat,'map_lon':lon,'map_lat':lat,
            'map_impact':max(1,min(100,impact)),'russian_text':_cyryl(row.get('title'))}

def _jitter(rows):
    groups={}
    for r in rows: groups.setdefault(r['map_region'],[]).append(r)
    out=[]
    golden=2.399963229728653
    for region,items in groups.items():
        # Stable order: changing API order does not make all dots jump.
        items=sorted(items,key=lambda r:hashlib.sha1((str(r.get('title',''))+str(r.get('published',''))).encode('utf-8')).hexdigest())
        for i,r in enumerate(items):
            if len(items)==1:
                out.append(r); continue
            ring=1.15+0.72*math.sqrt(i+1)
            angle=i*golden
            lat0=float(r['map_base_lat']); lon0=float(r['map_base_lon'])
            lat=lat0+math.sin(angle)*ring
            lon_scale=max(.38,math.cos(math.radians(lat0)))
            lon=lon0+math.cos(angle)*ring/lon_scale
            out.append({**r,'map_lon':round(lon,4),'map_lat':round(lat,4),'map_cluster_index':i+1,'map_cluster_size':len(items)})
    return out

def enrich(rows):
    # Не фильтруем новости по языку: карта показывает весь поток. Интерфейс
    # ожидает русские title/summary из новостного слоя, но иностранная строка
    # не должна исчезать с карты из-за технической проверки кириллицы.
    return _jitter([locate(r) for r in (rows or [])])
